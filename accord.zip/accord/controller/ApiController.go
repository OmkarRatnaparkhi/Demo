package controller

import (
	"accorddata/helper"
	"accorddata/service"
	"bytes"
	"fmt"
	"io"
	"log"
	"net"
	"net/http"
	"strings"

	"github.com/gin-gonic/gin"
)

func TestIP(c *gin.Context) {
	_, err := http.Get("https://nuuu.com/accord/getip")
	if err != nil {
		log.Fatalln(err)
	}
}

func GetIP(c *gin.Context) {
	fmt.Println("RemoteIP = " + c.Request.Host)
	var userIP string
	if len(c.GetHeader("CF-Connecting-IP")) > 1 {
		userIP = c.GetHeader("CF-Connecting-IP")
		fmt.Println(net.ParseIP(userIP))
	} else if len(c.GetHeader("X-Forwarded-For")) > 1 {
		userIP = c.GetHeader("X-Forwarded-For")
		fmt.Println(net.ParseIP(userIP))
	} else if len(c.GetHeader("X-Real-IP")) > 1 {
		userIP = c.GetHeader("X-Real-IP")
		fmt.Println(net.ParseIP(userIP))
	} else {
		userIP = c.Request.RemoteAddr
		if strings.Contains(userIP, ":") {
			fmt.Println(net.ParseIP(strings.Split(userIP, ":")[0]))
		} else {
			fmt.Println(net.ParseIP(userIP))
		}
	}
}

func Upload(c *gin.Context) {
	var buffer bytes.Buffer
	file, header, err := c.Request.FormFile("file")
	if err != nil {
		c.String(http.StatusBadRequest, fmt.Sprintf("file err : %s", err.Error()))
		return
	}
	filename := header.Filename
	filename = strings.Replace(filename, ".txt", "", 1)
	filename = strings.ToLower(filename)

	fmt.Println(filename)
	readbyte, err := io.ReadAll(file)
	if err != nil {
		fmt.Println(err)
	}
	strjson, err := helper.ParseDataByte(readbyte)
	// fmt.Println(strjson)
	if err != nil {
		fmt.Println(err)
		//return err
	}
	//fmt.Println(string(readbyte))

	service.FunctionMap[filename].(func([]byte, *bytes.Buffer) error)(strjson, &buffer)

	c.JSON(http.StatusOK, "")
}

func ApiController(c *gin.Context) {
	datetime := c.Query("date")
	name := c.Param("name")
	var buffer bytes.Buffer
	strjson, err := service.FetchdataFromAccord(datetime, name, buffer)
	if err != nil {
		fmt.Println(err)
		c.JSON(http.StatusBadRequest, "Error ParseData")
		return
	}
	// strjson, err := ioutil.ReadFile("C:\\data\\data.txt") // just pass the file name
	// if err != nil {
	// 	fmt.Print(err)
	// 	c.JSON(http.StatusBadGateway, "")
	// 	return
	// }

	// var arryJson []interface{}
	// if err := json.Unmarshal(strjson, &arryJson); err != nil {
	// 	fmt.Print(err)
	// 	c.JSON(http.StatusBadGateway, "")
	// 	return
	// }

	name = strings.ToLower(name)
	service.FunctionMap[name].(func([]byte, *bytes.Buffer) error)(strjson, &buffer)
	c.JSON(http.StatusOK, string(strjson))
}
