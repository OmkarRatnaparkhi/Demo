package controller

import (
	"accorddata/service"
	"net/http"

	"github.com/gin-gonic/gin"
)

func DownloadDRHPDownload(c *gin.Context) {
	symbol := c.Param("symbol")
	if symbol == "" {
		c.JSON(http.StatusBadRequest, "")
		return
	}

	bytedownload, err := service.DownloadDRHPDownload(symbol, "Draft_Prospectus")
	if err != nil {
		c.JSON(http.StatusBadRequest, err.Error())
		return
	}
	if bytedownload == nil {
		c.JSON(http.StatusBadRequest, "empty file")
		return
	}
	//encodedText := base64.StdEncoding.EncodeToString(bytedownload)
	c.Data(200, "application/pdf", bytedownload)

}
