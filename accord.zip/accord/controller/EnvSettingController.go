package controller

import (
	"accorddata/service"
	"net/http"

	"github.com/TecXLab/libdb/settingservice"
	"github.com/TecXLab/libhttp"
	"github.com/gin-gonic/gin"
)

func EnvSettingController(c *gin.Context) {
	libhttp.CoreHeader(c)
	var EnvSettingModel []settingservice.Tbl_SettingService
	if err := c.BindJSON(&EnvSettingModel); err != nil {
		service.Zerologs.Error().Err(err).Msgf("EnvSettingController(): Error in BindJSON is %s", err.Error())
		c.JSON(http.StatusBadRequest, err)
		return
	}
	err := service.EnvSettingService(EnvSettingModel)
	if err != nil {
		service.Zerologs.Error().Err(err).Msgf("EnvSettingController(): Error in EnvSettingService is %s", err.Error())
		c.JSON(http.StatusInternalServerError, err)
		return
	}
	c.JSON(http.StatusOK, "Success")
}
