package controller

import (
	"accorddata/model"
	"accorddata/service"
	"fmt"
	"net/http"

	"github.com/gin-gonic/gin"
)

func SearchController(c *gin.Context) {
	filterquery := c.Query("data")
	strjson, err := service.FetchSearchData(filterquery)
	if err != nil {
		fmt.Println(err)
		c.JSON(http.StatusBadRequest, "Error ParseData")
		return
	}
	c.JSON(http.StatusOK, string(strjson))
}

func GetStockInfo(c *gin.Context) {
	stockname := c.Param("stockname")
	if stockname == "" {
		c.JSON(http.StatusBadRequest, "")
		return
	}
	compdetail := model.CompanyDetailModel{}
	err := service.GetStockInfo(&compdetail, stockname)
	if err != nil {
		c.JSON(http.StatusBadRequest, "")
		return
	}
	compdetail.URLPATH = stockname
	// bytestr, err := json.MarshalIndent(compdetail)
	// if err != nil {
	// 	c.JSON(http.StatusBadRequest, "")
	// }
	c.JSON(http.StatusOK, compdetail)
}

func GetIPOInfo(c *gin.Context) {

	arr, err := service.IPOReader()
	if err != nil {
		c.JSON(http.StatusBadRequest, "")
		return
	}
	// bytestr, err := json.MarshalIndent(compdetail)
	// if err != nil {
	// 	c.JSON(http.StatusBadRequest, "")
	// }
	c.JSON(http.StatusOK, &arr)
}

func GetIPODetailInfo(c *gin.Context) {
	stockname := c.Param("stockname")
	if stockname == "" {
		c.JSON(http.StatusBadRequest, "")
		return
	}
	//arr, err :=
	resultModel := model.IPODetails{}
	service.IPODetails(stockname, &resultModel)
	// if err != nil {
	// 	c.JSON(http.StatusBadRequest, "")
	// 	return
	// }
	c.JSON(http.StatusOK, &resultModel)
}

func GetStockList(c *gin.Context) {
	resultModel, err := service.GetStockList()
	if err != nil {
		c.JSON(http.StatusBadRequest, "")
		return
	}
	c.JSON(http.StatusOK, &resultModel)
}
