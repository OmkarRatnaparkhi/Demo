package controller

import (
	"accorddata/service"
	"fmt"
	"io"
	"net/http"

	"github.com/gin-gonic/gin"
)

func StockPageUrlMaster(c *gin.Context) {
	response, err := service.StockPageUrlMaster()
	if err != nil {
		fmt.Println(err)
	}
	c.JSON(http.StatusOK, response)
}

func StockPageURLMasterUpload(c *gin.Context) {
	file, _, err := c.Request.FormFile("file")
	if err != nil {
		c.String(http.StatusBadRequest, fmt.Sprintf("file err : %s", err.Error()))
		return
	}

	byteread, err := io.ReadAll(file)
	if err != nil {
		c.String(http.StatusBadRequest, "Read All Failed")
		return
	}
	err = service.StockPageUrlMasterUpload(byteread)
	if err != nil {
		c.String(http.StatusBadRequest, err.Error())
		return
	}
	c.JSON(http.StatusOK, "")
}
