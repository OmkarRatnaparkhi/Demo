package controller

import (
	"accorddata/service"
	"fmt"
	"net/http"

	"github.com/gin-gonic/gin"
)

func TimerCall(c *gin.Context) {
	service.Zerologs.Info().Msgf("cron started==> step1")
	name := c.Param("name")

	err := service.FetchDataOnTimer(name)
	if err != nil {
		fmt.Println("Error while executing timer" + err.Error())
		c.JSON(http.StatusBadRequest, "Timer not found")
	}

	c.JSON(200, "ok")
}

func TimerDateCall(c *gin.Context) {
	// name := c.Param("name")

	err := service.FetchDataOnTimerDate(c)
	if err != nil {
		fmt.Println("Error while executing timer")
		c.JSON(http.StatusBadRequest, "Timer not found")
	}

	c.JSON(200, "ok")
}
