package controller

import (
	"accorddata/service"
	"net/http"

	"github.com/gin-gonic/gin"
)

func NewsController(c *gin.Context) {
	fincode := c.Param("fincode")
	if fincode == "" {
		c.JSON(http.StatusBadRequest, "")
		return
	}
	newsmodel, err := service.GetNewsNevents(fincode)
	if err != nil {
		c.JSON(http.StatusBadRequest, "")
		return
	}
	// bytestr, err := json.MarshalIndent(compdetail)
	// if err != nil {
	// 	c.JSON(http.StatusBadRequest, "")
	// }
	c.JSON(http.StatusOK, newsmodel)
}

func CorpEventsController(c *gin.Context) {
	fincode := c.Param("fincode")
	if fincode == "" {
		c.JSON(http.StatusBadRequest, "")
		return
	}
	corpactionmodel, err := service.GetCorpActions(fincode)
	if err != nil {
		c.JSON(http.StatusBadRequest, "")
		return
	}
	// bytestr, err := json.MarshalIndent(compdetail)
	// if err != nil {
	// 	c.JSON(http.StatusBadRequest, "")
	// }
	c.JSON(http.StatusOK, corpactionmodel)
}
