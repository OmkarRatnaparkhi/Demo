package controller

import (
	"accorddata/model"
	"accorddata/service"
	"fmt"
	"io/ioutil"
	"net/http"
	"net/url"
	"strconv"

	"github.com/gin-gonic/gin"
)

func UploadTypeSense(c *gin.Context) {

	//Droping collection from typesense
	service.DropCollection()

	//service.GetDataFromDB()
	service.GetDataFromDBOptimized()

	c.JSON(http.StatusOK, "Successfully uploaded")

}

func UploadMfDataTypeSense(c *gin.Context) {
	service.GetMfDataFromDB()

	c.JSON(http.StatusOK, "Successfully uploaded")
}

func DropCollectionTypeSense(c *gin.Context) {
	//Droping collection from typesense
	service.DropCollection()

	c.JSON(http.StatusOK, "Collection Dropped Successfully")

}

func TypeSenseClient(c *gin.Context) {

	var reqModel model.TypeSenseModel
	if err := c.ShouldBindJSON(&reqModel); err != nil {
		service.Zerologs.Error().Err(err).Msg("Error binding json" + err.Error())
		fmt.Println(err)
	}
	q := reqModel.Q
	//URL := helper.BaseURL + "/collections/" + helper.CollectionName + "/documents/search?query_by=" + helper.Query_By + "&q=" + url.QueryEscape(q) + "&group_limit=99&per_page=250"
	URL := service.BaseURL + "/collections/" + service.CollectionName + "/documents/search?" + "sort_by=" + service.Sort_by + "&query_by=" + service.Query_By + "&per_page=" + service.PerPage + "&q=" + url.QueryEscape(q) + "&group_limit=" + service.Group_Limit + "&exhaustive_search=" + service.Exhaustive_search
	//req, err := http.NewRequest("GET", "https://www.nuuu.com/collections/companymasters/documents/search?query_by=compname,s_name,isin&q="+q, nil)
	//fmt.Println(URL)
	req, err := http.NewRequest("GET", URL, nil)
	if err != nil {
		service.Zerologs.Error().Err(err).Msg("Error in Http NewRequest" + err.Error())
		fmt.Print(err.Error())
	}
	req.Header.Add(service.TypessenseKey, service.TypessenseValue)

	client := &http.Client{}
	resp, err := client.Do(req)
	if err != nil {
		service.Zerologs.Error().Err(err).Msg("Client DO Error " + err.Error())
		fmt.Println(err)
	}

	//fmt.Println(resp.Body)
	jsonString, err := ioutil.ReadAll(resp.Body)
	if err != nil {
		service.Zerologs.Error().Err(err).Msg("Error reading response body from " + URL + err.Error())
		fmt.Println(err)
	}
	//fmt.Println(jsonString)

	// var responseModel model.TypeSenseResponse

	// err = json.Unmarshal(jsonString, &responseModel)
	// if err != nil {
	// 	fmt.Println(err)
	// }

	// var arrTypeSenseData []model.TypesenseDocumentModel

	// for _, s := range responseModel.Hits {
	// 	var TypeSenseData model.TypesenseDocumentModel
	// 	TypeSenseData.ExchangeID = s.Document.ExchangeID
	// 	TypeSenseData.Fincode = s.Document.Fincode
	// 	TypeSenseData.Scr_ip_name = s.Document.Scr_ip_name
	// 	TypeSenseData.Compname = s.Document.Compname
	// 	TypeSenseData.Isin = s.Document.Isin

	// 	arrTypeSenseData = append(arrTypeSenseData, TypeSenseData)
	// }

	// var Reponse model.TypeSenseResponseModel
	// Reponse.Status = "Success"
	// Reponse.Code = http.StatusOK
	// Reponse.Data = arrTypeSenseData
	//c.JSON(http.StatusOK, Reponse)		//Document wise response

	//c.JSON(http.StatusOK, responseModel) //Direct Response

	if resp.StatusCode == 503 {
		c.String(503, "SERVICE UNAVAILABE")
	} else {
		c.String(200, string(jsonString))	
	}
	
	service.Zerologs.Info().Msg("Ending TypeSenseClient Controller")

}

func LetterBasedSearch(c *gin.Context) {

	var reqModel model.TypeSenseLetterModel
	if err := c.ShouldBindJSON(&reqModel); err != nil {
		service.Zerologs.Error().Err(err).Msg("Error binding json" + err.Error())
		fmt.Println(err)
	}
	q := reqModel.Q
	page := reqModel.Page

	perpage, _ := strconv.Atoi(reqModel.Per_page)
	var per_page string
	if perpage > 250 {
		per_page = "250"
	} else if reqModel.Per_page == "" {
		per_page = "250"
	} else {
		per_page = reqModel.Per_page
	}

	//https://www.foocut.com/collections/companymasters/documents/search?query_by=startletter&q=a&per_page=250&page=1&exhaustive_search=true
	URL := service.BaseURL + "/collections/" + service.CollectionName + "/documents/search?" + "query_by=" + service.Query_ByLetter + "&q=" + url.QueryEscape(q) + "&per_page=" + per_page + "&page=" + page + "&exhaustive_search=" + service.Exhaustive_search + "&use_cache=true&cache_ttl=1200"
	fmt.Println(URL)
	req, err := http.NewRequest("GET", URL, nil)
	if err != nil {
		service.Zerologs.Error().Err(err).Msg("Error in Http NewRequest" + err.Error())
		fmt.Print(err.Error())
	}
	req.Header.Add(service.TypessenseKey, service.TypessenseValue)

	client := &http.Client{}
	resp, err := client.Do(req)
	if err != nil {
		service.Zerologs.Error().Err(err).Msg("Client DO Error " + err.Error())
		fmt.Println(err)
	}

	//fmt.Println(resp.Body)
	jsonString, err := ioutil.ReadAll(resp.Body)
	if err != nil {
		service.Zerologs.Error().Err(err).Msg("Error reading response body from " + URL + err.Error())
		fmt.Println(err)
	}

	if resp.StatusCode == 503 {
		c.String(503, "SERVICE UNAVAILABE")
	} else {
		c.String(200, string(jsonString))	
	}
	
	service.Zerologs.Info().Msg("Ending TypeSenseClient Controller")

}


func TypeSenseAccordfacet(c *gin.Context) {

	var reqModel model.TypeSenseModel
	if err := c.ShouldBindJSON(&reqModel); err != nil {
		service.Zerologs.Error().Err(err).Msg("Error binding json" + err.Error())
		fmt.Println(err)
	}
	q := reqModel.Q

	//https://www.foocut.com/collections/companymasters/documents/search?per_page=250&query_by=symbl,cnm&q=*&page=2&facet_by=industry 
	URL := service.BaseURL + "/collections/" + service.CollectionName + "/documents/search?" + "&per_page=" + service.PerPage + "&query_by=" + service.Query_By + "&q=" + url.QueryEscape(q) + "&facet_by=" + service.AccordFacet_by
	//fmt.Println(URL)
	req, err := http.NewRequest("GET", URL, nil)
	if err != nil {
		service.Zerologs.Error().Err(err).Msg("Error in Http NewRequest" + err.Error())
		fmt.Print(err.Error())
	}
	req.Header.Add(service.TypessenseKey, service.TypessenseValue)

	client := &http.Client{}
	resp, err := client.Do(req)
	if err != nil {
		service.Zerologs.Error().Err(err).Msg("Client DO Error " + err.Error())
		fmt.Println(err)
	}

	jsonString, err := ioutil.ReadAll(resp.Body)
	if err != nil {
		service.Zerologs.Error().Err(err).Msg("Error reading response body from " + URL + err.Error())
		fmt.Println(err)
	}

	if resp.StatusCode == 503 {
		c.String(503, "SERVICE UNAVAILABE")
	} else {
		c.String(200, string(jsonString))	
	}

	service.Zerologs.Info().Msg("Ending TypeSenseClient Controller")
}

func TypeSenseAccordfacetfilter(c *gin.Context) {

	var reqModel model.TypeSenseFilter
	if err := c.ShouldBindJSON(&reqModel); err != nil {
		service.Zerologs.Error().Err(err).Msg("Error binding json" + err.Error())
		fmt.Println(err)
	}
	q := reqModel.Q
	page := reqModel.Page

	perpage , _ := strconv.Atoi(reqModel.Per_page)
	
	var per_page string 
	if (perpage > 250) {
		per_page = "250"	
	} else if (reqModel.Per_page == "") {
		per_page = "250"
	} else {
		per_page = reqModel.Per_page
	}

	var Filter_by string
	if reqModel.Industry != "" {
		Filter_by += "industry:=[" + reqModel.Industry + "]"
	}
	if reqModel.MCAPMin != "" && reqModel.MCAPMax != "" {
		Filter_by += "&& mcap:[" + reqModel.MCAPMin +".." + reqModel.MCAPMax +"]"
	}

	//fmt.Println(Filter_by)

	var URL string
	if reqModel.Industry != "" {
		//https://www.nuuu.com/collections/companymasters/documents/search?query_by=symbl,cnm&q=*&page=1&per_page=25&filter_by=industry:=[Finance - Investment,Bank - Private]
		URL = service.BaseURL + "/collections/" + service.CollectionName + "/documents/search?" + "query_by=" + service.Query_By + "&q=" + url.QueryEscape(q) + "&page=" + page + "&per_page=" + per_page + "&filter_by=" + url.QueryEscape(Filter_by) + "&sort_by=" + service.AccordmcapSort 
	} else {
		if reqModel.MCAPMin != "" && reqModel.MCAPMax != "" {
			Filter_by += "&& mcap:[" + reqModel.MCAPMin +".." + reqModel.MCAPMax +"]"
			URL = service.BaseURL + "/collections/" + service.CollectionName + "/documents/search?" + "query_by=" + service.Query_By + "&q=" + url.QueryEscape(q) + "&page=" + page + "&per_page=" + per_page + "&filter_by=" + url.QueryEscape(Filter_by) + "&sort_by=" + service.AccordmcapSort
		} else {
			URL = service.BaseURL + "/collections/" + service.CollectionName + "/documents/search?" + "&page=" + page + "&per_page=" + per_page + "&query_by=" + service.Query_By + "&q=" + url.QueryEscape(q) + "&sort_by=" + service.AccordmcapSort
		}
	}

	//fmt.Println(URL)
	req, err := http.NewRequest("GET", URL, nil)
	if err != nil {
		service.Zerologs.Error().Err(err).Msg("Error in Http NewRequest" + err.Error())
		fmt.Print(err.Error())
	}
	req.Header.Add(service.TypessenseKey, service.TypessenseValue)

	client := &http.Client{}
	resp, err := client.Do(req)
	if err != nil {
		service.Zerologs.Error().Err(err).Msg("Client DO Error " + err.Error())
		fmt.Println(err)
	}

	jsonString, err := ioutil.ReadAll(resp.Body)
	if err != nil {
		service.Zerologs.Error().Err(err).Msg("Error reading response body from " + URL + err.Error())
		fmt.Println(err)
	}

	if resp.StatusCode == 503 {
		c.String(503, "SERVICE UNAVAILABE")
	} else {
		c.String(200, string(jsonString))
	}

	service.Zerologs.Info().Msg("Ending TypeSenseClient Controller")
}
