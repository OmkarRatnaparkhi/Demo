package helper

import (
	"fmt"
	"net/http"

	"github.com/gin-gonic/gin"
)

func RouteView(router *gin.Engine) {
	accord := router.Group("/accord")
	accord.GET("/", func(c *gin.Context) {
		c.HTML(
			http.StatusOK,
			"index.html",
			gin.H{
				"title":     "Home Page",
				"routename": "CompanyMaster",
			},
		)

	})
	accord.GET("/:name", func(c *gin.Context) {
		name := c.Param("name")
		fmt.Println("REquest:", name)
		c.HTML(
			http.StatusOK,
			"index.html",
			gin.H{
				"title":     "Home Page",
				"routename": name,
			},
		)

	})

}
