package helper

import (
	"encoding/json"
	"fmt"
	"io/ioutil"
	"log"
	"net/http"
	"net/http/cookiejar"
	"strconv"
	"time"

	"github.com/TecXLab/libenv"
)

var Env libenv.Env

// const BaseURL = "https://www.nuuu.com"
// const TypessenseKey = "X-TYPESENSE-API-KEY"
// const TypessenseValue = "Hu52dwsas2AdxdE"
// const CollectionName = "companymasters"
// const Query_By = "symbl,cnm"
// const Group_Limit = "99"
// const PerPage = "250"
// const Sort_by = "exid:asc"
// const Exhaustive_search = "true"

var Httpclient http.Client

func InitCookie() {
	jar, err := cookiejar.New(nil)
	if err != nil {
		log.Fatalf("Got error while creating cookie jar %s", err.Error())
	}

	Httpclient = http.Client{
		Jar: jar,
	}
}

func HttpGet(url string) ([]byte, error) {
	fmt.Println(url)
	req, err := http.NewRequest("GET", url, nil)
	if err != nil {
		fmt.Println("Got error " + err.Error())
		return nil, err
	}
	resp, err := Httpclient.Do(req)
	fmt.Println(resp)
	if err != nil {
		fmt.Println("Httpclient.Do " + err.Error())
		return nil, err
	}
	defer resp.Body.Close()
	body, err := ioutil.ReadAll(resp.Body)
	if err != nil {
		fmt.Println("ioutil.ReadAll " + err.Error())
		return nil, err
	}

	return body, nil
}

type DataStruct struct {
	Table []interface{} `json:"Table"`
}

func ParseData(buff []byte) (string, error) {
	var data DataStruct
	json.Unmarshal([]byte(buff), &data)
	res1B, _ := json.Marshal(data.Table)
	//fmt.Println(string(res1B))
	return string(res1B), nil
}
func ParseDataByte(buff []byte) ([]byte, error) {
	var data DataStruct
	json.Unmarshal([]byte(buff), &data)
	res1B, _ := json.Marshal(data.Table)
	//fmt.Println(string(res1B))
	return res1B, nil
}

func GetStringfromMap(mapdata map[string]interface{}, name string) string {
	data := mapdata[name]
	if data == nil {
		return ""
	}
	return data.(string)
}
func GetFloatToStringfromMap(mapdata map[string]interface{}, name string) string {
	data := mapdata[name]
	if data == nil {
		return ""
	}
	return fmt.Sprintf("%v", data)
}

func GetIntfromMap(mapdata map[string]interface{}, name string) int {
	data := mapdata[name]
	if data == nil {
		return 0
	}

	switch data.(type) {
	case string:
		sdata := data.(string)
		num, err := strconv.Atoi(sdata)
		if err != nil {
			return 0
		}
		return num
	case int:
		return data.(int)
	case float64:
		intdsts := data.(float64)
		return int(intdsts)
	}
	return 0
}

func GetInt64fromMap(mapdata map[string]interface{}, name string) int64 {
	data := mapdata[name]
	if data == nil {
		return 0
	}

	switch data.(type) {
	case string:
		sdata := data.(string)
		num, err := strconv.Atoi(sdata)
		if err != nil {
			return 0
		}
		num2 := int64(num)
		return num2
	case int:
		return int64(data.(int))
	case float64:
		intdsts := data.(float64)
		return int64(intdsts)
	}
	return 0
}

func GetFloatfromMap(mapdata map[string]interface{}, name string) float64 {
	data := mapdata[name]
	if data == nil {
		return 0
	}
	switch data.(type) {
	case string:
		sdata := data.(string)
		num, err := strconv.ParseFloat(sdata, 64)
		if err != nil {
			return 0
		}
		return num
	case int:
		return float64(data.(int))
	case float64:
		intdsts := data.(float64)
		return intdsts
	}
	return 0
}
func GetTimefromMap(mapdata map[string]interface{}, name string) time.Time {
	data := mapdata[name]
	if data == "" {
		return time.Date(1070, 1, 1, 0, 0, 0, 0, time.UTC)
	}
	switch data.(type) {
	case string:
		sdata := data.(string)
		if sdata != "" {
			num, err := time.Parse("2006-01-02 15:04:05.000", sdata)
			if err != nil {
				return time.Date(1070, 1, 1, 0, 0, 0, 0, time.UTC)
			}
			if num.Year() == 0 {
				num = time.Time{}
			}
			// fmt.Println(err)
			return num
		}
	}
	return time.Date(1070, 1, 1, 0, 0, 0, 0, time.UTC)
}
