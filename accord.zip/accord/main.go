package main

import (
	"accorddata/controller"
	"accorddata/helper"
	"accorddata/service"
	"fmt"
	"log"
	"os"

	"github.com/TecXLab/libdb"
	"github.com/TecXLab/libdrainer"
	"github.com/TecXLab/libenv"
	"github.com/TecXLab/libhttp"
	"github.com/TecXLab/libjwt"
	"github.com/TecXLab/liblogs"
	"github.com/TecXLab/libslack"
	"github.com/gin-gonic/gin"
	"github.com/golobby/container/v3"
	"github.com/joho/godotenv"
	"github.com/rs/zerolog"
)

var (
	router   = gin.Default()
	Env      libenv.Env
	Zerologs zerolog.Logger
)

func init() {

	err := godotenv.Load(".env")
	if err != nil {
		fmt.Println("No Env file found")
	}
	fmt.Println(os.Getenv(gin.Mode()))
	//Env
	err = Env.Init()
	//Env.VOLUMNE_PATH = "/home/pratikk/Postfiles"
	if err != nil {
		fmt.Println("Env Lib Not Initialize" + err.Error())
	}

	//loblog
	err = liblogs.Init()
	if err != nil {
		fmt.Println("Logs Lib Not Initialize" + err.Error())
	}
	err = container.NamedResolve(&Zerologs, "zerologs")
	if err != nil {
		panic("Log Lib Not Initialize" + err.Error())
	}
	// Env.MSQL_PASSWORD = "Tecxlabs@123"
	// os.Setenv("REDIS_PASSWORD", "Mksl@1234")

	if Env.MSQL_ACCORD_DBNAME == "" {
		Env.MSQL_ACCORD_DBNAME = "accord_dev"
	}
	//jwt
	err = libjwt.InitNetJwt()
	if err != nil {
		fmt.Println("JWT Lib Not Initialize" + err.Error())
		Zerologs.Error().Msg("JWT Lib Not Initialize" + err.Error())
	}

	var accorddb libdb.AccordDB
	err = accorddb.Connect()
	if err != nil {
		fmt.Println("Database is Not Connected" + err.Error())
		Zerologs.Error().Msg("Database is Not Connected" + err.Error())
	}

	var contractdb libdb.ContractMasterDB
	err = contractdb.Connect()
	if err != nil {
		fmt.Println("Database is Not Connected" + err.Error())
		Zerologs.Error().Msg("Database is Not Connected" + err.Error())
	}
	var q libdrainer.Q
	err = q.Init("timerdrainer")
	if err != nil {
		fmt.Println("Drainer Lib Not Initialize" + err.Error())
		Zerologs.Error().Msg("Drainer Lib Not Initialize" + err.Error())
	}

	//Redis -- **
	// var redis libredis.RedisClient
	// fmt.Println("Redis Connection start")
	// err = redis.Connect()
	// if err != nil {
	// 	fmt.Println("Redis Connection Error " + err.Error())
	// 	panic("RedisClient Lib Not Initialize" + err.Error())
	// }
	// fmt.Println("Redis Connected")

	err = service.InitDI()
	if err != nil {
		fmt.Println("DI Not Initialize" + err.Error())
		Zerologs.Error().Msg("DI Not Initialize" + err.Error())
	}

	libslack.InitSlack()

	helper.InitCookie()

	if Env.STAGE == "testing" || Env.STAGE == "dev" || Env.STAGE == "staging" || Env.STAGE == "production" {
		// sVolumepath := os.Getenv("VOLUMNE_PATH")
		service.InitRouteFile("/handler.csv")
		fmt.Println("handler.csv")
	} else {
		service.InitRouteFile("handler.csv")
		fmt.Printf("Handler.csv")
	}
	service.InitEnvvariables()
}

func main() {

	if Env.STAGE == "testing" || Env.STAGE == "dev" || Env.STAGE == "staging" || Env.STAGE == "production" {
		// sVolumepath := os.Getenv("VOLUMNE_PATH")
		if _, err := os.Stat("/webtemplate/accordview/html"); os.IsNotExist(err) {
			fmt.Println("/webtemplate/accordview/html not avilable")
		} else {
			router.LoadHTMLGlob("/webtemplate/accordview/html/*")
			router.Static("/accord/js", "/webtemplate/accordview/js")
		}
	} else {
		router.LoadHTMLGlob("WebTemplate/AccordView/html/*")
		router.Static("/accord/js", "WebTemplate/AccordView/js")
	}
	router.Use(CORSMiddleware())
	api := router.Group("/accord")
	api.GET("/getip", controller.GetIP)
	api.GET("/testip", controller.TestIP)
	api.POST("/upload", controller.Upload)
	//api.GET("/search", controller.SearchController)
	router.GET("/getstocklist", controller.GetStockList)
	api.GET("/stockpageurlmaster", controller.StockPageUrlMaster)
	router.GET("/news/:fincode", controller.NewsController)
	router.GET("/corpevents/:fincode", controller.CorpEventsController)
	router.GET("/getstockinfo/:stockname", controller.GetStockInfo)
	router.GET("/getipolist", controller.GetIPOInfo)
	router.GET("/getipoinfo/:stockname", controller.GetIPODetailInfo)
	router.POST("/uploadcustomercsv", controller.StockPageURLMasterUpload)
	api.GET("/redherringprospectus/:symbol", controller.DownloadDRHPDownload) //change name to red-herring prospectus
	api.GET("/api/:name", controller.ApiController)                           //manual timer check

	api.GET("/uploadtypesense", controller.UploadTypeSense) //first collection deleted then uploaded
	api.GET("/uploadmfdatatypesense", controller.UploadMfDataTypeSense)
	api.DELETE("/dropcollection", controller.DropCollectionTypeSense)
	api.POST("/search", controller.TypeSenseClient) //typesenseclient
	api.POST("/lettersearch", controller.LetterBasedSearch)
	api.POST("/searchfacet", controller.TypeSenseAccordfacet)
	api.POST("/searchfilter", controller.TypeSenseAccordfacetfilter)
	api.POST("timerdate", controller.TimerDateCall)
	api.OPTIONS("/updateenvsettings", libhttp.CORSMiddleware())
	api.POST("/updateenvsettings", controller.EnvSettingController)
	timerrouter := router.Group("/timer")
	timerrouter.GET("/:name", controller.TimerCall)
	//0400
	// timerrouter.GET("/timer0730", controller.Timer07"/30)
	// timerrouter.GET("/timer0830", controller.Timer0830)
	// timerrouter.GET("/timer0930", controller.Timer0930)
	// timerrouter.GET("/timer1000", controller.Timer1000)
	// timerrouter.GET("/timer1230", controller.Timer1230)
	// timerrouter.GET("/timer1400", controller.Timer1400)
	// timerrouter.GET("/timer1430", controller.Timer1430)
	// timerrouter.GET("/timer1600", controller.Timer1600)
	// timerrouter.GET("/timer2230", controller.Timer2230)
	// timerrouter.GET("/timer2345", controller.Timer2345)
	// timerrouter.GET("/timer2355", controller.Timer2355)
	// timerrouter.GET("/timehalfminute09002130", controller.Timehalfminute08301900)
	// timerrouter.GET("/timehalfminute08301900", controller.Timehalfminute08301900)

	helper.RouteView(router)
	if Env.EXPOSEPORT == "" {
		log.Fatal(router.Run(":8085"))
	} else {
		log.Fatal(router.Run(":" + Env.EXPOSEPORT))
	}
}

func CORSMiddleware() gin.HandlerFunc {
	return func(c *gin.Context) {
		c.Writer.Header().Set("Access-Control-Allow-Origin", "*")
		c.Writer.Header().Set("Access-Control-Allow-Credentials", "true")
		c.Writer.Header().Set("Access-Control-Allow-Headers", "Content-Type, Content-Length, Accept-Encoding, X-CSRF-Token, Authorization, accept, origin, Cache-Control, X-Requested-With")
		c.Writer.Header().Set("Access-Control-Allow-Methods", "POST, OPTIONS, GET, PUT")

		if c.Request.Method == "OPTIONS" {
			c.AbortWithStatus(204)
			return
		}

		c.Next()
	}
}
