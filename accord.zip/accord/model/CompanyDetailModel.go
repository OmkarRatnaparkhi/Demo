package model

type SimilarStock struct {
	S_NAME   string `json:"s_name"`
	ISIN     string `json:"isin"`
	COMPNAME string `json:"compname"`
	URLPATH  string `json:"urlpath"`
}
type CompanyDetailModel struct {
	FINCODE       int            `json:"fincode"`
	SCRIPCODE     int            `json:"scripcode"`
	SCRIP_NAME    string         `json:"scrip_name"`
	SCRIP_GROUP   string         `json:"scrip_group"`
	COMPNAME      string         `json:"compname"`
	IND_CODE      int            `json:"ind_code"`
	HSE_CODE      int            `json:"hse_code"`
	SYMBOL        string         `json:"symbol"`
	SERIES        string         `json:"series"`
	ISIN          string         `json:"isin"`
	S_NAME        string         `json:"s_name"`
	Status        string         `json:"status"`
	FLAG          string         `json:"flag"`
	Industry      string         `json:"industry"`
	MCAP          string         `json:"mcap"`
	PERATIO       string         `json:"peratio"`
	PBRATIO       string         `json:"pbratio"`
	INDPERATIO    string         `json:"indperatio"`
	ROE           string         `json:"roe"`
	EPS           string         `json:"eps"`
	DIVIDENDYIELD string         `json:"dividendyield"`
	BOOKVALUE     string         `json:"bookvalue"`
	URLPATH       string         `json:"urlpath"`
	Token         int            `json:"token"`
	SimilarStock  []SimilarStock `json:"similarstock"`
}
