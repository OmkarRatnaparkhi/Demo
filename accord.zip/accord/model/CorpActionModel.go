package model

import (
	"time"
)

type CorpActionModel struct {
	CORPACTID       int       `json:"corpactid"`
	CORPACTNAME     string    `json:"corpactname"`
	CORPACTMASTERID int       `json:"corpactmasterid"`
	DATE            time.Time `json:"date"`
	DETAILS         string    `json:"details"`
}
