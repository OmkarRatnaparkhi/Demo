package model

type Filename struct {
	Filename string `json:"filename"`
}
