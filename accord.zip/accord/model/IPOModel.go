package model

import "time"

type AllIPOModels struct {
	RecentlyAddedList  []RecentIPOModel `json:"recentlyaddedlist"`
	UpcomingList       []OpenIPOModel   `json:"upcomingList"`
	OpenNowList        []OpenIPOModel   `json:"opennowlist"`
	RecentlyClosedList []RecentIPOModel `json:"recentlyclosedlist"`
}
type RecentIPOModel struct {
	IPOCode     float64   `json:"ip_ocode"`
	FinCode     float64   `json:"fincode"`
	ListDate    time.Time `json:"listdate"`
	Issueprice1 float64   `json:"issueprice1"`
	Issueprice2 float64   `json:"issueprice2"`
	ListPrice   float64   `json:"listprice"`
	ListGain    float64   `json:"listinggain"`
	NSEList     float64   `json:"nseli	st"`
	MinaPlan    float64   `json:"minapln"`
	TotalEquity float64   `json:"total_eq_ui_ty"`
	CompanyName string    `json:"companyname"`
	OpenDate    time.Time `json:"opendate"`
	CloseDate   time.Time `json:"closeDate"`
	IssueSize   float64   `json:"issuesize"`
	Isin        string    `json:"isin"`
	CompanyUrl  string    `json:"companyUrl"`
}

type OpenIPOModel struct {
	IPOCode     float64   `json:"ip_ocode"`
	FinCode     float64   `json:"fincode"`
	ListDate    time.Time `json:"listdate"`
	Issueprice1 float64   `json:"issueprice1"`
	Issueprice2 float64   `json:"issueprice2"`
	NSEList     float64   `json:"nseli	st"`
	MinaPlan    float64   `json:"minapln"`
	TotalEquity float64   `json:"total_eq_ui_ty"`
	CompanyName string    `json:"companyname"`
	OpenDate    time.Time `json:"opendate"`
	CloseDate   time.Time `json:"closeDate"`
	IssueSize   float64   `json:"issuesize"`
	Isin        string    `json:"isin"`
	CompanyUrl  string    `json:"companyUrl"`
}

type UpcomingIPOModel struct {
	IPOCode     float64 `json:"ip_ocode"`
	FinCode     float64 `json:"fincode"`
	CompanyName string  `json:"companyname"`
	CompanyUrl  string  `json:"companyUrl"`
}

type IPODetails struct {
	Symbol      string    `json:"symbol"`
	CompanyName string    `json:"companyname"`
	Fincode     int       `json:"fincode"`
	StkId       []int     `json:"stk_id"`
	StkName     []string  `json:"stk_name"`
	IssuePrice  float64   `json:"issueprice"`
	NSEList     float64   `json:"nselist"`
	Opendate    time.Time `json:"opendate"`
	Closedate   time.Time `json:"closedate"`
	MinaPlan    float64   `json:"minaplan"`
	Mdir        string    `json:"mdir"`
	Issueprice1 float64   `json:"issueprice1"`
	Issueprice2 float64   `json:"issueprice2"`
	Isin        string    `json:"isin"`
	CompanyUrl  string    `json:"companyUrl"`
	Objective   []string  `json:"objective"`
	Foundyear   string    `json:"foundyear"`
}
