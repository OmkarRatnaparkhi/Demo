package model

import (
	"time"
)

type NewsModel struct {
	NEWSID     int       `json:"newsid"`
	SECNAME    string    `json:"secname"`
	SUBSECNAME string    `json:"subsecname"`
	DATE       time.Time `json:"date"`
	TIME       string    `json:"time"`
	HEADING    string    `json:"heading"`
	CAPTION    string    `json:"caption"`
	DETAILS    string    `json:"details"`
}
