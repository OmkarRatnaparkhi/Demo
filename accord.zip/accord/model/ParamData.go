package model

type ParamData struct {
	MainMenu string
	Handler  string
	URL      string
	Sub      string
	Token    string
	Timer    string
}
