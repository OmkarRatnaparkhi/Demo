package model

type StockModel struct {
	FINCODE     int    `json:"fincode"`
	SCRIP_GROUP string `json:"scrip_group"`
	COMPNAME    string `json:"compname"`
	SYMBOL      string `json:"symbol"`
	SERIES      string `json:"series"`
	IND_CODE    int    `json:"ind_code"`
	ISIN        string `json:"isin"`
	Status      string `json:"status"`
	Industry    string `json:"industry"`
	MCAP        string `json:"mcap"`
	URLPATH     string `json:"urlpath"`
	Token       int    `json:"token"`
}
