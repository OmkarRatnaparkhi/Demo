package model

type TypesenseDocumentModel struct {
	ExchangeID   int     `json:"exid"`
	Token        int     `json:"tk"`
	URL          string  `json:"url"`
	Fincode      int64   `json:"fincode"`
	Isin         string  `json:"isin"`
	Compname     string  `json:"cnm"`
	Scr_ip_name  string  `json:"scrnm"`
	SSymbol      string  `json:"symbl"`
	Industry     string  `json:"industry"`
	MCAP         float64 `json:"mcap"`
	Start_Letter string  `json:"startletter"`
}

type TypeSenseResponseModel struct {
	Status string                   `json:"status"`
	Code   int                      `json:"code"`
	Data   []TypesenseDocumentModel `json:"data"`
}

type TypeSenseModel struct {
	Q string `json:"q"`
}

type TypeSenseLetterModel struct {
	Q string `json:"q"`
	Page           string `json:"page"`
	Per_page       string `json:"per_page"`
}

type TypeSenseFilter struct {
	Q        string `json:"q"`
	Industry string `json:"industry"`
	Page     string `json:"page"`
	Per_page string `json:"per_page"`
	//MCAP     string `json:"mcap"`
	MCAPMin string `json:"mcapmin"`
	MCAPMax string `json:"mcapmax"`
}

type FacetCount struct {
}

type Highlight struct {
	Field          string   `json:"field"`
	Matched_Tokens []string `json:"matched_tokens"`
	Snippet        string   `json:"snippet"`
}

type Hit struct {
	Document   TypesenseDocumentModel `json:"document"`
	Highlights []Highlight            `json:"highlights"`
	Text_match int64                  `json:"text_match"`
}

type RequestParams struct {
	Collection_Name string `json:"collection_name"`
	Per_Page        int    `json:"per_page"`
	Q               string `json:"q"`
}
type TypeSenseResponse struct {
	Facet_Counts   []FacetCount  `json:"facet_counts"`
	Found          int           `json:"found"`
	Hits           []Hit         `json:"hits"`
	Out_of         int           `json:"out_of"`
	Page           int           `json:"page"`
	Request_Params RequestParams `json:"request_params"`
	Search_Cutoff  bool          `json:"search_cutoff"`
	Search_Time_Ms int           `json:"search_time_ms"`
}
