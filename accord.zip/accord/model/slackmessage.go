package model

type SlackMessage struct {
	Text string `json:"text"`
}
