package service

import (
	"accorddata/helper"
	"bytes"
	"encoding/json"
	"fmt"
	"strconv"
	"time"

	"github.com/TecXLab/libdb/accord"
	"gorm.io/gorm"
	"gorm.io/gorm/clause"
)

var FunctionMap = make(map[string]interface{})

func Companymaster(strjson []byte, buffer *bytes.Buffer) error {
	var arryJson []interface{}
	if err := json.Unmarshal(strjson, &arryJson); err != nil {
		buffer.WriteString(err.Error() + "\n")
		return err
	}
	var datamodelUpdate []accord.Companymaster
	count := 0
	// q.Enqueue(arryJson, func(data interface{}) {
	db.Accord.Transaction(func(tx *gorm.DB) error {
		start := time.Now()
		for _, json := range arryJson {
			jsonmap := json.(map[string]interface{})
			datamodel := accord.Companymaster{}
			datamodel.FINCODE = helper.GetIntfromMap(jsonmap, "FINCODE")
			// err := tx.Where("fincode=?", datamodel.FINCODE).First(&datamodel).Error
			// if err != nil {
			// 	Zerologs.Error().Msg("Record Not Found In Companymaster" + err.Error())
			// }

			datamodel.CHAIRMAN = helper.GetStringfromMap(jsonmap, "CHAIRMAN")
			datamodel.COMPNAME = helper.GetStringfromMap(jsonmap, "COMPNAME")
			datamodel.COSEC = helper.GetStringfromMap(jsonmap, "COSEC")
			datamodel.FFORMAT = helper.GetStringfromMap(jsonmap, "FFORMAT")
			datamodel.FLAG = helper.GetStringfromMap(jsonmap, "FLAG")
			datamodel.FV = helper.GetFloatfromMap(jsonmap, "FV")
			datamodel.HSE_CODE = helper.GetIntfromMap(jsonmap, "HSE_CODE")
			datamodel.INC_MONTH = helper.GetStringfromMap(jsonmap, "INC_MONTH")
			datamodel.INC_YEAR = helper.GetStringfromMap(jsonmap, "INC_YEAR")
			datamodel.IND_CODE = helper.GetIntfromMap(jsonmap, "IND_CODE")
			datamodel.ISIN = helper.GetStringfromMap(jsonmap, "ISIN")
			datamodel.MDIR = helper.GetStringfromMap(jsonmap, "MDIR")
			//datamodel.Model = jsonmap["Model"].(int)
			datamodel.RFORMAT = helper.GetStringfromMap(jsonmap, "RFORMAT")
			datamodel.SCRIPCODE = helper.GetIntfromMap(jsonmap, "SCRIPCODE")
			datamodel.SCRIP_GROUP = helper.GetStringfromMap(jsonmap, "SCRIP_GROUP")
			datamodel.SCRIP_NAME = helper.GetStringfromMap(jsonmap, "SCRIP_NAME")
			datamodel.SERIES = helper.GetStringfromMap(jsonmap, "SERIES")
			datamodel.SYMBOL = helper.GetStringfromMap(jsonmap, "SYMBOL")
			datamodel.S_NAME = helper.GetStringfromMap(jsonmap, "S_NAME")
			datamodel.Status = helper.GetStringfromMap(jsonmap, "Status")
			datamodel.Sublisting = helper.GetStringfromMap(jsonmap, "Sublisting")
			fincode := strconv.Itoa(datamodel.FINCODE)
			datamodel.ID = fincode
			// err = tx.Save(&datamodel).Error
			// if err != nil {
			// 	buffer.WriteString(err.Error())
			// }
			datamodelUpdate = append(datamodelUpdate, datamodel)
			count++
		}
		err := db.Accord.Clauses(clause.OnConflict{
			Columns:   []clause.Column{{Name: "id"}}, //, {Name: "invdate"}, {Name: "srno"}},
			DoUpdates: clause.AssignmentColumns([]string{"fincode", "scr_ip_code", "scr_ip_name", "scr_ip_group", "compname", "ind_code", "hse_code", "symbol", "series", "isin", "s_name", "rformat", "fformat", "chairman", "mdir", "cosec", "inc_month", "inc_year", "fv", "status", "sublisting", "flag"}),
			// DoUpdates: clause.AssignmentColumns([]string{"rating"}),
		}).CreateInBatches(&datamodelUpdate, 1000).Error
		if err != nil {
			fmt.Println(err)
			Zerologs.Error().Msg("Error while Inserting data into companymaster")
		}
		Zerologs.Info().Msgf(" execution time for companymaster ==>", time.Since(start))
		buffer.WriteString("Total Record updated " + strconv.Itoa(count) + "\n")
		return nil
	})

	// })
	return nil
}

func Industrymaster(strjson []byte, buffer *bytes.Buffer) error {
	var arryJson []interface{}
	if err := json.Unmarshal(strjson, &arryJson); err != nil {
		buffer.WriteString(err.Error() + "\n")
		return err
	}
	var datamodelUpdate []accord.Industrymaster
	count := 0
	// q.Enqueue(arryJson, func(data interface{}) {
	db.Accord.Transaction(func(tx *gorm.DB) error {
		start := time.Now()
		for _, json := range arryJson {
			jsonmap := json.(map[string]interface{})
			datamodel := accord.Industrymaster{}

			datamodel.IND_CODE = helper.GetIntfromMap(jsonmap, "IND_CODE")
			datamodel.INDUSTRY = helper.GetStringfromMap(jsonmap, "INDUSTRY")
			datamodel.Flag = helper.GetStringfromMap(jsonmap, "FLAG")
			indcode := strconv.Itoa(datamodel.IND_CODE)
			datamodel.ID = indcode
			//datamodel.Model = jsonmap["Model"].(int)
			datamodelUpdate = append(datamodelUpdate, datamodel)
			count++

		}
		err := db.Accord.Clauses(clause.OnConflict{
			Columns:   []clause.Column{{Name: "id"}}, //, {Name: "invdate"}, {Name: "srno"}},
			DoUpdates: clause.AssignmentColumns([]string{"ind_code", "industry", "flag"}),
			// DoUpdates: clause.AssignmentColumns([]string{"rating"}),
		}).CreateInBatches(&datamodelUpdate, 1000).Error
		if err != nil {
			fmt.Println(err)
			Zerologs.Error().Msg("Error while Inserting data into industrymaster")
		}
		Zerologs.Info().Msgf(" execution time for industrymaster ==>", time.Since(start))
		buffer.WriteString("Total Record updated " + strconv.Itoa(count) + "\n")

		return nil
	})

	// })
	return nil
}

func Monthlyprice(strjson []byte, buffer *bytes.Buffer) error {
	var arryJson []interface{}
	if err := json.Unmarshal(strjson, &arryJson); err != nil {
		buffer.WriteString(err.Error() + "\n")
		return err
	}
	var datamodelUpdate []accord.Monthlyprice
	count := 0
	// q.Enqueue(arryJson, func(data interface{}) {
	db.Accord.Transaction(func(tx *gorm.DB) error {
		start := time.Now()
		for _, json := range arryJson {
			jsonmap := json.(map[string]interface{})
			datamodel := accord.Monthlyprice{}
			datamodel.Fincode = helper.GetIntfromMap(jsonmap, "Fincode")

			datamodel.Month = helper.GetIntfromMap(jsonmap, "Month")

			datamodel.Year = helper.GetIntfromMap(jsonmap, "Year")
			// err := tx.Where("fincode=? AND month=? AND year=?", datamodel.Fincode, datamodel.Month, datamodel.Year).First(&datamodel).Error
			// if err != nil {
			// 	Zerologs.Error().Msg("Record Not Found In MonethlyPrice" + err.Error())
			// }
			datamodel.SCripCode = helper.GetIntfromMap(jsonmap, "SCripCode")

			datamodel.Open = helper.GetFloatfromMap(jsonmap, "Open")

			datamodel.High = helper.GetFloatfromMap(jsonmap, "high")

			datamodel.Low = helper.GetFloatfromMap(jsonmap, "low")

			datamodel.Close = helper.GetFloatfromMap(jsonmap, "Close")

			datamodel.Volume = helper.GetFloatfromMap(jsonmap, "Volume")

			datamodel.Value = helper.GetFloatfromMap(jsonmap, "Value")

			datamodel.Flag = helper.GetStringfromMap(jsonmap, "flag")

			// datamodel.Model = jsonmap["Model"].(int)
			fincode := strconv.Itoa(datamodel.Fincode)
			month := strconv.Itoa(datamodel.Month)
			year := strconv.Itoa(datamodel.Year)
			fincode_month_year := fincode + "_" + month + "_" + year
			// err = tx.Save(&datamodel).Error
			// if err != nil {
			// 	buffer.WriteString(err.Error())
			// }
			datamodel.ID = fincode_month_year
			datamodelUpdate = append(datamodelUpdate, datamodel)
			count++
		}
		err := db.Accord.Clauses(clause.OnConflict{
			Columns:   []clause.Column{{Name: "id"}}, //, {Name: "invdate"}, {Name: "srno"}},
			DoUpdates: clause.AssignmentColumns([]string{"fincode", "s_crip_code", "month", "year", "open", "high", "low", "close", "volume", "value", "flag"}),
			// DoUpdates: clause.AssignmentColumns([]string{"rating"}),
		}).CreateInBatches(&datamodelUpdate, 1000).Error
		if err != nil {
			fmt.Println(err)
			Zerologs.Error().Msg("Error while Inserting data into monthprice")
		}
		Zerologs.Info().Msgf(" execution time for industrymaster ==>", time.Since(start))
		buffer.WriteString("Total Record updated " + strconv.Itoa(count) + "\n")

		return nil
	})

	// })
	return nil
}

func Nse_Monthprice(strjson []byte, buffer *bytes.Buffer) error {
	var arryJson []interface{}
	if err := json.Unmarshal(strjson, &arryJson); err != nil {
		buffer.WriteString(err.Error() + "\n")
		return err
	}
	var datamodelUpdate []accord.Nse_Monthprice
	count := 0
	// q.Enqueue(arryJson, func(data interface{}) {
	db.Accord.Transaction(func(tx *gorm.DB) error {
		start := time.Now()
		for _, json := range arryJson {
			jsonmap := json.(map[string]interface{})
			datamodel := accord.Nse_Monthprice{}
			datamodel.Fincode = helper.GetIntfromMap(jsonmap, "Fincode")

			datamodel.Month = helper.GetIntfromMap(jsonmap, "Month")

			datamodel.Year = helper.GetIntfromMap(jsonmap, "Year")

			// err := tx.Where("fincode=? AND month=? AND year=?", datamodel.Fincode, datamodel.Month, datamodel.Year).First(&datamodel).Error
			// if err != nil {
			// 	Zerologs.Error().Msg("Record Not Found In Nse_Monthprice" + err.Error())
			// }
			datamodel.Symbol = helper.GetStringfromMap(jsonmap, "symbol")

			datamodel.Open = helper.GetFloatfromMap(jsonmap, "Open")

			datamodel.High = helper.GetFloatfromMap(jsonmap, "high")

			datamodel.Low = helper.GetFloatfromMap(jsonmap, "low")

			datamodel.Close = helper.GetFloatfromMap(jsonmap, "Close")

			datamodel.Volume = helper.GetFloatfromMap(jsonmap, "Volume")

			datamodel.Value = helper.GetFloatfromMap(jsonmap, "Value")

			datamodel.Flag = helper.GetStringfromMap(jsonmap, "flag")
			fincode := strconv.Itoa(datamodel.Fincode)
			month := strconv.Itoa(datamodel.Month)
			year := strconv.Itoa(datamodel.Year)
			fincode_month_year := fincode + "_" + month + "_" + year
			datamodel.ID = fincode_month_year

			//datamodel.Model = jsonmap["Model"].(int)

			// err = tx.Save(&datamodel).Error
			// if err != nil {
			// 	buffer.WriteString(err.Error())
			// }
			datamodelUpdate = append(datamodelUpdate, datamodel)

			count++

		}
		err := db.Accord.Clauses(clause.OnConflict{
			Columns:   []clause.Column{{Name: "id"}}, //, {Name: "invdate"}, {Name: "srno"}},
			DoUpdates: clause.AssignmentColumns([]string{"fincode", "symbol", "month", "year", "open", "high", "low", "close", "volume", "value", "flag"}),
			// DoUpdates: clause.AssignmentColumns([]string{"rating"}),
		}).CreateInBatches(&datamodelUpdate, 1000).Error
		if err != nil {
			fmt.Println(err)
			Zerologs.Error().Msg("Error while Inserting data into Nsemonthprice")
		}
		Zerologs.Info().Msgf(" execution time for industrymaster ==>", time.Since(start))
		buffer.WriteString("Total Record updated " + strconv.Itoa(count) + "\n")

		return nil
	})

	// })
	return nil
}

func Quarterly(strjson []byte, buffer *bytes.Buffer) error {
	var arryJson []interface{}
	if err := json.Unmarshal(strjson, &arryJson); err != nil {
		buffer.WriteString(err.Error() + "\n")
		return err
	}
	var datamodelUpdate []accord.Quarterly
	count := 0
	// q.Enqueue(arryJson, func(data interface{}) {
	db.Accord.Transaction(func(tx *gorm.DB) error {
		start := time.Now()
		for _, json := range arryJson {
			jsonmap := json.(map[string]interface{})
			datamodel := accord.Quarterly{}
			datamodel.Fincode = helper.GetIntfromMap(jsonmap, "Fincode")
			datamodel.Result_Type = helper.GetStringfromMap(jsonmap, "Result_Type")
			datamodel.Date_End = helper.GetIntfromMap(jsonmap, "Date_End")
			// err := tx.Where("fincode=? AND result_type=? AND date_end=?", datamodel.Fincode, datamodel.Result_Type, datamodel.Date_End).First(&datamodel).Error

			// if err != nil {
			// 	Zerologs.Error().Msg("Record Not Found In Quaterly" + err.Error())
			// }
			datamodel.NoOfMonths = helper.GetIntfromMap(jsonmap, "NoOfMonths")
			datamodel.NET_SALES = helper.GetFloatfromMap(jsonmap, "NET_SALES")
			datamodel.INT_ADV = helper.GetFloatfromMap(jsonmap, "INT_ADV")
			datamodel.INC_INV = helper.GetFloatfromMap(jsonmap, "INC_INV")
			datamodel.INT_BAL = helper.GetFloatfromMap(jsonmap, "INT_BAL")
			datamodel.INT_OTHERS = helper.GetFloatfromMap(jsonmap, "INT_OTHERS")
			datamodel.OTHER_INCOME = helper.GetFloatfromMap(jsonmap, "OTHER_INCOME")
			datamodel.TOTAL_INCOME = helper.GetFloatfromMap(jsonmap, "TOTAL_INCOME")
			datamodel.EXPENDITURE = helper.GetFloatfromMap(jsonmap, "EXPENDITURE")
			datamodel.OPERATING_PROFIT = helper.GetFloatfromMap(jsonmap, "OPERATING_PROFIT")
			datamodel.INTEREST = helper.GetFloatfromMap(jsonmap, "INTEREST")
			datamodel.GROSS_PROFIT = helper.GetFloatfromMap(jsonmap, "GROSS_PROFIT")
			datamodel.DEPRECIATION = helper.GetFloatfromMap(jsonmap, "DEPRECIATION")
			datamodel.PBT = helper.GetFloatfromMap(jsonmap, "PBT")
			datamodel.PAC = helper.GetFloatfromMap(jsonmap, "PAC")
			datamodel.TAX = helper.GetFloatfromMap(jsonmap, "TAX")
			datamodel.PAT = helper.GetFloatfromMap(jsonmap, "PAT")
			datamodel.EI = helper.GetFloatfromMap(jsonmap, "EI")
			datamodel.PPI = helper.GetFloatfromMap(jsonmap, "PPI")
			datamodel.NET_PROFIT = helper.GetFloatfromMap(jsonmap, "NET_PROFIT")
			datamodel.EQUITY_CAP = helper.GetFloatfromMap(jsonmap, "EQUITY_CAP")
			datamodel.FV = helper.GetFloatfromMap(jsonmap, "FV")
			datamodel.RESERVES = helper.GetFloatfromMap(jsonmap, "RESERVES")
			datamodel.PREF_CAP = helper.GetFloatfromMap(jsonmap, "PREF_CAP")
			datamodel.EPSABS = helper.GetFloatfromMap(jsonmap, "EPSABS")
			datamodel.PROM_NO_OF_SHARES = helper.GetFloatfromMap(jsonmap, "PROM_NO_OF_SHARES")
			datamodel.PROM_PERCENT_OF_SHARES = helper.GetFloatfromMap(jsonmap, "PROM_PERCENT_OF_SHARES")
			datamodel.OPERATING_PROFIT_MARGIN = helper.GetFloatfromMap(jsonmap, "OPERATING_PROFIT_MARGIN")
			datamodel.NET_PROFIT_MARGIN = helper.GetFloatfromMap(jsonmap, "NET_PROFIT_MARGIN")
			datamodel.CAP_RATIO_PERCENT = helper.GetFloatfromMap(jsonmap, "CAP_RATIO_PERCENT")
			datamodel.Minority_interest = helper.GetFloatfromMap(jsonmap, "Minority_interest")
			datamodel.Shares_Associate = helper.GetFloatfromMap(jsonmap, "Shares_Associate")
			datamodel.Other_related_items = helper.GetFloatfromMap(jsonmap, "Other_related_items")
			datamodel.Misc_expd_woff = helper.GetFloatfromMap(jsonmap, "Misc_expd_woff")
			datamodel.Consolidated_net_profit = helper.GetFloatfromMap(jsonmap, "Consolidated_net_profit")
			datamodel.NOTES = helper.GetFloatfromMap(jsonmap, "NOTES")
			datamodel.CASA = helper.GetFloatfromMap(jsonmap, "CASA")
			datamodel.CASA_Amount = helper.GetFloatfromMap(jsonmap, "CASA_Amount")
			datamodel.NIM = helper.GetFloatfromMap(jsonmap, "NIM")
			datamodel.Provisions_Coverage = helper.GetFloatfromMap(jsonmap, "Provisions_Coverage")
			datamodel.No_of_ATMs = helper.GetFloatfromMap(jsonmap, "No_of_ATMs")
			datamodel.No_of_Branches = helper.GetFloatfromMap(jsonmap, "No_of_Branches")
			datamodel.Tier_I_Basel_II = helper.GetFloatfromMap(jsonmap, "Tier_I_Basel_II")
			datamodel.Tier_2_Basel_II = helper.GetFloatfromMap(jsonmap, "Tier_2_Basel_II")
			datamodel.Adj_eps_abs = helper.GetFloatfromMap(jsonmap, "Adj_eps_abs")
			datamodel.Operating_Ex = helper.GetFloatfromMap(jsonmap, "Operating_Ex")
			datamodel.Exception_Items = helper.GetFloatfromMap(jsonmap, "Exception_Items")
			datamodel.NPA_Gross = helper.GetFloatfromMap(jsonmap, "NPA_Gross")
			datamodel.NPA_Net = helper.GetFloatfromMap(jsonmap, "NPA_Net")
			datamodel.NPA_Gross_perc = helper.GetFloatfromMap(jsonmap, "NPA_Gross_perc")
			datamodel.NPA_Net_perc = helper.GetFloatfromMap(jsonmap, "NPA_Net_perc")
			datamodel.Job_works = helper.GetFloatfromMap(jsonmap, "job_works")
			datamodel.Cash_bank = helper.GetFloatfromMap(jsonmap, "Cash_bank")
			datamodel.Debtors = helper.GetFloatfromMap(jsonmap, "Debtors")
			datamodel.Inventory = helper.GetFloatfromMap(jsonmap, "Inventory")
			datamodel.Loans_adv = helper.GetFloatfromMap(jsonmap, "Loans_adv")
			datamodel.Return_on_Capital_Employed = helper.GetFloatfromMap(jsonmap, "Return on Capital Employed")
			datamodel.NsGrandTotal = helper.GetFloatfromMap(jsonmap, "nsGrandTotal")
			datamodel.Debt_Or_Equity_Ratio = helper.GetFloatfromMap(jsonmap, "Debt/Equity Ratio")
			datamodel.Interest_Coverage_Ratio = helper.GetFloatfromMap(jsonmap, "Interest Coverage Ratio")
			datamodel.Inventory_Turnover_Ratio = helper.GetFloatfromMap(jsonmap, "Inventory Turnover Ratio")
			datamodel.Debtor_Turnover_Ratio = helper.GetFloatfromMap(jsonmap, "Debtor Turnover Ratio")
			datamodel.Dividend_per_share = helper.GetFloatfromMap(jsonmap, "Dividend per share")
			datamodel.Dividend_payout_ratio = helper.GetFloatfromMap(jsonmap, "Dividend payout ratio")
			datamodel.Gross_sale = helper.GetFloatfromMap(jsonmap, "gross_sale")
			datamodel.Excise_duty = helper.GetFloatfromMap(jsonmap, "excise_duty")
			datamodel.Other_netsales = helper.GetFloatfromMap(jsonmap, "other_netsales")
			datamodel.Inc_Dec_Inventory = helper.GetFloatfromMap(jsonmap, "Inc_Dec_Inventory")
			datamodel.Purchase_fin_good = helper.GetFloatfromMap(jsonmap, "Purchase_fin_good")
			datamodel.Raw_Material_Cost = helper.GetFloatfromMap(jsonmap, "Raw_Material_Cost")
			datamodel.Excise = helper.GetFloatfromMap(jsonmap, "Excise")
			datamodel.Mfg_Exps = helper.GetFloatfromMap(jsonmap, "Mfg_Exps")
			datamodel.Electricity_Power_Fuel = helper.GetFloatfromMap(jsonmap, "Electricity_Power_Fuel")
			datamodel.Exployee_Cost = helper.GetFloatfromMap(jsonmap, "Exployee_Cost")
			datamodel.Gen_AdminExpenses = helper.GetFloatfromMap(jsonmap, "Gen_AdminExpenses")
			datamodel.Selling_Dist_Expenses = helper.GetFloatfromMap(jsonmap, "Selling_Dist_Expenses")
			datamodel.Loss_foreign_exchange = helper.GetFloatfromMap(jsonmap, "loss_foreign_exchange")
			datamodel.LossForeignExchangeLoan = helper.GetFloatfromMap(jsonmap, "LossForeignExchangeLoan")
			datamodel.Misc_Expenses = helper.GetFloatfromMap(jsonmap, "Misc_Expenses")
			datamodel.EPS_DILUTED = helper.GetFloatfromMap(jsonmap, "EPS_DILUTED")
			datamodel.Promoter_NOS = helper.GetFloatfromMap(jsonmap, "Promoter_NOS")
			datamodel.Encumbered_NOS = helper.GetFloatfromMap(jsonmap, "Encumbered_NOS")
			datamodel.Percentage_PledgedPromoter = helper.GetFloatfromMap(jsonmap, "Percentage_PledgedPromoter")
			datamodel.Percentage_PledgedCapital = helper.GetFloatfromMap(jsonmap, "Percentage_PledgedCapital")
			datamodel.NonPledgedEncum = helper.GetFloatfromMap(jsonmap, "NonPledgedEncum")
			datamodel.NonPledged_NOS = helper.GetFloatfromMap(jsonmap, "NonPledged_NOS")
			datamodel.Percentage_NonPledgedPromoter = helper.GetFloatfromMap(jsonmap, "Percentage_NonPledgedPromoter")
			datamodel.Percentage_NonPledgedCapital = helper.GetFloatfromMap(jsonmap, "Percentage_NonPledgedCapital")
			datamodel.Roa = helper.GetFloatfromMap(jsonmap, "Roa")
			datamodel.Prov_Emp = helper.GetFloatfromMap(jsonmap, "Prov_Emp")
			datamodel.Other_Exp = helper.GetFloatfromMap(jsonmap, "Other_Exp")
			datamodel.Cap_Ratio_Percent3 = helper.GetFloatfromMap(jsonmap, "Cap_Ratio_Percent3")
			datamodel.Tier1basel3 = helper.GetFloatfromMap(jsonmap, "Tier1basel3")
			datamodel.Tier2basel3 = helper.GetFloatfromMap(jsonmap, "Tier2basel3")
			datamodel.PBIDTMEXOI = helper.GetFloatfromMap(jsonmap, "PBIDTMEXOI")
			datamodel.PBIDTM = helper.GetFloatfromMap(jsonmap, "PBIDTM")
			datamodel.PBDTM = helper.GetFloatfromMap(jsonmap, "PBDTM")
			datamodel.PBTM = helper.GetFloatfromMap(jsonmap, "PBTM")
			datamodel.PATM = helper.GetFloatfromMap(jsonmap, "PATM")
			datamodel.Other_Adjustments = helper.GetFloatfromMap(jsonmap, "Other_Adjustments")
			datamodel.EPS_BASIC = helper.GetFloatfromMap(jsonmap, "EPS_BASIC")
			datamodel.EPS_BASIC_EXTRAORD = helper.GetFloatfromMap(jsonmap, "EPS_BASIC_EXTRAORD")
			datamodel.Govt_Percent_Of_Shares = helper.GetFloatfromMap(jsonmap, "Govt_Percent_Of_Shares")
			datamodel.Gross_Net_Npa = helper.GetFloatfromMap(jsonmap, "Gross_Net_Npa")
			datamodel.Perc_Gross_Net_Npa = helper.GetFloatfromMap(jsonmap, "Perc_Gross_Net_Npa")
			datamodel.EPS_DILUTED_EXTRAORD = helper.GetFloatfromMap(jsonmap, "EPS_DILUTED_EXTRAORD")
			datamodel.EPSann = helper.GetFloatfromMap(jsonmap, "EPSann")
			datamodel.NsTotalpublic = helper.GetFloatfromMap(jsonmap, "nsTotalpublic")
			datamodel.TpTotalpublic = helper.GetFloatfromMap(jsonmap, "tpTotalpublic")
			datamodel.Dividend_Income = helper.GetFloatfromMap(jsonmap, "Dividend_Income")
			datamodel.Export_Incentives = helper.GetFloatfromMap(jsonmap, "Export_Incentives")
			datamodel.Foreign_exchange_gain = helper.GetFloatfromMap(jsonmap, "Foreign_exchange_gain")
			datamodel.Profit_Investment = helper.GetFloatfromMap(jsonmap, "Profit_Investment")
			datamodel.Other_Interest_income = helper.GetFloatfromMap(jsonmap, "Other_Interest_income")
			datamodel.Rental_income = helper.GetFloatfromMap(jsonmap, "rental_income")
			datamodel.Sale_Shares_Units = helper.GetFloatfromMap(jsonmap, "Sale_Shares_Units")
			datamodel.Prov_written_back = helper.GetFloatfromMap(jsonmap, "Prov_written_back")
			datamodel.Sale_Assets = helper.GetFloatfromMap(jsonmap, "Sale_Assets")
			datamodel.Other_Other_Income = helper.GetFloatfromMap(jsonmap, "Other_Other_Income")
			datamodel.Pbidtxoi = helper.GetFloatfromMap(jsonmap, "pbidtxoi")
			datamodel.Exc_foreign_exch_gain = helper.GetFloatfromMap(jsonmap, "exc_foreign_exch_gain")
			datamodel.Exc_other = helper.GetFloatfromMap(jsonmap, "exc_other")
			datamodel.Curr_tax = helper.GetFloatfromMap(jsonmap, "Curr_tax")
			datamodel.Def_tax = helper.GetFloatfromMap(jsonmap, "Def_tax")
			datamodel.Fringe_benefits = helper.GetFloatfromMap(jsonmap, "Fringe_benefits")
			datamodel.Prior_Period_Tax = helper.GetFloatfromMap(jsonmap, "Prior_Period_Tax")
			datamodel.Mat_Credit = helper.GetFloatfromMap(jsonmap, "Mat_Credit")
			datamodel.Other_Tax = helper.GetFloatfromMap(jsonmap, "Other_Tax")
			datamodel.Flag = helper.GetStringfromMap(jsonmap, "flag")
			fincode := strconv.Itoa(datamodel.Fincode)
			resultType := datamodel.Result_Type
			dateEnd := strconv.Itoa(datamodel.Date_End)
			datamodel.ID = fincode + "_" + resultType + "_" + dateEnd
			//	datamodel.Model = jsonmap["Model"].(int)

			// err = tx.Save(&datamodel).Error
			// if err != nil {
			// 	buffer.WriteString(err.Error())
			// }
			datamodelUpdate = append(datamodelUpdate, datamodel)
			count++

		}
		err := db.Accord.Clauses(clause.OnConflict{
			Columns:   []clause.Column{{Name: "id"}}, //, {Name: "invdate"}, {Name: "srno"}},
			DoUpdates: clause.AssignmentColumns([]string{"fincode", "result_type", "no_of_months", "date_end", "net_sales", "int_adv", "inc_inv", "int_bal", "int_others", "other_income", "total_income", "expenditure", "operating_profit", "interest", "gross_profit", "depreciation", "pbt", "pac", "tax", "pat", "ei", "ppi", "net_profit", "eq_ui_ty_cap", "fv", "reserves", "pref_cap", "epsabs", "prom_no_of_shares", "prom_percent_of_shares", "operating_profit_margin", "net_profit_margin", "cap_ratio_percent", "minority_interest", "shares_associate", "other_related_items", "misc_expd_woff", "consolidated_net_profit", "notes", "casa", "casa_amount", "nim", "provisions_coverage", "no_of_at_ms", "no_of_branches", "tier_i_basel_ii", "tier_2_basel_ii", "adj_eps_abs", "operating_ex", "exception_items", "npa_gross", "npa_net", "npa_gross_perc", "npa_net_perc", "job_works", "cash_bank", "debtors", "inventory", "loans_adv", "return_on_capital_employed", "ns_grand_total", "debt_or_equity_ratio", "interest_coverage_ratio", "inventory_turnover_ratio", "debtor_turnover_ratio", "dividend_per_share", "dividend_payout_ratio", "gross_sale", "excise_duty", "other_netsales", "inc_dec_inventory", "purchase_fin_good", "raw_material_cost", "excise", "mfg_exps", "electricity_power_fuel", "exployee_cost", "gen_admin_expenses", "selling_dist_expenses", "loss_foreign_exchange", "loss_foreign_exchange_loan", "misc_expenses", "eps_diluted", "promoter_nos", "encumbered_nos", "percentage_pledged_promoter", "percentage_pledged_capital", "non_pledged_encum", "non_pledged_nos", "percentage_non_pledged_promoter", "percentage_non_pledged_capital", "roa", "prov_emp", "other_exp", "cap_ratio_percent3", "tier1basel3", "tier2basel3", "pb_id_tmexoi", "pb_id_tm", "pbdtm", "pbtm", "patm", "other_adjustments", "eps_basic", "eps_basic_extraord", "govt_percent_of_shares", "gross_net_npa", "perc_gross_net_npa", "eps_diluted_extraord", "ep_sann", "ns_totalpublic", "tp_totalpublic", "dividend_income", "export_incentives", "foreign_exchange_gain", "profit_investment", "other_interest_income", "rental_income", "sale_shares_units", "prov_written_back", "sale_assets", "other_other_income", "pbidtxoi", "exc_foreign_exch_gain", "exc_other", "curr_tax", "def_tax", "fringe_benefits", "prior_period_tax", "mat_credit", "other_tax", "flag"}),
			//DoUpdates: clause.AssignmentColumns([]string{"rating"}),
		}).CreateInBatches(&datamodelUpdate, 300).Error
		if err != nil {
			fmt.Println(err)
			Zerologs.Error().Msg("Error while Inserting data into Nsemonthprice")
		}
		Zerologs.Info().Msgf(" execution time for quaterly ==>", time.Since(start))
		buffer.WriteString("Total Record updated " + strconv.Itoa(count) + "\n")

		return nil
	})

	// })
	return nil
}

func Quarterly_Cons(strjson []byte, buffer *bytes.Buffer) error {
	var arryJson []interface{}
	if err := json.Unmarshal(strjson, &arryJson); err != nil {
		buffer.WriteString(err.Error() + "\n")
		return err
	}
	var datamodelUpdate []accord.Quarterly_Cons
	count := 0
	// q.Enqueue(arryJson, func(data interface{}) {
	db.Accord.Transaction(func(tx *gorm.DB) error {
		start := time.Now()
		for _, json := range arryJson {
			jsonmap := json.(map[string]interface{})
			datamodel := accord.Quarterly_Cons{}
			datamodel.Fincode = helper.GetIntfromMap(jsonmap, "Fincode")
			datamodel.Result_Type = helper.GetStringfromMap(jsonmap, "Result_Type")
			datamodel.Date_End = helper.GetIntfromMap(jsonmap, "Date_End")
			// err := tx.Where("fincode=? AND result_type=? AND date_end=?", datamodel.Fincode, datamodel.Result_Type, datamodel.Date_End).First(&datamodel).Error

			// if err != nil {
			// 	Zerologs.Error().Msg("Record Not Found In Quaterly" + err.Error())
			// }
			datamodel.NoOfMonths = helper.GetIntfromMap(jsonmap, "NoOfMonths")
			datamodel.NET_SALES = helper.GetFloatfromMap(jsonmap, "NET_SALES")
			datamodel.INT_ADV = helper.GetFloatfromMap(jsonmap, "INT_ADV")
			datamodel.INC_INV = helper.GetFloatfromMap(jsonmap, "INC_INV")
			datamodel.INT_BAL = helper.GetFloatfromMap(jsonmap, "INT_BAL")
			datamodel.INT_OTHERS = helper.GetFloatfromMap(jsonmap, "INT_OTHERS")
			datamodel.OTHER_INCOME = helper.GetFloatfromMap(jsonmap, "OTHER_INCOME")
			datamodel.TOTAL_INCOME = helper.GetFloatfromMap(jsonmap, "TOTAL_INCOME")
			datamodel.EXPENDITURE = helper.GetFloatfromMap(jsonmap, "EXPENDITURE")
			datamodel.OPERATING_PROFIT = helper.GetFloatfromMap(jsonmap, "OPERATING_PROFIT")
			datamodel.INTEREST = helper.GetFloatfromMap(jsonmap, "INTEREST")
			datamodel.GROSS_PROFIT = helper.GetFloatfromMap(jsonmap, "GROSS_PROFIT")
			datamodel.DEPRECIATION = helper.GetFloatfromMap(jsonmap, "DEPRECIATION")
			datamodel.PBT = helper.GetFloatfromMap(jsonmap, "PBT")
			datamodel.PAC = helper.GetFloatfromMap(jsonmap, "PAC")
			datamodel.TAX = helper.GetFloatfromMap(jsonmap, "TAX")
			datamodel.PAT = helper.GetFloatfromMap(jsonmap, "PAT")
			datamodel.EI = helper.GetFloatfromMap(jsonmap, "EI")
			datamodel.PPI = helper.GetFloatfromMap(jsonmap, "PPI")
			datamodel.NET_PROFIT = helper.GetFloatfromMap(jsonmap, "NET_PROFIT")
			datamodel.EQUITY_CAP = helper.GetFloatfromMap(jsonmap, "EQUITY_CAP")
			datamodel.FV = helper.GetFloatfromMap(jsonmap, "FV")
			datamodel.RESERVES = helper.GetFloatfromMap(jsonmap, "RESERVES")
			datamodel.PREF_CAP = helper.GetFloatfromMap(jsonmap, "PREF_CAP")
			datamodel.EPSABS = helper.GetFloatfromMap(jsonmap, "EPSABS")
			datamodel.PROM_NO_OF_SHARES = helper.GetFloatfromMap(jsonmap, "PROM_NO_OF_SHARES")
			datamodel.PROM_PERCENT_OF_SHARES = helper.GetFloatfromMap(jsonmap, "PROM_PERCENT_OF_SHARES")
			datamodel.OPERATING_PROFIT_MARGIN = helper.GetFloatfromMap(jsonmap, "OPERATING_PROFIT_MARGIN")
			datamodel.NET_PROFIT_MARGIN = helper.GetFloatfromMap(jsonmap, "NET_PROFIT_MARGIN")
			datamodel.CAP_RATIO_PERCENT = helper.GetFloatfromMap(jsonmap, "CAP_RATIO_PERCENT")
			datamodel.Minority_interest = helper.GetFloatfromMap(jsonmap, "Minority_interest")
			datamodel.Shares_Associate = helper.GetFloatfromMap(jsonmap, "Shares_Associate")
			datamodel.Other_related_items = helper.GetFloatfromMap(jsonmap, "Other_related_items")
			datamodel.Misc_expd_woff = helper.GetFloatfromMap(jsonmap, "Misc_expd_woff")
			datamodel.Consolidated_net_profit = helper.GetFloatfromMap(jsonmap, "Consolidated_net_profit")
			datamodel.NOTES = helper.GetFloatfromMap(jsonmap, "NOTES")
			datamodel.CASA = helper.GetFloatfromMap(jsonmap, "CASA")
			datamodel.CASA_Amount = helper.GetFloatfromMap(jsonmap, "CASA_Amount")
			datamodel.NIM = helper.GetFloatfromMap(jsonmap, "NIM")
			datamodel.Provisions_Coverage = helper.GetFloatfromMap(jsonmap, "Provisions_Coverage")
			datamodel.No_of_ATMs = helper.GetFloatfromMap(jsonmap, "No_of_ATMs")
			datamodel.No_of_Branches = helper.GetFloatfromMap(jsonmap, "No_of_Branches")
			datamodel.Tier_I_Basel_II = helper.GetFloatfromMap(jsonmap, "Tier_I_Basel_II")
			datamodel.Tier_2_Basel_II = helper.GetFloatfromMap(jsonmap, "Tier_2_Basel_II")
			datamodel.Adj_eps_abs = helper.GetFloatfromMap(jsonmap, "Adj_eps_abs")
			datamodel.Operating_Ex = helper.GetFloatfromMap(jsonmap, "Operating_Ex")
			datamodel.Exception_Items = helper.GetFloatfromMap(jsonmap, "Exception_Items")
			datamodel.NPA_Gross = helper.GetFloatfromMap(jsonmap, "NPA_Gross")
			datamodel.NPA_Net = helper.GetFloatfromMap(jsonmap, "NPA_Net")
			datamodel.NPA_Gross_perc = helper.GetFloatfromMap(jsonmap, "NPA_Gross_perc")
			datamodel.NPA_Net_perc = helper.GetFloatfromMap(jsonmap, "NPA_Net_perc")
			datamodel.Job_works = helper.GetFloatfromMap(jsonmap, "job_works")
			datamodel.Cash_bank = helper.GetFloatfromMap(jsonmap, "Cash_bank")
			datamodel.Debtors = helper.GetFloatfromMap(jsonmap, "Debtors")
			datamodel.Inventory = helper.GetFloatfromMap(jsonmap, "Inventory")
			datamodel.Loans_adv = helper.GetFloatfromMap(jsonmap, "Loans_adv")
			datamodel.Return_on_Capital_Employed = helper.GetFloatfromMap(jsonmap, "Return on Capital Employed")
			datamodel.NsGrandTotal = helper.GetFloatfromMap(jsonmap, "nsGrandTotal")
			datamodel.Debt_Or_Equity_Ratio = helper.GetFloatfromMap(jsonmap, "Debt/Equity Ratio")
			datamodel.Interest_Coverage_Ratio = helper.GetFloatfromMap(jsonmap, "Interest Coverage Ratio")
			datamodel.Inventory_Turnover_Ratio = helper.GetFloatfromMap(jsonmap, "Inventory Turnover Ratio")
			datamodel.Debtor_Turnover_Ratio = helper.GetFloatfromMap(jsonmap, "Debtor Turnover Ratio")
			datamodel.Dividend_per_share = helper.GetFloatfromMap(jsonmap, "Dividend per share")
			datamodel.Dividend_payout_ratio = helper.GetFloatfromMap(jsonmap, "Dividend payout ratio")
			datamodel.Gross_sale = helper.GetFloatfromMap(jsonmap, "gross_sale")
			datamodel.Excise_duty = helper.GetFloatfromMap(jsonmap, "excise_duty")
			datamodel.Other_netsales = helper.GetFloatfromMap(jsonmap, "other_netsales")
			datamodel.Inc_Dec_Inventory = helper.GetFloatfromMap(jsonmap, "Inc_Dec_Inventory")
			datamodel.Purchase_fin_good = helper.GetFloatfromMap(jsonmap, "Purchase_fin_good")
			datamodel.Raw_Material_Cost = helper.GetFloatfromMap(jsonmap, "Raw_Material_Cost")
			datamodel.Excise = helper.GetFloatfromMap(jsonmap, "Excise")
			datamodel.Mfg_Exps = helper.GetFloatfromMap(jsonmap, "Mfg_Exps")
			datamodel.Electricity_Power_Fuel = helper.GetFloatfromMap(jsonmap, "Electricity_Power_Fuel")
			datamodel.Exployee_Cost = helper.GetFloatfromMap(jsonmap, "Exployee_Cost")
			datamodel.Gen_AdminExpenses = helper.GetFloatfromMap(jsonmap, "Gen_AdminExpenses")
			datamodel.Selling_Dist_Expenses = helper.GetFloatfromMap(jsonmap, "Selling_Dist_Expenses")
			datamodel.Loss_foreign_exchange = helper.GetFloatfromMap(jsonmap, "loss_foreign_exchange")
			datamodel.LossForeignExchangeLoan = helper.GetFloatfromMap(jsonmap, "LossForeignExchangeLoan")
			datamodel.Misc_Expenses = helper.GetFloatfromMap(jsonmap, "Misc_Expenses")
			datamodel.EPS_DILUTED = helper.GetFloatfromMap(jsonmap, "EPS_DILUTED")
			datamodel.Promoter_NOS = helper.GetFloatfromMap(jsonmap, "Promoter_NOS")
			datamodel.Encumbered_NOS = helper.GetFloatfromMap(jsonmap, "Encumbered_NOS")
			datamodel.Percentage_PledgedPromoter = helper.GetFloatfromMap(jsonmap, "Percentage_PledgedPromoter")
			datamodel.Percentage_PledgedCapital = helper.GetFloatfromMap(jsonmap, "Percentage_PledgedCapital")
			datamodel.NonPledgedEncum = helper.GetFloatfromMap(jsonmap, "NonPledgedEncum")
			datamodel.NonPledged_NOS = helper.GetFloatfromMap(jsonmap, "NonPledged_NOS")
			datamodel.Percentage_NonPledgedPromoter = helper.GetFloatfromMap(jsonmap, "Percentage_NonPledgedPromoter")
			datamodel.Percentage_NonPledgedCapital = helper.GetFloatfromMap(jsonmap, "Percentage_NonPledgedCapital")
			datamodel.Roa = helper.GetFloatfromMap(jsonmap, "Roa")
			datamodel.Prov_Emp = helper.GetFloatfromMap(jsonmap, "Prov_Emp")
			datamodel.Other_Exp = helper.GetFloatfromMap(jsonmap, "Other_Exp")
			datamodel.Cap_Ratio_Percent3 = helper.GetFloatfromMap(jsonmap, "Cap_Ratio_Percent3")
			datamodel.Tier1basel3 = helper.GetFloatfromMap(jsonmap, "Tier1basel3")
			datamodel.Tier2basel3 = helper.GetFloatfromMap(jsonmap, "Tier2basel3")
			datamodel.PBIDTMEXOI = helper.GetFloatfromMap(jsonmap, "PBIDTMEXOI")
			datamodel.PBIDTM = helper.GetFloatfromMap(jsonmap, "PBIDTM")
			datamodel.PBDTM = helper.GetFloatfromMap(jsonmap, "PBDTM")
			datamodel.PBTM = helper.GetFloatfromMap(jsonmap, "PBTM")
			datamodel.PATM = helper.GetFloatfromMap(jsonmap, "PATM")
			datamodel.Other_Adjustments = helper.GetFloatfromMap(jsonmap, "Other_Adjustments")
			datamodel.EPS_BASIC = helper.GetFloatfromMap(jsonmap, "EPS_BASIC")
			datamodel.EPS_BASIC_EXTRAORD = helper.GetFloatfromMap(jsonmap, "EPS_BASIC_EXTRAORD")
			datamodel.Govt_Percent_Of_Shares = helper.GetFloatfromMap(jsonmap, "Govt_Percent_Of_Shares")
			datamodel.Gross_Net_Npa = helper.GetFloatfromMap(jsonmap, "Gross_Net_Npa")
			datamodel.Perc_Gross_Net_Npa = helper.GetFloatfromMap(jsonmap, "Perc_Gross_Net_Npa")
			datamodel.EPS_DILUTED_EXTRAORD = helper.GetFloatfromMap(jsonmap, "EPS_DILUTED_EXTRAORD")
			datamodel.EPSann = helper.GetFloatfromMap(jsonmap, "EPSann")
			datamodel.NsTotalpublic = helper.GetFloatfromMap(jsonmap, "nsTotalpublic")
			datamodel.TpTotalpublic = helper.GetFloatfromMap(jsonmap, "tpTotalpublic")
			datamodel.Dividend_Income = helper.GetFloatfromMap(jsonmap, "Dividend_Income")
			datamodel.Export_Incentives = helper.GetFloatfromMap(jsonmap, "Export_Incentives")
			datamodel.Foreign_exchange_gain = helper.GetFloatfromMap(jsonmap, "Foreign_exchange_gain")
			datamodel.Profit_Investment = helper.GetFloatfromMap(jsonmap, "Profit_Investment")
			datamodel.Other_Interest_income = helper.GetFloatfromMap(jsonmap, "Other_Interest_income")
			datamodel.Rental_income = helper.GetFloatfromMap(jsonmap, "rental_income")
			datamodel.Sale_Shares_Units = helper.GetFloatfromMap(jsonmap, "Sale_Shares_Units")
			datamodel.Prov_written_back = helper.GetFloatfromMap(jsonmap, "Prov_written_back")
			datamodel.Sale_Assets = helper.GetFloatfromMap(jsonmap, "Sale_Assets")
			datamodel.Other_Other_Income = helper.GetFloatfromMap(jsonmap, "Other_Other_Income")
			datamodel.Pbidtxoi = helper.GetFloatfromMap(jsonmap, "pbidtxoi")
			datamodel.Exc_foreign_exch_gain = helper.GetFloatfromMap(jsonmap, "exc_foreign_exch_gain")
			datamodel.Exc_other = helper.GetFloatfromMap(jsonmap, "exc_other")
			datamodel.Curr_tax = helper.GetFloatfromMap(jsonmap, "Curr_tax")
			datamodel.Def_tax = helper.GetFloatfromMap(jsonmap, "Def_tax")
			datamodel.Fringe_benefits = helper.GetFloatfromMap(jsonmap, "Fringe_benefits")
			datamodel.Prior_Period_Tax = helper.GetFloatfromMap(jsonmap, "Prior_Period_Tax")
			datamodel.Mat_Credit = helper.GetFloatfromMap(jsonmap, "Mat_Credit")
			datamodel.Other_Tax = helper.GetFloatfromMap(jsonmap, "Other_Tax")
			datamodel.Flag = helper.GetStringfromMap(jsonmap, "flag")
			fincode := strconv.Itoa(datamodel.Fincode)
			resultType := datamodel.Result_Type
			dateEnd := strconv.Itoa(datamodel.Date_End)
			datamodel.ID = fincode + "_" + resultType + "_" + dateEnd
			//	datamodel.Model = jsonmap["Model"].(int)

			// err = tx.Save(&datamodel).Error
			// if err != nil {
			// 	buffer.WriteString(err.Error())
			// }
			datamodelUpdate = append(datamodelUpdate, datamodel)
			count++

		}
		err := db.Accord.Clauses(clause.OnConflict{
			Columns:   []clause.Column{{Name: "id"}}, //, {Name: "invdate"}, {Name: "srno"}},
			DoUpdates: clause.AssignmentColumns([]string{"fincode", "result_type", "no_of_months", "date_end", "net_sales", "int_adv", "inc_inv", "int_bal", "int_others", "other_income", "total_income", "expenditure", "operating_profit", "interest", "gross_profit", "depreciation", "pbt", "pac", "tax", "pat", "ei", "ppi", "net_profit", "eq_ui_ty_cap", "fv", "reserves", "pref_cap", "epsabs", "prom_no_of_shares", "prom_percent_of_shares", "operating_profit_margin", "net_profit_margin", "cap_ratio_percent", "minority_interest", "shares_associate", "other_related_items", "misc_expd_woff", "consolidated_net_profit", "notes", "casa", "casa_amount", "nim", "provisions_coverage", "no_of_at_ms", "no_of_branches", "tier_i_basel_ii", "tier_2_basel_ii", "adj_eps_abs", "operating_ex", "exception_items", "npa_gross", "npa_net", "npa_gross_perc", "npa_net_perc", "job_works", "cash_bank", "debtors", "inventory", "loans_adv", "return_on_capital_employed", "ns_grand_total", "debt_or_equity_ratio", "interest_coverage_ratio", "inventory_turnover_ratio", "debtor_turnover_ratio", "dividend_per_share", "dividend_payout_ratio", "gross_sale", "excise_duty", "other_netsales", "inc_dec_inventory", "purchase_fin_good", "raw_material_cost", "excise", "mfg_exps", "electricity_power_fuel", "exployee_cost", "gen_admin_expenses", "selling_dist_expenses", "loss_foreign_exchange", "loss_foreign_exchange_loan", "misc_expenses", "eps_diluted", "promoter_nos", "encumbered_nos", "percentage_pledged_promoter", "percentage_pledged_capital", "non_pledged_encum", "non_pledged_nos", "percentage_non_pledged_promoter", "percentage_non_pledged_capital", "roa", "prov_emp", "other_exp", "cap_ratio_percent3", "tier1basel3", "tier2basel3", "pb_id_tmexoi", "pb_id_tm", "pbdtm", "pbtm", "patm", "other_adjustments", "eps_basic", "eps_basic_extraord", "govt_percent_of_shares", "gross_net_npa", "perc_gross_net_npa", "eps_diluted_extraord", "ep_sann", "ns_totalpublic", "tp_totalpublic", "dividend_income", "export_incentives", "foreign_exchange_gain", "profit_investment", "other_interest_income", "rental_income", "sale_shares_units", "prov_written_back", "sale_assets", "other_other_income", "pbidtxoi", "exc_foreign_exch_gain", "exc_other", "curr_tax", "def_tax", "fringe_benefits", "prior_period_tax", "mat_credit", "other_tax", "flag"}),
			// DoUpdates: clause.AssignmentColumns([]string{"rating"}),
		}).CreateInBatches(&datamodelUpdate, 300).Error
		if err != nil {
			fmt.Println(err)
			Zerologs.Error().Msg("Error while Inserting data into QuaterlyCons")
		}
		Zerologs.Info().Msgf(" execution time for quaterly_cons ==>", time.Since(start))
		buffer.WriteString("Total Record updated " + strconv.Itoa(count) + "\n")

		return nil
	})

	// })
	return nil
}

func Registrardata(strjson []byte, buffer *bytes.Buffer) error {
	var arryJson []interface{}
	if err := json.Unmarshal(strjson, &arryJson); err != nil {
		buffer.WriteString(err.Error() + "\n")
		return err
	}
	var datamodelUpdate []accord.Registrardata
	count := 0
	// q.Enqueue(arryJson, func(data interface{}) {
	db.Accord.Transaction(func(tx *gorm.DB) error {
		start := time.Now()
		for _, json := range arryJson {
			jsonmap := json.(map[string]interface{})
			datamodel := accord.Registrardata{}
			datamodel.FINCODE = helper.GetIntfromMap(jsonmap, "FINCODE")
			datamodel.RegistrarNo = helper.GetIntfromMap(jsonmap, "RegistrarNo")
			// err := tx.Where("fincode=? AND registrar_no=?", datamodel.FINCODE, datamodel.RegistrarNo).First(&datamodel).Error

			// if err != nil {
			// 	Zerologs.Error().Msg("Record Not Found In Registerdata" + err.Error())
			// }
			datamodel.Flag = helper.GetStringfromMap(jsonmap, "Flag")
			fincode := strconv.Itoa(datamodel.FINCODE)
			registrarNo := strconv.Itoa(datamodel.RegistrarNo)
			datamodel.ID = fincode + "_" + registrarNo
			// datamodel.Model = jsonmap["Model"].(int)

			// err = tx.Save(&datamodel).Error
			// if err != nil {
			// 	buffer.WriteString(err.Error())
			// }
			datamodelUpdate = append(datamodelUpdate, datamodel)
			count++
		}
		err := db.Accord.Clauses(clause.OnConflict{
			Columns:   []clause.Column{{Name: "id"}}, //, {Name: "invdate"}, {Name: "srno"}},
			DoUpdates: clause.AssignmentColumns([]string{"fincode", "registrar_no", "flag"}),
			// DoUpdates: clause.AssignmentColumns([]string{"rating"}),
		}).CreateInBatches(&datamodelUpdate, 1000).Error
		if err != nil {
			fmt.Println(err)
			Zerologs.Error().Msg("Error while Inserting data into registrardata")
		}
		Zerologs.Info().Msgf(" execution time for registrardata ==>", time.Since(start))
		buffer.WriteString("Total Record updated " + strconv.Itoa(count) + "\n")
		return nil
	})

	// })
	return nil
}

func Registrarmaster(strjson []byte, buffer *bytes.Buffer) error {
	var arryJson []interface{}
	if err := json.Unmarshal(strjson, &arryJson); err != nil {
		buffer.WriteString(err.Error() + "\n")
		return err
	}
	var datamodelUpdate []accord.Registrarmaster
	count := 0
	// q.Enqueue(arryJson, func(data interface{}) {
	db.Accord.Transaction(func(tx *gorm.DB) error {
		start := time.Now()
		for _, json := range arryJson {
			jsonmap := json.(map[string]interface{})
			datamodel := accord.Registrarmaster{}
			datamodel.RegistrarNo = helper.GetIntfromMap(jsonmap, "RegistrarNo")
			// err := tx.Where("registrar_no=?", datamodel.RegistrarNo).First(&datamodel).Error
			// if err != nil {
			// 	Zerologs.Error().Msg("Record Not Found In Registermaster" + err.Error())
			// }
			datamodel.RegistrarName = helper.GetStringfromMap(jsonmap, "RegistrarName")
			datamodel.RegAddress = helper.GetStringfromMap(jsonmap, "RegAddress")
			datamodel.RegistrarAddress1 = helper.GetStringfromMap(jsonmap, "RegistrarAddress1")
			datamodel.RegistrarAddress2 = helper.GetStringfromMap(jsonmap, "RegistrarAddress2")
			datamodel.RegistrarAddress3 = helper.GetStringfromMap(jsonmap, "RegistrarAddress3")
			datamodel.RegistrarPhone = helper.GetStringfromMap(jsonmap, "RegistrarPhone")
			datamodel.RegistrarFax = helper.GetStringfromMap(jsonmap, "RegistrarFax")
			datamodel.RegistrarEMail = helper.GetStringfromMap(jsonmap, "RegistrarEMail")
			datamodel.RegistrarWebSite = helper.GetStringfromMap(jsonmap, "RegistrarWebSite")
			datamodel.Flag = helper.GetStringfromMap(jsonmap, "Flag")
			registrarNo := strconv.Itoa(datamodel.RegistrarNo)
			datamodel.ID = registrarNo
			//datamodel.Model = jsonmap["Model"].(int)

			// err = tx.Save(&datamodel).Error
			// if err != nil {
			// 	buffer.WriteString(err.Error())
			// }
			datamodelUpdate = append(datamodelUpdate, datamodel)
			count++
		}
		err := db.Accord.Clauses(clause.OnConflict{
			Columns:   []clause.Column{{Name: "id"}}, //, {Name: "invdate"}, {Name: "srno"}},
			DoUpdates: clause.AssignmentColumns([]string{"registrar_no", "registrar_name", "reg_address", "registrar_address1", "registrar_address2", "registrar_address3", "registrar_phone", "registrar_fax", "registrar_e_mail", "registrar_web_site", "flag"}),
			// DoUpdates: clause.AssignmentColumns([]string{"rating"}),
		}).CreateInBatches(&datamodelUpdate, 1000).Error
		if err != nil {
			fmt.Println(err)
			Zerologs.Error().Msg("Error while Inserting data into registrarmaster")
		}
		Zerologs.Info().Msgf(" execution time for registrarmaster ==>", time.Since(start))
		buffer.WriteString("Total Record updated " + strconv.Itoa(count) + "\n")
		return nil
	})

	// })
	return nil
}

func Complistings(strjson []byte, buffer *bytes.Buffer) error {
	var arryJson []interface{}
	if err := json.Unmarshal(strjson, &arryJson); err != nil {
		buffer.WriteString(err.Error() + "\n")
		return err
	}
	// var datamodelUpdate []accord.Complistings
	count := 0
	// q.Enqueue(arryJson, func(data interface{}) {
	db.Accord.Transaction(func(tx *gorm.DB) error {
		// start := time.Now()
		for _, json := range arryJson {
			jsonmap := json.(map[string]interface{})
			datamodel := accord.Complistings{}
			datamodel.FINCODE = helper.GetIntfromMap(jsonmap, "FINCODE")
			datamodel.STK_ID = helper.GetIntfromMap(jsonmap, "STK_ID")
			err := tx.Where("fincode=? AND stk_id=? ", datamodel.FINCODE, datamodel.STK_ID).First(&datamodel).Error
			if err != nil {
				Zerologs.Error().Msg("Record Not Found In Companylistnings" + err.Error())
			}
			datamodel.Flag = helper.GetStringfromMap(jsonmap, "FLAG")
			fincode := strconv.Itoa(datamodel.FINCODE)
			stkId := strconv.Itoa(datamodel.STK_ID)
			fincode_stkId := fincode + "_" + stkId
			datamodel.ID = fincode_stkId
			//datamodel.Model = jsonmap["Model"].(int)

			err = tx.Save(&datamodel).Error
			if err != nil {
				buffer.WriteString(err.Error())
			}
			// datamodelUpdate = append(datamodelUpdate, datamodel)
			count++

		}
		// err := db.Accord.Clauses(clause.OnConflict{
		// 	Columns:   []clause.Column{{Name: "id"}}, //, {Name: "invdate"}, {Name: "srno"}},
		// 	DoUpdates: clause.AssignmentColumns([]string{"fincode", "stk_id", "flag"}),
		// 	// DoUpdates: clause.AssignmentColumns([]string{"rating"}),
		// }).CreateInBatches(&datamodelUpdate, 1000).Error
		// if err != nil {
		// 	fmt.Println(err)
		// 	Zerologs.Error().Msg("Error while Inserting data into complistings")
		// }
		// Zerologs.Info().Msgf(" execution time for complistings ==>", time.Since(start))
		buffer.WriteString("Total Record updated " + strconv.Itoa(count) + "\n")
		return nil
	})

	// })
	return nil
}

func Finance_bs(strjson []byte, buffer *bytes.Buffer) error {
	var arryJson []interface{}
	if err := json.Unmarshal(strjson, &arryJson); err != nil {
		buffer.WriteString(err.Error() + "\n")
		return err
	}
	var datamodelUpdate []accord.Finance_bs
	count := 0
	// q.Enqueue(arryJson, func(data interface{}) {
	db.Accord.Transaction(func(tx *gorm.DB) error {
		start := time.Now()
		for _, json := range arryJson {
			jsonmap := json.(map[string]interface{})
			datamodel := accord.Finance_bs{}
			datamodel.Fincode = helper.GetIntfromMap(jsonmap, "Fincode")
			datamodel.Year_end = helper.GetIntfromMap(jsonmap, "Year_end")
			datamodel.Type = helper.GetStringfromMap(jsonmap, "Type")
			// err := tx.Where("fincode=? AND year_end=? AND type=?", datamodel.Fincode, datamodel.Year_end, datamodel.Type).First(&datamodel).Error

			// if err != nil {
			// 	Zerologs.Error().Msg("Record Not Found In Finance_bs" + err.Error())
			// }
			datamodel.No_months = helper.GetIntfromMap(jsonmap, "No_months")
			datamodel.Unit = helper.GetIntfromMap(jsonmap, "Unit")
			datamodel.Share_Capital = helper.GetFloatfromMap(jsonmap, "Share_Capital")
			datamodel.Shares_warrants = helper.GetFloatfromMap(jsonmap, "Shares_warrants")
			datamodel.Shares_application_money = helper.GetFloatfromMap(jsonmap, "Shares_application_money")
			datamodel.ESOP_Outstanding = helper.GetFloatfromMap(jsonmap, "ESOP_Outstanding")
			datamodel.Share_suspense = helper.GetFloatfromMap(jsonmap, "Share_suspense")
			datamodel.Reserve = helper.GetFloatfromMap(jsonmap, "Reserve")
			datamodel.Sharehoders_funds = helper.GetFloatfromMap(jsonmap, "Sharehoders_funds")
			datamodel.Deposits = helper.GetFloatfromMap(jsonmap, "Deposits")
			datamodel.Borrowings = helper.GetFloatfromMap(jsonmap, "Borrowings")
			datamodel.Other_liabilities = helper.GetFloatfromMap(jsonmap, "Other_liabilities")
			datamodel.Total_sounces_Funds = helper.GetFloatfromMap(jsonmap, "Total_sounces_Funds")
			datamodel.Cash_balances_RBI = helper.GetFloatfromMap(jsonmap, "Cash_balances_RBI")
			datamodel.Bank_Call_money = helper.GetFloatfromMap(jsonmap, "Bank_Call_money")
			datamodel.Investments = helper.GetFloatfromMap(jsonmap, "Investments")
			datamodel.Advances = helper.GetFloatfromMap(jsonmap, "Advances")
			datamodel.Gross_block = helper.GetFloatfromMap(jsonmap, "Gross_block")
			datamodel.Acc_Depreciation = helper.GetFloatfromMap(jsonmap, "Acc_Depreciation")
			datamodel.Impairment_assets = helper.GetFloatfromMap(jsonmap, "Impairment_assets")
			datamodel.Lease_adj = helper.GetFloatfromMap(jsonmap, "Lease_adj")
			datamodel.CWIP = helper.GetFloatfromMap(jsonmap, "CWIP")
			datamodel.Other_Assets = helper.GetFloatfromMap(jsonmap, "Other_Assets")
			datamodel.Total_Applications = helper.GetFloatfromMap(jsonmap, "Total_Applications")
			datamodel.Contingent_liabilities = helper.GetFloatfromMap(jsonmap, "Contingent_liabilities")
			datamodel.Bills_For_Collection = helper.GetFloatfromMap(jsonmap, "Bills_For_Collection")
			datamodel.Ltrm_Borrowing = helper.GetFloatfromMap(jsonmap, "Ltrm_Borrowing")
			datamodel.Secured_Loans = helper.GetFloatfromMap(jsonmap, "Secured_Loans")
			datamodel.Unsecured_Loans_Nf = helper.GetFloatfromMap(jsonmap, "Unsecured_Loans_Nf")
			datamodel.Net_Def_Tax_Nf = helper.GetFloatfromMap(jsonmap, "Net_Def_Tax_Nf")
			datamodel.Oth_Lt_Liab = helper.GetFloatfromMap(jsonmap, "Oth_Lt_Liab")
			datamodel.Lt_Trade_Payables = helper.GetFloatfromMap(jsonmap, "Lt_Trade_Payables")
			datamodel.Lt_Provisions = helper.GetFloatfromMap(jsonmap, "Lt_Provisions")
			datamodel.Total_Nonliab = helper.GetFloatfromMap(jsonmap, "Total_Nonliab")
			datamodel.Trade_Payables = helper.GetFloatfromMap(jsonmap, "Trade_Payables")
			datamodel.Current_Liabilities_Nf = helper.GetFloatfromMap(jsonmap, "Current_Liabilities_Nf")
			datamodel.St_Borrowings = helper.GetFloatfromMap(jsonmap, "St_Borrowings")
			datamodel.Provisions = helper.GetFloatfromMap(jsonmap, "Provisions")
			datamodel.Current_Laib_Prov_Nf = helper.GetFloatfromMap(jsonmap, "Current_Laib_Prov_Nf")
			datamodel.Total_Sounces_Funds_Nf = helper.GetFloatfromMap(jsonmap, "Total_Sounces_Funds_Nf")
			datamodel.Non_Current_Assets = helper.GetFloatfromMap(jsonmap, "Non_Current_Assets")
			datamodel.Loan_Non_Cuurent_Assets = helper.GetFloatfromMap(jsonmap, "Loan_Non_Cuurent_Assets")
			datamodel.Net_Block = helper.GetFloatfromMap(jsonmap, "Net_Block")
			datamodel.Cwip_Nf = helper.GetFloatfromMap(jsonmap, "Cwip_Nf")
			datamodel.Intang_Assetunderdev = helper.GetFloatfromMap(jsonmap, "Intang_Assetunderdev")
			datamodel.Pre_Operatieve_Exps = helper.GetFloatfromMap(jsonmap, "Pre_Operatieve_Exps")
			datamodel.Assetsintransit = helper.GetFloatfromMap(jsonmap, "Assetsintransit")
			datamodel.Investments_Nf = helper.GetFloatfromMap(jsonmap, "Investments_Nf")
			datamodel.Lt_Loanadv = helper.GetFloatfromMap(jsonmap, "Lt_Loanadv")
			datamodel.Other_Noc_Assets = helper.GetFloatfromMap(jsonmap, "Other_Noc_Assets")
			datamodel.Total_Nonassets = helper.GetFloatfromMap(jsonmap, "Total_Nonassets")
			datamodel.Current_Investments = helper.GetFloatfromMap(jsonmap, "Current_Investments")
			datamodel.Inventory = helper.GetFloatfromMap(jsonmap, "Inventory")
			datamodel.Debtors = helper.GetFloatfromMap(jsonmap, "Debtors")
			datamodel.Cash_Bank = helper.GetFloatfromMap(jsonmap, "Cash_Bank")
			datamodel.Other_Current_Nf = helper.GetFloatfromMap(jsonmap, "Other_Current_Nf")
			datamodel.Loans_Adv = helper.GetFloatfromMap(jsonmap, "Loans_Adv")
			datamodel.Currant_Assets_Nf = helper.GetFloatfromMap(jsonmap, "Currant_Assets_Nf")
			datamodel.Net_Current_Assets_Nf = helper.GetFloatfromMap(jsonmap, "Net_Current_Assets_Nf")
			datamodel.Other_Crnt_Assets = helper.GetFloatfromMap(jsonmap, "Other_Crnt_Assets")
			datamodel.Misc_Exps_Not_Wo = helper.GetFloatfromMap(jsonmap, "Misc_Exps_Not_Wo")
			datamodel.Total_Applications_Nf = helper.GetFloatfromMap(jsonmap, "Total_Applications_Nf")
			datamodel.Total_Debt_Inclst_Nf = helper.GetFloatfromMap(jsonmap, "Total_Debt_Inclst_Nf")
			datamodel.Book_Nav_Share = helper.GetFloatfromMap(jsonmap, "Book_Nav_Share")
			datamodel.Adj_Bv = helper.GetFloatfromMap(jsonmap, "Adj_Bv")
			datamodel.Minority_Interest = helper.GetFloatfromMap(jsonmap, "Minority_Interest")
			datamodel.Equity_Authorised = helper.GetFloatfromMap(jsonmap, "Equity_Authorised")
			datamodel.Equity_Issued = helper.GetFloatfromMap(jsonmap, "Equity_Issued")
			datamodel.EQUITY_PAIDUP = helper.GetFloatfromMap(jsonmap, "EQUITY_PAIDUP")
			datamodel.Equity_Forfeited = helper.GetFloatfromMap(jsonmap, "Equity_Forfeited")
			datamodel.Adj_Equity = helper.GetFloatfromMap(jsonmap, "Adj_Equity")
			datamodel.Preference_Capital = helper.GetFloatfromMap(jsonmap, "Preference_Capital")
			datamodel.FACE_VALUE = helper.GetFloatfromMap(jsonmap, "FACE_VALUE")
			datamodel.Share_Premium = helper.GetFloatfromMap(jsonmap, "Share_Premium")
			datamodel.Capital_Reserve = helper.GetFloatfromMap(jsonmap, "Capital_Reserve")
			datamodel.Profit_Loss = helper.GetFloatfromMap(jsonmap, "Profit_Loss")
			datamodel.General_Reserve = helper.GetFloatfromMap(jsonmap, "General_Reserve")
			datamodel.Reserve_Excl_Revaluation = helper.GetFloatfromMap(jsonmap, "Reserve_Excl_Revaluation")
			datamodel.Revaluation_Reserve = helper.GetFloatfromMap(jsonmap, "Revaluation_Reserve")
			datamodel.Demand_Deposits = helper.GetFloatfromMap(jsonmap, "Demand_Deposits")
			datamodel.Saving_Deposits = helper.GetFloatfromMap(jsonmap, "Saving_Deposits")
			datamodel.Term_Fixed_Deposits = helper.GetFloatfromMap(jsonmap, "Term_Fixed_Deposits")
			datamodel.Current_Deposits = helper.GetFloatfromMap(jsonmap, "Current_Deposits")
			datamodel.Recurring_Deposits = helper.GetFloatfromMap(jsonmap, "Recurring_Deposits")
			datamodel.Borrowings_RBI = helper.GetFloatfromMap(jsonmap, "Borrowings_RBI")
			datamodel.Borrowings_Banks = helper.GetFloatfromMap(jsonmap, "Borrowings_Banks")
			datamodel.Borrowings_GOI = helper.GetFloatfromMap(jsonmap, "Borrowings_GOI")
			datamodel.Borrowings_FI = helper.GetFloatfromMap(jsonmap, "Borrowings_FI")
			datamodel.Borrowings_Bonds = helper.GetFloatfromMap(jsonmap, "Borrowings_Bonds")
			datamodel.Borrowings_Other = helper.GetFloatfromMap(jsonmap, "Borrowings_Other")
			datamodel.Borrowings_Outof_India = helper.GetFloatfromMap(jsonmap, "Borrowings_Outof_India")
			datamodel.Bills_payable = helper.GetFloatfromMap(jsonmap, "Bills_payable")
			datamodel.Inter_oofice_adjustments_liabilities = helper.GetFloatfromMap(jsonmap, "Inter_oofice_adjustments_liabilities")
			datamodel.Interest_accrued = helper.GetFloatfromMap(jsonmap, "Interest_accrued")
			datamodel.Proposed_dividend = helper.GetFloatfromMap(jsonmap, "Proposed_dividend")
			datamodel.Corporate_dividend_tax = helper.GetFloatfromMap(jsonmap, "Corporate_dividend_tax")
			datamodel.Cash_RBI = helper.GetFloatfromMap(jsonmap, "Cash_RBI")
			datamodel.Cash_In_hand = helper.GetFloatfromMap(jsonmap, "Cash_In_hand")
			datamodel.Investments_India = helper.GetFloatfromMap(jsonmap, "Investments_India")
			datamodel.GOI_Securities = helper.GetFloatfromMap(jsonmap, "GOI_Securities")
			datamodel.Equity_Shares_corporate = helper.GetFloatfromMap(jsonmap, "Equity_Shares_corporate")
			datamodel.Debentures_Bonds = helper.GetFloatfromMap(jsonmap, "Debentures_Bonds")
			datamodel.Subsidiaries_Joint_ventures = helper.GetFloatfromMap(jsonmap, "Subsidiaries_Joint_ventures")
			datamodel.Mutual_Funds_insurance_Units = helper.GetFloatfromMap(jsonmap, "Mutual_Funds_insurance_Units")
			datamodel.Investments_Outside_India = helper.GetFloatfromMap(jsonmap, "Investments_Outside_India")
			datamodel.GOI_Securities_Outside_india = helper.GetFloatfromMap(jsonmap, "GOI_Securities_Outside_india")
			datamodel.Subsidiaries_Joint_ventures_outside_india = helper.GetFloatfromMap(jsonmap, "Subsidiaries_Joint_ventures_outside_india")
			datamodel.Other_investments_outside_India = helper.GetFloatfromMap(jsonmap, "Other_investments_outside_India")
			datamodel.Dimunition_Investments = helper.GetFloatfromMap(jsonmap, "Dimunition_Investments")
			datamodel.Bills_purchased_discounted = helper.GetFloatfromMap(jsonmap, "Bills_purchased_discounted")
			datamodel.Cash_credit_overdraft = helper.GetFloatfromMap(jsonmap, "Cash_credit_overdraft")
			datamodel.Term_Loans = helper.GetFloatfromMap(jsonmap, "Term_Loans")
			datamodel.Finance_Lease_Hire_purchase = helper.GetFloatfromMap(jsonmap, "Finance_Lease_Hire_purchase")
			datamodel.Buildings = helper.GetFloatfromMap(jsonmap, "Buildings")
			datamodel.Assets_despose = helper.GetFloatfromMap(jsonmap, "Assets_despose")
			datamodel.Other_fix_assets = helper.GetFloatfromMap(jsonmap, "Other_fix_assets")
			datamodel.Inter_office_adjustments_Assets = helper.GetFloatfromMap(jsonmap, "Inter_office_adjustments_Assets")
			datamodel.Interest_accrued_assets = helper.GetFloatfromMap(jsonmap, "Interest_accrued_assets")
			datamodel.Advance_tax_TDS = helper.GetFloatfromMap(jsonmap, "Advance_tax_TDS")
			datamodel.Stationery_stamps = helper.GetFloatfromMap(jsonmap, "Stationery_stamps")
			datamodel.Non_banking_assets = helper.GetFloatfromMap(jsonmap, "Non_banking_assets")
			datamodel.Deferred_tax_Assets = helper.GetFloatfromMap(jsonmap, "Deferred_tax_Assets")
			datamodel.Misc_expenditures_Not_writtoff = helper.GetFloatfromMap(jsonmap, "Misc_expenditures_Not_writtoff")
			datamodel.Claims_Not_acknowledge_debt = helper.GetFloatfromMap(jsonmap, "Claims_Not_acknowledge_debt")
			datamodel.Outstanding_Forward_Exchange_Contract = helper.GetFloatfromMap(jsonmap, "Outstanding_Forward_Exchange_Contract")
			datamodel.Guarantees_Constituents_India = helper.GetFloatfromMap(jsonmap, "Guarantees_Constituents_India")
			datamodel.Guarantees_Constituents_Outside_India = helper.GetFloatfromMap(jsonmap, "Guarantees_Constituents_Outside_India")
			datamodel.Acceptances_Endorsements_Obligations = helper.GetFloatfromMap(jsonmap, "Acceptances_Endorsements_Obligations")
			datamodel.Non_Convertible_Debenture = helper.GetFloatfromMap(jsonmap, "Non_Convertible_Debenture")
			datamodel.Conv_Debenture_Bnds = helper.GetFloatfromMap(jsonmap, "Conv_Debenture_Bnds")
			datamodel.Packing_Credit = helper.GetFloatfromMap(jsonmap, "Packing_Credit")
			datamodel.Intercorpsecdeposits = helper.GetFloatfromMap(jsonmap, "Intercorpsecdeposits")
			datamodel.Term_Loan_Bank = helper.GetFloatfromMap(jsonmap, "Term_Loan_Bank")
			datamodel.Term_Loan_Inst = helper.GetFloatfromMap(jsonmap, "Term_Loan_Inst")
			datamodel.Fixed_Deposits = helper.GetFloatfromMap(jsonmap, "Fixed_Deposits")
			datamodel.Loans_Susidiaries = helper.GetFloatfromMap(jsonmap, "Loans_Susidiaries")
			datamodel.Inter_Corp_Deposits = helper.GetFloatfromMap(jsonmap, "Inter_Corp_Deposits")
			datamodel.Foreign_Curr_Convertible_Notes = helper.GetFloatfromMap(jsonmap, "Foreign_Curr_Convertible_Notes")
			datamodel.Foreign_Curr_Long_Term_Loans = helper.GetFloatfromMap(jsonmap, "Foreign_Curr_Long_Term_Loans")
			datamodel.Loans_Bank = helper.GetFloatfromMap(jsonmap, "Loans_Bank")
			datamodel.Loans_Govt = helper.GetFloatfromMap(jsonmap, "Loans_Govt")
			datamodel.Loans_Others = helper.GetFloatfromMap(jsonmap, "Loans_Others")
			datamodel.Def_Tax_Assets = helper.GetFloatfromMap(jsonmap, "Def_Tax_Assets")
			datamodel.Def_Tax_Liability = helper.GetFloatfromMap(jsonmap, "Def_Tax_Liability")
			datamodel.Sundry_Crs = helper.GetFloatfromMap(jsonmap, "Sundry_Crs")
			datamodel.Acceptances = helper.GetFloatfromMap(jsonmap, "Acceptances")
			datamodel.Trade_Paysubs = helper.GetFloatfromMap(jsonmap, "Trade_Paysubs")
			datamodel.Bank_Od = helper.GetFloatfromMap(jsonmap, "Bank_Od")
			datamodel.Adv_Customers = helper.GetFloatfromMap(jsonmap, "Adv_Customers")
			datamodel.Interest_Not_Due = helper.GetFloatfromMap(jsonmap, "Interest_Not_Due")
			datamodel.Share_Application = helper.GetFloatfromMap(jsonmap, "Share_Application")
			datamodel.Cl_Curmat_Deb = helper.GetFloatfromMap(jsonmap, "Cl_Curmat_Deb")
			datamodel.Cl_Curmat_Others = helper.GetFloatfromMap(jsonmap, "Cl_Curmat_Others")
			datamodel.Loans = helper.GetFloatfromMap(jsonmap, "Loans")
			datamodel.Stbs_Sec_Loandemand = helper.GetFloatfromMap(jsonmap, "Stbs_Sec_Loandemand")
			datamodel.Stbs_Wcap = helper.GetFloatfromMap(jsonmap, "Stbs_Wcap")
			datamodel.Stbu_Buycredit = helper.GetFloatfromMap(jsonmap, "Stbu_Buycredit")
			datamodel.Stbu_Commborr = helper.GetFloatfromMap(jsonmap, "Stbu_Commborr")
			datamodel.Proposed_Divided = helper.GetFloatfromMap(jsonmap, "Proposed_Divided")
			datamodel.Prov_Corp_Tax = helper.GetFloatfromMap(jsonmap, "Prov_Corp_Tax")
			datamodel.Prov_Tax = helper.GetFloatfromMap(jsonmap, "Prov_Tax")
			datamodel.Prov_Retirements = helper.GetFloatfromMap(jsonmap, "Prov_Retirements")
			datamodel.Prefence_Dividend = helper.GetFloatfromMap(jsonmap, "Prefence_Dividend")
			datamodel.Long_Term_Investments_Nf = helper.GetFloatfromMap(jsonmap, "Long_Term_Investments_Nf")
			datamodel.Long_Term_Quoted = helper.GetFloatfromMap(jsonmap, "Long_Term_Quoted")
			datamodel.Long_Term_Unquoted = helper.GetFloatfromMap(jsonmap, "Long_Term_Unquoted")
			datamodel.CURRENT_QUOTED = helper.GetFloatfromMap(jsonmap, "CURRENT_QUOTED")
			datamodel.Raw_Material = helper.GetFloatfromMap(jsonmap, "Raw_Material")
			datamodel.Wip = helper.GetFloatfromMap(jsonmap, "Wip")
			datamodel.Fin_Goods = helper.GetFloatfromMap(jsonmap, "Fin_Goods")
			datamodel.Packing_Materials_Inventory = helper.GetFloatfromMap(jsonmap, "Packing_Materials_Inventory")
			datamodel.Store_Spares = helper.GetFloatfromMap(jsonmap, "Store_Spares")
			datamodel.Drs_Six_Months = helper.GetFloatfromMap(jsonmap, "Drs_Six_Months")
			datamodel.Drs_Others = helper.GetFloatfromMap(jsonmap, "Drs_Others")
			datamodel.Cash_Hand = helper.GetFloatfromMap(jsonmap, "Cash_Hand")
			datamodel.Bank_Balance = helper.GetFloatfromMap(jsonmap, "Bank_Balance")
			datamodel.Interest_Investments = helper.GetFloatfromMap(jsonmap, "Interest_Investments")
			datamodel.Interest_Debentures = helper.GetFloatfromMap(jsonmap, "Interest_Debentures")
			datamodel.Deposits_Govt_Other = helper.GetFloatfromMap(jsonmap, "Deposits_Govt_Other")
			datamodel.Interest_Accrued_Due = helper.GetFloatfromMap(jsonmap, "Interest_Accrued_Due")
			datamodel.Prepaid_Exps = helper.GetFloatfromMap(jsonmap, "Prepaid_Exps")
			datamodel.Adv_Cash_Kind = helper.GetFloatfromMap(jsonmap, "Adv_Cash_Kind")
			datamodel.Adv_Tax = helper.GetFloatfromMap(jsonmap, "Adv_Tax")
			datamodel.Due_Director = helper.GetFloatfromMap(jsonmap, "Due_Director")
			datamodel.Due_Subsidiaries = helper.GetFloatfromMap(jsonmap, "Due_Subsidiaries")
			datamodel.Inter_Corporate_Deposits = helper.GetFloatfromMap(jsonmap, "Inter_Corporate_Deposits")
			datamodel.Corporate_Deposits = helper.GetFloatfromMap(jsonmap, "Corporate_Deposits")
			datamodel.Flag = helper.GetStringfromMap(jsonmap, "flag")
			fincode := strconv.Itoa(datamodel.Fincode)
			yearEnd := strconv.Itoa(datamodel.Year_end)
			datamodel.ID = fincode + "_" + yearEnd + "_" + datamodel.Type

			//datamodel.Model = jsonmap["Model"].(int)

			// err = tx.Save(&datamodel).Error
			// if err != nil {
			// 	buffer.WriteString(err.Error())
			// }
			datamodelUpdate = append(datamodelUpdate, datamodel)
			count++
		}
		err := db.Accord.Clauses(clause.OnConflict{
			Columns:   []clause.Column{{Name: "id"}}, //, {Name: "invdate"}, {Name: "srno"}},
			DoUpdates: clause.AssignmentColumns([]string{"fincode", "year_end", "type", "no_months", "unit", "share_capital", "shares_warrants", "shares_application_money", "esop_outstanding", "share_suspense", "reserve", "sharehoders_funds", "deposits", "borrowings", "other_liabilities", "total_sounces_funds", "cash_balances_rbi", "bank_call_money", "investments", "advances", "gross_block", "acc_depreciation", "impairment_assets", "lease_adj", "cw_ip", "other_assets", "total_applications", "contingent_liabilities", "bills_for_collection", "ltrm_borrowing", "secured_loans", "unsecured_loans_nf", "net_def_tax_nf", "oth_lt_liab", "lt_trade_payables", "lt_provisions", "total_nonliab", "trade_payables", "current_liabilities_nf", "st_borrowings", "provisions", "current_laib_prov_nf", "total_sounces_funds_nf", "non_current_assets", "loan_non_cuurent_assets", "net_block", "cwip_nf", "intang_assetunderdev", "pre_operatieve_exps", "assetsintransit", "investments_nf", "lt_loanadv", "other_noc_assets", "total_nonassets", "current_investments", "inventory", "debtors", "cash_bank", "other_current_nf", "loans_adv", "currant_assets_nf", "net_current_assets_nf", "other_crnt_assets", "misc_exps_not_wo", "total_applications_nf", "total_debt_inclst_nf", "book_nav_share", "adj_bv", "minority_interest", "equity_authorised", "equity_issued", "eq_ui_ty_pa_id_up", "equity_forfeited", "adj_equity", "preference_capital", "face_value", "share_premium", "capital_reserve", "profit_loss", "general_reserve", "reserve_excl_revaluation", "revaluation_reserve", "demand_deposits", "saving_deposits", "term_fixed_deposits", "current_deposits", "recurring_deposits", "borrowings_rbi", "borrowings_banks", "borrowings_goi", "borrowings_fi", "borrowings_bonds", "borrowings_other", "borrowings_outof_india", "bills_payable", "inter_oofice_adjustments_liabilities", "interest_accrued", "proposed_dividend", "corporate_dividend_tax", "cash_rbi", "cash_in_hand", "investments_india", "goi_securities", "equity_shares_corporate", "debentures_bonds", "subsidiaries_joint_ventures", "mutual_funds_insurance_units", "investments_outside_india", "goi_securities_outside_india", "subsidiaries_joint_ventures_outside_india", "other_investments_outside_india", "dimunition_investments", "bills_purchased_discounted", "cash_credit_overdraft", "term_loans", "finance_lease_hire_purchase", "buildings", "assets_despose", "other_fix_assets", "inter_office_adjustments_assets", "interest_accrued_assets", "advance_tax_tds", "stationery_stamps", "non_banking_assets", "deferred_tax_assets", "misc_expenditures_not_writtoff", "claims_not_acknowledge_debt", "outstanding_forward_exchange_contract", "guarantees_constituents_india", "guarantees_constituents_outside_india", "acceptances_endorsements_obligations", "non_convertible_debenture", "conv_debenture_bnds", "packing_credit", "intercorpsecdeposits", "term_loan_bank", "term_loan_inst", "fixed_deposits", "loans_susidiaries", "inter_corp_deposits", "foreign_curr_convertible_notes", "foreign_curr_long_term_loans", "loans_bank", "loans_govt", "loans_others", "def_tax_assets", "def_tax_liability", "sundry_crs", "acceptances", "trade_paysubs", "bank_od", "adv_customers", "interest_not_due", "share_application", "cl_curmat_deb", "cl_curmat_others", "loans", "stbs_sec_loandemand", "stbs_wcap", "stbu_buycredit", "stbu_commborr", "proposed_divided", "prov_corp_tax", "prov_tax", "prov_retirements", "prefence_dividend", "long_term_investments_nf", "long_term_quoted", "long_term_unquoted", "current_quoted", "raw_material", "wip", "fin_goods", "packing_materials_inventory", "store_spares", "drs_six_months", "drs_others", "cash_hand", "bank_balance", "interest_investments", "interest_debentures", "deposits_govt_other", "interest_accrued_due", "prepaid_exps", "adv_cash_kind", "adv_tax", "due_director", "due_subsidiaries", "inter_corporate_deposits", "corporate_deposits", "flag"}),
			// DoUpdates: clause.AssignmentColumns([]string{"rating"}),
		}).CreateInBatches(&datamodelUpdate, 300).Error
		if err != nil {
			fmt.Println(err)
			Zerologs.Error().Msg("Error while Inserting data into finance_bs")
		}
		Zerologs.Info().Msgf(" execution time for finance_bs ==>", time.Since(start))
		buffer.WriteString("Total Record updated " + strconv.Itoa(count) + "\n")
		return nil
	})

	// })
	return nil
}

func Shp_catmaster_2(strjson []byte, buffer *bytes.Buffer) error {
	var arryJson []interface{}
	if err := json.Unmarshal(strjson, &arryJson); err != nil {
		buffer.WriteString(err.Error() + "\n")
		return err
	}
	var datamodelUpdate []accord.Shp_catmaster_2
	count := 0
	// q.Enqueue(arryJson, func(data interface{}) {
	db.Accord.Transaction(func(tx *gorm.DB) error {
		start := time.Now()
		for _, json := range arryJson {
			jsonmap := json.(map[string]interface{})
			datamodel := accord.Shp_catmaster_2{}
			datamodel.SHP_CATID = helper.GetIntfromMap(jsonmap, "SHP_CATID")
			// err := tx.Where("shp_cat_id=? ", datamodel.SHP_CATID).First(&datamodel).Error

			// if err != nil {
			// 	Zerologs.Error().Msg("Record Not Found In shp_catmaster" + err.Error())
			// }
			datamodel.SHP_CATNAME = helper.GetStringfromMap(jsonmap, "SHP_CATNAME")
			datamodel.SUB_CATEGORY = helper.GetStringfromMap(jsonmap, "SUB_CATEGORY")
			datamodel.Flag = helper.GetStringfromMap(jsonmap, "Flag")
			shpCatid := strconv.Itoa(datamodel.SHP_CATID)
			datamodel.ID = shpCatid
			// err = tx.Save(&datamodel).Error
			// if err != nil {
			// 	buffer.WriteString(err.Error())
			// }
			datamodelUpdate = append(datamodelUpdate, datamodel)
			count++

		}
		err := db.Accord.Clauses(clause.OnConflict{
			Columns:   []clause.Column{{Name: "id"}}, //, {Name: "invdate"}, {Name: "srno"}},
			DoUpdates: clause.AssignmentColumns([]string{"shp_cat_id", "shp_catname", "sub_category", "flag"}),
			// DoUpdates: clause.AssignmentColumns([]string{"rating"}),
		}).CreateInBatches(&datamodelUpdate, 1000).Error
		if err != nil {
			fmt.Println(err)
			Zerologs.Error().Msg("Error while Inserting data into shp_catmaster_2")
		}
		Zerologs.Info().Msgf(" execution time for shp_catmaster_2 ==>", time.Since(start))
		buffer.WriteString("Total Record updated " + strconv.Itoa(count) + "\n")
		return nil
	})

	// })
	return nil
}

func Stockexchangemaster(strjson []byte, buffer *bytes.Buffer) error {
	var arryJson []interface{}
	if err := json.Unmarshal(strjson, &arryJson); err != nil {
		buffer.WriteString(err.Error() + "\n")
		return err
	}
	var datamodelUpdate []accord.Stockexchangemaster
	count := 0
	// q.Enqueue(arryJson, func(data interface{}) {
	db.Accord.Transaction(func(tx *gorm.DB) error {
		start := time.Now()
		for _, json := range arryJson {
			jsonmap := json.(map[string]interface{})
			datamodel := accord.Stockexchangemaster{}
			datamodel.STK_ID = helper.GetIntfromMap(jsonmap, "STK_ID")
			// err := tx.Where("stk_id=? ", datamodel.STK_ID).First(&datamodel).Error
			// if err != nil {
			// 	Zerologs.Error().Msg("Record Not Found In Stockexchangemaster" + err.Error())
			// }
			datamodel.STK_NAME = helper.GetStringfromMap(jsonmap, "STK_NAME")
			datamodel.Flag = helper.GetStringfromMap(jsonmap, "Flag")
			stkId := strconv.Itoa(datamodel.STK_ID)
			datamodel.ID = stkId
			// err = tx.Save(&datamodel).Error
			// if err != nil {
			// 	buffer.WriteString(err.Error())
			// }
			datamodelUpdate = append(datamodelUpdate, datamodel)
			count++

		}
		err := db.Accord.Clauses(clause.OnConflict{
			Columns:   []clause.Column{{Name: "id"}}, //, {Name: "invdate"}, {Name: "srno"}},
			DoUpdates: clause.AssignmentColumns([]string{"stk_id", "stk_name", "flag"}),
			// DoUpdates: clause.AssignmentColumns([]string{"rating"}),
		}).CreateInBatches(&datamodelUpdate, 1000).Error
		if err != nil {
			fmt.Println(err)
			Zerologs.Error().Msg("Error while Inserting data into stockexchangemaster")
		}
		Zerologs.Info().Msgf(" execution time for stockexchangemaster ==>", time.Since(start))
		buffer.WriteString("Total Record updated " + strconv.Itoa(count) + "\n")
		return nil
	})

	// })
	return nil
}

func Shp_details(strjson []byte, buffer *bytes.Buffer) error {
	var arryJson []interface{}
	if err := json.Unmarshal(strjson, &arryJson); err != nil {
		buffer.WriteString(err.Error() + "\n")
		return err
	}
	var datamodelUpdate []accord.Shp_details
	count := 0
	// q.Enqueue(arryJson, func(data interface{}) {
	db.Accord.Transaction(func(tx *gorm.DB) error {
		start := time.Now()
		for _, json := range arryJson {
			jsonmap := json.(map[string]interface{})
			datamodel := accord.Shp_details{}
			datamodel.FINCODE = helper.GetIntfromMap(jsonmap, "FINCODE")
			datamodel.DATE_END = helper.GetIntfromMap(jsonmap, "DATE_END")
			datamodel.SRNO = helper.GetIntfromMap(jsonmap, "SRNO")
			// err := tx.Where("fincode=? AND date_end=? AND srno=?", datamodel.FINCODE, datamodel.DATE_END, datamodel.SRNO).First(&datamodel).Error

			// if err != nil {
			// 	Zerologs.Error().Msg("Record Not Found In Shp_details" + err.Error())
			// }
			datamodel.SHP_CATID = helper.GetIntfromMap(jsonmap, "SHP_CATID")
			datamodel.NAME = helper.GetStringfromMap(jsonmap, "NAME")
			datamodel.PERCENTAGE = helper.GetFloatfromMap(jsonmap, "PERCENTAGE")
			datamodel.NO_OF_SHARES = helper.GetFloatfromMap(jsonmap, "NO_OF_SHARES")
			datamodel.PledgeEncumberedNoofShares = helper.GetFloatfromMap(jsonmap, "PledgeEncumberedNoofShares")
			datamodel.PledgeEncumberedPercentage = helper.GetFloatfromMap(jsonmap, "PledgeEncumberedPercentage")
			datamodel.Flag = helper.GetStringfromMap(jsonmap, "Flag")
			fincode := strconv.Itoa(datamodel.FINCODE)
			dateEnd := strconv.Itoa(datamodel.DATE_END)
			srNo := strconv.Itoa(datamodel.SRNO)
			fincode_dateEnd_srNo := fincode + "_" + dateEnd + "_" + srNo
			datamodel.ID = fincode_dateEnd_srNo
			// err = tx.Save(&datamodel).Error
			// if err != nil {
			// 	buffer.WriteString(err.Error())
			// }
			datamodelUpdate = append(datamodelUpdate, datamodel)
			count++

		}
		err := db.Accord.Clauses(clause.OnConflict{
			Columns:   []clause.Column{{Name: "id"}}, //, {Name: "invdate"}, {Name: "srno"}},
			DoUpdates: clause.AssignmentColumns([]string{"fincode", "date_end", "srno", "shp_cat_id", "name", "percentage", "no_of_shares", "pledge_encumbered_noof_shares", "pledge_encumbered_percentage", "flag"}),
			// DoUpdates: clause.AssignmentColumns([]string{"rating"}),
		}).CreateInBatches(&datamodelUpdate, 1000).Error
		if err != nil {
			fmt.Println(err)
			Zerologs.Error().Msg("Error while Inserting data into shp_details")
		}
		Zerologs.Info().Msgf(" execution time for shp_details ==>", time.Since(start))
		buffer.WriteString("Total Record updated " + strconv.Itoa(count) + "\n")
		return nil
	})

	// })
	return nil
}

func Board(strjson []byte, buffer *bytes.Buffer) error {
	var arryJson []interface{}
	if err := json.Unmarshal(strjson, &arryJson); err != nil {
		buffer.WriteString(err.Error() + "\n")
		return err
	}
	var datamodelUpdate []accord.Board
	count := 0
	// q.Enqueue(arryJson, func(data interface{}) {
	db.Accord.Transaction(func(tx *gorm.DB) error {
		start := time.Now()
		for _, json := range arryJson {
			jsonmap := json.(map[string]interface{})
			datamodel := accord.Board{}
			datamodel.FINCODE = helper.GetIntfromMap(jsonmap, "FINCODE")
			datamodel.YRC = helper.GetIntfromMap(jsonmap, "YRC")
			datamodel.SERIALNO = helper.GetIntfromMap(jsonmap, "SERIALNO")
			datamodel.DIRTYPE_ID = helper.GetIntfromMap(jsonmap, "DIRTYPE_ID")
			// err := tx.Where("fincode=? AND yrc=? AND serialno=? AND dirtype_id=?", datamodel.FINCODE, datamodel.YRC, datamodel.SERIALNO, datamodel.DIRTYPE_ID).First(&datamodel).Error

			// if err != nil {
			// 	Zerologs.Error().Msg("Record Not Found In Board" + err.Error())
			// }
			datamodel.SRNO = helper.GetIntfromMap(jsonmap, "SRNO")
			datamodel.EFFECT_DATE = helper.GetTimefromMap(jsonmap, "EFFECT_DATE")
			datamodel.DIRNAME = helper.GetStringfromMap(jsonmap, "DIRNAME")
			datamodel.DIRREM = helper.GetFloatfromMap(jsonmap, "DIRREM")
			datamodel.Reported_DSG = helper.GetStringfromMap(jsonmap, "Reported_DSG")
			datamodel.REM_UNIT = helper.GetFloatfromMap(jsonmap, "REM_UNIT")
			datamodel.Independent = helper.GetStringfromMap(jsonmap, "Independent")
			datamodel.DirectorId = helper.GetIntfromMap(jsonmap, "DirectorId")
			datamodel.FLAG = helper.GetStringfromMap(jsonmap, "FLAG")
			fincode := strconv.Itoa(datamodel.FINCODE)
			yrc := strconv.Itoa(datamodel.YRC)
			serialNo := strconv.Itoa(datamodel.SERIALNO)
			dirTypeId := strconv.Itoa(datamodel.DIRTYPE_ID)
			fincode_yrc_serialNo_dirTypeId := fincode + "_" + yrc + "_" + serialNo + "_" + dirTypeId
			datamodel.ID = fincode_yrc_serialNo_dirTypeId
			// err = tx.Save(&datamodel).Error
			// if err != nil {
			// 	buffer.WriteString(err.Error())
			// }
			datamodelUpdate = append(datamodelUpdate, datamodel)
			count++
		}
		err := db.Accord.Clauses(clause.OnConflict{
			Columns:   []clause.Column{{Name: "id"}}, //, {Name: "invdate"}, {Name: "srno"}},
			DoUpdates: clause.AssignmentColumns([]string{"fincode", "yrc", "serialno", "dirtype_id", "srno", "effect_date", "dirname", "dirrem", "reported_dsg", "rem_unit", "independent", "director_id", "flag"}),
			// DoUpdates: clause.AssignmentColumns([]string{"rating"}),
		}).CreateInBatches(&datamodelUpdate, 1000).Error
		if err != nil {
			fmt.Println(err)
			Zerologs.Error().Msg("Error while Inserting data into board")
		}
		Zerologs.Info().Msgf(" execution time for board ==>", time.Since(start))
		buffer.WriteString("Total Record updated " + strconv.Itoa(count) + "\n")
		return nil
	})

	// })
	return nil
}

func Company_equity(strjson []byte, buffer *bytes.Buffer) error {
	var arryJson []interface{}
	if err := json.Unmarshal(strjson, &arryJson); err != nil {
		buffer.WriteString(err.Error() + "\n")
		return err
	}
	var datamodelUpdate []accord.Company_equity
	count := 0
	// q.Enqueue(arryJson, func(data interface{}) {
	db.Accord.Transaction(func(tx *gorm.DB) error {
		start := time.Now()
		for _, json := range arryJson {
			jsonmap := json.(map[string]interface{})
			datamodel := accord.Company_equity{}
			datamodel.FINCODE = helper.GetIntfromMap(jsonmap, "FINCODE")
			// err := tx.Where("fincode=?", datamodel.FINCODE).First(&datamodel).Error

			// if err != nil {
			// 	Zerologs.Error().Msg("Record Not Found In company_equity" + err.Error())
			// }
			datamodel.YEAR_END = helper.GetIntfromMap(jsonmap, "YEAR_END")
			datamodel.No_Shs_Subscribed = helper.GetFloatfromMap(jsonmap, "No_Shs_Subscribed")
			datamodel.Latest_Equityc = helper.GetFloatfromMap(jsonmap, "Latest_Equity")
			datamodel.Latest_Reserve = helper.GetFloatfromMap(jsonmap, "Latest_Reserve")
			datamodel.PRICE = helper.GetFloatfromMap(jsonmap, "PRICE")
			datamodel.MCAP = helper.GetFloatfromMap(jsonmap, "MCAP")
			datamodel.YIELD = helper.GetFloatfromMap(jsonmap, "YIELD")
			datamodel.FV = helper.GetFloatfromMap(jsonmap, "FV")
			datamodel.BOOKNAVPERSHARE = helper.GetFloatfromMap(jsonmap, "BOOKNAVPERSHARE")
			datamodel.TTM_YEAREND = helper.GetIntfromMap(jsonmap, "TTM_YEAREND")
			datamodel.TTMEPS = helper.GetFloatfromMap(jsonmap, "TTMEPS")
			datamodel.TTMPE = helper.GetFloatfromMap(jsonmap, "TTMPE")
			datamodel.Price_Sales = helper.GetFloatfromMap(jsonmap, "Price_Sales")
			datamodel.EV_Sales = helper.GetFloatfromMap(jsonmap, "EV_Sales")
			datamodel.MCAP_Sales = helper.GetFloatfromMap(jsonmap, "MCAP_Sales")
			datamodel.EV = helper.GetFloatfromMap(jsonmap, "EV")
			datamodel.Price_BV = helper.GetFloatfromMap(jsonmap, "Price_BV")
			datamodel.EV_EBITDA = helper.GetFloatfromMap(jsonmap, "EV_EBITDA")
			datamodel.TTMCEPS = helper.GetFloatfromMap(jsonmap, "TTMCEPS")
			datamodel.Price_CEPS = helper.GetFloatfromMap(jsonmap, "Price_CEPS")
			datamodel.PriceDate = helper.GetTimefromMap(jsonmap, "PriceDate")
			datamodel.STK_Exchange = helper.GetStringfromMap(jsonmap, "STK_Exchange")
			datamodel.Flag = helper.GetStringfromMap(jsonmap, "Flag")
			fincode := strconv.Itoa(datamodel.FINCODE)
			datamodel.ID = fincode
			// err = tx.Save(&datamodel).Error
			// if err != nil {
			// 	buffer.WriteString(err.Error())
			// }
			datamodelUpdate = append(datamodelUpdate, datamodel)
			count++

		}
		err := db.Accord.Clauses(clause.OnConflict{
			Columns:   []clause.Column{{Name: "id"}}, //, {Name: "invdate"}, {Name: "srno"}},
			DoUpdates: clause.AssignmentColumns([]string{"fincode", "year_end", "no_shs_subscribed", "latest_equityc", "latest_reserve", "price", "mcap", "yield", "fv", "booknavpershare", "ttm_yearend", "ttmeps", "ttmpe", "price_sales", "ev_sales", "mcap_sales", "ev", "price_bv", "ev_ebitda", "ttmceps", "price_ceps", "price_date", "stk_exchange", "flag"}),
			// DoUpdates: clause.AssignmentColumns([]string{"rating"}),
		}).CreateInBatches(&datamodelUpdate, 1000).Error
		if err != nil {
			fmt.Println(err)
			Zerologs.Error().Msg("Error while Inserting data into company_equity")
		}
		Zerologs.Info().Msgf(" execution time for company_equity ==>", time.Since(start))
		buffer.WriteString("Total Record updated " + strconv.Itoa(count) + "\n")
		return nil
	})

	// })
	return nil
}

func Company_equity_cons(strjson []byte, buffer *bytes.Buffer) error {
	var arryJson []interface{}
	if err := json.Unmarshal(strjson, &arryJson); err != nil {
		buffer.WriteString(err.Error() + "\n")
		return err
	}
	var datamodelUpdate []accord.Company_equity_cons
	count := 0
	// q.Enqueue(arryJson, func(data interface{}) {
	db.Accord.Transaction(func(tx *gorm.DB) error {
		start := time.Now()
		for _, json := range arryJson {
			jsonmap := json.(map[string]interface{})
			datamodel := accord.Company_equity_cons{}
			datamodel.FINCODE = helper.GetIntfromMap(jsonmap, "FINCODE")
			// err := tx.Where("fincode=?", datamodel.FINCODE).First(&datamodel).Error

			// if err != nil {
			// 	Zerologs.Error().Msg("Record Not Found In company_equity_cons" + err.Error())
			// }
			datamodel.YEAR_END = helper.GetIntfromMap(jsonmap, "YEAR_END")
			datamodel.No_Shs_Subscribed = helper.GetFloatfromMap(jsonmap, "No_Shs_Subscribed")
			datamodel.Latest_Equityc = helper.GetFloatfromMap(jsonmap, "Latest_Equity")
			datamodel.Latest_Reserve = helper.GetFloatfromMap(jsonmap, "Latest_Reserve")
			datamodel.PRICE = helper.GetFloatfromMap(jsonmap, "PRICE")
			datamodel.MCAP = helper.GetFloatfromMap(jsonmap, "MCAP")
			datamodel.YIELD = helper.GetFloatfromMap(jsonmap, "YIELD")
			datamodel.FV = helper.GetFloatfromMap(jsonmap, "FV")
			datamodel.BOOKNAVPERSHARE = helper.GetFloatfromMap(jsonmap, "BOOKNAVPERSHARE")
			datamodel.TTM_YEAREND = helper.GetIntfromMap(jsonmap, "TTM_YEAREND")
			datamodel.TTMEPS = helper.GetFloatfromMap(jsonmap, "TTMEPS")
			datamodel.TTMPE = helper.GetFloatfromMap(jsonmap, "TTMPE")
			datamodel.Price_Sales = helper.GetFloatfromMap(jsonmap, "Price_Sales")
			datamodel.EV_Sales = helper.GetFloatfromMap(jsonmap, "EV_Sales")
			datamodel.MCAP_Sales = helper.GetFloatfromMap(jsonmap, "MCAP_Sales")
			datamodel.EV = helper.GetFloatfromMap(jsonmap, "EV")
			datamodel.Price_BV = helper.GetFloatfromMap(jsonmap, "Price_BV")
			datamodel.EV_EBITDA = helper.GetFloatfromMap(jsonmap, "EV_EBITDA")
			datamodel.TTMCEPS = helper.GetFloatfromMap(jsonmap, "TTMCEPS")
			datamodel.Price_CEPS = helper.GetFloatfromMap(jsonmap, "Price_CEPS")
			datamodel.PriceDate = helper.GetTimefromMap(jsonmap, "PriceDate")
			datamodel.STK_Exchange = helper.GetStringfromMap(jsonmap, "STK_Exchange")
			datamodel.Flag = helper.GetStringfromMap(jsonmap, "Flag")
			fincode := strconv.Itoa(datamodel.FINCODE)
			datamodel.ID = fincode
			// err = tx.Save(&datamodel).Error
			// if err != nil {
			// 	buffer.WriteString(err.Error())
			// }
			datamodelUpdate = append(datamodelUpdate, datamodel)

			count++

		}
		err := db.Accord.Clauses(clause.OnConflict{
			Columns:   []clause.Column{{Name: "id"}}, //, {Name: "invdate"}, {Name: "srno"}},
			DoUpdates: clause.AssignmentColumns([]string{"fincode", "year_end", "no_shs_subscribed", "latest_equityc", "latest_reserve", "price", "mcap", "yield", "fv", "booknavpershare", "ttm_yearend", "ttmeps", "ttmpe", "price_sales", "ev_sales", "mcap_sales", "ev", "price_bv", "ev_ebitda", "ttmceps", "price_ceps", "price_date", "stk_exchange", "flag"}),
			// DoUpdates: clause.AssignmentColumns([]string{"rating"}),
		}).CreateInBatches(&datamodelUpdate, 1000).Error
		if err != nil {
			fmt.Println(err)
			Zerologs.Error().Msg("Error while Inserting data into company_equity_cons")
		}
		Zerologs.Info().Msgf(" execution time for company_equity_cons ==>", time.Since(start))
		buffer.WriteString("Total Record updated " + strconv.Itoa(count) + "\n")
		return nil
	})

	// })
	return nil
}

func Companyaddress(strjson []byte, buffer *bytes.Buffer) error {
	var arryJson []interface{}
	if err := json.Unmarshal(strjson, &arryJson); err != nil {
		buffer.WriteString(err.Error() + "\n")
		return err
	}
	var datamodelUpdate []accord.Companyaddress
	count := 0
	// q.Enqueue(arryJson, func(data interface{}) {
	db.Accord.Transaction(func(tx *gorm.DB) error {
		start := time.Now()
		for _, json := range arryJson {
			jsonmap := json.(map[string]interface{})
			datamodel := accord.Companyaddress{}
			datamodel.FINCODE = helper.GetIntfromMap(jsonmap, "FINCODE")
			// err := tx.Where("FINCODE=?", datamodel.FINCODE).Find(&datamodel).Error
			// if err != nil {
			// 	Zerologs.Error().Msg("Record Not Found In Companyaddress" + err.Error())
			// }

			datamodel.ADD1 = helper.GetStringfromMap(jsonmap, "ADD1")
			datamodel.ADD2 = helper.GetStringfromMap(jsonmap, "ADD2")
			datamodel.ADD3 = helper.GetStringfromMap(jsonmap, "ADD3")
			datamodel.CITY_NAME = helper.GetStringfromMap(jsonmap, "CITY_NAME")
			datamodel.PINCODE = helper.GetStringfromMap(jsonmap, "PINCODE")
			datamodel.STATE_NAME = helper.GetStringfromMap(jsonmap, "STATE_NAME")
			datamodel.PHONE = helper.GetStringfromMap(jsonmap, "PHONE")
			datamodel.FAX_NO = helper.GetStringfromMap(jsonmap, "FAX_NO")
			datamodel.WEBSITE = helper.GetStringfromMap(jsonmap, "WEBSITE")
			datamodel.E_MAIL = helper.GetStringfromMap(jsonmap, "E_MAIL")
			datamodel.Flag = helper.GetStringfromMap(jsonmap, "Flag")
			fincode := strconv.Itoa(datamodel.FINCODE)
			datamodel.ID = fincode
			// err = tx.Save(&datamodel).Error
			// if err != nil {
			// 	buffer.WriteString(err.Error())
			// }
			datamodelUpdate = append(datamodelUpdate, datamodel)
			count++
		}
		err := db.Accord.Clauses(clause.OnConflict{
			Columns:   []clause.Column{{Name: "id"}}, //, {Name: "invdate"}, {Name: "srno"}},
			DoUpdates: clause.AssignmentColumns([]string{"fincode", "add1", "add2", "add3", "city_name", "pincode", "state_name", "phone", "fax_no", "website", "e_mail", "flag"}),
			// DoUpdates: clause.AssignmentColumns([]string{"rating"}),
		}).CreateInBatches(&datamodelUpdate, 1000).Error
		if err != nil {
			fmt.Println(err)
			Zerologs.Error().Msg("Error while Inserting data into companyaddresss")
		}
		Zerologs.Info().Msgf(" execution time for companyaddresss ==>", time.Since(start))
		buffer.WriteString("Total Record updated " + strconv.Itoa(count) + "\n")
		return nil
	})

	// })
	return nil
}

func Type_mst(strjson []byte, buffer *bytes.Buffer) error {
	var arryJson []interface{}
	if err := json.Unmarshal(strjson, &arryJson); err != nil {
		buffer.WriteString(err.Error() + "\n")
		return err
	}
	var datamodelUpdate []accord.Type_mst
	count := 0
	// q.Enqueue(arryJson, func(data interface{}) {
	db.Accord.Transaction(func(tx *gorm.DB) error {
		start := time.Now()
		for _, json := range arryJson {
			jsonmap := json.(map[string]interface{})
			datamodel := accord.Type_mst{}
			datamodel.TYPE_CODE = helper.GetIntfromMap(jsonmap, "type_code")
			err := tx.Where("type_code=? ", datamodel.TYPE_CODE).First(&datamodel).Error
			if err != nil {
				Zerologs.Error().Msg("Record Not Found In Type_mst" + err.Error())
			}
			datamodel.Type = helper.GetStringfromMap(jsonmap, "type")
			datamodel.FLAG = helper.GetStringfromMap(jsonmap, "flag")
			typeCode := strconv.Itoa(datamodel.TYPE_CODE)
			datamodel.ID = typeCode
			// err := tx.Where("type_code=? ", datamodel.TYPE_CODE).First(&datamodel).Error
			// if err != nil {
			// 	err := tx.Create(&datamodel).Error
			// 	if err != nil {
			// 		buffer.WriteString(err.Error())
			// 	}
			// } else {
			// err = tx.Save(&datamodel).Error
			// if err != nil {
			// 	buffer.WriteString(err.Error())
			// }
			// }
			datamodelUpdate = append(datamodelUpdate, datamodel)
			count++

		}
		err := db.Accord.Clauses(clause.OnConflict{
			Columns:   []clause.Column{{Name: "id"}}, //, {Name: "invdate"}, {Name: "srno"}},
			DoUpdates: clause.AssignmentColumns([]string{"type_code", "type", "flag"}),
			// DoUpdates: clause.AssignmentColumns([]string{"rating"}),
		}).CreateInBatches(&datamodelUpdate, 1000).Error
		if err != nil {
			fmt.Println(err)
			Zerologs.Error().Msg("Error while Inserting data into type_mst")
		}
		Zerologs.Info().Msgf(" execution time for type_mst ==>", time.Since(start))
		buffer.WriteString("Total Record updated " + strconv.Itoa(count) + "\n")
		return nil
	})

	// })
	return nil
}

func Sect_mst(strjson []byte, buffer *bytes.Buffer) error {
	var arryJson []interface{}
	if err := json.Unmarshal(strjson, &arryJson); err != nil {
		buffer.WriteString(err.Error() + "\n")
		return err
	}
	var datamodelUpdate []accord.Sect_mst
	count := 0
	// q.Enqueue(arryJson, func(data interface{}) {
	db.Accord.Transaction(func(tx *gorm.DB) error {
		start := time.Now()
		for _, json := range arryJson {
			jsonmap := json.(map[string]interface{})
			datamodel := accord.Sect_mst{}
			datamodel.SECT_CODE = helper.GetFloatfromMap(jsonmap, "sect_code")
			// err := tx.Where("sect_code=? ", datamodel.SECT_CODE).First(&datamodel).Error
			// if err != nil {
			// 	Zerologs.Error().Msg("Record Not Found In Sect_mst" + err.Error())
			// }
			datamodel.SECT_NAME = helper.GetStringfromMap(jsonmap, "sect_name")
			datamodel.FLAG = helper.GetStringfromMap(jsonmap, "flag")
			sectCode := fmt.Sprintf("%v", datamodel.SECT_CODE)
			datamodel.ID = sectCode
			// err := tx.Where("sect_code=? ", datamodel.SECT_CODE).First(&datamodel).Error
			// if err != nil {
			// 	err := tx.Create(&datamodel).Error
			// 	if err != nil {
			// 		buffer.WriteString(err.Error())
			// 	}
			// } else {
			// err = tx.Save(&datamodel).Error
			// if err != nil {
			// 	buffer.WriteString(err.Error())
			// }
			// }
			datamodelUpdate = append(datamodelUpdate, datamodel)
			count++

		}
		err := db.Accord.Clauses(clause.OnConflict{
			Columns:   []clause.Column{{Name: "id"}}, //, {Name: "invdate"}, {Name: "srno"}},
			DoUpdates: clause.AssignmentColumns([]string{"sect_code", "sect_name", "flag"}),
			// DoUpdates: clause.AssignmentColumns([]string{"rating"}),
		}).CreateInBatches(&datamodelUpdate, 1000).Error
		if err != nil {
			fmt.Println(err)
			Zerologs.Error().Msg("Error while Inserting data into Sect_mst")
		}
		Zerologs.Info().Msgf(" execution time for Sect_mst ==>", time.Since(start))
		buffer.WriteString("Total Record updated " + strconv.Itoa(count) + "\n")
		return nil
	})

	// })
	return nil
}

func Sect_allocation(strjson []byte, buffer *bytes.Buffer) error {
	var arryJson []interface{}
	if err := json.Unmarshal(strjson, &arryJson); err != nil {
		buffer.WriteString(err.Error() + "\n")
		return err
	}
	var datamodelUpdate []accord.Sect_allocation
	count := 0
	// q.Enqueue(arryJson, func(data interface{}) {
	db.Accord.Transaction(func(tx *gorm.DB) error {
		start := time.Now()
		for _, json := range arryJson {
			jsonmap := json.(map[string]interface{})
			datamodel := accord.Sect_allocation{}
			datamodel.AMC_CODE = helper.GetIntfromMap(jsonmap, "Amc_Code")
			datamodel.SCHEMECODE = helper.GetIntfromMap(jsonmap, "SchemeCode")
			datamodel.INVDATE = helper.GetTimefromMap(jsonmap, "InvDate")
			datamodel.SECT_NAME = helper.GetStringfromMap(jsonmap, "SECT_NAME")
			datamodel.ASECT_CODE = helper.GetIntfromMap(jsonmap, "Asect_Code")
			// err := tx.Where("amc_code=? AND scheme_code=? AND invdate=? AND sect_name=? AND asect_code=?", datamodel.AMC_CODE, datamodel.SCHEMECODE, datamodel.INVDATE, datamodel.SECT_NAME, datamodel.ASECT_CODE).First(&datamodel).Error
			// if err != nil {
			// 	Zerologs.Error().Msg("Record Not Found In Sect_allocation" + err.Error())
			// }

			datamodel.INVENDDATE = helper.GetTimefromMap(jsonmap, "InvEndDate")
			datamodel.SRNO = helper.GetIntfromMap(jsonmap, "Srno")
			datamodel.SECT_CODE = helper.GetIntfromMap(jsonmap, "SECT_CODE")
			datamodel.PERC_HOLD = helper.GetFloatfromMap(jsonmap, "Perc_Hold")
			datamodel.VALUE = helper.GetFloatfromMap(jsonmap, "VALUE")
			datamodel.AUM = helper.GetFloatfromMap(jsonmap, "AUM")
			datamodel.FLAG = helper.GetStringfromMap(jsonmap, "Flag")
			amcCode := strconv.Itoa(datamodel.AMC_CODE)
			schemeCode := strconv.Itoa(datamodel.SCHEMECODE)
			invDate := datamodel.INVDATE.String()
			asectCode := strconv.Itoa(datamodel.ASECT_CODE)
			amcCode_schemeCode_invDate_sectName_asectCode := amcCode + "_" + schemeCode + "_" + invDate + "_" + datamodel.SECT_NAME + "_" + asectCode
			datamodel.ID = amcCode_schemeCode_invDate_sectName_asectCode
			// err := tx.Where("amc_code=? AND schemecode=? AND invdate=? AND sect_name=? AND asect_code=?", datamodel.AMC_CODE, datamodel.SCHEMECODE, datamodel.INVDATE, datamodel.SECT_NAME, datamodel.ASECT_CODE).First(&datamodel).Error
			// if err != nil {
			// 	err := tx.Create(&datamodel).Error
			// 	if err != nil {
			// 		buffer.WriteString(err.Error())
			// 	}
			// } else {
			// err = tx.Save(&datamodel).Error
			// if err != nil {
			// 	buffer.WriteString(err.Error())
			// }
			// }
			datamodelUpdate = append(datamodelUpdate, datamodel)
			count++

		}
		err := db.Accord.Clauses(clause.OnConflict{
			Columns:   []clause.Column{{Name: "id"}}, //, {Name: "invdate"}, {Name: "srno"}},
			DoUpdates: clause.AssignmentColumns([]string{"amc_code", "schemecode", "invdate", "invenddate", "srno", "sect_code", "sect_name", "asect_code", "perc_hold", "value", "aum", "flag"}),
			// DoUpdates: clause.AssignmentColumns([]string{"rating"}),
		}).CreateInBatches(&datamodelUpdate, 1000).Error
		if err != nil {
			fmt.Println(err)
			Zerologs.Error().Msg("Error while Inserting data into Sect_allocation")
		}
		Zerologs.Info().Msgf(" execution time for Sect_allocation ==>", time.Since(start))
		buffer.WriteString("Total Record updated " + strconv.Itoa(count) + "\n")
		return nil
	})

	// })
	return nil
}

func Sclass_mst(strjson []byte, buffer *bytes.Buffer) error {
	var arryJson []interface{}
	if err := json.Unmarshal(strjson, &arryJson); err != nil {
		buffer.WriteString(err.Error() + "\n")
		return err
	}
	var datamodelUpdate []accord.Sclass_mst
	count := 0
	// q.Enqueue(arryJson, func(data interface{}) {
	db.Accord.Transaction(func(tx *gorm.DB) error {
		start := time.Now()
		for _, json := range arryJson {
			jsonmap := json.(map[string]interface{})
			datamodel := accord.Sclass_mst{}
			datamodel.Classcode = helper.GetIntfromMap(jsonmap, "classcode")
			// err := tx.Where("classcode=?", datamodel.Classcode).First(&datamodel).Error
			// if err != nil {
			// 	Zerologs.Error().Msg("Record Not Found In Sclass_mst" + err.Error())
			// }
			datamodel.Class_name = helper.GetStringfromMap(jsonmap, "classname")
			datamodel.Asset_code = helper.GetIntfromMap(jsonmap, "asset_code")
			datamodel.Asset_type = helper.GetStringfromMap(jsonmap, "asset_type")
			datamodel.Category = helper.GetStringfromMap(jsonmap, "category")
			datamodel.Sub_category = helper.GetStringfromMap(jsonmap, "sub_category")
			datamodel.Flag = helper.GetStringfromMap(jsonmap, "flag")
			classCode := strconv.Itoa(datamodel.Classcode)
			datamodel.ID = classCode
			// err := tx.Where("classcode=?", datamodel.Classcode).First(&datamodel).Error
			// if err != nil {
			// 	err := tx.Create(&datamodel).Error
			// 	if err != nil {
			// 		buffer.WriteString(err.Error())
			// 	}
			// } else {
			// err = tx.Save(&datamodel).Error
			// if err != nil {
			// 	buffer.WriteString(err.Error())
			// }
			// }
			datamodelUpdate = append(datamodelUpdate, datamodel)
			count++

		}
		err := db.Accord.Clauses(clause.OnConflict{
			Columns:   []clause.Column{{Name: "id"}},
			DoUpdates: clause.AssignmentColumns([]string{"classcode", "class_name", "asset_code", "asset_type", "category", "sub_category", "flag"}),
			// DoUpdates: clause.AssignmentColumns([]string{"rating"}),
		}).CreateInBatches(&datamodelUpdate, 1000).Error
		if err != nil {
			fmt.Println(err)
			Zerologs.Error().Msg("Error while Inserting data into Sclass_mst")
		}
		Zerologs.Info().Msgf(" execution time for Sclass_mst ==>", time.Since(start))
		buffer.WriteString("Total Record updated " + strconv.Itoa(count) + "\n")
		return nil
	})

	// })
	return nil
}

func Schemeload(strjson []byte, buffer *bytes.Buffer) error {
	var arryJson []interface{}
	if err := json.Unmarshal(strjson, &arryJson); err != nil {
		buffer.WriteString(err.Error() + "\n")
		return err
	}
	var datamodelUpdate []accord.Schemeload
	count := 0
	// q.Enqueue(arryJson, func(data interface{}) {
	db.Accord.Transaction(func(tx *gorm.DB) error {
		start := time.Now()
		for _, json := range arryJson {
			jsonmap := json.(map[string]interface{})
			datamodel := accord.Schemeload{}
			datamodel.SCHEMECODE = helper.GetIntfromMap(jsonmap, "SCHEMECODE")
			datamodel.LDATE = helper.GetTimefromMap(jsonmap, "LDATE")
			datamodel.LTYPECODE = helper.GetIntfromMap(jsonmap, "LTYPECODE")
			datamodel.LSRNO = helper.GetIntfromMap(jsonmap, "LSRNO")
			// err := tx.Where("schemecode=? AND ldate=? AND ltypecode=? AND lsrno=?", datamodel.SCHEMECODE, datamodel.LDATE, datamodel.LTYPECODE, datamodel.LSRNO).First(&datamodel).Error
			// if err != nil {
			// 	Zerologs.Error().Msg("Record Not Found In Schemeload" + err.Error())
			// }
			schemecode := strconv.Itoa(datamodel.SCHEMECODE)
			lDate := datamodel.LDATE.String()
			lTypeCode := strconv.Itoa(datamodel.LTYPECODE)
			lSrNo := strconv.Itoa(datamodel.LSRNO)
			schemecode_lDate_lTypeCode_lSrNo := schemecode + "_" + lDate + "_" + lTypeCode + "_" + lSrNo
			datamodel.ID = schemecode_lDate_lTypeCode_lSrNo
			datamodel.FRMAMOUNT = helper.GetFloatfromMap(jsonmap, "FRMAMOUNT")
			datamodel.UPTOAMOUNT = helper.GetFloatfromMap(jsonmap, "UPTOAMOUNT")
			datamodel.MINPERIOD = helper.GetIntfromMap(jsonmap, "MINPERIOD")
			datamodel.MAXPERIOD = helper.GetIntfromMap(jsonmap, "MAXPERIOD")
			datamodel.MIN = helper.GetStringfromMap(jsonmap, "MIN")
			datamodel.MAX = helper.GetStringfromMap(jsonmap, "MAX")
			datamodel.ENTRYLOAD = helper.GetFloatfromMap(jsonmap, "ENTRYLOAD")
			datamodel.EXITLOAD = helper.GetFloatfromMap(jsonmap, "EXITLOAD")
			datamodel.REMARKS = helper.GetStringfromMap(jsonmap, "REMARKS")
			datamodel.Period_Condition = helper.GetStringfromMap(jsonmap, "Period_Condition")
			datamodel.Period_Type = helper.GetStringfromMap(jsonmap, "Period_Type")
			datamodel.Period = helper.GetStringfromMap(jsonmap, "Period")
			datamodel.Amount_Condition = helper.GetStringfromMap(jsonmap, "Amount_Condition")
			datamodel.Amount_Type = helper.GetStringfromMap(jsonmap, "Amount_Type")
			datamodel.Per_Condition = helper.GetStringfromMap(jsonmap, "Per_Condition")
			datamodel.Per_Frm = helper.GetFloatfromMap(jsonmap, "Per_Frm")
			datamodel.Per_To = helper.GetFloatfromMap(jsonmap, "Per_To")
			datamodel.FLAG = helper.GetStringfromMap(jsonmap, "FLAG")

			// err := tx.Where("schemecode=? AND ldate=? AND ltypecode=? AND lsrno=?", datamodel.SCHEMECODE, datamodel.LDATE, datamodel.LTYPECODE, datamodel.LSRNO).First(&datamodel).Error
			// if err != nil {
			// 	err := tx.Create(&datamodel).Error
			// 	if err != nil {
			// 		buffer.WriteString(err.Error())
			// 	}
			// } else {
			// err = tx.Save(&datamodel).Error
			// if err != nil {
			// 	buffer.WriteString(err.Error())
			// }
			// }
			datamodelUpdate = append(datamodelUpdate, datamodel)
			count++

		}
		err := db.Accord.Clauses(clause.OnConflict{
			Columns:   []clause.Column{{Name: "id"}},
			DoUpdates: clause.AssignmentColumns([]string{"schemecode", "ldate", "ltypecode", "lsrno", "frmamount", "uptoamount", "minperiod", "maxperiod", "min", "max", "entryload", "exitload", "remarks", "period_condition", "period_type", "period", "amount_condition", "amount_type", "per_condition", "per_frm", "per_to", "flag"}),
			// DoUpdates: clause.AssignmentColumns([]string{"rating"}),
		}).CreateInBatches(&datamodelUpdate, 1000).Error
		if err != nil {
			fmt.Println(err)
			Zerologs.Error().Msg("Error while Inserting data into Schemeload")
		}
		Zerologs.Info().Msgf(" execution time for Schemeload ==>", time.Since(start))
		buffer.WriteString("Total Record updated " + strconv.Itoa(count) + "\n")
		return nil
	})

	// })
	return nil
}

func Schemeisinmaster(strjson []byte, buffer *bytes.Buffer) error {
	var arryJson []interface{}
	if err := json.Unmarshal(strjson, &arryJson); err != nil {
		buffer.WriteString(err.Error() + "\n")
		return err
	}
	var datamodelUpdate []accord.Schemeisinmaster
	count := 0
	// q.Enqueue(arryJson, func(data interface{}) {
	db.Accord.Transaction(func(tx *gorm.DB) error {
		start := time.Now()
		for _, json := range arryJson {
			jsonmap := json.(map[string]interface{})
			datamodel := accord.Schemeisinmaster{}

			datamodel.ISIN = helper.GetStringfromMap(jsonmap, "ISIN")
			// err := tx.Where("isin=?", datamodel.ISIN).First(&datamodel).Error
			// if err != nil {
			// 	Zerologs.Error().Msg("Record Not Found In Schemeisinmaster" + err.Error())
			// }
			datamodel.ID = datamodel.ISIN
			datamodel.Schemecode = helper.GetIntfromMap(jsonmap, "Schemecode")
			datamodel.Amc_code = helper.GetIntfromMap(jsonmap, "Amc_code")
			datamodel.NseSymbol = helper.GetStringfromMap(jsonmap, "NseSymbol")
			datamodel.Series = helper.GetStringfromMap(jsonmap, "Series")
			datamodel.RTASchemecode = helper.GetStringfromMap(jsonmap, "RTASchemecode")
			datamodel.AMCSchemecode = helper.GetStringfromMap(jsonmap, "AMCSchemecode")
			datamodel.LongSchemeDescrip = helper.GetStringfromMap(jsonmap, "LongSchemeDescrip")
			datamodel.ShortSchemeDescrip = helper.GetStringfromMap(jsonmap, "ShortSchemeDescrip")
			datamodel.Status = helper.GetStringfromMap(jsonmap, "Status")
			datamodel.Flag = helper.GetStringfromMap(jsonmap, "flag")

			// err := tx.Where("isin=?", datamodel.ISIN).First(&datamodel).Error
			// if err != nil {
			// 	err := tx.Create(&datamodel).Error
			// 	if err != nil {
			// 		buffer.WriteString(err.Error())
			// 	}
			// } else {
			// err = tx.Save(&datamodel).Error
			// if err != nil {
			// 	buffer.WriteString(err.Error())
			// }
			datamodelUpdate = append(datamodelUpdate, datamodel)
			// }
			count++

		}
		err := db.Accord.Clauses(clause.OnConflict{
			Columns:   []clause.Column{{Name: "id"}},
			DoUpdates: clause.AssignmentColumns([]string{"isin", "schemecode", "amc_code", "nse_symbol", "series", "rta_schemecode", "amc_schemecode", "long_scheme_descrip", "short_scheme_descrip", "status", "flag"}),
			// DoUpdates: clause.AssignmentColumns([]string{"rating"}),
		}).CreateInBatches(&datamodelUpdate, 1000).Error
		if err != nil {
			fmt.Println(err)
			Zerologs.Error().Msg("Error while Inserting data into Schemeisinmaster")
		}
		Zerologs.Info().Msgf(" execution time for Schemeisinmaster ==>", time.Since(start))
		buffer.WriteString("Total Record updated " + strconv.Itoa(count) + "\n")
		return nil
	})

	// })
	return nil
}

func CorpEvents(strjson []byte, buffer *bytes.Buffer) error {
	var arryJson []interface{}
	if err := json.Unmarshal(strjson, &arryJson); err != nil {
		buffer.WriteString(err.Error() + "\n")
		return err
	}
	var datamodelUpdate []accord.Corpevent
	count := 0
	// q.Enqueue(arryJson, func(data interface{}) {
	db.Accord.Transaction(func(tx *gorm.DB) error {
		start := time.Now()
		for _, json := range arryJson {
			jsonmap := json.(map[string]interface{})
			datamodel := accord.Corpevent{}
			datamodel.FINCODE = helper.GetIntfromMap(jsonmap, "FINCODE")
			datamodel.SDATE = helper.GetTimefromMap(jsonmap, "SDATE")
			datamodel.SRNO = helper.GetIntfromMap(jsonmap, "SRNO")
			datamodel.CORPACT_ID = helper.GetIntfromMap(jsonmap, "CORPACT_ID")
			// err := tx.Where("fincode=? AND sdate=? AND srno=? AND corpact_id=?", datamodel.FINCODE, datamodel.SDATE, datamodel.SRNO, datamodel.CORPACT_ID).First(&datamodel).Error

			// if err != nil {
			// 	Zerologs.Error().Msg("Record Not Found In CorpEvent" + err.Error())
			// }
			fincode := strconv.Itoa(datamodel.FINCODE)
			sDate := datamodel.SDATE.String()
			srNo := strconv.Itoa(datamodel.SRNO)
			corpact_id := strconv.Itoa(datamodel.CORPACT_ID)
			fincode_sDate_srNo_corpid := fincode + "_" + sDate + "_" + srNo + "_" + corpact_id
			datamodel.ID = fincode_sDate_srNo_corpid
			datamodel.RECRD_DATE = helper.GetTimefromMap(jsonmap, "RECRD_DATE")
			datamodel.CUMDATE = helper.GetTimefromMap(jsonmap, "CUMDATE")
			datamodel.DETAILS = helper.GetStringfromMap(jsonmap, "DETAILS")
			datamodel.EF_FROMDATE = helper.GetTimefromMap(jsonmap, "EF_FROMDATE")
			datamodel.EF_TODATE = helper.GetTimefromMap(jsonmap, "EF_TODATE")
			datamodel.EX_DATE = helper.GetTimefromMap(jsonmap, "EX_DATE")
			datamodel.OFFERPRICE = helper.GetFloatfromMap(jsonmap, "OFFERPRICE")
			datamodel.PREMPRICE = helper.GetFloatfromMap(jsonmap, "PREMPRICE")
			datamodel.RATIO1 = helper.GetFloatfromMap(jsonmap, "RATIO1")
			datamodel.RATIO2 = helper.GetFloatfromMap(jsonmap, "RATIO2")
			datamodel.AggregateAmmnt = helper.GetFloatfromMap(jsonmap, "AggregateAmnt")
			datamodel.Amount = helper.GetFloatfromMap(jsonmap, "Amount")
			datamodel.DIVIDEND_TYPE = helper.GetStringfromMap(jsonmap, "DIVIDEND_TYPE")
			datamodel.Face_value = helper.GetFloatfromMap(jsonmap, "Face_value")
			datamodel.Face_value2 = helper.GetFloatfromMap(jsonmap, "Face_value2")
			datamodel.FROMSHARES = helper.GetFloatfromMap(jsonmap, "FROMSHARES")
			datamodel.NoofShares = helper.GetFloatfromMap(jsonmap, "NoofShares")
			datamodel.NosExtn = helper.GetFloatfromMap(jsonmap, "NosExtn")
			datamodel.Partyname = helper.GetStringfromMap(jsonmap, "Partyname")
			datamodel.SUBJECT = helper.GetStringfromMap(jsonmap, "SUBJECT")
			datamodel.ToShares = helper.GetFloatfromMap(jsonmap, "ToShares")
			datamodel.Type = helper.GetStringfromMap(jsonmap, "Type")
			datamodel.CAPTION = helper.GetStringfromMap(jsonmap, "CAPTION")
			datamodel.FLAG = helper.GetStringfromMap(jsonmap, "FLAG")

			// err = tx.Save(&datamodel).Error
			// if err != nil {
			// 	buffer.WriteString(err.Error())
			// }
			datamodelUpdate = append(datamodelUpdate, datamodel)

			count++

		}
		err := db.Accord.Clauses(clause.OnConflict{
			Columns:   []clause.Column{{Name: "id"}},
			DoUpdates: clause.AssignmentColumns([]string{"fincode", "sdate", "srno", "recrd_date", "corpact_id", "cumdate", "details", "ef_fromdate", "ef_todate", "ex_date", "offerprice", "premprice", "ratio1", "ratio2", "aggregate_ammnt", "amount", "div_id_end_type", "face_value", "face_value2", "fromshares", "noof_shares", "nos_extn", "partyname", "subject", "to_shares", "type", "caption", "flag"}),
			// DoUpdates: clause.AssignmentColumns([]string{"rating"}),
		}).CreateInBatches(&datamodelUpdate, 1000).Error
		if err != nil {
			fmt.Println(err)
			Zerologs.Error().Msg("Error while Inserting data into Corpevent")
		}
		Zerologs.Info().Msgf(" execution time for Corpevent ==>", time.Since(start))
		buffer.WriteString("Total Record updated " + strconv.Itoa(count) + "\n")
		return nil
	})

	// })
	return nil
}

func Shpsummary(strjson []byte, buffer *bytes.Buffer) error {
	var arryJson []interface{}
	if err := json.Unmarshal(strjson, &arryJson); err != nil {
		buffer.WriteString(err.Error() + "\n")
		return err
	}
	var datamodelUpdate []accord.Shpsummary
	count := 0
	// q.Enqueue(arryJson, func(data interface{}) {
	db.Accord.Transaction(func(tx *gorm.DB) error {
		start := time.Now()
		for _, json := range arryJson {
			jsonmap := json.(map[string]interface{})
			datamodel := accord.Shpsummary{}
			datamodel.FINCODE = helper.GetIntfromMap(jsonmap, "FINCODE")
			datamodel.DATE_END = helper.GetInt64fromMap(jsonmap, "DATE_END")
			// err := tx.Where("fincode=? AND date_end=?", datamodel.FINCODE, datamodel.DATE_END).First(&datamodel).Error

			// if err != nil {
			// 	Zerologs.Error().Msg("Record Not Found In Shpsummary" + err.Error())
			// }
			fincode := strconv.Itoa(datamodel.FINCODE)
			dateEnd := strconv.FormatInt(datamodel.DATE_END, 10)
			fincode_dateEnd := fincode + "_" + dateEnd
			datamodel.ID = fincode_dateEnd
			datamodel.NhINDindivd = helper.GetFloatfromMap(jsonmap, "nhINDindivd")
			datamodel.NsINDindivd = helper.GetFloatfromMap(jsonmap, "nsINDindivd")
			datamodel.DpINDindivd = helper.GetFloatfromMap(jsonmap, "dpINDindivd")
			datamodel.TpINDindivd = helper.GetFloatfromMap(jsonmap, "tpINDindivd")
			datamodel.NhINDcgovt = helper.GetFloatfromMap(jsonmap, "nhINDcgovt")
			datamodel.NsINDcgovt = helper.GetFloatfromMap(jsonmap, "nsINDcgovt")
			datamodel.DpINDcgovt = helper.GetFloatfromMap(jsonmap, "dpINDcgovt")
			datamodel.TpINDcgovt = helper.GetFloatfromMap(jsonmap, "tpINDcgovt")
			datamodel.NhINDbodyCorp = helper.GetFloatfromMap(jsonmap, "nhINDbodyCorp")
			datamodel.NsINDbodyCorp = helper.GetFloatfromMap(jsonmap, "nsINDbodyCorp")
			datamodel.DpINDbodyCorp = helper.GetFloatfromMap(jsonmap, "dpINDbodyCorp")
			datamodel.TpINDbodyCorp = helper.GetFloatfromMap(jsonmap, "tpINDbodyCorp")
			datamodel.NhINDFIBankcc = helper.GetFloatfromMap(jsonmap, "nhINDFIBankcc")
			datamodel.NsINDFIBankcc = helper.GetFloatfromMap(jsonmap, "nsINDFIBankcc")
			datamodel.DpINDFIBankcc = helper.GetFloatfromMap(jsonmap, "dpINDFIBankcc")
			datamodel.TpINDFIBankcc = helper.GetFloatfromMap(jsonmap, "tpINDFIBankcc")
			datamodel.NhINDOther = helper.GetFloatfromMap(jsonmap, "nhINDOther")
			datamodel.NsINDOther = helper.GetFloatfromMap(jsonmap, "nsINDOther")
			datamodel.DpINDOther = helper.GetFloatfromMap(jsonmap, "dpINDOther")
			datamodel.TpINDOther = helper.GetFloatfromMap(jsonmap, "tpINDOther")
			datamodel.NhINDSubtotal = helper.GetFloatfromMap(jsonmap, "nhINDSubtotal")
			datamodel.NsINDSubtotal = helper.GetFloatfromMap(jsonmap, "nsINDSubtotal")
			datamodel.DpINDSubtotal = helper.GetFloatfromMap(jsonmap, "dpINDSubtotal")
			datamodel.TpINDSubtotal = helper.GetFloatfromMap(jsonmap, "tpINDSubtotal")
			datamodel.NhFNRIFN = helper.GetFloatfromMap(jsonmap, "nhFNRIFN")
			datamodel.NsFNRIFN = helper.GetFloatfromMap(jsonmap, "nsFNRIFN")
			datamodel.DpFNRIFN = helper.GetFloatfromMap(jsonmap, "dpFNRIFN")
			datamodel.TpFNRIFN = helper.GetFloatfromMap(jsonmap, "tpFNRIFN")
			datamodel.NhFbodyCorp = helper.GetFloatfromMap(jsonmap, "nhFbodyCorp")
			datamodel.NsFbodyCorp = helper.GetFloatfromMap(jsonmap, "nsFbodyCorp")
			datamodel.DpFbodyCorp = helper.GetFloatfromMap(jsonmap, "dpFbodyCorp")
			datamodel.TpFbodyCorp = helper.GetFloatfromMap(jsonmap, "tpFbodyCorp")
			datamodel.NhFInstitution = helper.GetFloatfromMap(jsonmap, "nhFInstitution")
			datamodel.NsFInstitution = helper.GetFloatfromMap(jsonmap, "nsFInstitution")
			datamodel.DpFInstitution = helper.GetFloatfromMap(jsonmap, "dpFInstitution")
			datamodel.TpFInstitution = helper.GetFloatfromMap(jsonmap, "tpFInstitution")
			datamodel.NhFOther = helper.GetFloatfromMap(jsonmap, "nhFOther")
			datamodel.NsFOther = helper.GetFloatfromMap(jsonmap, "nsFOther")
			datamodel.DpFOther = helper.GetFloatfromMap(jsonmap, "dpFOther")
			datamodel.TpFOther = helper.GetFloatfromMap(jsonmap, "tpFOther")
			datamodel.NhFSubtotal = helper.GetFloatfromMap(jsonmap, "nhFSubtotal")
			datamodel.NsFSubtotal = helper.GetFloatfromMap(jsonmap, "nsFSubtotal")
			datamodel.DpFSubtotal = helper.GetFloatfromMap(jsonmap, "dpFSubtotal")
			datamodel.TpFSubtotal = helper.GetFloatfromMap(jsonmap, "tpFSubtotal")
			datamodel.NhFtotalpromoter = helper.GetFloatfromMap(jsonmap, "nhFtotalpromoter")
			datamodel.NsFtotalpromoter = helper.GetFloatfromMap(jsonmap, "nsFtotalpromoter")
			datamodel.DpFtotalpromoter = helper.GetFloatfromMap(jsonmap, "dpFtotalpromoter")
			datamodel.TpFtotalpromoter = helper.GetFloatfromMap(jsonmap, "tpFtotalpromoter")
			datamodel.NhINMFUTI = helper.GetFloatfromMap(jsonmap, "nhINMFUTI")
			datamodel.NsINMFUTI = helper.GetFloatfromMap(jsonmap, "nsINMFUTI")
			datamodel.DpINMFUTI = helper.GetFloatfromMap(jsonmap, "dpINMFUTI")
			datamodel.TpINMFUTI = helper.GetFloatfromMap(jsonmap, "tpINMFUTI")
			datamodel.NhINFIBanks = helper.GetFloatfromMap(jsonmap, "nhINFIBanks")
			datamodel.NsINFIBanks = helper.GetFloatfromMap(jsonmap, "nsINFIBanks")
			datamodel.DpINFIBanks = helper.GetFloatfromMap(jsonmap, "dpINFIBanks")
			datamodel.TpINFIBanks = helper.GetFloatfromMap(jsonmap, "tpINFIBanks")
			datamodel.NhINInsurance = helper.GetFloatfromMap(jsonmap, "nhINInsurance")
			datamodel.NsINInsurance = helper.GetFloatfromMap(jsonmap, "nsINInsurance")
			datamodel.DpINInsurance = helper.GetFloatfromMap(jsonmap, "dpINInsurance")
			datamodel.TpINInsurance = helper.GetFloatfromMap(jsonmap, "tpINInsurance")
			datamodel.NhINFII = helper.GetFloatfromMap(jsonmap, "nhINFII")
			datamodel.NsINFII = helper.GetFloatfromMap(jsonmap, "nsINFII")
			datamodel.DpINFII = helper.GetFloatfromMap(jsonmap, "dpINFII")
			datamodel.TpINFII = helper.GetFloatfromMap(jsonmap, "tpINFII")
			datamodel.NhINVenCap = helper.GetFloatfromMap(jsonmap, "nhINVenCap")
			datamodel.NsINVenCap = helper.GetFloatfromMap(jsonmap, "nsINVenCap")
			datamodel.DpINVenCap = helper.GetFloatfromMap(jsonmap, "dpINVenCap")
			datamodel.TpINVenCap = helper.GetFloatfromMap(jsonmap, "tpINVenCap")
			datamodel.NhINForVenCap = helper.GetFloatfromMap(jsonmap, "nhINForVenCap")
			datamodel.NsINForVenCap = helper.GetFloatfromMap(jsonmap, "nsINForVenCap")
			datamodel.DpINForVenCap = helper.GetFloatfromMap(jsonmap, "dpINForVenCap")
			datamodel.TpINForVenCap = helper.GetFloatfromMap(jsonmap, "tpINForVenCap")
			datamodel.NhINcgovt = helper.GetFloatfromMap(jsonmap, "nhINcgovt")
			datamodel.NsINcgovt = helper.GetFloatfromMap(jsonmap, "nsINcgovt")
			datamodel.DpINcgovt = helper.GetFloatfromMap(jsonmap, "dpINcgovt")
			datamodel.TpINcgovt = helper.GetFloatfromMap(jsonmap, "tpINcgovt")
			datamodel.NhINForFinIns = helper.GetFloatfromMap(jsonmap, "nhINForFinIns")
			datamodel.NsINForFinIns = helper.GetFloatfromMap(jsonmap, "nsINForFinIns")
			datamodel.DpINForFinIns = helper.GetFloatfromMap(jsonmap, "dpINForFinIns")
			datamodel.TpINForFinIns = helper.GetFloatfromMap(jsonmap, "tpINForFinIns")
			datamodel.NhINStateFinCorp = helper.GetFloatfromMap(jsonmap, "nhINStateFinCorp")
			datamodel.NsINStateFinCorp = helper.GetFloatfromMap(jsonmap, "nsINStateFinCorp")
			datamodel.DpINStateFinCorp = helper.GetFloatfromMap(jsonmap, "dpINStateFinCorp")
			datamodel.TpINStateFinCorp = helper.GetFloatfromMap(jsonmap, "tpINStateFinCorp")
			datamodel.NhINForBody = helper.GetFloatfromMap(jsonmap, "nhINForBody")
			datamodel.NsINForBody = helper.GetFloatfromMap(jsonmap, "nsINForBody")
			datamodel.DpINForBody = helper.GetFloatfromMap(jsonmap, "dpINForBody")
			datamodel.TpINForBody = helper.GetFloatfromMap(jsonmap, "tpINForBody")
			datamodel.NhINOther = helper.GetFloatfromMap(jsonmap, "nhINOther")
			datamodel.NsINOther = helper.GetFloatfromMap(jsonmap, "nsINOther")
			datamodel.DpINOther = helper.GetFloatfromMap(jsonmap, "dpINOther")
			datamodel.TpINOther = helper.GetFloatfromMap(jsonmap, "tpINOther")
			datamodel.NhINSubtotal = helper.GetFloatfromMap(jsonmap, "nhINSubtotal")
			datamodel.NsINSubtotal = helper.GetFloatfromMap(jsonmap, "nsINSubtotal")
			datamodel.DpINSubtotal = helper.GetFloatfromMap(jsonmap, "dpINSubtotal")
			datamodel.TpINSubtotal = helper.GetFloatfromMap(jsonmap, "tpINSubtotal")
			datamodel.NhNINbodyCorp = helper.GetFloatfromMap(jsonmap, "nhNINbodyCorp")
			datamodel.NsNINbodyCorp = helper.GetFloatfromMap(jsonmap, "nsNINbodyCorp")
			datamodel.DpNINbodyCorp = helper.GetFloatfromMap(jsonmap, "dpNINbodyCorp")
			datamodel.TpNINbodyCorp = helper.GetFloatfromMap(jsonmap, "tpNINbodyCorp")
			datamodel.NhNINIndivd = helper.GetFloatfromMap(jsonmap, "nhNINIndivd")
			datamodel.NsNINIndivd = helper.GetFloatfromMap(jsonmap, "nsNINIndivd")
			datamodel.DpNINIndivd = helper.GetFloatfromMap(jsonmap, "dpNINIndivd")
			datamodel.TpNINIndivd = helper.GetFloatfromMap(jsonmap, "tpNINIndivd")
			datamodel.NhNINIndivd1lac = helper.GetFloatfromMap(jsonmap, "nhNINIndivd1lac")
			datamodel.NsNINIndivd1lac = helper.GetFloatfromMap(jsonmap, "nsNINIndivd1lac")
			datamodel.DpNINIndivd1lac = helper.GetFloatfromMap(jsonmap, "dpNINIndivd1lac")
			datamodel.TpNINIndivd1lac = helper.GetFloatfromMap(jsonmap, "tpNINIndivd1lac")
			datamodel.NhNINIndivd1lacmore = helper.GetFloatfromMap(jsonmap, "nhNINIndivd1lacmore")
			datamodel.NsNINIndivd1lacmore = helper.GetFloatfromMap(jsonmap, "nsNINIndivd1lacmore")
			datamodel.DpNINIndivd1lacmore = helper.GetFloatfromMap(jsonmap, "dpNINIndivd1lacmore")
			datamodel.TpNINIndivd1lacmore = helper.GetFloatfromMap(jsonmap, "tpNINIndivd1lacmore")
			datamodel.NhNINClearMemb = helper.GetFloatfromMap(jsonmap, "nhNINClearMemb")
			datamodel.NsNINClearMemb = helper.GetFloatfromMap(jsonmap, "nsNINClearMemb")
			datamodel.DpNINClearMemb = helper.GetFloatfromMap(jsonmap, "dpNINClearMemb")
			datamodel.TpNINClearMemb = helper.GetFloatfromMap(jsonmap, "tpNINClearMemb")
			datamodel.NhNINNRI = helper.GetFloatfromMap(jsonmap, "nhNINNRI")
			datamodel.NsNINNRI = helper.GetFloatfromMap(jsonmap, "nsNINNRI")
			datamodel.DpNINNRI = helper.GetFloatfromMap(jsonmap, "dpNINNRI")
			datamodel.TpNINNRI = helper.GetFloatfromMap(jsonmap, "tpNINNRI")
			datamodel.NhNINDirector = helper.GetFloatfromMap(jsonmap, "nhNINDirector")
			datamodel.NsNINDirector = helper.GetFloatfromMap(jsonmap, "nsNINDirector")
			datamodel.DpNINDirector = helper.GetFloatfromMap(jsonmap, "dpNINDirector")
			datamodel.TpNINDirector = helper.GetFloatfromMap(jsonmap, "tpNINDirector")
			datamodel.NhNINFornColl = helper.GetFloatfromMap(jsonmap, "nhNINFornColl")
			datamodel.NsNINFornColl = helper.GetFloatfromMap(jsonmap, "nsNINFornColl")
			datamodel.DpNINFornColl = helper.GetFloatfromMap(jsonmap, "dpNINFornColl")
			datamodel.TpNINFornColl = helper.GetFloatfromMap(jsonmap, "tpNINFornColl")
			datamodel.NhNINFornMF = helper.GetFloatfromMap(jsonmap, "nhNINFornMF")
			datamodel.NsNINFornMF = helper.GetFloatfromMap(jsonmap, "nsNINFornMF")
			datamodel.DpNINFornMF = helper.GetFloatfromMap(jsonmap, "dpNINFornMF")
			datamodel.TpNINFornMF = helper.GetFloatfromMap(jsonmap, "tpNINFornMF")
			datamodel.NhNINTrusts = helper.GetFloatfromMap(jsonmap, "nhNINTrusts")
			datamodel.NsNINTrusts = helper.GetFloatfromMap(jsonmap, "nsNINTrusts")
			datamodel.DpNINTrusts = helper.GetFloatfromMap(jsonmap, "dpNINTrusts")
			datamodel.TpNINTrusts = helper.GetFloatfromMap(jsonmap, "tpNINTrusts")
			datamodel.NhNINHUF = helper.GetFloatfromMap(jsonmap, "nhNINHUF")
			datamodel.NsNINHUF = helper.GetFloatfromMap(jsonmap, "nsNINHUF")
			datamodel.DpNINHUF = helper.GetFloatfromMap(jsonmap, "dpNINHUF")
			datamodel.TpNINHUF = helper.GetFloatfromMap(jsonmap, "tpNINHUF")
			datamodel.NhNINFornCorpBody = helper.GetFloatfromMap(jsonmap, "nhNINFornCorpBody")
			datamodel.NsNINFornCorpBody = helper.GetFloatfromMap(jsonmap, "nsNINFornCorpBody")
			datamodel.DpNINFornCorpBody = helper.GetFloatfromMap(jsonmap, "dpNINFornCorpBody")
			datamodel.TpNINFornCorpBody = helper.GetFloatfromMap(jsonmap, "tpNINFornCorpBody")
			datamodel.NhNINShareIntransit = helper.GetFloatfromMap(jsonmap, "nhNINShareIntransit")
			datamodel.NsNINShareIntransit = helper.GetFloatfromMap(jsonmap, "nsNINShareIntransit")
			datamodel.DpNINShareIntransit = helper.GetFloatfromMap(jsonmap, "dpNINShareIntransit")
			datamodel.TpNINShareIntransit = helper.GetFloatfromMap(jsonmap, "tpNINShareIntransit")
			datamodel.NhNINMktMaker = helper.GetFloatfromMap(jsonmap, "nhNINMktMaker")
			datamodel.NsNINMktMaker = helper.GetFloatfromMap(jsonmap, "nsNINMktMaker")
			datamodel.DpNINMktMaker = helper.GetFloatfromMap(jsonmap, "dpNINMktMaker")
			datamodel.TpNINMktMaker = helper.GetFloatfromMap(jsonmap, "tpNINMktMaker")
			datamodel.NhNINEmployees = helper.GetFloatfromMap(jsonmap, "nhNINEmployees")
			datamodel.NsNINEmployees = helper.GetFloatfromMap(jsonmap, "nsNINEmployees")
			datamodel.DpNINEmployees = helper.GetFloatfromMap(jsonmap, "dpNINEmployees")
			datamodel.TpNINEmployees = helper.GetFloatfromMap(jsonmap, "tpNINEmployees")
			datamodel.NhNINSociety = helper.GetFloatfromMap(jsonmap, "nhNINSociety")
			datamodel.NsNINSociety = helper.GetFloatfromMap(jsonmap, "nsNINSociety")
			datamodel.DpNINSociety = helper.GetFloatfromMap(jsonmap, "dpNINSociety")
			datamodel.TpNINSociety = helper.GetFloatfromMap(jsonmap, "tpNINSociety")
			datamodel.NhNINEscrow = helper.GetFloatfromMap(jsonmap, "nhNINEscrow")
			datamodel.NsNINEscrow = helper.GetFloatfromMap(jsonmap, "nsNINEscrow")
			datamodel.DpNINEscrow = helper.GetFloatfromMap(jsonmap, "dpNINEscrow")
			datamodel.TpNINEscrow = helper.GetFloatfromMap(jsonmap, "tpNINEscrow")
			datamodel.NhNINother = helper.GetFloatfromMap(jsonmap, "nhNINother")
			datamodel.NsNINother = helper.GetFloatfromMap(jsonmap, "nsNINother")
			datamodel.DpNINother = helper.GetFloatfromMap(jsonmap, "dpNINother")
			datamodel.TpNINother = helper.GetFloatfromMap(jsonmap, "tpNINother")
			datamodel.NhNINSubtotal = helper.GetFloatfromMap(jsonmap, "nhNINSubtotal")
			datamodel.NsNINSubtotal = helper.GetFloatfromMap(jsonmap, "nsNINSubtotal")
			datamodel.DpNINSubtotal = helper.GetFloatfromMap(jsonmap, "dpNINSubtotal")
			datamodel.TpNINSubtotal = helper.GetFloatfromMap(jsonmap, "tpNINSubtotal")
			datamodel.NhTotalpublic = helper.GetFloatfromMap(jsonmap, "nhTotalpublic")
			datamodel.NsTotalpublic = helper.GetFloatfromMap(jsonmap, "nsTotalpublic")
			datamodel.DpTotalpublic = helper.GetFloatfromMap(jsonmap, "dpTotalpublic")
			datamodel.TpTotalpublic = helper.GetFloatfromMap(jsonmap, "tpTotalpublic")
			datamodel.NhTotalprompublic = helper.GetFloatfromMap(jsonmap, "nhTotalprompublic")
			datamodel.NsTotalprompublic = helper.GetFloatfromMap(jsonmap, "nsTotalprompublic")
			datamodel.DpTotalprompublic = helper.GetFloatfromMap(jsonmap, "dpTotalprompublic")
			datamodel.TpTotalprompublic = helper.GetFloatfromMap(jsonmap, "tpTotalprompublic")
			datamodel.NhCustodianDRs = helper.GetFloatfromMap(jsonmap, "nhCustodianDRs")
			datamodel.NsCustodianDRs = helper.GetFloatfromMap(jsonmap, "nsCustodianDRs")
			datamodel.DpCustodianDRs = helper.GetFloatfromMap(jsonmap, "dpCustodianDRs")
			datamodel.TpCustodianDRs = helper.GetFloatfromMap(jsonmap, "tpCustodianDRs")
			datamodel.NhADR = helper.GetFloatfromMap(jsonmap, "nhADR")
			datamodel.NsADR = helper.GetFloatfromMap(jsonmap, "nsADR")
			datamodel.DpADR = helper.GetFloatfromMap(jsonmap, "dpADR")
			datamodel.TpADR = helper.GetFloatfromMap(jsonmap, "tpADR")
			datamodel.NhGDR = helper.GetFloatfromMap(jsonmap, "nhGDR")
			datamodel.NsGDR = helper.GetFloatfromMap(jsonmap, "nsGDR")
			datamodel.DpGDR = helper.GetFloatfromMap(jsonmap, "dpGDR")
			datamodel.TpGDR = helper.GetFloatfromMap(jsonmap, "tpGDR")
			datamodel.NhOther = helper.GetFloatfromMap(jsonmap, "nhOther")
			datamodel.NsOther = helper.GetFloatfromMap(jsonmap, "nsOther")
			datamodel.DpOther = helper.GetFloatfromMap(jsonmap, "dpOther")
			datamodel.TpOther = helper.GetFloatfromMap(jsonmap, "tpOther")
			datamodel.NhGrandTotal = helper.GetFloatfromMap(jsonmap, "nhGrandTotal")
			datamodel.NsGrandTotal = helper.GetFloatfromMap(jsonmap, "nsGrandTotal")
			datamodel.DpGrandTotal = helper.GetFloatfromMap(jsonmap, "dpGrandTotal")
			datamodel.TpGrandTotal = helper.GetFloatfromMap(jsonmap, "tpGrandTotal")
			datamodel.NhOtherPrtFirms = helper.GetFloatfromMap(jsonmap, "nhOtherPrtFirms")
			datamodel.NsOtherPrtFirms = helper.GetFloatfromMap(jsonmap, "nsOtherPrtFirms")
			datamodel.DpOtherPrtFirms = helper.GetFloatfromMap(jsonmap, "dpOtherPrtFirms")
			datamodel.TpOtherPrtFirms = helper.GetFloatfromMap(jsonmap, "tpOtherPrtFirms")
			datamodel.NhOtherPromgroup = helper.GetFloatfromMap(jsonmap, "nhOtherPromgroup")
			datamodel.NsOtherPromgroup = helper.GetFloatfromMap(jsonmap, "nsOtherPromgroup")
			datamodel.DpOtherPromgroup = helper.GetFloatfromMap(jsonmap, "dpOtherPromgroup")
			datamodel.TpOtherPromgroup = helper.GetFloatfromMap(jsonmap, "tpOtherPromgroup")
			datamodel.NhOtherEWF = helper.GetFloatfromMap(jsonmap, "nhOtherEWF")
			datamodel.NsOtherEWF = helper.GetFloatfromMap(jsonmap, "nsOtherEWF")
			datamodel.DpOtherEWF = helper.GetFloatfromMap(jsonmap, "dpOtherEWF")
			datamodel.TpOtherEWF = helper.GetFloatfromMap(jsonmap, "tpOtherEWF")
			datamodel.NhSASF = helper.GetFloatfromMap(jsonmap, "nhSASF")
			datamodel.NsSASF = helper.GetFloatfromMap(jsonmap, "nsSASF")
			datamodel.DpSASF = helper.GetFloatfromMap(jsonmap, "dpSASF")
			datamodel.TpSASF = helper.GetFloatfromMap(jsonmap, "tpSASF")
			datamodel.NhINDAnyOtherSpecfd = helper.GetFloatfromMap(jsonmap, "nhINDAnyOtherSpecfd")
			datamodel.NhINAnyOtherSpecfd = helper.GetFloatfromMap(jsonmap, "nhINAnyOtherSpecfd")
			datamodel.NsINAnyOtherSpecfd = helper.GetFloatfromMap(jsonmap, "nsINAnyOtherSpecfd")
			datamodel.DpINAnyOtherSpecfd = helper.GetFloatfromMap(jsonmap, "dpINAnyOtherSpecfd")
			datamodel.TpINAnyOtherSpecfd = helper.GetFloatfromMap(jsonmap, "tpINAnyOtherSpecfd")
			datamodel.NhNINAnyOtherSpecfd = helper.GetFloatfromMap(jsonmap, "nhNINAnyOtherSpecfd")
			datamodel.NsNINAnyOtherSpecfd = helper.GetFloatfromMap(jsonmap, "nsNINAnyOtherSpecfd")
			datamodel.DpNINAnyOtherSpecfd = helper.GetFloatfromMap(jsonmap, "dpNINAnyOtherSpecfd")
			datamodel.TpNINAnyOtherSpecfd = helper.GetFloatfromMap(jsonmap, "tpNINAnyOtherSpecfd")
			datamodel.NhFAnyOtherSpecfd = helper.GetFloatfromMap(jsonmap, "nhFAnyOtherSpecfd")
			datamodel.NsFAnyOtherSpecfd = helper.GetFloatfromMap(jsonmap, "nsFAnyOtherSpecfd")
			datamodel.DpFAnyOtherSpecfd = helper.GetFloatfromMap(jsonmap, "dpFAnyOtherSpecfd")
			datamodel.TpFAnyOtherSpecfd = helper.GetFloatfromMap(jsonmap, "tpFAnyOtherSpecfd")
			datamodel.NsINDAnyOtherSpecfd = helper.GetFloatfromMap(jsonmap, "nsINDAnyOtherSpecfd")
			datamodel.DpINDAnyOtherSpecfd = helper.GetFloatfromMap(jsonmap, "dpINDAnyOtherSpecfd")
			datamodel.TpINDAnyOtherSpecfd = helper.GetFloatfromMap(jsonmap, "tpINDAnyOtherSpecfd")
			datamodel.NshINDSubtotal = helper.GetFloatfromMap(jsonmap, "nshINDSubtotal")
			datamodel.NshINDindivd = helper.GetFloatfromMap(jsonmap, "nshINDindivd")
			datamodel.NshINDcgovt = helper.GetFloatfromMap(jsonmap, "nshINDcgovt")
			datamodel.NshINDbodyCorp = helper.GetFloatfromMap(jsonmap, "nshINDbodyCorp")
			datamodel.NshINDFIBankcc = helper.GetFloatfromMap(jsonmap, "nshINDFIBankcc")
			datamodel.NshOtherPrtFirms = helper.GetFloatfromMap(jsonmap, "nshOtherPrtFirms")
			datamodel.NshOtherPromgroup = helper.GetFloatfromMap(jsonmap, "nshOtherPromgroup")
			datamodel.NshOtherEWF = helper.GetFloatfromMap(jsonmap, "nshOtherEWF")
			datamodel.NshINDOther = helper.GetFloatfromMap(jsonmap, "nshINDOther")
			datamodel.NshINDAnyOtherSpecfd = helper.GetFloatfromMap(jsonmap, "nshINDAnyOtherSpecfd")
			datamodel.NshFSubtotal = helper.GetFloatfromMap(jsonmap, "nshFSubtotal")
			datamodel.NshFNRIFN = helper.GetFloatfromMap(jsonmap, "nshFNRIFN")
			datamodel.NshFbodyCorp = helper.GetFloatfromMap(jsonmap, "nshFbodyCorp")
			datamodel.NshFInstitution = helper.GetFloatfromMap(jsonmap, "nshFInstitution")
			datamodel.NshFOther = helper.GetFloatfromMap(jsonmap, "nshFOther")
			datamodel.NshFAnyOtherSpecfd = helper.GetFloatfromMap(jsonmap, "nshFAnyOtherSpecfd")
			datamodel.NshFtotalpromoter = helper.GetFloatfromMap(jsonmap, "nshFtotalpromoter")
			datamodel.NshINSubtotal = helper.GetFloatfromMap(jsonmap, "nshINSubtotal")
			datamodel.NshINMFUTI = helper.GetFloatfromMap(jsonmap, "nshINMFUTI")
			datamodel.NshINFIBanks = helper.GetFloatfromMap(jsonmap, "nshINFIBanks")
			datamodel.NshINInsurance = helper.GetFloatfromMap(jsonmap, "nshINInsurance")
			datamodel.NshINFII = helper.GetFloatfromMap(jsonmap, "nshINFII")
			datamodel.NshINVenCap = helper.GetFloatfromMap(jsonmap, "nshINVenCap")
			datamodel.NshINForVenCap = helper.GetFloatfromMap(jsonmap, "nshINForVenCap")
			datamodel.NshINAnyOtherSpecfd = helper.GetFloatfromMap(jsonmap, "nshINAnyOtherSpecfd")
			datamodel.NshINcgovt = helper.GetFloatfromMap(jsonmap, "nshINcgovt")
			datamodel.NshINForFinIns = helper.GetFloatfromMap(jsonmap, "nshINForFinIns")
			datamodel.NshSASF = helper.GetFloatfromMap(jsonmap, "nshSasF")
			datamodel.NshINStateFinCorp = helper.GetFloatfromMap(jsonmap, "nshINStateFinCorp")
			datamodel.NshINForBody = helper.GetFloatfromMap(jsonmap, "nshINForBody")
			datamodel.NshINOther = helper.GetFloatfromMap(jsonmap, "nshINOther")
			datamodel.NshNINSubtotal = helper.GetFloatfromMap(jsonmap, "nshNINSubtotal")
			datamodel.NshNINbodyCorp = helper.GetFloatfromMap(jsonmap, "nshNINbodyCorp")
			datamodel.NshNINIndivd = helper.GetFloatfromMap(jsonmap, "nshNINIndivd")
			datamodel.NshNINIndivd1lac = helper.GetFloatfromMap(jsonmap, "nshNINIndivd1lac")
			datamodel.NshNINIndivd1lacmore = helper.GetFloatfromMap(jsonmap, "nshNINIndivd1lacmore")
			datamodel.NshNINAnyOtherSpecfd = helper.GetFloatfromMap(jsonmap, "nshNINAnyOtherSpecfd")
			datamodel.NshNINClearMemb = helper.GetFloatfromMap(jsonmap, "nshNINClearMemb")
			datamodel.NshNINNRI = helper.GetFloatfromMap(jsonmap, "nshNINNRI")
			datamodel.NshNINDirector = helper.GetFloatfromMap(jsonmap, "nshNINDirector")
			datamodel.NshNINFornColl = helper.GetFloatfromMap(jsonmap, "nshNINFornColl")
			datamodel.NshNINFornMF = helper.GetFloatfromMap(jsonmap, "nshNINFornMF")
			datamodel.NshNINTrusts = helper.GetFloatfromMap(jsonmap, "nshNINTrusts")
			datamodel.NshNINHUF = helper.GetFloatfromMap(jsonmap, "nshNINHUF")
			datamodel.NshNINFornCorpBody = helper.GetFloatfromMap(jsonmap, "nshNINFornCorpBody")
			datamodel.NshNINShareIntransit = helper.GetFloatfromMap(jsonmap, "nshNINShareIntransit")
			datamodel.NshNINMktMaker = helper.GetFloatfromMap(jsonmap, "nshNINMktMaker")
			datamodel.NshNINEmployees = helper.GetFloatfromMap(jsonmap, "nshNINEmployees")
			datamodel.NshNINSociety = helper.GetFloatfromMap(jsonmap, "nshNINSociety")
			datamodel.NshNINEscrow = helper.GetFloatfromMap(jsonmap, "nshNINEscrow")
			datamodel.NshNINother = helper.GetFloatfromMap(jsonmap, "nshNINother")
			datamodel.NshTotalpublic = helper.GetFloatfromMap(jsonmap, "nshTotalpublic")
			datamodel.NshTotalprompublic = helper.GetFloatfromMap(jsonmap, "nshTotalprompublic")
			datamodel.NshCustodianDRs = helper.GetFloatfromMap(jsonmap, "nshCustodianDRs")
			datamodel.NshADR = helper.GetFloatfromMap(jsonmap, "nshADR")
			datamodel.NshGDR = helper.GetFloatfromMap(jsonmap, "nshGDR")
			datamodel.NshOther = helper.GetFloatfromMap(jsonmap, "nshOther")
			datamodel.NshGrandTotal = helper.GetFloatfromMap(jsonmap, "nshGrandTotal")
			datamodel.PshINDSubtotal = helper.GetFloatfromMap(jsonmap, "pshINDSubtotal")
			datamodel.PshINDindivd = helper.GetFloatfromMap(jsonmap, "pshINDindivd")
			datamodel.PshINDcgovt = helper.GetFloatfromMap(jsonmap, "pshINDcgovt")
			datamodel.PshINDbodyCorp = helper.GetFloatfromMap(jsonmap, "pshINDbodyCorp")
			datamodel.PshINDFIBankcc = helper.GetFloatfromMap(jsonmap, "pshINDFIBankcc")
			datamodel.PshOtherPrtFirms = helper.GetFloatfromMap(jsonmap, "pshOtherPrtFirms")
			datamodel.PshOtherPromgroup = helper.GetFloatfromMap(jsonmap, "pshOtherPromgroup")
			datamodel.PshOtherEWF = helper.GetFloatfromMap(jsonmap, "pshOtherEWF")
			datamodel.PshINDOther = helper.GetFloatfromMap(jsonmap, "pshINDOther")
			datamodel.PshINDAnyOtherSpecfd = helper.GetFloatfromMap(jsonmap, "pshINDAnyOtherSpecfd")
			datamodel.PshFSubtotal = helper.GetFloatfromMap(jsonmap, "pshFSubtotal")
			datamodel.PshFNRIFN = helper.GetFloatfromMap(jsonmap, "pshFNRIFN")
			datamodel.PshFbodyCorp = helper.GetFloatfromMap(jsonmap, "pshFbodyCorp")
			datamodel.PshFInstitution = helper.GetFloatfromMap(jsonmap, "pshFInstitution")
			datamodel.PshFOther = helper.GetFloatfromMap(jsonmap, "pshFOther")
			datamodel.PshFAnyOtherSpecfd = helper.GetFloatfromMap(jsonmap, "pshFAnyOtherSpecfd")
			datamodel.PshFtotalpromoter = helper.GetFloatfromMap(jsonmap, "pshFtotalpromoter")
			datamodel.PshINSubtotal = helper.GetFloatfromMap(jsonmap, "pshINSubtotal")
			datamodel.PshINMFUTI = helper.GetFloatfromMap(jsonmap, "pshINMFUTI")
			datamodel.PshINFIBanks = helper.GetFloatfromMap(jsonmap, "pshINFIBanks")
			datamodel.PshINInsurance = helper.GetFloatfromMap(jsonmap, "pshINInsurance")
			datamodel.PshINFII = helper.GetFloatfromMap(jsonmap, "pshINFII")
			datamodel.PshINVenCap = helper.GetFloatfromMap(jsonmap, "pshINVenCap")
			datamodel.PshINForVenCap = helper.GetFloatfromMap(jsonmap, "pshINForVenCap")
			datamodel.PshINAnyOtherSpecfd = helper.GetFloatfromMap(jsonmap, "pshINAnyOtherSpecfd")
			datamodel.PshINcgovt = helper.GetFloatfromMap(jsonmap, "pshINcgovt")
			datamodel.PshINForFinIns = helper.GetFloatfromMap(jsonmap, "pshINForFinIns")
			datamodel.PshSASF = helper.GetFloatfromMap(jsonmap, "pshSasF")
			datamodel.PshINStateFinCorp = helper.GetFloatfromMap(jsonmap, "pshINStateFinCorp")
			datamodel.PshINForBody = helper.GetFloatfromMap(jsonmap, "pshINForBody")
			datamodel.PshINOther = helper.GetFloatfromMap(jsonmap, "pshINOther")
			datamodel.PshNINSubtotal = helper.GetFloatfromMap(jsonmap, "pshNINSubtotal")
			datamodel.PshNINbodyCorp = helper.GetFloatfromMap(jsonmap, "pshNINbodyCorp")
			datamodel.PshNINIndivd = helper.GetFloatfromMap(jsonmap, "pshNINIndivd")
			datamodel.PshNINIndivd1lac = helper.GetFloatfromMap(jsonmap, "pshNINIndivd1lac")
			datamodel.PshNINIndivd1lacmore = helper.GetFloatfromMap(jsonmap, "pshNINIndivd1lacmore")
			datamodel.PshNINAnyOtherSpecfd = helper.GetFloatfromMap(jsonmap, "pshNINAnyOtherSpecfd")
			datamodel.PshNINClearMemb = helper.GetFloatfromMap(jsonmap, "pshNINClearMemb")
			datamodel.PshNINNRI = helper.GetFloatfromMap(jsonmap, "pshNINNRI")
			datamodel.PshNINDirector = helper.GetFloatfromMap(jsonmap, "pshNINDirector")
			datamodel.PshNINFornColl = helper.GetFloatfromMap(jsonmap, "pshNINFornColl")
			datamodel.PshNINFornMF = helper.GetFloatfromMap(jsonmap, "pshNINFornMF")
			datamodel.PshNINTrusts = helper.GetFloatfromMap(jsonmap, "pshNINTrusts")
			datamodel.PshNINHUF = helper.GetFloatfromMap(jsonmap, "pshNINHUF")
			datamodel.PshNINFornCorpBody = helper.GetFloatfromMap(jsonmap, "pshNINFornCorpBody")
			datamodel.PshNINShareIntransit = helper.GetFloatfromMap(jsonmap, "pshNINShareIntransit")
			datamodel.PshNINMktMaker = helper.GetFloatfromMap(jsonmap, "pshNINMktMaker")
			datamodel.PshNINEmployees = helper.GetFloatfromMap(jsonmap, "pshNINEmployees")
			datamodel.PshNINSociety = helper.GetFloatfromMap(jsonmap, "pshNINSociety")
			datamodel.PshNINEscrow = helper.GetFloatfromMap(jsonmap, "pshNINEscrow")
			datamodel.PshNINother = helper.GetFloatfromMap(jsonmap, "pshNINother")
			datamodel.PshTotalpublic = helper.GetFloatfromMap(jsonmap, "pshTotalpublic")
			datamodel.PshTotalprompublic = helper.GetFloatfromMap(jsonmap, "pshTotalprompublic")
			datamodel.PshCustodianDRs = helper.GetFloatfromMap(jsonmap, "pshCustodianDRs")
			datamodel.PshADR = helper.GetFloatfromMap(jsonmap, "pshADR")
			datamodel.PshOther = helper.GetFloatfromMap(jsonmap, "pshOther")
			datamodel.PshGrandTotal = helper.GetFloatfromMap(jsonmap, "pshGrandTotal")
			datamodel.NhINAltInvFund = helper.GetFloatfromMap(jsonmap, "nhINAltInvFund")
			datamodel.NsINAltInvFund = helper.GetFloatfromMap(jsonmap, "nsINAltInvFund")
			datamodel.DpINAltInvFund = helper.GetFloatfromMap(jsonmap, "dpINAltInvFund")
			datamodel.TpINAltInvFund = helper.GetFloatfromMap(jsonmap, "tpINAltInvFund")
			datamodel.NhINForeignPortInv = helper.GetFloatfromMap(jsonmap, "nhINForeignPortInv")
			datamodel.NsINForeignPortInv = helper.GetFloatfromMap(jsonmap, "nsINForeignPortInv")
			datamodel.DpINForeignPortInv = helper.GetFloatfromMap(jsonmap, "dpINForeignPortInv")
			datamodel.TpINForeignPortInv = helper.GetFloatfromMap(jsonmap, "tpINForeignPortInv")
			datamodel.NhINProviPenFund = helper.GetFloatfromMap(jsonmap, "nhINProviPenFund")
			datamodel.NsINProviPenFund = helper.GetFloatfromMap(jsonmap, "nsINProviPenFund")
			datamodel.DpINProviPenFund = helper.GetFloatfromMap(jsonmap, "dpINProviPenFund")
			datamodel.TpINProviPenFund = helper.GetFloatfromMap(jsonmap, "tpINProviPenFund")
			datamodel.NhNINIndivdNBFC = helper.GetFloatfromMap(jsonmap, "nhNINIndivdNBFC")
			datamodel.NsNINIndivdNBFC = helper.GetFloatfromMap(jsonmap, "nsNINIndivdNBFC")
			datamodel.DpNINIndivdNBFC = helper.GetFloatfromMap(jsonmap, "dpNINIndivdNBFC")
			datamodel.TpNINIndivdNBFC = helper.GetFloatfromMap(jsonmap, "tpNINIndivdNBFC")
			datamodel.NhNINIndEmpTrust = helper.GetFloatfromMap(jsonmap, "nhNINIndEmpTrust")
			datamodel.NsNINIndEmpTrust = helper.GetFloatfromMap(jsonmap, "nsNINIndEmpTrust")
			datamodel.DpNINIndEmpTrust = helper.GetFloatfromMap(jsonmap, "dpNINIndEmpTrust")
			datamodel.TpNINIndEmpTrust = helper.GetFloatfromMap(jsonmap, "tpNINIndEmpTrust")
			datamodel.Flag = helper.GetStringfromMap(jsonmap, "flag")

			// err = tx.Save(&datamodel).Error
			// if err != nil {
			// 	buffer.WriteString(err.Error())
			// }
			datamodelUpdate = append(datamodelUpdate, datamodel)
			count++

		}
		err := db.Accord.Clauses(clause.OnConflict{
			Columns:   []clause.Column{{Name: "id"}},
			DoUpdates: clause.AssignmentColumns([]string{"fincode", "date_end", "nh_in_dindivd", "ns_in_dindivd", "dp_in_dindivd", "tp_in_dindivd", "nh_in_dcgovt", "ns_in_dcgovt", "dp_in_dcgovt", "tp_in_dcgovt", "nh_in_dbody_corp", "ns_in_dbody_corp", "dp_in_dbody_corp", "tp_in_dbody_corp", "nh_indfi_bankcc", "ns_indfi_bankcc", "dp_indfi_bankcc", "tp_indfi_bankcc", "nh_ind_other", "ns_ind_other", "dp_ind_other", "tp_ind_other", "nh_ind_subtotal", "ns_ind_subtotal", "dp_ind_subtotal", "tp_ind_subtotal", "nh_fnrifn", "ns_fnrifn", "dp_fnrifn", "tp_fnrifn", "nh_fbody_corp", "ns_fbody_corp", "dp_fbody_corp", "tp_fbody_corp", "nh_f_institution", "ns_f_institution", "dp_f_institution", "tp_f_institution", "nh_f_other", "ns_f_other", "dp_f_other", "tp_f_other", "nh_f_subtotal", "ns_f_subtotal", "dp_f_subtotal", "tp_f_subtotal", "nh_ftotalpromoter", "ns_ftotalpromoter", "dp_ftotalpromoter", "tp_ftotalpromoter", "nh_inmfuti", "ns_inmfuti", "dp_inmfuti", "tp_inmfuti", "nh_infi_banks", "ns_infi_banks", "dp_infi_banks", "tp_infi_banks", "nh_in_insurance", "ns_in_insurance", "dp_in_insurance", "tp_in_insurance", "nh_infii", "ns_infii", "dp_infii", "tp_infii", "nh_in_ven_cap", "ns_in_ven_cap", "dp_in_ven_cap", "tp_in_ven_cap", "nh_in_for_ven_cap", "ns_in_for_ven_cap", "dp_in_for_ven_cap", "tp_in_for_ven_cap", "nh_i_ncgovt", "ns_i_ncgovt", "dp_i_ncgovt", "tp_i_ncgovt", "nh_in_for_fin_ins", "ns_in_for_fin_ins", "dp_in_for_fin_ins", "tp_in_for_fin_ins", "nh_in_state_fin_corp", "ns_in_state_fin_corp", "dp_in_state_fin_corp", "tp_in_state_fin_corp", "nh_in_for_body", "ns_in_for_body", "dp_in_for_body", "tp_in_for_body", "nh_in_other", "ns_in_other", "dp_in_other", "tp_in_other", "nh_in_subtotal", "ns_in_subtotal", "dp_in_subtotal", "tp_in_subtotal", "nh_ni_nbody_corp", "ns_ni_nbody_corp", "dp_ni_nbody_corp", "tp_ni_nbody_corp", "nh_nin_indivd", "ns_nin_indivd", "dp_nin_indivd", "tp_nin_indivd", "nh_nin_indivd1lac", "ns_nin_indivd1lac", "dp_nin_indivd1lac", "tp_nin_indivd1lac", "nh_nin_indivd1lacmore", "ns_nin_indivd1lacmore", "dp_nin_indivd1lacmore", "tp_nin_indivd1lacmore", "nh_nin_clear_memb", "ns_nin_clear_memb", "dp_nin_clear_memb", "tp_nin_clear_memb", "nh_ninnri", "ns_ninnri", "dp_ninnri", "tp_ninnri", "nh_nin_director", "ns_nin_director", "dp_nin_director", "tp_nin_director", "nh_nin_forn_coll", "ns_nin_forn_coll", "dp_nin_forn_coll", "tp_nin_forn_coll", "nh_nin_forn_mf", "ns_nin_forn_mf", "dp_nin_forn_mf", "tp_nin_forn_mf", "nh_nin_trusts", "ns_nin_trusts", "dp_nin_trusts", "tp_nin_trusts", "nh_ninhuf", "ns_ninhuf", "dp_ninhuf", "tp_ninhuf", "nh_nin_forn_corp_body", "ns_nin_forn_corp_body", "dp_nin_forn_corp_body", "tp_nin_forn_corp_body", "nh_nin_share_intransit", "ns_nin_share_intransit", "dp_nin_share_intransit", "tp_nin_share_intransit", "nh_nin_mkt_maker", "ns_nin_mkt_maker", "dp_nin_mkt_maker", "tp_nin_mkt_maker", "nh_nin_employees", "ns_nin_employees", "dp_nin_employees", "tp_nin_employees", "nh_nin_society", "ns_nin_society", "dp_nin_society", "tp_nin_society", "nh_nin_escrow", "ns_nin_escrow", "dp_nin_escrow", "tp_nin_escrow", "nh_ni_nother", "ns_ni_nother", "dp_ni_nother", "tp_ni_nother", "nh_nin_subtotal", "ns_nin_subtotal", "dp_nin_subtotal", "tp_nin_subtotal", "nh_totalpublic", "ns_totalpublic", "dp_totalpublic", "tp_totalpublic", "nh_totalprompublic", "ns_totalprompublic", "dp_totalprompublic", "tp_totalprompublic", "nh_custodian_d_rs", "ns_custodian_d_rs", "dp_custodian_d_rs", "tp_custodian_d_rs", "nh_adr", "ns_adr", "dp_adr", "tp_adr", "nh_gdr", "ns_gdr", "dp_gdr", "tp_gdr", "nh_other", "ns_other", "dp_other", "tp_other", "nh_grand_total", "ns_grand_total", "dp_grand_total", "tp_grand_total", "nh_other_prt_firms", "ns_other_prt_firms", "dp_other_prt_firms", "tp_other_prt_firms", "nh_other_promgroup", "ns_other_promgroup", "dp_other_promgroup", "tp_other_promgroup", "nh_other_ewf", "ns_other_ewf", "dp_other_ewf", "tp_other_ewf", "nh_sasf", "ns_sasf", "dp_sasf", "tp_sasf", "nh_ind_any_other_specfd", "nh_in_any_other_specfd", "ns_in_any_other_specfd", "dp_in_any_other_specfd", "tp_in_any_other_specfd", "nh_nin_any_other_specfd", "ns_nin_any_other_specfd", "dp_nin_any_other_specfd", "tp_nin_any_other_specfd", "nh_f_any_other_specfd", "ns_f_any_other_specfd", "dp_f_any_other_specfd", "tp_f_any_other_specfd", "ns_ind_any_other_specfd", "dp_ind_any_other_specfd", "tp_ind_any_other_specfd", "nsh_ind_subtotal", "nsh_in_dindivd", "nsh_in_dcgovt", "nsh_in_dbody_corp", "nsh_indfi_bankcc", "nsh_other_prt_firms", "nsh_other_promgroup", "nsh_other_ewf", "nsh_ind_other", "nsh_ind_any_other_specfd", "nsh_f_subtotal", "nsh_fnrifn", "nsh_fbody_corp", "nsh_f_institution", "nsh_f_other", "nsh_f_any_other_specfd", "nsh_ftotalpromoter", "nsh_in_subtotal", "nsh_inmfuti", "nsh_infi_banks", "nsh_in_insurance", "nsh_infii", "nsh_in_ven_cap", "nsh_in_for_ven_cap", "nsh_in_any_other_specfd", "nsh_i_ncgovt", "nsh_in_for_fin_ins", "nsh_sasf", "nsh_in_state_fin_corp", "nsh_in_for_body", "nsh_in_other", "nsh_nin_subtotal", "nsh_ni_nbody_corp", "nsh_nin_indivd", "nsh_nin_indivd1lac", "nsh_nin_indivd1lacmore", "nsh_nin_any_other_specfd", "nsh_nin_clear_memb", "nsh_ninnri", "nsh_nin_director", "nsh_nin_forn_coll", "nsh_nin_forn_mf", "nsh_nin_trusts", "nsh_ninhuf", "nsh_nin_forn_corp_body", "nsh_nin_share_intransit", "nsh_nin_mkt_maker", "nsh_nin_employees", "nsh_nin_society", "nsh_nin_escrow", "nsh_ni_nother", "nsh_totalpublic", "nsh_totalprompublic", "nsh_custodian_d_rs", "nsh_adr", "nsh_gdr", "nsh_other", "nsh_grand_total", "psh_ind_subtotal", "psh_in_dindivd", "psh_in_dcgovt", "psh_in_dbody_corp", "psh_indfi_bankcc", "psh_other_prt_firms", "psh_other_promgroup", "psh_other_ewf", "psh_ind_other", "psh_ind_any_other_specfd", "psh_f_subtotal", "psh_fnrifn", "psh_fbody_corp", "psh_f_institution", "psh_f_other", "psh_f_any_other_specfd", "psh_ftotalpromoter", "psh_in_subtotal", "psh_inmfuti", "psh_infi_banks", "psh_in_insurance", "psh_infii", "psh_in_ven_cap", "psh_in_for_ven_cap", "psh_in_any_other_specfd", "psh_i_ncgovt", "psh_in_for_fin_ins", "psh_sasf", "psh_in_state_fin_corp", "psh_in_for_body", "psh_in_other", "psh_nin_subtotal", "psh_ni_nbody_corp", "psh_nin_indivd", "psh_nin_indivd1lac", "psh_nin_indivd1lacmore", "psh_nin_any_other_specfd", "psh_nin_clear_memb", "psh_ninnri", "psh_nin_director", "psh_nin_forn_coll", "psh_nin_forn_mf", "psh_nin_trusts", "psh_ninhuf", "psh_nin_forn_corp_body", "psh_nin_share_intransit", "psh_nin_mkt_maker", "psh_nin_employees", "psh_nin_society", "psh_nin_escrow", "psh_ni_nother", "psh_totalpublic", "psh_totalprompublic", "psh_custodian_d_rs", "psh_adr", "psh_other", "psh_grand_total", "nh_in_alt_inv_fund", "ns_in_alt_inv_fund", "dp_in_alt_inv_fund", "tp_in_alt_inv_fund", "nh_in_foreign_port_inv", "ns_in_foreign_port_inv", "dp_in_foreign_port_inv", "tp_in_foreign_port_inv", "nh_in_provi_pen_fund", "ns_in_provi_pen_fund", "dp_in_provi_pen_fund", "tp_in_provi_pen_fund", "nh_nin_indivd_nbfc", "ns_nin_indivd_nbfc", "dp_nin_indivd_nbfc", "tp_nin_indivd_nbfc", "nh_nin_ind_emp_trust", "ns_nin_ind_emp_trust", "dp_nin_ind_emp_trust", "tp_nin_ind_emp_trust", "flag"}),
			//DoUpdates: clause.AssignmentColumns([]string{"rating"}),
		}).CreateInBatches(&datamodelUpdate, 150).Error
		if err != nil {
			fmt.Println(err)
			Zerologs.Error().Msg("Error while Inserting data into Shpsummary")
		}
		Zerologs.Info().Msgf(" execution time for Shpsummary ==>", time.Since(start))
		buffer.WriteString("Total Record updated " + strconv.Itoa(count) + "\n")
		return nil
	})

	// })
	return nil
}

func Finance_cons_fr(strjson []byte, buffer *bytes.Buffer) error {
	var arryJson []interface{}
	if err := json.Unmarshal(strjson, &arryJson); err != nil {
		buffer.WriteString(err.Error() + "\n")
		return err
	}
	var datamodelUpdate []accord.Finance_cons_fr
	count := 0
	// q.Enqueue(arryJson, func(data interface{}) {
	db.Accord.Transaction(func(tx *gorm.DB) error {
		start := time.Now()
		for _, json := range arryJson {
			jsonmap := json.(map[string]interface{})
			datamodel := accord.Finance_cons_fr{}
			datamodel.FINCODE = helper.GetIntfromMap(jsonmap, "FINCODE")
			datamodel.Year_end = helper.GetIntfromMap(jsonmap, "Year_end")
			datamodel.TYPE = helper.GetStringfromMap(jsonmap, "TYPE")
			// err := tx.Where("fincode=? AND year_end=? AND type=?", datamodel.FINCODE, datamodel.Year_end, datamodel.TYPE).First(&datamodel).Error

			// if err != nil {
			// 	Zerologs.Error().Msg("Record Not Found In Finance_cons_fr" + err.Error())
			// }
			fincode := strconv.Itoa(datamodel.FINCODE)
			yearEnd := strconv.Itoa(datamodel.Year_end)
			fincode_yearEnd_type := fincode + "_" + yearEnd + "_" + datamodel.TYPE
			datamodel.ID = fincode_yearEnd_type
			datamodel.Reported_EPS = helper.GetFloatfromMap(jsonmap, "Reported_EPS")
			datamodel.Adjusted_EPS = helper.GetFloatfromMap(jsonmap, "Adjusted_EPS")
			datamodel.CEPS = helper.GetFloatfromMap(jsonmap, "CEPS")
			datamodel.DPS = helper.GetFloatfromMap(jsonmap, "DPS")
			datamodel.Book_NAV_Share = helper.GetFloatfromMap(jsonmap, "Book_NAV_Share")
			datamodel.Tax_Rate = helper.GetFloatfromMap(jsonmap, "Tax_Rate")
			datamodel.Core_EBITDA_Margin = helper.GetFloatfromMap(jsonmap, "Core_EBITDA_Margin")
			datamodel.EBIT_Margin = helper.GetFloatfromMap(jsonmap, "EBIT_Margin")
			datamodel.Pre_Tax_Margin = helper.GetFloatfromMap(jsonmap, "Pre_Tax_Margin")
			datamodel.PAT_Margin = helper.GetFloatfromMap(jsonmap, "PAT_Margin")
			datamodel.Cash_Profit_Margin = helper.GetFloatfromMap(jsonmap, "Cash_Profit_Margin")
			datamodel.ROA = helper.GetFloatfromMap(jsonmap, "ROA")
			datamodel.ROE = helper.GetFloatfromMap(jsonmap, "ROE")
			datamodel.ROCE = helper.GetFloatfromMap(jsonmap, "ROCE")
			datamodel.Asset_Turnover = helper.GetFloatfromMap(jsonmap, "Asset_Turnover")
			datamodel.Sales_Fixed_Asset = helper.GetFloatfromMap(jsonmap, "Sales_Fixed_Asset")
			datamodel.Working_Capital_Sales = helper.GetFloatfromMap(jsonmap, "Working_Capital_Sales")
			datamodel.Fixed_Capital_Sales = helper.GetFloatfromMap(jsonmap, "Fixed_Capital_Sales")
			datamodel.Receivable_days = helper.GetFloatfromMap(jsonmap, "Receivable_days")
			datamodel.Inventory_Days = helper.GetFloatfromMap(jsonmap, "Inventory_Days")
			datamodel.Payable_days = helper.GetFloatfromMap(jsonmap, "Payable_days")
			datamodel.PER = helper.GetFloatfromMap(jsonmap, "PER")
			datamodel.PCE = helper.GetFloatfromMap(jsonmap, "PCE")
			datamodel.Price_Book = helper.GetFloatfromMap(jsonmap, "Price_Book")
			datamodel.Yield = helper.GetFloatfromMap(jsonmap, "Yield")
			datamodel.EV_Net_Sales = helper.GetFloatfromMap(jsonmap, "EV_Net_Sales")
			datamodel.EV_Core_EBITDA = helper.GetFloatfromMap(jsonmap, "EV_Core_EBITDA")
			datamodel.EV_EBIT = helper.GetFloatfromMap(jsonmap, "EV_EBIT")
			datamodel.EV_CE = helper.GetFloatfromMap(jsonmap, "EV_CE")
			datamodel.MCap_Sales = helper.GetFloatfromMap(jsonmap, "MCap_Sales")
			datamodel.Net_Sales_Growth = helper.GetFloatfromMap(jsonmap, "Net_Sales_Growth")
			datamodel.PBIDT_Excl_OI_Growth = helper.GetFloatfromMap(jsonmap, "PBIDT_Excl_OI_Growth")
			datamodel.Core_EBITDA_Growth = helper.GetFloatfromMap(jsonmap, "Core_EBITDA_Growth")
			datamodel.EBIT_Growth = helper.GetFloatfromMap(jsonmap, "EBIT_Growth")
			datamodel.PAT_Growth = helper.GetFloatfromMap(jsonmap, "PAT_Growth")
			datamodel.Adj_PAT_Growth = helper.GetFloatfromMap(jsonmap, "Adj_PAT_Growth")
			datamodel.Adj_EPS_Growth = helper.GetFloatfromMap(jsonmap, "Adj_EPS_Growth")
			datamodel.Reported_EPS_Growth = helper.GetFloatfromMap(jsonmap, "Reported_EPS_Growth")
			datamodel.Total_Debt_Equity = helper.GetFloatfromMap(jsonmap, "Total_Debt_Equity")
			datamodel.Current_Ratio = helper.GetFloatfromMap(jsonmap, "Current_Ratio")
			datamodel.Quick_Ratio = helper.GetFloatfromMap(jsonmap, "Quick_Ratio")
			datamodel.Interest_Cover = helper.GetFloatfromMap(jsonmap, "Interest_Cover")
			datamodel.Total_Debt_Mcap = helper.GetFloatfromMap(jsonmap, "Total_Debt_Mcap")
			datamodel.Yield_Adv = helper.GetFloatfromMap(jsonmap, "Yield_Adv")
			datamodel.Yield_Inv = helper.GetFloatfromMap(jsonmap, "Yield_Inv")
			datamodel.Cost_Liab = helper.GetFloatfromMap(jsonmap, "Cost_Liab")
			datamodel.NIM = helper.GetFloatfromMap(jsonmap, "NIM")
			datamodel.Int_Spread = helper.GetFloatfromMap(jsonmap, "Int_Spread")
			datamodel.Cost_IncRatio = helper.GetFloatfromMap(jsonmap, "Cost_IncRatio")
			datamodel.Core_Cost_IncRatio = helper.GetFloatfromMap(jsonmap, "Core_Cost_IncRatio")
			datamodel.OpCost_Asset = helper.GetFloatfromMap(jsonmap, "OpCost_Asset")
			datamodel.Adj_PER = helper.GetFloatfromMap(jsonmap, "Adj_PER")
			datamodel.Tier1Ratio = helper.GetFloatfromMap(jsonmap, "Tier1Ratio")
			datamodel.Tier2Ratio = helper.GetFloatfromMap(jsonmap, "Tier2Ratio")
			datamodel.CAR = helper.GetFloatfromMap(jsonmap, "CAR")
			datamodel.CoreOpIncomeGrowth = helper.GetFloatfromMap(jsonmap, "CoreOpIncomeGrowth")
			datamodel.EPSGrowth = helper.GetFloatfromMap(jsonmap, "EPSGrowth")
			datamodel.BVPSGrowth = helper.GetFloatfromMap(jsonmap, "BVPSGrowth")
			datamodel.Adv_Growth = helper.GetFloatfromMap(jsonmap, "Adv_Growth")
			datamodel.LoanDeposits = helper.GetFloatfromMap(jsonmap, "LoanDeposits")
			datamodel.CashDeposits = helper.GetFloatfromMap(jsonmap, "CashDeposits")
			datamodel.InvestmentDeposits = helper.GetFloatfromMap(jsonmap, "InvestmentDeposits")
			datamodel.IncLoanDeposits = helper.GetFloatfromMap(jsonmap, "IncLoanDeposits")
			datamodel.GrossNPA = helper.GetFloatfromMap(jsonmap, "GrossNPA")
			datamodel.NetNPA = helper.GetFloatfromMap(jsonmap, "NetNPA")
			datamodel.Ownersfund_total_Source = helper.GetFloatfromMap(jsonmap, "Ownersfund_total_Source")
			datamodel.Fixed_Assets_TA = helper.GetFloatfromMap(jsonmap, "Fixed_Assets_TA")
			datamodel.Inventory_TR = helper.GetFloatfromMap(jsonmap, "Inventory_TR")
			datamodel.Dividend_PR_NP = helper.GetFloatfromMap(jsonmap, "Dividend_PR_NP")
			datamodel.Dividend_PR_CP = helper.GetFloatfromMap(jsonmap, "Dividend_PR_CP")
			datamodel.Earning_Retention_Ratio = helper.GetFloatfromMap(jsonmap, "Earning_Retention_Ratio")
			datamodel.Cash_Earnings_Retention = helper.GetFloatfromMap(jsonmap, "Cash_Earnings_Retention")
			datamodel.Price_BV = helper.GetFloatfromMap(jsonmap, "Price_BV")
			datamodel.Return_Sales = helper.GetFloatfromMap(jsonmap, "Return_Sales")
			datamodel.Debt_TA = helper.GetFloatfromMap(jsonmap, "Debt_TA")
			datamodel.EV = helper.GetFloatfromMap(jsonmap, "EV")
			datamodel.PriceSalesRatio = helper.GetFloatfromMap(jsonmap, "PriceSalesRatio")
			datamodel.EV_EBITA = helper.GetFloatfromMap(jsonmap, "EV_EBITA")
			datamodel.CF_PerShare = helper.GetFloatfromMap(jsonmap, "CF_PerShare")
			datamodel.PCF_RATIO = helper.GetFloatfromMap(jsonmap, "PCF_RATIO")
			datamodel.FCF_Share = helper.GetFloatfromMap(jsonmap, "FCF_Share")
			datamodel.PFCF_Ratio = helper.GetFloatfromMap(jsonmap, "PFCF_Ratio")
			datamodel.FCF_Yield = helper.GetFloatfromMap(jsonmap, "FCF_Yield")
			datamodel.SCF_Ratio = helper.GetFloatfromMap(jsonmap, "SCF_Ratio")
			datamodel.GPM = helper.GetFloatfromMap(jsonmap, "GPM")
			datamodel.SalesToTotalAssets = helper.GetFloatfromMap(jsonmap, "SalesToTotalAssets")
			datamodel.SalesToCurrentAssets = helper.GetFloatfromMap(jsonmap, "SalesToCurrentAssets")
			datamodel.Total_CAR_baseI = helper.GetFloatfromMap(jsonmap, "Total_CAR_baseI")
			datamodel.TI_CAR_baseI = helper.GetFloatfromMap(jsonmap, "TI_CAR_baseI")
			datamodel.TII_CAR_baseI = helper.GetFloatfromMap(jsonmap, "TII_CAR_baseI")
			datamodel.Total_CAR = helper.GetFloatfromMap(jsonmap, "Total_CAR")
			datamodel.TI_CAR = helper.GetFloatfromMap(jsonmap, "TI_CAR")
			datamodel.TII_CAR = helper.GetFloatfromMap(jsonmap, "TII_CAR")
			datamodel.NPA_Gross = helper.GetFloatfromMap(jsonmap, "NPA_Gross")
			datamodel.NPA_Net = helper.GetFloatfromMap(jsonmap, "NPA_Net")
			datamodel.NPA_Advances = helper.GetFloatfromMap(jsonmap, "NPA_Advances")
			datamodel.NetProfit_To_PBT = helper.GetFloatfromMap(jsonmap, "NetProfit_To_PBT")
			datamodel.PBT_To_PBIT = helper.GetFloatfromMap(jsonmap, "PBT_To_PBIT")
			datamodel.PBIT_To_Sales = helper.GetFloatfromMap(jsonmap, "PBIT_To_Sales")
			datamodel.NetProfit_To_Sales = helper.GetFloatfromMap(jsonmap, "NetProfit_To_Sales")
			datamodel.NetSales_To_TotalAssets = helper.GetFloatfromMap(jsonmap, "NetSales_To_TotalAssets")
			datamodel.Return_On_Assets = helper.GetFloatfromMap(jsonmap, "Return_On_Assets")
			datamodel.Assets_To_Equity = helper.GetFloatfromMap(jsonmap, "Assets_To_Equity")
			datamodel.Return_On_Equity = helper.GetFloatfromMap(jsonmap, "Return_On_Equity")
			datamodel.Interest_To_Debt = helper.GetFloatfromMap(jsonmap, "Interest_To_Debt")
			datamodel.Debt_To_Assets = helper.GetFloatfromMap(jsonmap, "Debt_To_Assets")
			datamodel.Interest_To_Assets = helper.GetFloatfromMap(jsonmap, "Interest_To_Assets")
			datamodel.ROE_After_Interest = helper.GetFloatfromMap(jsonmap, "ROE_After_Interest")
			datamodel.Dividend_Payout_Per = helper.GetFloatfromMap(jsonmap, "Dividend_Payout_Per")
			datamodel.OtherIncome_To_NetWorth = helper.GetFloatfromMap(jsonmap, "OtherIncome_To_NetWorth")
			datamodel.ROA_After_Interest = helper.GetFloatfromMap(jsonmap, "ROA_After_Interest")
			datamodel.ROE_Before_OtherInc = helper.GetFloatfromMap(jsonmap, "ROE_Before_OtherInc")
			datamodel.ROE_After_OtherInc = helper.GetFloatfromMap(jsonmap, "ROE_After_OtherInc")
			datamodel.ROE_After_Tax_Rate = helper.GetFloatfromMap(jsonmap, "ROE_After_Tax_Rate")
			datamodel.Credit_Deposit = helper.GetFloatfromMap(jsonmap, "Credit_Deposit")
			datamodel.InterestExpended_InterestEarned = helper.GetFloatfromMap(jsonmap, "InterestExpended_InterestEarned")
			datamodel.InterestIncome_TotalFunds = helper.GetFloatfromMap(jsonmap, "InterestIncome_TotalFunds")
			datamodel.InterestExpended_TotalFunds = helper.GetFloatfromMap(jsonmap, "InterestExpended_TotalFunds")
			datamodel.NetInterestIncome_TotalFunds = helper.GetFloatfromMap(jsonmap, "NetInterestIncome_TotalFunds")
			datamodel.CASA = helper.GetFloatfromMap(jsonmap, "CASA")
			datamodel.Inventory_Turnover = helper.GetFloatfromMap(jsonmap, "Inventory_Turnover")
			datamodel.Debtors_Turnover = helper.GetFloatfromMap(jsonmap, "Debtors_Turnover")
			datamodel.Adj_PE = helper.GetFloatfromMap(jsonmap, "Adj_PE")
			datamodel.Adjusted_bv = helper.GetFloatfromMap(jsonmap, "Adjusted_bv")
			datamodel.Adj_DPS = helper.GetFloatfromMap(jsonmap, "Adj_DPS")
			datamodel.Networth_Growth = helper.GetFloatfromMap(jsonmap, "Networth_Growth")
			datamodel.CE_Growth = helper.GetFloatfromMap(jsonmap, "CE_Growth")
			datamodel.GB_Growth = helper.GetFloatfromMap(jsonmap, "GB_Growth")
			datamodel.PBDT_Growth = helper.GetFloatfromMap(jsonmap, "PBDT_Growth")
			datamodel.PBIT_Growth = helper.GetFloatfromMap(jsonmap, "PBIT_Growth")
			datamodel.PBT_Growth = helper.GetFloatfromMap(jsonmap, "PBT_Growth")
			datamodel.CP_Growth = helper.GetFloatfromMap(jsonmap, "CP_Growth")
			datamodel.Exports_Growth = helper.GetFloatfromMap(jsonmap, "Exports_Growth")
			datamodel.Imports_Growth = helper.GetFloatfromMap(jsonmap, "Imports_Growth")
			datamodel.MCap_Growth = helper.GetFloatfromMap(jsonmap, "MCap_Growth")
			datamodel.EBIDTAM = helper.GetFloatfromMap(jsonmap, "EBIDTAM")
			datamodel.PBDTM = helper.GetFloatfromMap(jsonmap, "PBDTM")
			datamodel.LT_Debt_Equity_Ratio = helper.GetFloatfromMap(jsonmap, "LT_Debt_Equity_Ratio")
			datamodel.ROIC = helper.GetFloatfromMap(jsonmap, "ROIC")
			datamodel.Total_car_b = helper.GetFloatfromMap(jsonmap, "Total_car_b")
			datamodel.TI_CAR_b = helper.GetFloatfromMap(jsonmap, "TI_CAR_b")
			datamodel.TII_CAR_b = helper.GetFloatfromMap(jsonmap, "TII_CAR_b")
			datamodel.Flag = helper.GetStringfromMap(jsonmap, "Flag")

			// err = tx.Save(&datamodel).Error
			// if err != nil {
			// 	buffer.WriteString(err.Error())
			// }
			datamodelUpdate = append(datamodelUpdate, datamodel)
			count++
		}
		err := db.Accord.Clauses(clause.OnConflict{
			Columns:   []clause.Column{{Name: "id"}},
			DoUpdates: clause.AssignmentColumns([]string{"fincode", "year_end", "type", "reported_eps", "adjusted_eps", "ceps", "dps", "book_nav_share", "tax_rate", "core_ebitda_margin", "ebit_margin", "pre_tax_margin", "pat_margin", "cash_profit_margin", "roa", "roe", "roce", "asset_turnover", "sales_fixed_asset", "working_capital_sales", "fixed_capital_sales", "receivable_days", "inventory_days", "payable_days", "per", "pce", "price_book", "yield", "ev_net_sales", "ev_core_ebitda", "ev_ebit", "ev_ce", "m_cap_sales", "net_sales_growth", "pb_idt_excl_oi_growth", "core_ebitda_growth", "ebit_growth", "pat_growth", "adj_pat_growth", "adj_eps_growth", "reported_eps_growth", "total_debt_equity", "current_ratio", "quick_ratio", "interest_cover", "total_debt_mcap", "yield_adv", "yield_inv", "cost_liab", "nim", "int_spread", "cost_inc_ratio", "core_cost_inc_ratio", "op_cost_asset", "adj_per", "tier1_ratio", "tier2_ratio", "car", "core_op_income_growth", "eps_growth", "bvps_growth", "adv_growth", "loan_deposits", "cash_deposits", "investment_deposits", "inc_loan_deposits", "gross_npa", "net_npa", "ownersfund_total_source", "fixed_assets_ta", "inventory_tr", "dividend_pr_np", "dividend_pr_cp", "earning_retention_ratio", "cash_earnings_retention", "price_bv", "return_sales", "debt_ta", "ev", "price_sales_ratio", "ev_ebita", "cf_per_share", "pcf_ratio", "fcf_share", "pfcf_ratio", "fcf_yield", "scf_ratio", "gpm", "sales_to_total_assets", "sales_to_current_assets", "total_car_base_i", "ti_car_base_i", "tii_car_base_i", "total_car", "ti_car", "tii_car", "npa_gross", "npa_net", "npa_advances", "net_profit_to_pbt", "pbt_to_pbit", "pbit_to_sales", "net_profit_to_sales", "net_sales_to_total_assets", "return_on_assets", "assets_to_equity", "return_on_equity", "interest_to_debt", "debt_to_assets", "interest_to_assets", "roe_after_interest", "dividend_payout_per", "other_income_to_net_worth", "roa_after_interest", "roe_before_other_inc", "roe_after_other_inc", "roe_after_tax_rate", "credit_deposit", "interest_expended_interest_earned", "interest_income_total_funds", "interest_expended_total_funds", "net_interest_income_total_funds", "casa", "inventory_turnover", "debtors_turnover", "adj_pe", "adjusted_bv", "adj_dps", "networth_growth", "ce_growth", "gb_growth", "pbdt_growth", "pbit_growth", "pbt_growth", "cp_growth", "exports_growth", "imports_growth", "m_cap_growth", "eb_id_tam", "pbdtm", "lt_debt_equity_ratio", "roic", "total_car_b", "ti_car_b", "tii_car_b", "flag"}),
			// DoUpdates: clause.AssignmentColumns([]string{"rating"}),
		}).CreateInBatches(&datamodelUpdate, 300).Error
		if err != nil {
			fmt.Println(err)
			Zerologs.Error().Msg("Error while Inserting data into Finance_cons_fr")
		}
		Zerologs.Info().Msgf(" execution time for Finance_cons_fr ==>", time.Since(start))
		buffer.WriteString("Total Record updated " + strconv.Itoa(count) + "\n")
		return nil
	})

	// })
	return nil
}

func Finance_cons_pl(strjson []byte, buffer *bytes.Buffer) error {
	var arryJson []interface{}
	if err := json.Unmarshal(strjson, &arryJson); err != nil {
		buffer.WriteString(err.Error() + "\n")
		return err
	}
	var datamodelUpdate []accord.Finance_cons_pl
	count := 0
	// q.Enqueue(arryJson, func(data interface{}) {
	db.Accord.Transaction(func(tx *gorm.DB) error {
		start := time.Now()
		for _, json := range arryJson {
			jsonmap := json.(map[string]interface{})
			datamodel := accord.Finance_cons_pl{}
			datamodel.FINCODE = helper.GetIntfromMap(jsonmap, "FINCODE")
			datamodel.Year_end = helper.GetIntfromMap(jsonmap, "Year_end")
			datamodel.TYPE = helper.GetStringfromMap(jsonmap, "TYPE")
			// err := tx.Where("fincode=? AND year_end=? AND type=?", datamodel.FINCODE, datamodel.Year_end, datamodel.TYPE).First(&datamodel).Error

			// if err != nil {
			// 	Zerologs.Error().Msg("Record Not Found In Finance_cons_pl" + err.Error())
			// }
			fincode := strconv.Itoa(datamodel.FINCODE)
			yearEnd := strconv.Itoa(datamodel.Year_end)
			fincode_yearEnd_type := fincode + "_" + yearEnd + "_" + datamodel.TYPE
			datamodel.ID = fincode_yearEnd_type

			datamodel.No_Months = helper.GetIntfromMap(jsonmap, "No_Months")
			datamodel.Unit = helper.GetIntfromMap(jsonmap, "Unit")
			datamodel.Interest_earned = helper.GetFloatfromMap(jsonmap, "Interest_earned")
			datamodel.Other_income = helper.GetFloatfromMap(jsonmap, "Other_income")
			datamodel.Total_income = helper.GetFloatfromMap(jsonmap, "Total_income")
			datamodel.Interest = helper.GetFloatfromMap(jsonmap, "Interest")
			datamodel.Operating_expenses = helper.GetFloatfromMap(jsonmap, "Operating_expenses")
			datamodel.Provisions_contigency = helper.GetFloatfromMap(jsonmap, "Provisions_contigency")
			datamodel.Tax = helper.GetFloatfromMap(jsonmap, "Tax")
			datamodel.Total = helper.GetFloatfromMap(jsonmap, "Total")
			datamodel.Profit_after_tax = helper.GetFloatfromMap(jsonmap, "Profit_after_tax")
			datamodel.Extra_items = helper.GetFloatfromMap(jsonmap, "extra_items")
			datamodel.Profit_Brought_forward = helper.GetFloatfromMap(jsonmap, "Profit_Brought_forward")
			datamodel.Minority_interest = helper.GetFloatfromMap(jsonmap, "Minority_interest")
			datamodel.Share_Associate = helper.GetFloatfromMap(jsonmap, "Share_Associate")
			datamodel.Other_ConsItems = helper.GetFloatfromMap(jsonmap, "Other_ConsItems")
			datamodel.Consolidated_NetProfit = helper.GetFloatfromMap(jsonmap, "Consolidated_NetProfit")
			datamodel.Adj_Net_profit = helper.GetFloatfromMap(jsonmap, "Adj_Net_profit")
			datamodel.Extr_Items = helper.GetFloatfromMap(jsonmap, "Extr_Items")
			datamodel.PNLBF = helper.GetFloatfromMap(jsonmap, "PNLBF")
			datamodel.Profit_availble_appr = helper.GetFloatfromMap(jsonmap, "Profit_availble_appr")
			datamodel.Appropriation = helper.GetFloatfromMap(jsonmap, "Appropriation")
			datamodel.Dividend_perc = helper.GetFloatfromMap(jsonmap, "Dividend_perc")
			datamodel.Reported_EPS = helper.GetFloatfromMap(jsonmap, "Reported_EPS")
			datamodel.Gross_sales = helper.GetFloatfromMap(jsonmap, "Gross_sales")
			datamodel.Net_sales = helper.GetFloatfromMap(jsonmap, "Net_sales")
			datamodel.Inc_Dec_Inventory = helper.GetFloatfromMap(jsonmap, "Inc_Dec_Inventory")
			datamodel.Raw_matrs_consumed = helper.GetFloatfromMap(jsonmap, "Raw_matrs_consumed")
			datamodel.Employees = helper.GetFloatfromMap(jsonmap, "Employees")
			datamodel.Other_Mfg_Exps = helper.GetFloatfromMap(jsonmap, "Other_Mfg_Exps")
			datamodel.Sellg_Admn_Exps = helper.GetFloatfromMap(jsonmap, "Sellg_Admn_Exps")
			datamodel.Misc_exps = helper.GetFloatfromMap(jsonmap, "Misc_exps")
			datamodel.Pre_Op_exps = helper.GetFloatfromMap(jsonmap, "Pre_Op_exps")
			datamodel.Total_expendiure = helper.GetFloatfromMap(jsonmap, "Total_expendiure")
			datamodel.Operating_profit = helper.GetFloatfromMap(jsonmap, "Operating_profit")
			datamodel.Depreciation = helper.GetFloatfromMap(jsonmap, "Depreciation")
			datamodel.Profit_before_exception = helper.GetFloatfromMap(jsonmap, "Profit_before_exception")
			datamodel.ExceptionalIncome_Expenses = helper.GetFloatfromMap(jsonmap, "ExceptionalIncome_Expenses")
			datamodel.Profit_before_tax = helper.GetFloatfromMap(jsonmap, "Profit_before_tax")
			datamodel.Taxation = helper.GetFloatfromMap(jsonmap, "Taxation")
			datamodel.Profit_available_appropriation = helper.GetFloatfromMap(jsonmap, "Profit_available_appropriation")
			datamodel.Total_gross_sales = helper.GetFloatfromMap(jsonmap, "Total_gross_sales")
			datamodel.Excise = helper.GetFloatfromMap(jsonmap, "Excise")
			datamodel.Power_Fuel = helper.GetFloatfromMap(jsonmap, "Power_Fuel")
			datamodel.Gross_profits = helper.GetFloatfromMap(jsonmap, "Gross_profits")
			datamodel.Inter_div_trf = helper.GetFloatfromMap(jsonmap, "inter_div_trf")
			datamodel.Sales_return = helper.GetFloatfromMap(jsonmap, "Sales_return")
			datamodel.Sellg_Exps = helper.GetFloatfromMap(jsonmap, "Sellg_Exps")
			datamodel.Cost_SW = helper.GetFloatfromMap(jsonmap, "Cost_SW")
			datamodel.Provision_investment = helper.GetFloatfromMap(jsonmap, "Provision_investment")
			datamodel.Provision_advances = helper.GetFloatfromMap(jsonmap, "Provision_advances")
			datamodel.Provision_other = helper.GetFloatfromMap(jsonmap, "Provision_other")
			datamodel.Curr_tax = helper.GetFloatfromMap(jsonmap, "Curr_tax")
			datamodel.Def_tax = helper.GetFloatfromMap(jsonmap, "Def_tax")
			datamodel.Fringe_benefits = helper.GetFloatfromMap(jsonmap, "Fringe_benefits")
			datamodel.Wealth_tax = helper.GetFloatfromMap(jsonmap, "Wealth_tax")
			datamodel.Interest_advances_Bills = helper.GetFloatfromMap(jsonmap, "Interest_advances_Bills")
			datamodel.Job_works = helper.GetFloatfromMap(jsonmap, "Job_works")
			datamodel.Service_income = helper.GetFloatfromMap(jsonmap, "Service_income")
			datamodel.Opening_RM = helper.GetFloatfromMap(jsonmap, "Opening_RM")
			datamodel.Purchases_RM = helper.GetFloatfromMap(jsonmap, "Purchases_RM")
			datamodel.Closing_RM = helper.GetFloatfromMap(jsonmap, "Closing_RM")
			datamodel.Purchases_FG = helper.GetFloatfromMap(jsonmap, "Purchases_FG")
			datamodel.Electricity = helper.GetFloatfromMap(jsonmap, "Electricity")
			datamodel.Oils_fuels = helper.GetFloatfromMap(jsonmap, "Oils_fuels")
			datamodel.Coals = helper.GetFloatfromMap(jsonmap, "Coals")
			datamodel.Salaries = helper.GetFloatfromMap(jsonmap, "Salaries")
			datamodel.Providend_fund_contri = helper.GetFloatfromMap(jsonmap, "Providend_fund_contri")
			datamodel.Staff_welfare = helper.GetFloatfromMap(jsonmap, "Staff_welfare")
			datamodel.Sub_contract = helper.GetFloatfromMap(jsonmap, "sub_contract")
			datamodel.Processing_charges = helper.GetFloatfromMap(jsonmap, "processing_charges")
			datamodel.Repairs_maintenance = helper.GetFloatfromMap(jsonmap, "repairs_maintenance")
			datamodel.UpKeep_maintenance = helper.GetFloatfromMap(jsonmap, "UpKeep_maintenance")
			datamodel.Rent_rates_taxes = helper.GetFloatfromMap(jsonmap, "rent_rates_taxes")
			datamodel.Insurance = helper.GetFloatfromMap(jsonmap, "Insurance")
			datamodel.Priting_stationery = helper.GetFloatfromMap(jsonmap, "priting_stationery")
			datamodel.Professional_charges = helper.GetFloatfromMap(jsonmap, "professional_charges")
			datamodel.Travelling = helper.GetFloatfromMap(jsonmap, "travelling")
			datamodel.Advertising = helper.GetFloatfromMap(jsonmap, "Advertising")
			datamodel.Commission_incentives = helper.GetFloatfromMap(jsonmap, "Commission_incentives")
			datamodel.Freight_forwardings = helper.GetFloatfromMap(jsonmap, "freight_forwardings")
			datamodel.Handling_clearing = helper.GetFloatfromMap(jsonmap, "Handling_clearing")
			datamodel.Bad_debts = helper.GetFloatfromMap(jsonmap, "Bad_debts")
			datamodel.Prov_Doubtfull_debts = helper.GetFloatfromMap(jsonmap, "Prov_Doubtfull_debts")
			datamodel.Loss_Fixed_assets = helper.GetFloatfromMap(jsonmap, "Loss_Fixed_assets")
			datamodel.Loss_Foreign_exchange = helper.GetFloatfromMap(jsonmap, "Loss_Foreign_exchange")
			datamodel.Loss_sale_Investment = helper.GetFloatfromMap(jsonmap, "Loss_sale_Investment")
			datamodel.Interest_income = helper.GetFloatfromMap(jsonmap, "Interest_income")
			datamodel.Dividend_income = helper.GetFloatfromMap(jsonmap, "Dividend_income")
			datamodel.Profit_FA = helper.GetFloatfromMap(jsonmap, "Profit_FA")
			datamodel.Profit_Investment = helper.GetFloatfromMap(jsonmap, "Profit_Investment")
			datamodel.Prov_written_back = helper.GetFloatfromMap(jsonmap, "Prov_written_back")
			datamodel.Foreign_exchange_gain = helper.GetFloatfromMap(jsonmap, "Foreign_exchange_gain")
			datamodel.Interest_deb = helper.GetFloatfromMap(jsonmap, "Interest_deb")
			datamodel.Interest_Term_loans = helper.GetFloatfromMap(jsonmap, "Interest_Term_loans")
			datamodel.Interest_fixed_deposits = helper.GetFloatfromMap(jsonmap, "Interest_fixed_deposits")
			datamodel.Bank_charges = helper.GetFloatfromMap(jsonmap, "Bank_charges")
			datamodel.Appropriation_General_Reserve = helper.GetFloatfromMap(jsonmap, "Appropriation_General_Reserve")
			datamodel.Proposed_Equity_devided = helper.GetFloatfromMap(jsonmap, "Proposed_Equity_devided")
			datamodel.Corp_Divd_tax = helper.GetFloatfromMap(jsonmap, "Corp_Divd_tax")
			datamodel.EPS = helper.GetFloatfromMap(jsonmap, "EPS")
			datamodel.Adj_Eps = helper.GetFloatfromMap(jsonmap, "Adj_Eps")
			datamodel.Interest_RBI = helper.GetFloatfromMap(jsonmap, "Interest_RBI")
			datamodel.Interest_investment = helper.GetFloatfromMap(jsonmap, "Interest_investment")
			datamodel.Income_JV_subs = helper.GetFloatfromMap(jsonmap, "Income_JV_subs")
			datamodel.Rent_income = helper.GetFloatfromMap(jsonmap, "Rent_income")
			datamodel.Interest_RBI_borrowings = helper.GetFloatfromMap(jsonmap, "Interest_RBI_borrowings")
			datamodel.Interest_other = helper.GetFloatfromMap(jsonmap, "Interest_other")
			datamodel.Depreciation_leased_assets = helper.GetFloatfromMap(jsonmap, "Depreciation_leased_assets")
			datamodel.Auditor_payment = helper.GetFloatfromMap(jsonmap, "Auditor_payment")
			datamodel.Telephone = helper.GetFloatfromMap(jsonmap, "Telephone")
			datamodel.Repairs_other_admin = helper.GetFloatfromMap(jsonmap, "repairs_other_admin")
			datamodel.Statutory_reserve = helper.GetFloatfromMap(jsonmap, "Statutory_reserve")
			datamodel.Appropriation_Revenue_Reserve = helper.GetFloatfromMap(jsonmap, "Appropriation_Revenue_Reserve")
			datamodel.Other_appropriation = helper.GetFloatfromMap(jsonmap, "Other_appropriation")
			datamodel.Sale_Shares_Units = helper.GetFloatfromMap(jsonmap, "Sale_Shares_Units")
			datamodel.Interest_earned_loan = helper.GetFloatfromMap(jsonmap, "Interest_earned_loan")
			datamodel.Portfolio_mgt_income = helper.GetFloatfromMap(jsonmap, "Portfolio_mgt_income")
			datamodel.Dividend_earned = helper.GetFloatfromMap(jsonmap, "Dividend_earned")
			datamodel.Brokerage_commission = helper.GetFloatfromMap(jsonmap, "Brokerage_commission")
			datamodel.Processing_fees = helper.GetFloatfromMap(jsonmap, "Processing_fees")
			datamodel.Depository_charges = helper.GetFloatfromMap(jsonmap, "Depository_charges")
			datamodel.Security_trasaction_tax = helper.GetFloatfromMap(jsonmap, "Security_trasaction_tax")
			datamodel.Software_technical_charges = helper.GetFloatfromMap(jsonmap, "Software_technical_charges")
			datamodel.Provision_contigency = helper.GetFloatfromMap(jsonmap, "Provision_contigency")
			datamodel.Provision_NPA = helper.GetFloatfromMap(jsonmap, "provision_NPA")
			datamodel.Other_interest_income = helper.GetFloatfromMap(jsonmap, "Other_interest_income")
			datamodel.Commision = helper.GetFloatfromMap(jsonmap, "Commision")
			datamodel.Discounts = helper.GetFloatfromMap(jsonmap, "Discounts")
			datamodel.Other_Investmnet_income = helper.GetFloatfromMap(jsonmap, "Other_Investmnet_income")
			datamodel.Sales = helper.GetFloatfromMap(jsonmap, "Sales")
			datamodel.Income_Diagnostic = helper.GetFloatfromMap(jsonmap, "Income_Diagnostic")
			datamodel.Cash_discount = helper.GetFloatfromMap(jsonmap, "Cash_discount")
			datamodel.UpKeep_service = helper.GetFloatfromMap(jsonmap, "UpKeep_service")
			datamodel.Consultant_changes = helper.GetFloatfromMap(jsonmap, "Consultant_changes")
			datamodel.Packing_materials = helper.GetFloatfromMap(jsonmap, "Packing_materials")
			datamodel.Freight_outward = helper.GetFloatfromMap(jsonmap, "freight_outward")
			datamodel.Room_restaurents = helper.GetFloatfromMap(jsonmap, "Room_restaurents")
			datamodel.Communication_income = helper.GetFloatfromMap(jsonmap, "Communication_income")
			datamodel.Foods_beverage_Sales = helper.GetFloatfromMap(jsonmap, "Foods_beverage_Sales")
			datamodel.Linen_Room_supplies = helper.GetFloatfromMap(jsonmap, "Linen_Room_supplies")
			datamodel.Catering_supplies = helper.GetFloatfromMap(jsonmap, "Catering_supplies")
			datamodel.Laundry_washing_expenses = helper.GetFloatfromMap(jsonmap, "Laundry_washing_expenses")
			datamodel.Music_banquest_restaurants = helper.GetFloatfromMap(jsonmap, "music_banquest_restaurants")
			datamodel.Packing_expemses = helper.GetFloatfromMap(jsonmap, "packing_expemses")
			datamodel.Sales_property_development = helper.GetFloatfromMap(jsonmap, "Sales_property_development")
			datamodel.Broadcasting_revenue = helper.GetFloatfromMap(jsonmap, "Broadcasting_revenue")
			datamodel.Adverisement_revenue = helper.GetFloatfromMap(jsonmap, "Adverisement_revenue")
			datamodel.Licence_income = helper.GetFloatfromMap(jsonmap, "Licence_income")
			datamodel.Subscription_income = helper.GetFloatfromMap(jsonmap, "Subscription_income")
			datamodel.Contents_film_income = helper.GetFloatfromMap(jsonmap, "Contents_film_income")
			datamodel.Program_production_exps = helper.GetFloatfromMap(jsonmap, "Program_production_exps")
			datamodel.Telecastin_expenses = helper.GetFloatfromMap(jsonmap, "Telecastin_expenses")
			datamodel.Programs_Films_right = helper.GetFloatfromMap(jsonmap, "Programs_Films_right")
			datamodel.Transmission_EPC = helper.GetFloatfromMap(jsonmap, "Transmission_EPC")
			datamodel.Wheeling_Transmission = helper.GetFloatfromMap(jsonmap, "Wheeling_Transmission")
			datamodel.Power_Purchased = helper.GetFloatfromMap(jsonmap, "Power_Purchased")
			datamodel.Power_project_cost = helper.GetFloatfromMap(jsonmap, "Power_project_cost")
			datamodel.Wheeling_charges = helper.GetFloatfromMap(jsonmap, "wheeling_charges")
			datamodel.Spare_consumed = helper.GetFloatfromMap(jsonmap, "Spare_consumed")
			datamodel.Sub_contract_charges = helper.GetFloatfromMap(jsonmap, "Sub_contract_charges")
			datamodel.Development_rights = helper.GetFloatfromMap(jsonmap, "Development_rights")
			datamodel.Development_charges = helper.GetFloatfromMap(jsonmap, "Development_charges")
			datamodel.Income_Investment_property = helper.GetFloatfromMap(jsonmap, "Income_Investment_property")
			datamodel.Development_rights_cost = helper.GetFloatfromMap(jsonmap, "Development_rights_cost")
			datamodel.Shipbuilding_income = helper.GetFloatfromMap(jsonmap, "Shipbuilding_income")
			datamodel.Charter_income = helper.GetFloatfromMap(jsonmap, "Charter_income")
			datamodel.Freight_Income = helper.GetFloatfromMap(jsonmap, "freight_Income")
			datamodel.Stevedoreage_cargo_expenses = helper.GetFloatfromMap(jsonmap, "Stevedoreage_cargo_expenses")
			datamodel.Port_charges = helper.GetFloatfromMap(jsonmap, "Port_charges")
			datamodel.Sale_licenses = helper.GetFloatfromMap(jsonmap, "Sale_licenses")
			datamodel.Traded_sw = helper.GetFloatfromMap(jsonmap, "Traded_sw")
			datamodel.Tech_fees = helper.GetFloatfromMap(jsonmap, "Tech_fees")
			datamodel.Traing_exps = helper.GetFloatfromMap(jsonmap, "Traing_exps")
			datamodel.Software_licences = helper.GetFloatfromMap(jsonmap, "Software_licences")
			datamodel.Travels_SW = helper.GetFloatfromMap(jsonmap, "Travels_SW")
			datamodel.Insurance_SW = helper.GetFloatfromMap(jsonmap, "Insurance_SW")
			datamodel.Visa_charges = helper.GetFloatfromMap(jsonmap, "Visa_charges")
			datamodel.Contract_Support_SW = helper.GetFloatfromMap(jsonmap, "Contract_Support_SW")
			datamodel.Rates_taxes = helper.GetFloatfromMap(jsonmap, "rates_taxes")
			datamodel.Sales_scrap = helper.GetFloatfromMap(jsonmap, "Sales_scrap")
			datamodel.Export_benefits = helper.GetFloatfromMap(jsonmap, "Export_benefits")
			datamodel.Subsidy_incentives = helper.GetFloatfromMap(jsonmap, "Subsidy_incentives")
			datamodel.Freight_inward = helper.GetFloatfromMap(jsonmap, "freight_inward")
			datamodel.Hire_charges_mfg = helper.GetFloatfromMap(jsonmap, "Hire_charges_mfg")
			datamodel.Donation = helper.GetFloatfromMap(jsonmap, "Donation")
			datamodel.Interest_Other_income = helper.GetFloatfromMap(jsonmap, "Interest_Other_income")
			datamodel.Commission = helper.GetFloatfromMap(jsonmap, "Commission")
			datamodel.Power_fuel_cost = helper.GetFloatfromMap(jsonmap, "Power_fuel_cost")
			datamodel.Royalty = helper.GetFloatfromMap(jsonmap, "royalty")
			datamodel.Project_expenses = helper.GetFloatfromMap(jsonmap, "Project_expenses")
			datamodel.Flag = helper.GetStringfromMap(jsonmap, "flag")

			// err = tx.Save(&datamodel).Error
			// if err != nil {
			// 	buffer.WriteString(err.Error())
			// }
			datamodelUpdate = append(datamodelUpdate, datamodel)
			count++
		}
		err := db.Accord.Clauses(clause.OnConflict{
			Columns:   []clause.Column{{Name: "id"}},
			DoUpdates: clause.AssignmentColumns([]string{"fincode", "year_end", "type", "no_months", "unit", "interest_earned", "other_income", "total_income", "interest", "operating_expenses", "provisions_contigency", "tax", "total", "profit_after_tax", "extra_items", "profit_brought_forward", "minority_interest", "share_associate", "other_cons_items", "consolidated_net_profit", "adj_net_profit", "extr_items", "pnlbf", "profit_availble_appr", "appropriation", "dividend_perc", "reported_eps", "gross_sales", "net_sales", "inc_dec_inventory", "raw_matrs_consumed", "employees", "other_mfg_exps", "sellg_admn_exps", "misc_exps", "pre_op_exps", "total_expendiure", "operating_profit", "depreciation", "profit_before_exception", "exceptional_income_expenses", "profit_before_tax", "taxation", "profit_available_appropriation", "total_gross_sales", "excise", "power_fuel", "gross_profits", "inter_div_trf", "sales_return", "sellg_exps", "cost_sw", "provision_investment", "provision_advances", "provision_other", "curr_tax", "def_tax", "fringe_benefits", "wealth_tax", "interest_advances_bills", "job_works", "service_income", "opening_rm", "purchases_rm", "closing_rm", "purchases_fg", "electricity", "oils_fuels", "coals", "salaries", "providend_fund_contri", "staff_welfare", "sub_contract", "processing_charges", "repairs_maintenance", "up_keep_maintenance", "rent_rates_taxes", "insurance", "priting_stationery", "professional_charges", "travelling", "advertising", "commission_incentives", "freight_forwardings", "handling_clearing", "bad_debts", "prov_doubtfull_debts", "loss_fixed_assets", "loss_foreign_exchange", "loss_sale_investment", "interest_income", "dividend_income", "profit_fa", "profit_investment", "prov_written_back", "foreign_exchange_gain", "interest_deb", "interest_term_loans", "interest_fixed_deposits", "bank_charges", "appropriation_general_reserve", "proposed_equity_devided", "corp_divd_tax", "eps", "adj_eps", "interest_rbi", "interest_investment", "income_jv_subs", "rent_income", "interest_rbi_borrowings", "interest_other", "depreciation_leased_assets", "auditor_payment", "telephone", "repairs_other_admin", "statutory_reserve", "appropriation_revenue_reserve", "other_appropriation", "sale_shares_units", "interest_earned_loan", "portfolio_mgt_income", "dividend_earned", "brokerage_commission", "processing_fees", "depository_charges", "security_trasaction_tax", "software_technical_charges", "provision_contigency", "provision_npa", "other_interest_income", "commision", "discounts", "other_investmnet_income", "sales", "income_diagnostic", "cash_discount", "up_keep_service", "consultant_changes", "packing_materials", "freight_outward", "room_restaurents", "communication_income", "foods_beverage_sales", "linen_room_supplies", "catering_supplies", "laundry_washing_expenses", "music_banquest_restaurants", "packing_expemses", "sales_property_development", "broadcasting_revenue", "adverisement_revenue", "licence_income", "subscription_income", "contents_film_income", "program_production_exps", "telecastin_expenses", "programs_films_right", "transmission_epc", "wheeling_transmission", "power_purchased", "power_project_cost", "wheeling_charges", "spare_consumed", "sub_contract_charges", "development_rights", "development_charges", "income_investment_property", "development_rights_cost", "shipbuilding_income", "charter_income", "freight_income", "stevedoreage_cargo_expenses", "port_charges", "sale_licenses", "traded_sw", "tech_fees", "traing_exps", "software_licences", "travels_sw", "insurance_sw", "visa_charges", "contract_support_sw", "rates_taxes", "sales_scrap", "export_benefits", "subsidy_incentives", "freight_inward", "hire_charges_mfg", "donation", "interest_other_income", "commission", "power_fuel_cost", "royalty", "project_expenses", "flag"}),
			//DoUpdates: clause.AssignmentColumns([]string{"rating"}),
		}).CreateInBatches(&datamodelUpdate, 300).Error
		if err != nil {
			fmt.Println(err)
			Zerologs.Error().Msg("Error while Inserting data into Finance_cons_pl")
		}
		Zerologs.Info().Msgf(" execution time for Finance_cons_pl ==>", time.Since(start))
		buffer.WriteString("Total Record updated " + strconv.Itoa(count) + "\n")
		return nil
	})

	// })
	return nil
}

func Finance_fr(strjson []byte, buffer *bytes.Buffer) error {
	var arryJson []interface{}
	if err := json.Unmarshal(strjson, &arryJson); err != nil {
		buffer.WriteString(err.Error() + "\n")
		return err
	}
	var datamodelUpdate []accord.Finance_fr
	count := 0
	// q.Enqueue(arryJson, func(data interface{}) {
	db.Accord.Transaction(func(tx *gorm.DB) error {
		start := time.Now()
		for _, json := range arryJson {
			jsonmap := json.(map[string]interface{})
			datamodel := accord.Finance_fr{}
			datamodel.FINCODE = helper.GetIntfromMap(jsonmap, "FINCODE")
			datamodel.Year_end = helper.GetIntfromMap(jsonmap, "Year_end")
			datamodel.TYPE = helper.GetStringfromMap(jsonmap, "TYPE")
			// err := tx.Where("fincode=? AND year_end=? AND type=?", datamodel.FINCODE, datamodel.Year_end, datamodel.TYPE).First(&datamodel).Error

			// if err != nil {
			// 	Zerologs.Error().Msg("Record Not Found In Finance_fr" + err.Error())
			// }
			fincode := strconv.Itoa(datamodel.FINCODE)
			yearEnd := strconv.Itoa(datamodel.Year_end)
			fincode_yearEnd_type := fincode + "_" + yearEnd + "_" + datamodel.TYPE
			datamodel.ID = fincode_yearEnd_type
			datamodel.Reported_EPS = helper.GetFloatfromMap(jsonmap, "Reported_EPS")
			datamodel.Adjusted_EPS = helper.GetFloatfromMap(jsonmap, "Adjusted_EPS")
			datamodel.CEPS = helper.GetFloatfromMap(jsonmap, "CEPS")
			datamodel.DPS = helper.GetFloatfromMap(jsonmap, "DPS")
			datamodel.Book_NAV_Share = helper.GetFloatfromMap(jsonmap, "Book_NAV_Share")
			datamodel.Tax_Rate = helper.GetFloatfromMap(jsonmap, "Tax_Rate")
			datamodel.Core_EBITDA_Margin = helper.GetFloatfromMap(jsonmap, "Core_EBITDA_Margin")
			datamodel.EBIT_Margin = helper.GetFloatfromMap(jsonmap, "EBIT_Margin")
			datamodel.Pre_Tax_Margin = helper.GetFloatfromMap(jsonmap, "Pre_Tax_Margin")
			datamodel.PAT_Margin = helper.GetFloatfromMap(jsonmap, "PAT_Margin")
			datamodel.Cash_Profit_Margin = helper.GetFloatfromMap(jsonmap, "Cash_Profit_Margin")
			datamodel.ROA = helper.GetFloatfromMap(jsonmap, "ROA")
			datamodel.ROE = helper.GetFloatfromMap(jsonmap, "ROE")
			datamodel.ROCE = helper.GetFloatfromMap(jsonmap, "ROCE")
			datamodel.Asset_Turnover = helper.GetFloatfromMap(jsonmap, "Asset_Turnover")
			datamodel.Sales_Fixed_Asset = helper.GetFloatfromMap(jsonmap, "Sales_Fixed_Asset")
			datamodel.Working_Capital_Sales = helper.GetFloatfromMap(jsonmap, "Working_Capital_Sales")
			datamodel.Fixed_Capital_Sales = helper.GetFloatfromMap(jsonmap, "Fixed_Capital_Sales")
			datamodel.Receivable_days = helper.GetFloatfromMap(jsonmap, "Receivable_days")
			datamodel.Inventory_Days = helper.GetFloatfromMap(jsonmap, "Inventory_Days")
			datamodel.Payable_days = helper.GetFloatfromMap(jsonmap, "Payable_days")
			datamodel.PER = helper.GetFloatfromMap(jsonmap, "PER")
			datamodel.PCE = helper.GetFloatfromMap(jsonmap, "PCE")
			datamodel.Price_Book = helper.GetFloatfromMap(jsonmap, "Price_Book")
			datamodel.Yield = helper.GetFloatfromMap(jsonmap, "Yield")
			datamodel.EV_Net_Sales = helper.GetFloatfromMap(jsonmap, "EV_Net_Sales")
			datamodel.EV_Core_EBITDA = helper.GetFloatfromMap(jsonmap, "EV_Core_EBITDA")
			datamodel.EV_EBIT = helper.GetFloatfromMap(jsonmap, "EV_EBIT")
			datamodel.EV_CE = helper.GetFloatfromMap(jsonmap, "EV_CE")
			datamodel.MCap_Sales = helper.GetFloatfromMap(jsonmap, "MCap_Sales")
			datamodel.Net_Sales_Growth = helper.GetFloatfromMap(jsonmap, "Net_Sales_Growth")
			datamodel.PBIDT_Excl_OI_Growth = helper.GetFloatfromMap(jsonmap, "PBIDT_Excl_OI_Growth")
			datamodel.Core_EBITDA_Growth = helper.GetFloatfromMap(jsonmap, "Core_EBITDA_Growth")
			datamodel.EBIT_Growth = helper.GetFloatfromMap(jsonmap, "EBIT_Growth")
			datamodel.PAT_Growth = helper.GetFloatfromMap(jsonmap, "PAT_Growth")
			datamodel.Adj_PAT_Growth = helper.GetFloatfromMap(jsonmap, "Adj_PAT_Growth")
			datamodel.Adj_EPS_Growth = helper.GetFloatfromMap(jsonmap, "Adj_EPS_Growth")
			datamodel.Reported_EPS_Growth = helper.GetFloatfromMap(jsonmap, "Reported_EPS_Growth")
			datamodel.Total_Debt_Equity = helper.GetFloatfromMap(jsonmap, "Total_Debt_Equity")
			datamodel.Current_Ratio = helper.GetFloatfromMap(jsonmap, "Current_Ratio")
			datamodel.Quick_Ratio = helper.GetFloatfromMap(jsonmap, "Quick_Ratio")
			datamodel.Interest_Cover = helper.GetFloatfromMap(jsonmap, "Interest_Cover")
			datamodel.Total_Debt_Mcap = helper.GetFloatfromMap(jsonmap, "Total_Debt_Mcap")
			datamodel.Yield_Adv = helper.GetFloatfromMap(jsonmap, "Yield_Adv")
			datamodel.Yield_Inv = helper.GetFloatfromMap(jsonmap, "Yield_Inv")
			datamodel.Cost_Liab = helper.GetFloatfromMap(jsonmap, "Cost_Liab")
			datamodel.NIM = helper.GetFloatfromMap(jsonmap, "NIM")
			datamodel.Int_Spread = helper.GetFloatfromMap(jsonmap, "Int_Spread")
			datamodel.Cost_IncRatio = helper.GetFloatfromMap(jsonmap, "Cost_IncRatio")
			datamodel.Core_Cost_IncRatio = helper.GetFloatfromMap(jsonmap, "Core_Cost_IncRatio")
			datamodel.OpCost_Asset = helper.GetFloatfromMap(jsonmap, "OpCost_Asset")
			datamodel.Adj_PER = helper.GetFloatfromMap(jsonmap, "Adj_PER")
			datamodel.Tier1Ratio = helper.GetFloatfromMap(jsonmap, "Tier1Ratio")
			datamodel.Tier2Ratio = helper.GetFloatfromMap(jsonmap, "Tier2Ratio")
			datamodel.CAR = helper.GetFloatfromMap(jsonmap, "CAR")
			datamodel.CoreOpIncomeGrowth = helper.GetFloatfromMap(jsonmap, "CoreOpIncomeGrowth")
			datamodel.EPSGrowth = helper.GetFloatfromMap(jsonmap, "EPSGrowth")
			datamodel.BVPSGrowth = helper.GetFloatfromMap(jsonmap, "BVPSGrowth")
			datamodel.Adv_Growth = helper.GetFloatfromMap(jsonmap, "Adv_Growth")
			datamodel.LoanDeposits = helper.GetFloatfromMap(jsonmap, "LoanDeposits")
			datamodel.CashDeposits = helper.GetFloatfromMap(jsonmap, "CashDeposits")
			datamodel.InvestmentDeposits = helper.GetFloatfromMap(jsonmap, "InvestmentDeposits")
			datamodel.IncLoanDeposits = helper.GetFloatfromMap(jsonmap, "IncLoanDeposits")
			datamodel.GrossNPA = helper.GetFloatfromMap(jsonmap, "GrossNPA")
			datamodel.NetNPA = helper.GetFloatfromMap(jsonmap, "NetNPA")
			datamodel.Ownersfund_total_Source = helper.GetFloatfromMap(jsonmap, "Ownersfund_total_Source")
			datamodel.Fixed_Assets_TA = helper.GetFloatfromMap(jsonmap, "Fixed_Assets_TA")
			datamodel.Inventory_TR = helper.GetFloatfromMap(jsonmap, "Inventory_TR")
			datamodel.Dividend_PR_NP = helper.GetFloatfromMap(jsonmap, "Dividend_PR_NP")
			datamodel.Dividend_PR_CP = helper.GetFloatfromMap(jsonmap, "Dividend_PR_CP")
			datamodel.Earning_Retention_Ratio = helper.GetFloatfromMap(jsonmap, "Earning_Retention_Ratio")
			datamodel.Cash_Earnings_Retention = helper.GetFloatfromMap(jsonmap, "Cash_Earnings_Retention")
			datamodel.Price_BV = helper.GetFloatfromMap(jsonmap, "Price_BV")
			datamodel.Return_Sales = helper.GetFloatfromMap(jsonmap, "Return_Sales")
			datamodel.Debt_TA = helper.GetFloatfromMap(jsonmap, "Debt_TA")
			datamodel.EV = helper.GetFloatfromMap(jsonmap, "EV")
			datamodel.PriceSalesRatio = helper.GetFloatfromMap(jsonmap, "PriceSalesRatio")
			datamodel.EV_EBITA = helper.GetFloatfromMap(jsonmap, "EV_EBITA")
			datamodel.CF_PerShare = helper.GetFloatfromMap(jsonmap, "CF_PerShare")
			datamodel.PCF_RATIO = helper.GetFloatfromMap(jsonmap, "PCF_RATIO")
			datamodel.FCF_Share = helper.GetFloatfromMap(jsonmap, "FCF_Share")
			datamodel.PFCF_Ratio = helper.GetFloatfromMap(jsonmap, "PFCF_Ratio")
			datamodel.FCF_Yield = helper.GetFloatfromMap(jsonmap, "FCF_Yield")
			datamodel.SCF_Ratio = helper.GetFloatfromMap(jsonmap, "SCF_Ratio")
			datamodel.GPM = helper.GetFloatfromMap(jsonmap, "GPM")
			datamodel.SalesToTotalAssets = helper.GetFloatfromMap(jsonmap, "SalesToTotalAssets")
			datamodel.SalesToCurrentAssets = helper.GetFloatfromMap(jsonmap, "SalesToCurrentAssets")
			datamodel.Total_CAR_baseI = helper.GetFloatfromMap(jsonmap, "Total_CAR_baseI")
			datamodel.TI_CAR_baseI = helper.GetFloatfromMap(jsonmap, "TI_CAR_baseI")
			datamodel.TII_CAR_baseI = helper.GetFloatfromMap(jsonmap, "TII_CAR_baseI")
			datamodel.Total_CAR = helper.GetFloatfromMap(jsonmap, "Total_CAR")
			datamodel.TI_CAR = helper.GetFloatfromMap(jsonmap, "TI_CAR")
			datamodel.TII_CAR = helper.GetFloatfromMap(jsonmap, "TII_CAR")
			datamodel.NPA_Gross = helper.GetFloatfromMap(jsonmap, "NPA_Gross")
			datamodel.NPA_Net = helper.GetFloatfromMap(jsonmap, "NPA_Net")
			datamodel.NPA_Advances = helper.GetFloatfromMap(jsonmap, "NPA_Advances")
			datamodel.NetProfit_To_PBT = helper.GetFloatfromMap(jsonmap, "NetProfit_To_PBT")
			datamodel.PBT_To_PBIT = helper.GetFloatfromMap(jsonmap, "PBT_To_PBIT")
			datamodel.PBIT_To_Sales = helper.GetFloatfromMap(jsonmap, "PBIT_To_Sales")
			datamodel.NetProfit_To_Sales = helper.GetFloatfromMap(jsonmap, "NetProfit_To_Sales")
			datamodel.NetSales_To_TotalAssets = helper.GetFloatfromMap(jsonmap, "NetSales_To_TotalAssets")
			datamodel.Return_On_Assets = helper.GetFloatfromMap(jsonmap, "Return_On_Assets")
			datamodel.Assets_To_Equity = helper.GetFloatfromMap(jsonmap, "Assets_To_Equity")
			datamodel.Return_On_Equity = helper.GetFloatfromMap(jsonmap, "Return_On_Equity")
			datamodel.Interest_To_Debt = helper.GetFloatfromMap(jsonmap, "Interest_To_Debt")
			datamodel.Debt_To_Assets = helper.GetFloatfromMap(jsonmap, "Debt_To_Assets")
			datamodel.Interest_To_Assets = helper.GetFloatfromMap(jsonmap, "Interest_To_Assets")
			datamodel.ROE_After_Interest = helper.GetFloatfromMap(jsonmap, "ROE_After_Interest")
			datamodel.Dividend_Payout_Per = helper.GetFloatfromMap(jsonmap, "Dividend_Payout_Per")
			datamodel.OtherIncome_To_NetWorth = helper.GetFloatfromMap(jsonmap, "OtherIncome_To_NetWorth")
			datamodel.ROA_After_Interest = helper.GetFloatfromMap(jsonmap, "ROA_After_Interest")
			datamodel.ROE_Before_OtherInc = helper.GetFloatfromMap(jsonmap, "ROE_Before_OtherInc")
			datamodel.ROE_After_OtherInc = helper.GetFloatfromMap(jsonmap, "ROE_After_OtherInc")
			datamodel.ROE_After_Tax_Rate = helper.GetFloatfromMap(jsonmap, "ROE_After_Tax_Rate")
			datamodel.Credit_Deposit = helper.GetFloatfromMap(jsonmap, "Credit_Deposit")
			datamodel.InterestExpended_InterestEarned = helper.GetFloatfromMap(jsonmap, "InterestExpended_InterestEarned")
			datamodel.InterestIncome_TotalFunds = helper.GetFloatfromMap(jsonmap, "InterestIncome_TotalFunds")
			datamodel.InterestExpended_TotalFunds = helper.GetFloatfromMap(jsonmap, "InterestExpended_TotalFunds")
			datamodel.NetInterestIncome_TotalFunds = helper.GetFloatfromMap(jsonmap, "NetInterestIncome_TotalFunds")
			datamodel.CASA = helper.GetFloatfromMap(jsonmap, "CASA")
			datamodel.Inventory_Turnover = helper.GetFloatfromMap(jsonmap, "Inventory_Turnover")
			datamodel.Debtors_Turnover = helper.GetFloatfromMap(jsonmap, "Debtors_Turnover")
			datamodel.Adj_PE = helper.GetFloatfromMap(jsonmap, "Adj_PE")
			datamodel.Adjusted_bv = helper.GetFloatfromMap(jsonmap, "Adjusted_bv")
			datamodel.Adj_DPS = helper.GetFloatfromMap(jsonmap, "Adj_DPS")
			datamodel.Networth_Growth = helper.GetFloatfromMap(jsonmap, "Networth_Growth")
			datamodel.CE_Growth = helper.GetFloatfromMap(jsonmap, "CE_Growth")
			datamodel.GB_Growth = helper.GetFloatfromMap(jsonmap, "GB_Growth")
			datamodel.PBDT_Growth = helper.GetFloatfromMap(jsonmap, "PBDT_Growth")
			datamodel.PBIT_Growth = helper.GetFloatfromMap(jsonmap, "PBIT_Growth")
			datamodel.PBT_Growth = helper.GetFloatfromMap(jsonmap, "PBT_Growth")
			datamodel.CP_Growth = helper.GetFloatfromMap(jsonmap, "CP_Growth")
			datamodel.Exports_Growth = helper.GetFloatfromMap(jsonmap, "Exports_Growth")
			datamodel.Imports_Growth = helper.GetFloatfromMap(jsonmap, "Imports_Growth")
			datamodel.MCap_Growth = helper.GetFloatfromMap(jsonmap, "MCap_Growth")
			datamodel.EBIDTAM = helper.GetFloatfromMap(jsonmap, "EBIDTAM")
			datamodel.PBDTM = helper.GetFloatfromMap(jsonmap, "PBDTM")
			datamodel.LT_Debt_Equity_Ratio = helper.GetFloatfromMap(jsonmap, "LT_Debt_Equity_Ratio")
			datamodel.ROIC = helper.GetFloatfromMap(jsonmap, "ROIC")
			datamodel.Total_car_b = helper.GetFloatfromMap(jsonmap, "Total_car_b")
			datamodel.TI_CAR_b = helper.GetFloatfromMap(jsonmap, "TI_CAR_b")
			datamodel.TII_CAR_b = helper.GetFloatfromMap(jsonmap, "TII_CAR_b")
			datamodel.Flag = helper.GetStringfromMap(jsonmap, "Flag")

			// err = tx.Save(&datamodel).Error
			// if err != nil {
			// 	buffer.WriteString(err.Error())
			// }
			datamodelUpdate = append(datamodelUpdate, datamodel)
			count++
		}
		err := db.Accord.Clauses(clause.OnConflict{
			Columns:   []clause.Column{{Name: "id"}},
			DoUpdates: clause.AssignmentColumns([]string{"fincode", "year_end", "type", "reported_eps", "adjusted_eps", "ceps", "dps", "book_nav_share", "tax_rate", "core_ebitda_margin", "ebit_margin", "pre_tax_margin", "pat_margin", "cash_profit_margin", "roa", "roe", "roce", "asset_turnover", "sales_fixed_asset", "working_capital_sales", "fixed_capital_sales", "receivable_days", "inventory_days", "payable_days", "per", "pce", "price_book", "yield", "ev_net_sales", "ev_core_ebitda", "ev_ebit", "ev_ce", "m_cap_sales", "net_sales_growth", "pb_idt_excl_oi_growth", "core_ebitda_growth", "ebit_growth", "pat_growth", "adj_pat_growth", "adj_eps_growth", "reported_eps_growth", "total_debt_equity", "current_ratio", "quick_ratio", "interest_cover", "total_debt_mcap", "yield_adv", "yield_inv", "cost_liab", "nim", "int_spread", "cost_inc_ratio", "core_cost_inc_ratio", "op_cost_asset", "adj_per", "tier1_ratio", "tier2_ratio", "car", "core_op_income_growth", "eps_growth", "bvps_growth", "adv_growth", "loan_deposits", "cash_deposits", "investment_deposits", "inc_loan_deposits", "gross_npa", "net_npa", "ownersfund_total_source", "fixed_assets_ta", "inventory_tr", "dividend_pr_np", "dividend_pr_cp", "earning_retention_ratio", "cash_earnings_retention", "price_bv", "return_sales", "debt_ta", "ev", "price_sales_ratio", "ev_ebita", "cf_per_share", "pcf_ratio", "fcf_share", "pfcf_ratio", "fcf_yield", "scf_ratio", "gpm", "sales_to_total_assets", "sales_to_current_assets", "total_car_base_i", "ti_car_base_i", "tii_car_base_i", "total_car", "ti_car", "tii_car", "npa_gross", "npa_net", "npa_advances", "net_profit_to_pbt", "pbt_to_pbit", "pbit_to_sales", "net_profit_to_sales", "net_sales_to_total_assets", "return_on_assets", "assets_to_equity", "return_on_equity", "interest_to_debt", "debt_to_assets", "interest_to_assets", "roe_after_interest", "dividend_payout_per", "other_income_to_net_worth", "roa_after_interest", "roe_before_other_inc", "roe_after_other_inc", "roe_after_tax_rate", "credit_deposit", "interest_expended_interest_earned", "interest_income_total_funds", "interest_expended_total_funds", "net_interest_income_total_funds", "casa", "inventory_turnover", "debtors_turnover", "adj_pe", "adjusted_bv", "adj_dps", "networth_growth", "ce_growth", "gb_growth", "pbdt_growth", "pbit_growth", "pbt_growth", "cp_growth", "exports_growth", "imports_growth", "m_cap_growth", "eb_id_tam", "pbdtm", "lt_debt_equity_ratio", "roic", "total_car_b", "ti_car_b", "tii_car_b", "flag"}),
			// DoUpdates: clause.AssignmentColumns([]string{"rating"}),
		}).CreateInBatches(&datamodelUpdate, 300).Error
		if err != nil {
			fmt.Println(err)
			Zerologs.Error().Msg("Error while Inserting data into Finance_fr")
		}
		Zerologs.Info().Msgf(" execution time for Finance_fr ==>", time.Since(start))
		buffer.WriteString("Total Record updated " + strconv.Itoa(count) + "\n")
		return nil
	})

	// })
	return nil
}

func Finance_pl(strjson []byte, buffer *bytes.Buffer) error {
	var arryJson []interface{}
	if err := json.Unmarshal(strjson, &arryJson); err != nil {
		buffer.WriteString(err.Error() + "\n")
		return err
	}
	var datamodelUpdate []accord.Finance_pl
	count := 0
	// q.Enqueue(arryJson, func(data interface{}) {
	db.Accord.Transaction(func(tx *gorm.DB) error {
		start := time.Now()
		for _, json := range arryJson {
			jsonmap := json.(map[string]interface{})
			datamodel := accord.Finance_pl{}
			datamodel.FINCODE = helper.GetIntfromMap(jsonmap, "FINCODE")
			datamodel.Year_end = helper.GetIntfromMap(jsonmap, "Year_end")
			datamodel.TYPE = helper.GetStringfromMap(jsonmap, "TYPE")
			// err := tx.Where("fincode=? AND year_end=? AND type=?", datamodel.FINCODE, datamodel.Year_end, datamodel.TYPE).First(&datamodel).Error

			// if err != nil {
			// 	Zerologs.Error().Msg("Record Not Found In Finances_pl" + err.Error())
			// }
			fincode := strconv.Itoa(datamodel.FINCODE)
			yearEnd := strconv.Itoa(datamodel.Year_end)
			fincode_yearEnd_type := fincode + "_" + yearEnd + "_" + datamodel.TYPE
			datamodel.ID = fincode_yearEnd_type
			datamodel.No_Months = helper.GetIntfromMap(jsonmap, "No_Months")
			datamodel.Unit = helper.GetIntfromMap(jsonmap, "Unit")
			datamodel.Interest_earned = helper.GetFloatfromMap(jsonmap, "Interest_earned")
			datamodel.Other_income = helper.GetFloatfromMap(jsonmap, "Other_income")
			datamodel.Total_income = helper.GetFloatfromMap(jsonmap, "Total_income")
			datamodel.Interest = helper.GetFloatfromMap(jsonmap, "Interest")
			datamodel.Operating_expenses = helper.GetFloatfromMap(jsonmap, "Operating_expenses")
			datamodel.Provisions_contigency = helper.GetFloatfromMap(jsonmap, "Provisions_contigency")
			datamodel.Tax = helper.GetFloatfromMap(jsonmap, "Tax")
			datamodel.Total = helper.GetFloatfromMap(jsonmap, "Total")
			datamodel.Profit_after_tax = helper.GetFloatfromMap(jsonmap, "Profit_after_tax")
			datamodel.Extra_items = helper.GetFloatfromMap(jsonmap, "extra_items")
			datamodel.Profit_Brought_forward = helper.GetFloatfromMap(jsonmap, "Profit_Brought_forward")
			datamodel.Minority_interest = helper.GetFloatfromMap(jsonmap, "Minority_interest")
			datamodel.Share_Associate = helper.GetFloatfromMap(jsonmap, "Share_Associate")
			datamodel.Other_ConsItems = helper.GetFloatfromMap(jsonmap, "Other_ConsItems")
			datamodel.Consolidated_NetProfit = helper.GetFloatfromMap(jsonmap, "Consolidated_NetProfit")
			datamodel.Adj_Net_profit = helper.GetFloatfromMap(jsonmap, "Adj_Net_profit")
			datamodel.Extr_Items = helper.GetFloatfromMap(jsonmap, "Extr_Items")
			datamodel.PNLBF = helper.GetFloatfromMap(jsonmap, "PNLBF")
			datamodel.Profit_availble_appr = helper.GetFloatfromMap(jsonmap, "Profit_availble_appr")
			datamodel.Appropriation = helper.GetFloatfromMap(jsonmap, "Appropriation")
			datamodel.Dividend_perc = helper.GetFloatfromMap(jsonmap, "Dividend_perc")
			datamodel.Reported_EPS = helper.GetFloatfromMap(jsonmap, "Reported_EPS")
			datamodel.Gross_sales = helper.GetFloatfromMap(jsonmap, "Gross_sales")
			datamodel.Net_sales = helper.GetFloatfromMap(jsonmap, "Net_sales")
			datamodel.Inc_Dec_Inventory = helper.GetFloatfromMap(jsonmap, "Inc_Dec_Inventory")
			datamodel.Raw_matrs_consumed = helper.GetFloatfromMap(jsonmap, "Raw_matrs_consumed")
			datamodel.Employees = helper.GetFloatfromMap(jsonmap, "Employees")
			datamodel.Other_Mfg_Exps = helper.GetFloatfromMap(jsonmap, "Other_Mfg_Exps")
			datamodel.Sellg_Admn_Exps = helper.GetFloatfromMap(jsonmap, "Sellg_Admn_Exps")
			datamodel.Misc_exps = helper.GetFloatfromMap(jsonmap, "Misc_exps")
			datamodel.Pre_Op_exps = helper.GetFloatfromMap(jsonmap, "Pre_Op_exps")
			datamodel.Total_expendiure = helper.GetFloatfromMap(jsonmap, "Total_expendiure")
			datamodel.Operating_profit = helper.GetFloatfromMap(jsonmap, "Operating_profit")
			datamodel.Depreciation = helper.GetFloatfromMap(jsonmap, "Depreciation")
			datamodel.Profit_before_exception = helper.GetFloatfromMap(jsonmap, "Profit_before_exception")
			datamodel.ExceptionalIncome_Expenses = helper.GetFloatfromMap(jsonmap, "ExceptionalIncome_Expenses")
			datamodel.Profit_before_tax = helper.GetFloatfromMap(jsonmap, "Profit_before_tax")
			datamodel.Taxation = helper.GetFloatfromMap(jsonmap, "Taxation")
			datamodel.Profit_available_appropriation = helper.GetFloatfromMap(jsonmap, "Profit_available_appropriation")
			datamodel.Total_gross_sales = helper.GetFloatfromMap(jsonmap, "Total_gross_sales")
			datamodel.Excise = helper.GetFloatfromMap(jsonmap, "Excise")
			datamodel.Power_Fuel = helper.GetFloatfromMap(jsonmap, "Power_Fuel")
			datamodel.Gross_profits = helper.GetFloatfromMap(jsonmap, "Gross_profits")
			datamodel.Inter_div_trf = helper.GetFloatfromMap(jsonmap, "inter_div_trf")
			datamodel.Sales_return = helper.GetFloatfromMap(jsonmap, "Sales_return")
			datamodel.Sellg_Exps = helper.GetFloatfromMap(jsonmap, "Sellg_Exps")
			datamodel.Cost_SW = helper.GetFloatfromMap(jsonmap, "Cost_SW")
			datamodel.Provision_investment = helper.GetFloatfromMap(jsonmap, "Provision_investment")
			datamodel.Provision_advances = helper.GetFloatfromMap(jsonmap, "Provision_advances")
			datamodel.Provision_other = helper.GetFloatfromMap(jsonmap, "Provision_other")
			datamodel.Curr_tax = helper.GetFloatfromMap(jsonmap, "Curr_tax")
			datamodel.Def_tax = helper.GetFloatfromMap(jsonmap, "Def_tax")
			datamodel.Fringe_benefits = helper.GetFloatfromMap(jsonmap, "Fringe_benefits")
			datamodel.Wealth_tax = helper.GetFloatfromMap(jsonmap, "Wealth_tax")
			datamodel.Interest_advances_Bills = helper.GetFloatfromMap(jsonmap, "Interest_advances_Bills")
			datamodel.Job_works = helper.GetFloatfromMap(jsonmap, "Job_works")
			datamodel.Service_income = helper.GetFloatfromMap(jsonmap, "Service_income")
			datamodel.Opening_RM = helper.GetFloatfromMap(jsonmap, "Opening_RM")
			datamodel.Purchases_RM = helper.GetFloatfromMap(jsonmap, "Purchases_RM")
			datamodel.Closing_RM = helper.GetFloatfromMap(jsonmap, "Closing_RM")
			datamodel.Purchases_FG = helper.GetFloatfromMap(jsonmap, "Purchases_FG")
			datamodel.Electricity = helper.GetFloatfromMap(jsonmap, "Electricity")
			datamodel.Oils_fuels = helper.GetFloatfromMap(jsonmap, "Oils_fuels")
			datamodel.Coals = helper.GetFloatfromMap(jsonmap, "Coals")
			datamodel.Salaries = helper.GetFloatfromMap(jsonmap, "Salaries")
			datamodel.Providend_fund_contri = helper.GetFloatfromMap(jsonmap, "Providend_fund_contri")
			datamodel.Staff_welfare = helper.GetFloatfromMap(jsonmap, "Staff_welfare")
			datamodel.Sub_contract = helper.GetFloatfromMap(jsonmap, "sub_contract")
			datamodel.Processing_charges = helper.GetFloatfromMap(jsonmap, "processing_charges")
			datamodel.Repairs_maintenance = helper.GetFloatfromMap(jsonmap, "repairs_maintenance")
			datamodel.UpKeep_maintenance = helper.GetFloatfromMap(jsonmap, "UpKeep_maintenance")
			datamodel.Rent_rates_taxes = helper.GetFloatfromMap(jsonmap, "rent_rates_taxes")
			datamodel.Insurance = helper.GetFloatfromMap(jsonmap, "Insurance")
			datamodel.Priting_stationery = helper.GetFloatfromMap(jsonmap, "priting_stationery")
			datamodel.Professional_charges = helper.GetFloatfromMap(jsonmap, "professional_charges")
			datamodel.Travelling = helper.GetFloatfromMap(jsonmap, "travelling")
			datamodel.Advertising = helper.GetFloatfromMap(jsonmap, "Advertising")
			datamodel.Commission_incentives = helper.GetFloatfromMap(jsonmap, "Commission_incentives")
			datamodel.Freight_forwardings = helper.GetFloatfromMap(jsonmap, "freight_forwardings")
			datamodel.Handling_clearing = helper.GetFloatfromMap(jsonmap, "Handling_clearing")
			datamodel.Bad_debts = helper.GetFloatfromMap(jsonmap, "Bad_debts")
			datamodel.Prov_Doubtfull_debts = helper.GetFloatfromMap(jsonmap, "Prov_Doubtfull_debts")
			datamodel.Loss_Fixed_assets = helper.GetFloatfromMap(jsonmap, "Loss_Fixed_assets")
			datamodel.Loss_Foreign_exchange = helper.GetFloatfromMap(jsonmap, "Loss_Foreign_exchange")
			datamodel.Loss_sale_Investment = helper.GetFloatfromMap(jsonmap, "Loss_sale_Investment")
			datamodel.Interest_income = helper.GetFloatfromMap(jsonmap, "Interest_income")
			datamodel.Dividend_income = helper.GetFloatfromMap(jsonmap, "Dividend_income")
			datamodel.Profit_FA = helper.GetFloatfromMap(jsonmap, "Profit_FA")
			datamodel.Profit_Investment = helper.GetFloatfromMap(jsonmap, "Profit_Investment")
			datamodel.Prov_written_back = helper.GetFloatfromMap(jsonmap, "Prov_written_back")
			datamodel.Foreign_exchange_gain = helper.GetFloatfromMap(jsonmap, "Foreign_exchange_gain")
			datamodel.Interest_deb = helper.GetFloatfromMap(jsonmap, "Interest_deb")
			datamodel.Interest_Term_loans = helper.GetFloatfromMap(jsonmap, "Interest_Term_loans")
			datamodel.Interest_fixed_deposits = helper.GetFloatfromMap(jsonmap, "Interest_fixed_deposits")
			datamodel.Bank_charges = helper.GetFloatfromMap(jsonmap, "Bank_charges")
			datamodel.Appropriation_General_Reserve = helper.GetFloatfromMap(jsonmap, "Appropriation_General_Reserve")
			datamodel.Proposed_Equity_devided = helper.GetFloatfromMap(jsonmap, "Proposed_Equity_devided")
			datamodel.Corp_Divd_tax = helper.GetFloatfromMap(jsonmap, "Corp_Divd_tax")
			datamodel.EPS = helper.GetFloatfromMap(jsonmap, "EPS")
			datamodel.Adj_Eps = helper.GetFloatfromMap(jsonmap, "Adj_Eps")
			datamodel.Interest_RBI = helper.GetFloatfromMap(jsonmap, "Interest_RBI")
			datamodel.Interest_investment = helper.GetFloatfromMap(jsonmap, "Interest_investment")
			datamodel.Income_JV_subs = helper.GetFloatfromMap(jsonmap, "Income_JV_subs")
			datamodel.Rent_income = helper.GetFloatfromMap(jsonmap, "Rent_income")
			datamodel.Interest_RBI_borrowings = helper.GetFloatfromMap(jsonmap, "Interest_RBI_borrowings")
			datamodel.Interest_other = helper.GetFloatfromMap(jsonmap, "Interest_other")
			datamodel.Depreciation_leased_assets = helper.GetFloatfromMap(jsonmap, "Depreciation_leased_assets")
			datamodel.Auditor_payment = helper.GetFloatfromMap(jsonmap, "Auditor_payment")
			datamodel.Telephone = helper.GetFloatfromMap(jsonmap, "Telephone")
			datamodel.Repairs_other_admin = helper.GetFloatfromMap(jsonmap, "repairs_other_admin")
			datamodel.Statutory_reserve = helper.GetFloatfromMap(jsonmap, "Statutory_reserve")
			datamodel.Appropriation_Revenue_Reserve = helper.GetFloatfromMap(jsonmap, "Appropriation_Revenue_Reserve")
			datamodel.Other_appropriation = helper.GetFloatfromMap(jsonmap, "Other_appropriation")
			datamodel.Sale_Shares_Units = helper.GetFloatfromMap(jsonmap, "Sale_Shares_Units")
			datamodel.Interest_earned_loan = helper.GetFloatfromMap(jsonmap, "Interest_earned_loan")
			datamodel.Portfolio_mgt_income = helper.GetFloatfromMap(jsonmap, "Portfolio_mgt_income")
			datamodel.Dividend_earned = helper.GetFloatfromMap(jsonmap, "Dividend_earned")
			datamodel.Brokerage_commission = helper.GetFloatfromMap(jsonmap, "Brokerage_commission")
			datamodel.Processing_fees = helper.GetFloatfromMap(jsonmap, "Processing_fees")
			datamodel.Depository_charges = helper.GetFloatfromMap(jsonmap, "Depository_charges")
			datamodel.Security_trasaction_tax = helper.GetFloatfromMap(jsonmap, "Security_trasaction_tax")
			datamodel.Software_technical_charges = helper.GetFloatfromMap(jsonmap, "Software_technical_charges")
			datamodel.Provision_contigency = helper.GetFloatfromMap(jsonmap, "Provision_contigency")
			datamodel.Provision_NPA = helper.GetFloatfromMap(jsonmap, "provision_NPA")
			datamodel.Other_interest_income = helper.GetFloatfromMap(jsonmap, "Other_interest_income")
			datamodel.Commision = helper.GetFloatfromMap(jsonmap, "Commision")
			datamodel.Discounts = helper.GetFloatfromMap(jsonmap, "Discounts")
			datamodel.Other_Investmnet_income = helper.GetFloatfromMap(jsonmap, "Other_Investmnet_income")
			datamodel.Sales = helper.GetFloatfromMap(jsonmap, "Sales")
			datamodel.Income_Diagnostic = helper.GetFloatfromMap(jsonmap, "Income_Diagnostic")
			datamodel.Cash_discount = helper.GetFloatfromMap(jsonmap, "Cash_discount")
			datamodel.UpKeep_service = helper.GetFloatfromMap(jsonmap, "UpKeep_service")
			datamodel.Consultant_changes = helper.GetFloatfromMap(jsonmap, "Consultant_changes")
			datamodel.Packing_materials = helper.GetFloatfromMap(jsonmap, "Packing_materials")
			datamodel.Freight_outward = helper.GetFloatfromMap(jsonmap, "freight_outward")
			datamodel.Room_restaurents = helper.GetFloatfromMap(jsonmap, "Room_restaurents")
			datamodel.Communication_income = helper.GetFloatfromMap(jsonmap, "Communication_income")
			datamodel.Foods_beverage_Sales = helper.GetFloatfromMap(jsonmap, "Foods_beverage_Sales")
			datamodel.Linen_Room_supplies = helper.GetFloatfromMap(jsonmap, "Linen_Room_supplies")
			datamodel.Catering_supplies = helper.GetFloatfromMap(jsonmap, "Catering_supplies")
			datamodel.Laundry_washing_expenses = helper.GetFloatfromMap(jsonmap, "Laundry_washing_expenses")
			datamodel.Music_banquest_restaurants = helper.GetFloatfromMap(jsonmap, "music_banquest_restaurants")
			datamodel.Packing_expemses = helper.GetFloatfromMap(jsonmap, "packing_expemses")
			datamodel.Sales_property_development = helper.GetFloatfromMap(jsonmap, "Sales_property_development")
			datamodel.Broadcasting_revenue = helper.GetFloatfromMap(jsonmap, "Broadcasting_revenue")
			datamodel.Adverisement_revenue = helper.GetFloatfromMap(jsonmap, "Adverisement_revenue")
			datamodel.Licence_income = helper.GetFloatfromMap(jsonmap, "Licence_income")
			datamodel.Subscription_income = helper.GetFloatfromMap(jsonmap, "Subscription_income")
			datamodel.Contents_film_income = helper.GetFloatfromMap(jsonmap, "Contents_film_income")
			datamodel.Program_production_exps = helper.GetFloatfromMap(jsonmap, "Program_production_exps")
			datamodel.Telecastin_expenses = helper.GetFloatfromMap(jsonmap, "Telecastin_expenses")
			datamodel.Programs_Films_right = helper.GetFloatfromMap(jsonmap, "Programs_Films_right")
			datamodel.Transmission_EPC = helper.GetFloatfromMap(jsonmap, "Transmission_EPC")
			datamodel.Wheeling_Transmission = helper.GetFloatfromMap(jsonmap, "Wheeling_Transmission")
			datamodel.Power_Purchased = helper.GetFloatfromMap(jsonmap, "Power_Purchased")
			datamodel.Power_project_cost = helper.GetFloatfromMap(jsonmap, "Power_project_cost")
			datamodel.Wheeling_charges = helper.GetFloatfromMap(jsonmap, "wheeling_charges")
			datamodel.Spare_consumed = helper.GetFloatfromMap(jsonmap, "Spare_consumed")
			datamodel.Sub_contract_charges = helper.GetFloatfromMap(jsonmap, "Sub_contract_charges")
			datamodel.Development_rights = helper.GetFloatfromMap(jsonmap, "Development_rights")
			datamodel.Development_charges = helper.GetFloatfromMap(jsonmap, "Development_charges")
			datamodel.Income_Investment_property = helper.GetFloatfromMap(jsonmap, "Income_Investment_property")
			datamodel.Development_rights_cost = helper.GetFloatfromMap(jsonmap, "Development_rights_cost")
			datamodel.Shipbuilding_income = helper.GetFloatfromMap(jsonmap, "Shipbuilding_income")
			datamodel.Charter_income = helper.GetFloatfromMap(jsonmap, "Charter_income")
			datamodel.Freight_Income = helper.GetFloatfromMap(jsonmap, "freight_Income")
			datamodel.Stevedoreage_cargo_expenses = helper.GetFloatfromMap(jsonmap, "Stevedoreage_cargo_expenses")
			datamodel.Port_charges = helper.GetFloatfromMap(jsonmap, "Port_charges")
			datamodel.Sale_licenses = helper.GetFloatfromMap(jsonmap, "Sale_licenses")
			datamodel.Traded_sw = helper.GetFloatfromMap(jsonmap, "Traded_sw")
			datamodel.Tech_fees = helper.GetFloatfromMap(jsonmap, "Tech_fees")
			datamodel.Traing_exps = helper.GetFloatfromMap(jsonmap, "Traing_exps")
			datamodel.Software_licences = helper.GetFloatfromMap(jsonmap, "Software_licences")
			datamodel.Travels_SW = helper.GetFloatfromMap(jsonmap, "Travels_SW")
			datamodel.Insurance_SW = helper.GetFloatfromMap(jsonmap, "Insurance_SW")
			datamodel.Visa_charges = helper.GetFloatfromMap(jsonmap, "Visa_charges")
			datamodel.Contract_Support_SW = helper.GetFloatfromMap(jsonmap, "Contract_Support_SW")
			datamodel.Rates_taxes = helper.GetFloatfromMap(jsonmap, "rates_taxes")
			datamodel.Sales_scrap = helper.GetFloatfromMap(jsonmap, "Sales_scrap")
			datamodel.Export_benefits = helper.GetFloatfromMap(jsonmap, "Export_benefits")
			datamodel.Subsidy_incentives = helper.GetFloatfromMap(jsonmap, "Subsidy_incentives")
			datamodel.Freight_inward = helper.GetFloatfromMap(jsonmap, "freight_inward")
			datamodel.Hire_charges_mfg = helper.GetFloatfromMap(jsonmap, "Hire_charges_mfg")
			datamodel.Donation = helper.GetFloatfromMap(jsonmap, "Donation")
			datamodel.Interest_Other_income = helper.GetFloatfromMap(jsonmap, "Interest_Other_income")
			datamodel.Commission = helper.GetFloatfromMap(jsonmap, "Commission")
			datamodel.Power_fuel_cost = helper.GetFloatfromMap(jsonmap, "Power_fuel_cost")
			datamodel.Royalty = helper.GetFloatfromMap(jsonmap, "royalty")
			datamodel.Project_expenses = helper.GetFloatfromMap(jsonmap, "Project_expenses")
			datamodel.Flag = helper.GetStringfromMap(jsonmap, "flag")

			// err = tx.Save(&datamodel).Error
			// if err != nil {
			// 	buffer.WriteString(err.Error())
			// }
			datamodelUpdate = append(datamodelUpdate, datamodel)
			count++

		}
		err := db.Accord.Clauses(clause.OnConflict{
			Columns:   []clause.Column{{Name: "id"}},
			DoUpdates: clause.AssignmentColumns([]string{"fincode", "year_end", "type", "no_months", "unit", "interest_earned", "other_income", "total_income", "interest", "operating_expenses", "provisions_contigency", "tax", "total", "profit_after_tax", "extra_items", "profit_brought_forward", "minority_interest", "share_associate", "other_cons_items", "consolidated_net_profit", "adj_net_profit", "extr_items", "pnlbf", "profit_availble_appr", "appropriation", "dividend_perc", "reported_eps", "gross_sales", "net_sales", "inc_dec_inventory", "raw_matrs_consumed", "employees", "other_mfg_exps", "sellg_admn_exps", "misc_exps", "pre_op_exps", "total_expendiure", "operating_profit", "depreciation", "profit_before_exception", "exceptional_income_expenses", "profit_before_tax", "taxation", "profit_available_appropriation", "total_gross_sales", "excise", "power_fuel", "gross_profits", "inter_div_trf", "sales_return", "sellg_exps", "cost_sw", "provision_investment", "provision_advances", "provision_other", "curr_tax", "def_tax", "fringe_benefits", "wealth_tax", "interest_advances_bills", "job_works", "service_income", "opening_rm", "purchases_rm", "closing_rm", "purchases_fg", "electricity", "oils_fuels", "coals", "salaries", "providend_fund_contri", "staff_welfare", "sub_contract", "processing_charges", "repairs_maintenance", "up_keep_maintenance", "rent_rates_taxes", "insurance", "priting_stationery", "professional_charges", "travelling", "advertising", "commission_incentives", "freight_forwardings", "handling_clearing", "bad_debts", "prov_doubtfull_debts", "loss_fixed_assets", "loss_foreign_exchange", "loss_sale_investment", "interest_income", "dividend_income", "profit_fa", "profit_investment", "prov_written_back", "foreign_exchange_gain", "interest_deb", "interest_term_loans", "interest_fixed_deposits", "bank_charges", "appropriation_general_reserve", "proposed_equity_devided", "corp_divd_tax", "eps", "adj_eps", "interest_rbi", "interest_investment", "income_jv_subs", "rent_income", "interest_rbi_borrowings", "interest_other", "depreciation_leased_assets", "auditor_payment", "telephone", "repairs_other_admin", "statutory_reserve", "appropriation_revenue_reserve", "other_appropriation", "sale_shares_units", "interest_earned_loan", "portfolio_mgt_income", "dividend_earned", "brokerage_commission", "processing_fees", "depository_charges", "security_trasaction_tax", "software_technical_charges", "provision_contigency", "provision_npa", "other_interest_income", "commision", "discounts", "other_investmnet_income", "sales", "income_diagnostic", "cash_discount", "up_keep_service", "consultant_changes", "packing_materials", "freight_outward", "room_restaurents", "communication_income", "foods_beverage_sales", "linen_room_supplies", "catering_supplies", "laundry_washing_expenses", "music_banquest_restaurants", "packing_expemses", "sales_property_development", "broadcasting_revenue", "adverisement_revenue", "licence_income", "subscription_income", "contents_film_income", "program_production_exps", "telecastin_expenses", "programs_films_right", "transmission_epc", "wheeling_transmission", "power_purchased", "power_project_cost", "wheeling_charges", "spare_consumed", "sub_contract_charges", "development_rights", "development_charges", "income_investment_property", "development_rights_cost", "shipbuilding_income", "charter_income", "freight_income", "stevedoreage_cargo_expenses", "port_charges", "sale_licenses", "traded_sw", "tech_fees", "traing_exps", "software_licences", "travels_sw", "insurance_sw", "visa_charges", "contract_support_sw", "rates_taxes", "sales_scrap", "export_benefits", "subsidy_incentives", "freight_inward", "hire_charges_mfg", "donation", "interest_other_income", "commission", "power_fuel_cost", "royalty", "project_expenses", "flag"}),
			//DoUpdates: clause.AssignmentColumns([]string{"rating"}),
		}).CreateInBatches(&datamodelUpdate, 300).Error
		if err != nil {
			fmt.Println(err)
			Zerologs.Error().Msg("Error while Inserting data into Finance_pl")
		}
		Zerologs.Info().Msgf(" execution time for Finance_pl ==>", time.Since(start))
		buffer.WriteString("Total Record updated " + strconv.Itoa(count) + "\n")
		return nil
	})

	// })
	return nil
}

func Housemaster(strjson []byte, buffer *bytes.Buffer) error {
	var arryJson []interface{}
	if err := json.Unmarshal(strjson, &arryJson); err != nil {
		buffer.WriteString(err.Error() + "\n")
		return err
	}
	var datamodelUpdate []accord.Housemaster
	count := 0
	// q.Enqueue(arryJson, func(data interface{}) {
	db.Accord.Transaction(func(tx *gorm.DB) error {
		start := time.Now()
		for _, json := range arryJson {
			jsonmap := json.(map[string]interface{})
			datamodel := accord.Housemaster{}
			datamodel.HOUSE_CODE = helper.GetIntfromMap(jsonmap, "HOUSE_CODE")
			// err := tx.Where("house_code=?", datamodel.HOUSE_CODE).First(&datamodel).Error
			// if err != nil {
			// 	Zerologs.Error().Msg("Record Not Found In Housemaster" + err.Error())
			// }
			houseCode := strconv.Itoa(datamodel.HOUSE_CODE)
			datamodel.ID = houseCode
			datamodel.HOUSE = helper.GetStringfromMap(jsonmap, "HOUSE")
			datamodel.Flag = helper.GetStringfromMap(jsonmap, "Flag")

			// err = tx.Save(&datamodel).Error
			// if err != nil {
			// 	buffer.WriteString(err.Error())
			// }
			datamodelUpdate = append(datamodelUpdate, datamodel)
			count++

		}
		err := db.Accord.Clauses(clause.OnConflict{
			Columns:   []clause.Column{{Name: "id"}},
			DoUpdates: clause.AssignmentColumns([]string{"house_code", "house", "flag"}),
			// DoUpdates: clause.AssignmentColumns([]string{"rating"}),
		}).CreateInBatches(&datamodelUpdate, 1000).Error
		if err != nil {
			fmt.Println(err)
			Zerologs.Error().Msg("Error while Inserting data into housemaster")
		}
		Zerologs.Info().Msgf(" execution time for housemaster ==>", time.Since(start))
		buffer.WriteString("Total Record updated " + strconv.Itoa(count) + "\n")
		return nil
	})

	// })
	return nil
}

func Ipo_listings(strjson []byte, buffer *bytes.Buffer) error {
	var arryJson []interface{}
	if err := json.Unmarshal(strjson, &arryJson); err != nil {
		buffer.WriteString(err.Error() + "\n")
		return err
	}
	var datamodelUpdate []accord.Ipo_listings
	count := 0
	// q.Enqueue(arryJson, func(data interface{}) {
	db.Accord.Transaction(func(tx *gorm.DB) error {
		start := time.Now()
		for _, json := range arryJson {
			jsonmap := json.(map[string]interface{})
			datamodel := accord.Ipo_listings{}
			datamodel.FINCODE = helper.GetFloatfromMap(jsonmap, "FINCODE")
			datamodel.STK_ID = helper.GetFloatfromMap(jsonmap, "STK_ID")
			// err := tx.Where("fincode=? AND stk_id=?", datamodel.FINCODE, datamodel.STK_ID).First(&datamodel).Error
			// if err != nil {
			// 	Zerologs.Error().Msg("Record Not Found In IPO Listings")
			// }
			fincode := fmt.Sprintf("%v", datamodel.FINCODE)
			stkId := fmt.Sprintf("%v", datamodel.STK_ID)
			fincode_stkId := fincode + "_" + stkId
			datamodel.ID = fincode_stkId
			datamodel.IPOCODE = helper.GetFloatfromMap(jsonmap, "IPOCODE")

			// datamodel.LEADMANAGER = helper.GetStringfromMap(jsonmap, "LEADMANAGER")
			datamodel.FLAG = helper.GetStringfromMap(jsonmap, "FLAG")

			// err = tx.Save(&datamodel).Error
			// if err != nil {
			// 	buffer.WriteString(err.Error())

			// }
			datamodelUpdate = append(datamodelUpdate, datamodel)
			count++

		}
		err := db.Accord.Clauses(clause.OnConflict{
			Columns:   []clause.Column{{Name: "id"}},
			DoUpdates: clause.AssignmentColumns([]string{"ip_ocode", "fincode", "stk_id", "flag"}),
			// DoUpdates: clause.AssignmentColumns([]string{"rating"}),
		}).CreateInBatches(&datamodelUpdate, 1000).Error
		if err != nil {
			fmt.Println(err)
			Zerologs.Error().Msg("Error while Inserting data into Ipo_listings")
		}
		Zerologs.Info().Msgf(" execution time for Ipo_listings ==>", time.Since(start))
		buffer.WriteString("Total Record updated " + strconv.Itoa(count) + "\n")
		return nil
	})

	// })
	return nil
}

func Ipo_leadmgr(strjson []byte, buffer *bytes.Buffer) error {
	var arryJson []interface{}
	if err := json.Unmarshal(strjson, &arryJson); err != nil {
		buffer.WriteString(err.Error() + "\n")
		return err
	}
	var datamodelUpdate []accord.Ipo_leadmgr
	count := 0
	// q.Enqueue(arryJson, func(data interface{}) {
	db.Accord.Transaction(func(tx *gorm.DB) error {
		start := time.Now()
		for _, json := range arryJson {
			jsonmap := json.(map[string]interface{})
			datamodel := accord.Ipo_leadmgr{}
			datamodel.IPOCODE = helper.GetFloatfromMap(jsonmap, "IPOCODE")
			datamodel.FINCODE = helper.GetFloatfromMap(jsonmap, "FINCODE")
			datamodel.SRNO = helper.GetFloatfromMap(jsonmap, "SRNO")
			// err := tx.Where("ip_ocode=? AND fincode=? AND srno=?", datamodel.IPOCODE, datamodel.FINCODE, datamodel.SRNO).First(&datamodel).Error

			// if err != nil {
			// 	Zerologs.Error().Msg("Record Not Found In ledmgr" + err.Error())
			// }
			ipocode := fmt.Sprintf("%v", datamodel.IPOCODE)
			fincode := fmt.Sprintf("%v", datamodel.FINCODE)
			srno := fmt.Sprintf("%v", datamodel.SRNO)
			datamodel.ID = ipocode + "_" + fincode + "_" + srno

			datamodel.LEADMANAGER = helper.GetStringfromMap(jsonmap, "LEADMANAGER")
			datamodel.FLAG = helper.GetStringfromMap(jsonmap, "FLAG")

			// err = tx.Save(&datamodel).Error
			// if err != nil {
			// 	buffer.WriteString(err.Error())
			// }
			datamodelUpdate = append(datamodelUpdate, datamodel)
			count++

		}
		err := db.Accord.Clauses(clause.OnConflict{
			Columns:   []clause.Column{{Name: "id"}},
			DoUpdates: clause.AssignmentColumns([]string{"ip_ocode", "fincode", "srno", "leadmanager", "flag"}),
			// DoUpdates: clause.AssignmentColumns([]string{"rating"}),
		}).CreateInBatches(&datamodelUpdate, 1000).Error
		if err != nil {
			fmt.Println(err)
			Zerologs.Error().Msg("Error while Inserting data into Ipo_leadmgr")
		}
		Zerologs.Info().Msgf(" execution time for Ipo_leadmgr ==>", time.Since(start))
		buffer.WriteString("Total Record updated " + strconv.Itoa(count) + "\n")
		return nil
	})

	// })
	return nil
}

func Ipo_projects(strjson []byte, buffer *bytes.Buffer) error {
	var arryJson []interface{}
	if err := json.Unmarshal(strjson, &arryJson); err != nil {
		buffer.WriteString(err.Error() + "\n")
		return err
	}
	var datamodelUpdate []accord.Ipo_projects
	count := 0
	// q.Enqueue(arryJson, func(data interface{}) {
	db.Accord.Transaction(func(tx *gorm.DB) error {
		start := time.Now()
		for _, json := range arryJson {
			jsonmap := json.(map[string]interface{})
			datamodel := accord.Ipo_projects{}
			//datamodel.FINCODE = helper.GetFloatfromMap(jsonmap, "FINCODE")
			datamodel.IPOCODE = helper.GetFloatfromMap(jsonmap, "IPOCODE")
			datamodel.SRNO = helper.GetFloatfromMap(jsonmap, "SRNO")
			// err := tx.Where("ip_ocode=? AND srno=?", datamodel.IPOCODE, datamodel.SRNO).First(&datamodel).Error

			// if err != nil {
			// 	Zerologs.Error().Msg("Record Not Found In ipo_projects" + err.Error())
			// }
			ipocode := fmt.Sprintf("%v", datamodel.IPOCODE)
			srNo := fmt.Sprintf("%v", datamodel.SRNO)
			datamodel.ID = ipocode + "_" + srNo
			datamodel.PROJECT_NAME = helper.GetStringfromMap(jsonmap, "PROJECT_NAME")
			datamodel.PROJECT_COST = helper.GetFloatfromMap(jsonmap, "PROJECT_COST")
			datamodel.FLAG = helper.GetStringfromMap(jsonmap, "FLAG")

			// err = tx.Save(&datamodel).Error
			// if err != nil {
			// 	buffer.WriteString(err.Error())
			// }
			datamodelUpdate = append(datamodelUpdate, datamodel)
			count++

		}
		err := db.Accord.Clauses(clause.OnConflict{
			Columns:   []clause.Column{{Name: "id"}},
			DoUpdates: clause.AssignmentColumns([]string{"ip_ocode", "srno", "project_name", "project_cost", "flag"}),
			// DoUpdates: clause.AssignmentColumns([]string{"rating"}),
		}).CreateInBatches(&datamodelUpdate, 1000).Error
		if err != nil {
			fmt.Println(err)
			Zerologs.Error().Msg("Error while Inserting data into Ipo_projects")
		}
		Zerologs.Info().Msgf(" execution time for Ipo_projects ==>", time.Since(start))
		buffer.WriteString("Total Record updated " + strconv.Itoa(count) + "\n")
		return nil
	})

	// })
	return nil
}
func Ipo_Registrar(strjson []byte, buffer *bytes.Buffer) error {
	var arryJson []interface{}
	if err := json.Unmarshal(strjson, &arryJson); err != nil {
		buffer.WriteString(err.Error() + "\n")
		return err
	}
	var datamodelUpdate []accord.Ipo_Registrar
	count := 0
	// q.Enqueue(arryJson, func(data interface{}) {
	db.Accord.Transaction(func(tx *gorm.DB) error {
		start := time.Now()
		for _, json := range arryJson {
			jsonmap := json.(map[string]interface{})
			datamodel := accord.Ipo_Registrar{}
			//datamodel.FINCODE = helper.GetFloatfromMap(jsonmap, "FINCODE")
			datamodel.IPOCODE = helper.GetFloatfromMap(jsonmap, "IPOCODE")
			datamodel.FINCODE = helper.GetFloatfromMap(jsonmap, "FINCODE")
			// err := tx.Where("ip_ocode=? AND fincode=?", datamodel.IPOCODE, datamodel.FINCODE).First(&datamodel).Error

			// if err != nil {
			// 	Zerologs.Error().Msg("Record Not Found In ipo_Registrar" + err.Error())
			// }
			ipocode := fmt.Sprintf("%v", datamodel.IPOCODE)
			fincode := fmt.Sprintf("%v", datamodel.FINCODE)
			datamodel.ID = ipocode + "_" + fincode
			datamodel.SRNO = helper.GetFloatfromMap(jsonmap, "SRNO")
			datamodel.RegistrarNo = helper.GetFloatfromMap(jsonmap, "RegistrarNo")
			datamodel.FLAG = helper.GetStringfromMap(jsonmap, "FLAG")

			// err = tx.Save(&datamodel).Error
			// if err != nil {
			// 	buffer.WriteString(err.Error())
			// }
			datamodelUpdate = append(datamodelUpdate, datamodel)
			count++

		}
		err := db.Accord.Clauses(clause.OnConflict{
			Columns:   []clause.Column{{Name: "id"}},
			DoUpdates: clause.AssignmentColumns([]string{"ip_ocode", "registrar_no", "srno", "registrar_no", "flag"}),
			// DoUpdates: clause.AssignmentColumns([]string{"rating"}),
		}).CreateInBatches(&datamodelUpdate, 1000).Error
		if err != nil {
			fmt.Println(err)
			Zerologs.Error().Msg("Error while Inserting data into Ipo_Registrar")
		}
		Zerologs.Info().Msgf(" execution time for Ipo_Registrar ==>", time.Since(start))
		buffer.WriteString("Total Record updated " + strconv.Itoa(count) + "\n")
		return nil
	})

	// })
	return nil
}

func Ipo_promoterholdings(strjson []byte, buffer *bytes.Buffer) error {
	var arryJson []interface{}
	if err := json.Unmarshal(strjson, &arryJson); err != nil {
		buffer.WriteString(err.Error() + "\n")
		return err
	}
	var datamodelUpdate []accord.Ipo_promoterholdings
	count := 0
	// q.Enqueue(arryJson, func(data interface{}) {
	db.Accord.Transaction(func(tx *gorm.DB) error {
		start := time.Now()
		for _, json := range arryJson {
			jsonmap := json.(map[string]interface{})
			datamodel := accord.Ipo_promoterholdings{}
			//datamodel.FINCODE = helper.GetFloatfromMap(jsonmap, "FINCODE")
			datamodel.IPOCODE = helper.GetFloatfromMap(jsonmap, "IPOCODE")
			// err := tx.Where("ip_ocode=? ", datamodel.IPOCODE).First(&datamodel).Error

			// if err != nil {
			// 	Zerologs.Error().Msg("Record Not Found In ipo_promoterholdings" + err.Error())
			// }
			ipocode := fmt.Sprintf("%v", datamodel.IPOCODE)
			datamodel.ID = ipocode
			datamodel.PRE_PROMOTERHOLDER = helper.GetFloatfromMap(jsonmap, "PRE_PROMOTERHOLDER")
			datamodel.PRE_SHARE_CAP = helper.GetFloatfromMap(jsonmap, "PRE_SHARE_CAP")
			datamodel.OFFER_TO_PUBLIC = helper.GetFloatfromMap(jsonmap, "OFFER_TO_PUBLIC")
			datamodel.POST_PROMOTERHOLD = helper.GetFloatfromMap(jsonmap, "POST_PROMOTERHOLD")
			datamodel.POST_SHARECAP = helper.GetFloatfromMap(jsonmap, "POST_SHARECAP")
			datamodel.FLAG = helper.GetStringfromMap(jsonmap, "FLAG")

			// err = tx.Save(&datamodel).Error
			// if err != nil {
			// 	buffer.WriteString(err.Error())
			// }
			datamodelUpdate = append(datamodelUpdate, datamodel)
			count++

		}
		err := db.Accord.Clauses(clause.OnConflict{
			Columns:   []clause.Column{{Name: "id"}},
			DoUpdates: clause.AssignmentColumns([]string{"ip_ocode", "pre_promoterholder", "pre_share_cap", "offer_to_public", "post_sharecap", "post_promoterhold", "flag"}),
			// DoUpdates: clause.AssignmentColumns([]string{"rating"}),
		}).CreateInBatches(&datamodelUpdate, 1000).Error
		if err != nil {
			fmt.Println(err)
			Zerologs.Error().Msg("Error while Inserting data into Ipo_Promoterholding")
		}
		Zerologs.Info().Msgf(" execution time for Ipo_Promoterholding ==>", time.Since(start))
		buffer.WriteString("Total Record updated " + strconv.Itoa(count) + "\n")
		return nil
	})

	// })
	return nil
}

func Ipo_promoters(strjson []byte, buffer *bytes.Buffer) error {
	var arryJson []interface{}
	if err := json.Unmarshal(strjson, &arryJson); err != nil {
		buffer.WriteString(err.Error() + "\n")
		return err
	}
	var datamodelUpdate []accord.Ipo_promoters
	count := 0
	// q.Enqueue(arryJson, func(data interface{}) {
	db.Accord.Transaction(func(tx *gorm.DB) error {
		start := time.Now()
		for _, json := range arryJson {
			jsonmap := json.(map[string]interface{})
			datamodel := accord.Ipo_promoters{}
			//datamodel.FINCODE = helper.GetFloatfromMap(jsonmap, "FINCODE")
			datamodel.IPOCODE = helper.GetFloatfromMap(jsonmap, "IPOCODE")
			datamodel.FINCODE = helper.GetFloatfromMap(jsonmap, "FINCODE")
			datamodel.SRNO = helper.GetFloatfromMap(jsonmap, "SRNO")
			// err := tx.Where("ip_ocode=? AND fincode=? AND srno=?", datamodel.IPOCODE, datamodel.FINCODE, datamodel.SRNO).First(&datamodel).Error

			// if err != nil {
			// 	Zerologs.Error().Msg("Record Not Found In ipo_promoters" + err.Error())
			// }
			ipocode := fmt.Sprintf("%v", datamodel.IPOCODE)
			fincode := fmt.Sprintf("%v", datamodel.FINCODE)
			srNo := fmt.Sprintf("%v", datamodel.SRNO)
			datamodel.ID = ipocode + "_" + fincode + "_" + srNo
			datamodel.PROMNAME = helper.GetStringfromMap(jsonmap, "PROMNAME")

			datamodel.FLAG = helper.GetStringfromMap(jsonmap, "FLAG")

			// err = tx.Save(&datamodel).Error
			// if err != nil {
			// 	buffer.WriteString(err.Error())
			// }
			datamodelUpdate = append(datamodelUpdate, datamodel)
			count++

		}
		err := db.Accord.Clauses(clause.OnConflict{
			Columns:   []clause.Column{{Name: "id"}},
			DoUpdates: clause.AssignmentColumns([]string{"ip_ocode", "fincode", "srno", "promname", "flag"}),
			// DoUpdates: clause.AssignmentColumns([]string{"rating"}),
		}).CreateInBatches(&datamodelUpdate, 1000).Error
		if err != nil {
			fmt.Println(err)
			Zerologs.Error().Msg("Error while Inserting data into Ipo_Promoters")
		}
		Zerologs.Info().Msgf(" execution time for Ipo_Promoters ==>", time.Since(start))
		buffer.WriteString("Total Record updated " + strconv.Itoa(count) + "\n")
		return nil
	})

	// })
	return nil
}

func Ipo_subscriptions(strjson []byte, buffer *bytes.Buffer) error {
	var arryJson []interface{}
	if err := json.Unmarshal(strjson, &arryJson); err != nil {
		buffer.WriteString(err.Error() + "\n")
		return err
	}
	var datamodelUpdate []accord.Ipo_subscriptions
	count := 0
	// q.Enqueue(arryJson, func(data interface{}) {
	db.Accord.Transaction(func(tx *gorm.DB) error {
		start := time.Now()
		for _, json := range arryJson {
			jsonmap := json.(map[string]interface{})
			datamodel := accord.Ipo_subscriptions{}

			datamodel.IPOCODE = helper.GetFloatfromMap(jsonmap, "IpoCode")
			// err := tx.Where("ip_ocode=? ", datamodel.IPOCODE).First(&datamodel).Error

			// if err != nil {
			// 	Zerologs.Error().Msg("Record Not Found In ipo_subscriptions" + err.Error())
			// }
			ipocode := fmt.Sprintf("%v", datamodel.IPOCODE)
			datamodel.ID = ipocode
			datamodel.TotalEquity = helper.GetFloatfromMap(jsonmap, "TotalEquity")
			datamodel.QIB_Nos = helper.GetFloatfromMap(jsonmap, "QIB_Nos")
			datamodel.QIB_NosBidFor = helper.GetFloatfromMap(jsonmap, "QIB_NosBidFor")
			datamodel.QIB_Tot = helper.GetFloatfromMap(jsonmap, "QIB_Tot")
			datamodel.QIB_Fiis_Nos = helper.GetFloatfromMap(jsonmap, "QIB_Fiis_Nos")
			datamodel.QIB_Fiis_NosBidFor = helper.GetFloatfromMap(jsonmap, "QIB_Fiis_NosBidFor")
			datamodel.QIB_Fiis_Tot = helper.GetFloatfromMap(jsonmap, "QIB_Fiis_Tot")
			datamodel.QIB_Mf_Nos = helper.GetFloatfromMap(jsonmap, "QIB_Mf_Nos")
			datamodel.QIB_Mf_NosBidFor = helper.GetFloatfromMap(jsonmap, "QIB_Mf_NosBidFor")
			datamodel.QIB_Mf_Tot = helper.GetFloatfromMap(jsonmap, "QIB_Mf_Tot")
			datamodel.QIB_Other_Nos = helper.GetFloatfromMap(jsonmap, "QIB_Other_Nos")
			datamodel.QIB_Others_NosBidFor = helper.GetFloatfromMap(jsonmap, "QIB_Others_NosBidFor")
			datamodel.QIB_Others_Tot = helper.GetFloatfromMap(jsonmap, "QIB_Others_Tot")
			datamodel.NII_Nos = helper.GetFloatfromMap(jsonmap, "NII_Nos")
			datamodel.NII_NosBidFor = helper.GetFloatfromMap(jsonmap, "NII_NosBidFor")
			datamodel.NII_Tot = helper.GetFloatfromMap(jsonmap, "NII_Tot")
			datamodel.NII_Corp_Nos = helper.GetFloatfromMap(jsonmap, "NII_Corp_Nos")
			datamodel.NII_Corp_NosBidFor = helper.GetFloatfromMap(jsonmap, "NII_Corp_NosBidFor")
			datamodel.NII_Corp_Tot = helper.GetFloatfromMap(jsonmap, "NII_Corp_Tot")
			datamodel.NII_Indiv_Nos = helper.GetFloatfromMap(jsonmap, "NII_Indiv_Nos")
			datamodel.NII_Indiv_NosBidFor = helper.GetFloatfromMap(jsonmap, "NII_Indiv_NosBidFor")
			datamodel.NII_Indiv_Tot = helper.GetFloatfromMap(jsonmap, "NII_Indiv_Tot")
			datamodel.NII_Other_Nos = helper.GetFloatfromMap(jsonmap, "NII_Other_Nos")
			datamodel.NII_Others_NosBidFor = helper.GetFloatfromMap(jsonmap, "NII_Others_NosBidFor")
			datamodel.NII_Others_To = helper.GetFloatfromMap(jsonmap, "NII_Others_Tot")
			datamodel.RII_Nos = helper.GetFloatfromMap(jsonmap, "RII_Nos")
			datamodel.RII_NosBidFor = helper.GetFloatfromMap(jsonmap, "RII_NosBidFor")
			datamodel.RII_Tot = helper.GetFloatfromMap(jsonmap, "RII_Tot")
			datamodel.RII_CutOff_Nos = helper.GetFloatfromMap(jsonmap, "RII_CutOff_Nos")
			datamodel.RII_CutOff_NosBidFor = helper.GetFloatfromMap(jsonmap, "RII_CutOff_NosBidFor")
			datamodel.RII_CutOff_Tot = helper.GetFloatfromMap(jsonmap, "RII_CutOff_Tot")
			datamodel.RII_PriceBids_Nos = helper.GetFloatfromMap(jsonmap, "RII_PriceBids_Nos")
			datamodel.RII_PriceBids_NosBidFor = helper.GetFloatfromMap(jsonmap, "RII_PriceBids_NosBidFor")
			datamodel.RII_PriceBids_Tot = helper.GetFloatfromMap(jsonmap, "RII_PriceBids_Tot")
			datamodel.EMP_Nos = helper.GetFloatfromMap(jsonmap, "EMP_Nos")
			datamodel.EMP_NosBidFor = helper.GetFloatfromMap(jsonmap, "EMP_NosBidFor")
			datamodel.EMP_Tot = helper.GetFloatfromMap(jsonmap, "EMP_Tot")
			datamodel.EMP_CutOff_Nos = helper.GetFloatfromMap(jsonmap, "EMP_CutOff_Nos")
			datamodel.EMP_CutOff_NosBidFor = helper.GetFloatfromMap(jsonmap, "EMP_CutOff_NosBidFor")
			datamodel.EMP_CutOff_Tot = helper.GetFloatfromMap(jsonmap, "EMP_CutOff_Tot")
			datamodel.EMP_PriceBids_Nos = helper.GetFloatfromMap(jsonmap, "EMP_PriceBids_Nos")
			datamodel.EMP_PriceBids_NosBidFor = helper.GetFloatfromMap(jsonmap, "EMP_PriceBids_NosBidFor")
			datamodel.EMP_PriceBids_Tot = helper.GetFloatfromMap(jsonmap, "EMP_PriceBids_Tot")
			datamodel.Total_Nos = helper.GetFloatfromMap(jsonmap, "Total_Nos")
			datamodel.Total_NosBidFor = helper.GetFloatfromMap(jsonmap, "Total_NosBidFor")
			datamodel.GrandTotal = helper.GetFloatfromMap(jsonmap, "GrandTotal")
			datamodel.FLAG = helper.GetStringfromMap(jsonmap, "FLAG")

			// err = tx.Save(&datamodel).Error
			// if err != nil {
			// 	buffer.WriteString(err.Error())
			// }
			datamodelUpdate = append(datamodelUpdate, datamodel)
			count++

		}
		err := db.Accord.Clauses(clause.OnConflict{
			Columns:   []clause.Column{{Name: "id"}},
			DoUpdates: clause.AssignmentColumns([]string{"ip_ocode", "total_equity", "qib_nos", "qib_nos_bid_for", "qib_tot", "qib_fiis_nos", "qib_fiis_nos_bid_for", "qib_fiis_tot", "qib_mf_nos", "qib_mf_nos_bid_for", "qib_mf_tot", "qib_other_nos", "qib_others_nos_bid_for", "qib_others_tot", "nii_nos", "nii_nos_bid_for", "nii_tot", "nii_corp_nos", "nii_corp_nos_bid_for", "nii_corp_tot", "nii_indiv_nos", "nii_indiv_nos_bid_for", "nii_indiv_tot", "nii_other_nos", "nii_others_nos_bid_for", "nii_others_to", "rii_nos", "rii_nos_bid_for", "rii_tot", "rii_cut_off_nos", "rii_cut_off_nos_bid_for", "rii_cut_off_tot", "rii_price_bids_nos", "rii_price_bids_nos_bid_for", "rii_price_bids_tot", "emp_nos", "emp_nos_bid_for", "emp_tot", "emp_cut_off_nos", "emp_cut_off_nos_bid_for", "emp_cut_off_tot", "emp_price_bids_nos", "emp_price_bids_nos_bid_for", "emp_price_bids_tot", "total_nos", "total_nos_bid_for", "grand_total", "flag"}),
			// DoUpdates: clause.AssignmentColumns([]string{"rating"}),
		}).CreateInBatches(&datamodelUpdate, 1000).Error
		if err != nil {
			fmt.Println(err)
			Zerologs.Error().Msg("Error while Inserting data into Ipo_subscriptions")
		}
		Zerologs.Info().Msgf(" execution time for Ipo_subscriptions ==>", time.Since(start))
		buffer.WriteString("Total Record updated " + strconv.Itoa(count) + "\n")
		return nil
	})

	// })
	return nil
}

// func Ipodetails(strjson []byte, buffer *bytes.Buffer) error {
// 	var arryJson []interface{}
// 	if err := json.Unmarshal(strjson, &arryJson); err != nil {
// 		buffer.WriteString(err.Error() + "\n")
// 		return err
// 	}
// 	count := 0
// 	// q.Enqueue(arryJson, func(data interface{}) {
// 	db.Accord.Transaction(func(tx *gorm.DB) error {

// 		for _, json := range arryJson {
// 			jsonmap := json.(map[string]interface{})
// 			datamodel := accord.Ipodetails{}

// 			datamodel.FINCODE = helper.GetFloatfromMap(jsonmap, "FINCODE")
// 			datamodel.IPOCODE = helper.GetFloatfromMap(jsonmap, "IPOCODE")
// 			err := tx.Where("ip_ocode=? AND fincode=?", datamodel.IPOCODE, datamodel.FINCODE).First(&datamodel).Error
// 			if err != nil {
// 				Zerologs.Error().Msg("Record Not Found In IPODETAILS" + err.Error())
// 			}
// 			datamodel.ISSUETYPE = helper.GetStringfromMap(jsonmap, "ISSUETYPE")
// 			datamodel.FIXEDPERC = helper.GetFloatfromMap(jsonmap, "FIXEDPERC")
// 			datamodel.BBPERC = helper.GetFloatfromMap(jsonmap, "BBPERC")
// 			if jsonmap["OPENDATE"] != nil {
// 				datamodel.OPENDATE = helper.GetTimefromMap(jsonmap, "OPENDATE")
// 			}
// 			if jsonmap["CLOSEDATE"] != nil {
// 				datamodel.CLOSEDATE = helper.GetTimefromMap(jsonmap, "CLOSEDATE")
// 			}

// 			datamodel.ISSUEPRICE1 = helper.GetFloatfromMap(jsonmap, "ISSUEPRICE1")
// 			datamodel.ISSUEPRICE2 = helper.GetFloatfromMap(jsonmap, "ISSUEPRICE2")
// 			datamodel.TICKSIZE = helper.GetFloatfromMap(jsonmap, "TICKSIZE")
// 			datamodel.TOTAL_EQUITY = helper.GetFloatfromMap(jsonmap, "TOTAL_EQUITY")
// 			datamodel.FACEVALUE = helper.GetFloatfromMap(jsonmap, "FACEVALUE")
// 			datamodel.MKTLOT = helper.GetFloatfromMap(jsonmap, "MKTLOT")
// 			datamodel.MINAPLN = helper.GetFloatfromMap(jsonmap, "MINAPLN")
// 			datamodel.MAXRSUB = helper.GetFloatfromMap(jsonmap, "MAXRSUB")
// 			datamodel.RETDISCOUNT = helper.GetFloatfromMap(jsonmap, "RETDISCOUNT")
// 			datamodel.ISSUEPRICE = helper.GetFloatfromMap(jsonmap, "ISSUEPRICE")
// 			datamodel.LISTDATE = helper.GetTimefromMap(jsonmap, "LISTDATE")
// 			datamodel.LISTPRICE = helper.GetFloatfromMap(jsonmap, "LISTPRICE")
// 			datamodel.NOCBCENTERS = helper.GetFloatfromMap(jsonmap, "NOCBCENTERS")
// 			datamodel.APLN_MONEY = helper.GetFloatfromMap(jsonmap, "APLN_MONEY")
// 			datamodel.ALOT_MONEY = helper.GetFloatfromMap(jsonmap, "ALOT_MONEY")
// 			datamodel.CALL = helper.GetFloatfromMap(jsonmap, "CALL")
// 			datamodel.CONTACTPNAME = helper.GetStringfromMap(jsonmap, "CONTACTPNAME")
// 			datamodel.CONTACTPTEL = helper.GetStringfromMap(jsonmap, "CONTACTPTEL")
// 			datamodel.CONTACTPFAX = helper.GetStringfromMap(jsonmap, "CONTACTPFAX")
// 			datamodel.CONTACTPEMAIL = helper.GetStringfromMap(jsonmap, "CONTACTPEMAIL")
// 			datamodel.RATING1 = helper.GetFloatfromMap(jsonmap, "RATING1")
// 			datamodel.RATING2 = helper.GetFloatfromMap(jsonmap, "RATING2")
// 			datamodel.RATING3 = helper.GetFloatfromMap(jsonmap, "RATING3")
// 			datamodel.RATINGAGENCY1 = helper.GetStringfromMap(jsonmap, "RATINGAGENCY1")
// 			datamodel.RATINGAGENCY2 = helper.GetStringfromMap(jsonmap, "RATINGAGENCY2")
// 			datamodel.RATINGAGENCY3 = helper.GetStringfromMap(jsonmap, "RATINGAGENCY3")
// 			datamodel.BA = helper.GetStringfromMap(jsonmap, "BA")
// 			datamodel.NIM = helper.GetStringfromMap(jsonmap, "NIM")
// 			datamodel.DP = helper.GetStringfromMap(jsonmap, "DP")
// 			datamodel.DPCLEARDATE = helper.GetTimefromMap(jsonmap, "DPCLEARDATE")
// 			datamodel.STATUS = helper.GetStringfromMap(jsonmap, "STATUS")
// 			datamodel.Objective = helper.GetStringfromMap(jsonmap, "Objective")
// 			datamodel.Nselist = helper.GetFloatfromMap(jsonmap, "Nselist")
// 			datamodel.FLAG = helper.GetStringfromMap(jsonmap, "FLAG")

// 			// Zerologs.Info().Msgf("Ipodetails datamodel", datamodel)
// 			// err := tx.Where("ip_ocode=? AND fincode=?", datamodel.IPOCODE, datamodel.FINCODE).First(&datamodel).Error
// 			// if err != nil {
// 			// 	err := tx.Create(&datamodel).Error
// 			// 	if err != nil {
// 			// 		buffer.WriteString(err.Error())
// 			// 	}
// 			// }
// 			//  else {
// 			err = tx.Save(&datamodel).Error
// 			if err != nil {
// 				buffer.WriteString(err.Error())
// 			}
// 			// }
// 			count++

// 		}
// 		buffer.WriteString("Total Record updated " + strconv.Itoa(count) + "\n")
// 		return nil
// 	})

// 	// })
// 	return nil
// }

func Ipodetails(strjson []byte, buffer *bytes.Buffer) error {

	var arryJson []interface{}
	if err := json.Unmarshal(strjson, &arryJson); err != nil {
		buffer.WriteString(err.Error() + "\n")
		return err
	}
	var datamodelUpdate []accord.Ipodetails

	count := 0
	// q.Enqueue(arryJson, func(data interface{}) {
	db.Accord.Transaction(func(tx *gorm.DB) error {
		start := time.Now()
		for _, json := range arryJson {
			jsonmap := json.(map[string]interface{})
			datamodel := accord.Ipodetails{}
			datamodel.FINCODE = helper.GetFloatfromMap(jsonmap, "FINCODE")
			datamodel.IPOCODE = helper.GetFloatfromMap(jsonmap, "IPOCODE")
			datamodel.ISSUETYPE = helper.GetStringfromMap(jsonmap, "ISSUETYPE")
			datamodel.FIXEDPERC = helper.GetFloatfromMap(jsonmap, "FIXEDPERC")
			datamodel.BBPERC = helper.GetFloatfromMap(jsonmap, "BBPERC")
			if jsonmap["OPENDATE"] != nil {
				datamodel.OPENDATE = helper.GetTimefromMap(jsonmap, "OPENDATE")
			}
			if jsonmap["CLOSEDATE"] != nil {
				datamodel.CLOSEDATE = helper.GetTimefromMap(jsonmap, "CLOSEDATE")
			}
			datamodel.ISSUEPRICE1 = helper.GetFloatfromMap(jsonmap, "ISSUEPRICE1")
			datamodel.ISSUEPRICE2 = helper.GetFloatfromMap(jsonmap, "ISSUEPRICE2")
			datamodel.TICKSIZE = helper.GetFloatfromMap(jsonmap, "TICKSIZE")
			datamodel.TOTAL_EQUITY = helper.GetFloatfromMap(jsonmap, "TOTAL_EQUITY")
			datamodel.FACEVALUE = helper.GetFloatfromMap(jsonmap, "FACEVALUE")
			datamodel.MKTLOT = helper.GetFloatfromMap(jsonmap, "MKTLOT")
			datamodel.MINAPLN = helper.GetFloatfromMap(jsonmap, "MINAPLN")
			datamodel.MAXRSUB = helper.GetFloatfromMap(jsonmap, "MAXRSUB")
			datamodel.RETDISCOUNT = helper.GetFloatfromMap(jsonmap, "RETDISCOUNT")
			datamodel.ISSUEPRICE = helper.GetFloatfromMap(jsonmap, "ISSUEPRICE")
			datamodel.LISTDATE = helper.GetTimefromMap(jsonmap, "LISTDATE")
			datamodel.LISTPRICE = helper.GetFloatfromMap(jsonmap, "LISTPRICE")
			datamodel.NOCBCENTERS = helper.GetFloatfromMap(jsonmap, "NOCBCENTERS")
			datamodel.APLN_MONEY = helper.GetFloatfromMap(jsonmap, "APLN_MONEY")
			datamodel.ALOT_MONEY = helper.GetFloatfromMap(jsonmap, "ALOT_MONEY")
			datamodel.CALL = helper.GetFloatfromMap(jsonmap, "CALL")
			datamodel.CONTACTPNAME = helper.GetStringfromMap(jsonmap, "CONTACTPNAME")
			datamodel.CONTACTPTEL = helper.GetStringfromMap(jsonmap, "CONTACTPTEL")
			datamodel.CONTACTPFAX = helper.GetStringfromMap(jsonmap, "CONTACTPFAX")
			datamodel.CONTACTPEMAIL = helper.GetStringfromMap(jsonmap, "CONTACTPEMAIL")
			datamodel.RATING1 = helper.GetFloatfromMap(jsonmap, "RATING1")
			datamodel.RATING2 = helper.GetFloatfromMap(jsonmap, "RATING2")
			datamodel.RATING3 = helper.GetFloatfromMap(jsonmap, "RATING3")
			datamodel.RATINGAGENCY1 = helper.GetStringfromMap(jsonmap, "RATINGAGENCY1")
			datamodel.RATINGAGENCY2 = helper.GetStringfromMap(jsonmap, "RATINGAGENCY2")
			datamodel.RATINGAGENCY3 = helper.GetStringfromMap(jsonmap, "RATINGAGENCY3")
			datamodel.BA = helper.GetStringfromMap(jsonmap, "BA")
			datamodel.NIM = helper.GetStringfromMap(jsonmap, "NIM")
			datamodel.DP = helper.GetStringfromMap(jsonmap, "DP")
			datamodel.DPCLEARDATE = helper.GetTimefromMap(jsonmap, "DPCLEARDATE")
			datamodel.STATUS = helper.GetStringfromMap(jsonmap, "STATUS")
			datamodel.Objective = helper.GetStringfromMap(jsonmap, "Objective")
			datamodel.Nselist = helper.GetFloatfromMap(jsonmap, "Nselist")
			datamodel.FLAG = helper.GetStringfromMap(jsonmap, "FLAG")
			fcode := fmt.Sprintf("%v", datamodel.FINCODE)
			icode := fmt.Sprintf("%v", datamodel.IPOCODE)
			datamodel.ID = fcode + "_" + icode
			datamodelUpdate = append(datamodelUpdate, datamodel)
			count++

		}
		err := db.Accord.Clauses(clause.OnConflict{
			Columns: []clause.Column{{Name: "id"}},
			DoUpdates: clause.AssignmentColumns([]string{"ip_ocode",
				"fincode", "issuetype", "fixedperc", "bbperc", "opendate", "closedate", "issueprice1", "issueprice2", "ticksize", "total_eq_ui_ty", "facevalue", "mktlot", "minapln", "maxrsub", "retdiscount", "issueprice", "listdate", "listprice", "nocbcenters", "apln_money", "alot_money", "call", "contactpname", "contactptel", "contactpfax", "contactpemail", "rating1", "rating2", "rating3", "ratingagency1", "ratingagency2", "ratingagency3", "ba", "nim", "dp", "dpcleardate", "status", "objective", "nselist", "flag"}),
			// DoUpdates: clause.AssignmentColumns([]string{"rating"}),
		}).CreateInBatches(&datamodelUpdate, 1000).Error
		if err != nil {
			fmt.Println(err)
			Zerologs.Error().Msg("Error while Inserting data into ipodetails")
		}
		Zerologs.Info().Msgf(" execution time ==>", time.Since(start))
		buffer.WriteString("Total Record updated " + strconv.Itoa(count) + "\n")
		return nil
	})

	// })
	return nil
}
func CorpEventMaster(strjson []byte, buffer *bytes.Buffer) error {
	var arryJson []interface{}
	if err := json.Unmarshal(strjson, &arryJson); err != nil {
		buffer.WriteString(err.Error() + "\n")
		return err
	}
	var datamodelUpdate []accord.CorpeventMst
	count := 0
	// q.Enqueue(arryJson, func(data interface{}) {
	db.Accord.Transaction(func(tx *gorm.DB) error {
		start := time.Now()
		for _, json := range arryJson {
			jsonmap := json.(map[string]interface{})
			datamodel := accord.CorpeventMst{}
			datamodel.CORPACT_ID = helper.GetIntfromMap(jsonmap, "CORPACT_ID")
			// err := tx.Where("corpact_id=?", datamodel.CORPACT_ID).First(&datamodel).Error

			// if err != nil {
			// 	Zerologs.Error().Msg("Record Not Found In CorpEventMaster" + err.Error())
			// }
			corpactID := strconv.Itoa(datamodel.CORPACT_ID)
			datamodel.ID = corpactID
			datamodel.CORP_ACTION = helper.GetStringfromMap(jsonmap, "CORP_ACTION")
			datamodel.FLAG = helper.GetStringfromMap(jsonmap, "Flag")

			// err = tx.Save(&datamodel).Error
			// if err != nil {
			// 	buffer.WriteString(err.Error())
			// }
			datamodelUpdate = append(datamodelUpdate, datamodel)
			count++

		}
		err := db.Accord.Clauses(clause.OnConflict{
			Columns:   []clause.Column{{Name: "id"}},
			DoUpdates: clause.AssignmentColumns([]string{"corpact_id", "corp_action", "flag"}),
			// DoUpdates: clause.AssignmentColumns([]string{"rating"}),
		}).CreateInBatches(&datamodelUpdate, 1000).Error
		if err != nil {
			fmt.Println(err)
			Zerologs.Error().Msg("Error while Inserting data into CorpEventmaster")
		}
		Zerologs.Info().Msgf(" execution time for CorpEventmaster ==>", time.Since(start))
		buffer.WriteString("Total Record updated " + strconv.Itoa(count) + "\n")
		return nil
	})

	// })
	return nil
}

func Namechange(strjson []byte, buffer *bytes.Buffer) error {
	var arryJson []interface{}
	if err := json.Unmarshal(strjson, &arryJson); err != nil {
		buffer.WriteString(err.Error() + "\n")
		return err
	}
	var datamodelUpdate []accord.Namechange
	count := 0
	// q.Enqueue(arryJson, func(data interface{}) {
	db.Accord.Transaction(func(tx *gorm.DB) error {
		start := time.Now()
		for _, json := range arryJson {
			jsonmap := json.(map[string]interface{})
			datamodel := accord.Namechange{}
			datamodel.FINCODE = helper.GetIntfromMap(jsonmap, "Fincode")
			datamodel.SRNO = helper.GetIntfromMap(jsonmap, "Srno")
			// err := tx.Where("fincode=? AND srno=?", datamodel.FINCODE, datamodel.SRNO).First(&datamodel).Error

			// if err != nil {
			// 	Zerologs.Error().Msg("Record Not Found In NameChange" + err.Error())
			// }
			fincode := strconv.Itoa(datamodel.FINCODE)
			srNo := strconv.Itoa(datamodel.SRNO)
			fincode_srNo := fincode + "_" + srNo
			datamodel.ID = fincode_srNo
			datamodel.Effectivedate = helper.GetTimefromMap(jsonmap, "effectivedate")
			datamodel.OldName = helper.GetStringfromMap(jsonmap, "OldName")
			datamodel.NewName = helper.GetStringfromMap(jsonmap, "NewName")
			datamodel.FLAG = helper.GetStringfromMap(jsonmap, "flag")

			// err = tx.Save(&datamodel).Error
			// if err != nil {
			// 	buffer.WriteString(err.Error())
			// }
			datamodelUpdate = append(datamodelUpdate, datamodel)
			count++

		}
		err := db.Accord.Clauses(clause.OnConflict{
			Columns:   []clause.Column{{Name: "id"}},
			DoUpdates: clause.AssignmentColumns([]string{"fincode", "srno", "effectivedate", "old_name", "new_name", "flag"}),
			// DoUpdates: clause.AssignmentColumns([]string{"rating"}),
		}).CreateInBatches(&datamodelUpdate, 1000).Error
		if err != nil {
			fmt.Println(err)
			Zerologs.Error().Msg("Error while Inserting data into Namechange")
		}
		Zerologs.Info().Msgf(" execution time for Namechange ==>", time.Since(start))
		buffer.WriteString("Total Record updated " + strconv.Itoa(count) + "\n")
		return nil
	})

	// })
	return nil
}
func Delistedcompanies(strjson []byte, buffer *bytes.Buffer) error {
	var arryJson []interface{}
	if err := json.Unmarshal(strjson, &arryJson); err != nil {
		buffer.WriteString(err.Error() + "\n")
		return err
	}
	var datamodelUpdate []accord.Delistedcompanies
	count := 0
	// q.Enqueue(arryJson, func(data interface{}) {
	db.Accord.Transaction(func(tx *gorm.DB) error {
		start := time.Now()
		for _, json := range arryJson {
			jsonmap := json.(map[string]interface{})
			datamodel := accord.Delistedcompanies{}
			datamodel.Scripcode = helper.GetIntfromMap(jsonmap, "scripcode")
			// err := tx.Where("scripcode=?", datamodel.Scripcode).First(&datamodel).Error

			// if err != nil {
			// 	Zerologs.Error().Msg("Record Not Found In Delistedcompanies" + err.Error())
			// }
			scripcode := strconv.Itoa(datamodel.Scripcode)
			datamodel.ID = scripcode
			datamodel.Fincode = helper.GetIntfromMap(jsonmap, "fincode")
			datamodel.Compname = helper.GetStringfromMap(jsonmap, "compname")
			datamodel.Bsedelisted_date = helper.GetTimefromMap(jsonmap, "bsedelisted_date")
			datamodel.Flag = helper.GetStringfromMap(jsonmap, "Flag")

			// err = tx.Save(&datamodel).Error
			// if err != nil {
			// 	buffer.WriteString(err.Error())
			// }
			datamodelUpdate = append(datamodelUpdate, datamodel)
			count++

		}
		err := db.Accord.Clauses(clause.OnConflict{
			Columns:   []clause.Column{{Name: "id"}},
			DoUpdates: clause.AssignmentColumns([]string{"scripcode", "fincode", "compname", "bsedelisted_date", "flag"}),
			// DoUpdates: clause.AssignmentColumns([]string{"rating"}),
		}).CreateInBatches(&datamodelUpdate, 1000).Error
		if err != nil {
			fmt.Println(err)
			Zerologs.Error().Msg("Error while Inserting data into Delistedcompanies")
		}
		Zerologs.Info().Msgf(" execution time for Delistedcompanies ==>", time.Since(start))
		buffer.WriteString("Total Record updated " + strconv.Itoa(count) + "\n")
		return nil
	})

	// })
	return nil
}
func Bse_bulkdeals(strjson []byte, buffer *bytes.Buffer) error {
	var arryJson []interface{}
	if err := json.Unmarshal(strjson, &arryJson); err != nil {
		buffer.WriteString(err.Error() + "\n")
		return err
	}
	var datamodelUpdate []accord.BseBulkdeal
	count := 0
	// q.Enqueue(arryJson, func(data interface{}) {
	db.Accord.Transaction(func(tx *gorm.DB) error {
		start := time.Now()
		for _, json := range arryJson {
			jsonmap := json.(map[string]interface{})
			datamodel := accord.BseBulkdeal{}
			datamodel.DATE = helper.GetTimefromMap(jsonmap, "Date")
			datamodel.SCRIPCODE = helper.GetIntfromMap(jsonmap, "SCRIPCODE")
			datamodel.CLIENTNAME = helper.GetStringfromMap(jsonmap, "CLIENTNAME")
			datamodel.DEALTYPE = helper.GetStringfromMap(jsonmap, "DEALTYPE")
			datamodel.VOLUME = helper.GetFloatfromMap(jsonmap, "VOLUME")
			datamodel.PRICE = helper.GetFloatfromMap(jsonmap, "PRICE")
			// err := tx.Where("date=? AND scr_ip_code=? AND clientname=? AND dealtype=? volume=? AND price=?", datamodel.DATE, datamodel.SCRIPCODE, datamodel.CLIENTNAME, datamodel.DEALTYPE, datamodel.VOLUME, datamodel.PRICE).First(&datamodel).Error

			// if err != nil {
			// 	Zerologs.Error().Msg("Record Not Found In BseBulkdeal" + err.Error())
			// }
			date := datamodel.DATE.String()
			scripcode := strconv.Itoa(datamodel.SCRIPCODE)
			volume := fmt.Sprintf("%v", datamodel.VOLUME)
			price := fmt.Sprintf("%v", datamodel.PRICE)
			date_scode_cname_dealType_vol_prc := date + "_" + scripcode + "_" + datamodel.CLIENTNAME + "_" + datamodel.DEALTYPE + "_" + volume + "_" + price
			datamodel.ID = date_scode_cname_dealType_vol_prc
			datamodel.Fincode = helper.GetIntfromMap(jsonmap, "Fincode")

			datamodel.SCRIPNAME = helper.GetStringfromMap(jsonmap, "SCRIPNAME")

			datamodel.FLAG = helper.GetStringfromMap(jsonmap, "Flag")

			// err = tx.Save(&datamodel).Error
			// if err != nil {
			// 	buffer.WriteString(err.Error())
			// }
			datamodelUpdate = append(datamodelUpdate, datamodel)
			count++

		}
		err := db.Accord.Clauses(clause.OnConflict{
			Columns:   []clause.Column{{Name: "id"}},
			DoUpdates: clause.AssignmentColumns([]string{"date", "fincode", "scr_ip_code", "scr_ip_name", "clientname", "dealtype", "volume", "price", "flag"}),
			// DoUpdates: clause.AssignmentColumns([]string{"rating"}),
		}).CreateInBatches(&datamodelUpdate, 1000).Error
		if err != nil {
			fmt.Println(err)
			Zerologs.Error().Msg("Error while Inserting data into Bse_bulkdeals")
		}
		Zerologs.Info().Msgf(" execution time for Bse_bulkdeals ==>", time.Since(start))
		buffer.WriteString("Total Record updated " + strconv.Itoa(count) + "\n")
		return nil
	})

	// })
	return nil
}
func Bse_blockdeals(strjson []byte, buffer *bytes.Buffer) error {
	var arryJson []interface{}
	if err := json.Unmarshal(strjson, &arryJson); err != nil {
		buffer.WriteString(err.Error() + "\n")
		return err
	}
	var datamodelUpdate []accord.BseBlockdeal
	count := 0
	// q.Enqueue(arryJson, func(data interface{}) {
	db.Accord.Transaction(func(tx *gorm.DB) error {
		start := time.Now()
		for _, json := range arryJson {
			jsonmap := json.(map[string]interface{})
			datamodel := accord.BseBlockdeal{}
			datamodel.Date = helper.GetTimefromMap(jsonmap, "date")
			datamodel.SCRIPCODE = helper.GetIntfromMap(jsonmap, "SCRIPCODE")
			datamodel.CLIENTNAME = helper.GetStringfromMap(jsonmap, "CLIENTNAME")
			datamodel.DEALTYPE = helper.GetStringfromMap(jsonmap, "DEALTYPE")
			datamodel.VOLUME = helper.GetFloatfromMap(jsonmap, "VOLUME")
			datamodel.SCRIPNAME = helper.GetStringfromMap(jsonmap, "SCRIPNAME")
			datamodel.TRADEPRICE = helper.GetFloatfromMap(jsonmap, "TRADEPRICE")
			// err := tx.Where("date=?,scr_ip_code=?,clientname=?,dealtype=?,volume=?,scr_ip_name=?,tradeprice=?", datamodel.Date, datamodel.SCRIPCODE, datamodel.CLIENTNAME, datamodel.DEALTYPE, datamodel.VOLUME, datamodel.SCRIPNAME, datamodel.TRADEPRICE).First(&datamodel).Error

			// if err != nil {
			// 	Zerologs.Error().Msg("Record Not Found In Bseblockdeal" + err.Error())
			// }
			date := datamodel.Date.String()
			scripcode := strconv.Itoa(datamodel.SCRIPCODE)
			volume := fmt.Sprintf("%v", datamodel.VOLUME)
			trdprc := fmt.Sprintf("%v", datamodel.TRADEPRICE)
			date_scode_cname_dealType_vol_sname_tprice := date + "_" + scripcode + "_" + datamodel.CLIENTNAME + "_" + datamodel.DEALTYPE + "_" + volume + "_" + datamodel.SCRIPNAME + "_" + trdprc
			datamodel.ID = date_scode_cname_dealType_vol_sname_tprice
			datamodel.FINCODE = helper.GetIntfromMap(jsonmap, "FINCODE")

			datamodel.Flag = helper.GetStringfromMap(jsonmap, "Flag")

			// err = tx.Save(&datamodel).Error
			// if err != nil {
			// 	buffer.WriteString(err.Error())
			// }
			datamodelUpdate = append(datamodelUpdate, datamodel)
			count++

		}
		err := db.Accord.Clauses(clause.OnConflict{
			Columns:   []clause.Column{{Name: "id"}},
			DoUpdates: clause.AssignmentColumns([]string{"date", "fincode", "scr_ip_code", "scr_ip_name", "clientname", "dealtype", "volume", "tradeprice", "flag"}),
			// DoUpdates: clause.AssignmentColumns([]string{"rating"}),
		}).CreateInBatches(&datamodelUpdate, 1000).Error
		if err != nil {
			fmt.Println(err)
			Zerologs.Error().Msg("Error while Inserting data into Bse_blockdeals")
		}
		Zerologs.Info().Msgf(" execution time for Bse_blockdeals ==>", time.Since(start))
		buffer.WriteString("Total Record updated " + strconv.Itoa(count) + "\n")
		return nil
	})

	// })
	return nil
}
func Insider_trading(strjson []byte, buffer *bytes.Buffer) error {
	var arryJson []interface{}
	if err := json.Unmarshal(strjson, &arryJson); err != nil {
		buffer.WriteString(err.Error() + "\n")
		return err
	}
	var datamodelUpdate []accord.InsiderTrading
	count := 0
	// q.Enqueue(arryJson, func(data interface{}) {
	db.Accord.Transaction(func(tx *gorm.DB) error {
		start := time.Now()
		for _, json := range arryJson {
			jsonmap := json.(map[string]interface{})
			datamodel := accord.InsiderTrading{}
			datamodel.Srno = helper.GetIntfromMap(jsonmap, "srno")
			datamodel.Fincode = helper.GetIntfromMap(jsonmap, "fincode")
			datamodel.ProcessDate = helper.GetTimefromMap(jsonmap, "processDate")
			datamodel.Trader = helper.GetStringfromMap(jsonmap, "trader")
			datamodel.Red_id = helper.GetIntfromMap(jsonmap, "red_id")
			// err := tx.Where("srno=? AND fincode=? AND process_date=? AND trader=? AND red_id=?", datamodel.Srno, datamodel.Fincode, datamodel.ProcessDate, datamodel.Trader, datamodel.Red_id).First(&datamodel).Error

			// if err != nil {
			// 	Zerologs.Error().Msg("Record Not Found In InsiderTrading" + err.Error())
			// }
			srno := strconv.Itoa(datamodel.Srno)
			fincode := strconv.Itoa(datamodel.Fincode)
			pDate := datamodel.ProcessDate.String()
			redid := strconv.Itoa(datamodel.Red_id)
			sno_fcode_pdate_trader_rid := srno + "_" + fincode + "_" + pDate + "_" + datamodel.Trader + "_" + redid
			datamodel.ID = sno_fcode_pdate_trader_rid
			datamodel.Company = helper.GetStringfromMap(jsonmap, "company")
			datamodel.TransDateFrom = helper.GetTimefromMap(jsonmap, "TransDateFrom")
			datamodel.TransDateTo = helper.GetTimefromMap(jsonmap, "TransDateTo")
			datamodel.TransType = helper.GetStringfromMap(jsonmap, "TransType")
			datamodel.QuantityBuy = helper.GetFloatfromMap(jsonmap, "QuantityBuy")
			datamodel.QuantitySell = helper.GetFloatfromMap(jsonmap, "QuantitySell")
			datamodel.QuantityType = helper.GetStringfromMap(jsonmap, "QuantityType")
			datamodel.PercentBuySell = helper.GetFloatfromMap(jsonmap, "PercentBuySell")
			datamodel.PriceofTrans = helper.GetFloatfromMap(jsonmap, "PriceOfTrans")
			datamodel.HoldingBuySell = helper.GetFloatfromMap(jsonmap, "HoldingBuySell")
			datamodel.HoldingPercent = helper.GetFloatfromMap(jsonmap, "HoldingPercent")
			datamodel.Flag = helper.GetStringfromMap(jsonmap, "Flag")

			// err = tx.Save(&datamodel).Error
			// if err != nil {
			// 	buffer.WriteString(err.Error())
			// }
			datamodelUpdate = append(datamodelUpdate, datamodel)
			count++

		}
		err := db.Accord.Clauses(clause.OnConflict{
			Columns:   []clause.Column{{Name: "id"}},
			DoUpdates: clause.AssignmentColumns([]string{"srno", "fincode", "process_date", "trader", "red_id", "company", "trans_date_from", "trans_date_to", "trans_type", "quantity_buy", "quantity_sell", "quantity_type", "percent_buy_sell", "priceof_trans", "holding_buy_sell", "holding_percent", "flag"}),
			// DoUpdates: clause.AssignmentColumns([]string{"rating"}),
		}).CreateInBatches(&datamodelUpdate, 1000).Error
		if err != nil {
			fmt.Println(err)
			Zerologs.Error().Msg("Error while Inserting data into Insider_trading")
		}
		Zerologs.Info().Msgf(" execution time for Insider_trading ==>", time.Since(start))
		buffer.WriteString("Total Record updated " + strconv.Itoa(count) + "\n")
		return nil
	})

	// })
	return nil
}
func Bsedeliverables(strjson []byte, buffer *bytes.Buffer) error {
	var arryJson []interface{}
	if err := json.Unmarshal(strjson, &arryJson); err != nil {
		buffer.WriteString(err.Error() + "\n")
		return err
	}
	var datamodelUpdate []accord.Bsedeliveriable
	count := 0
	// q.Enqueue(arryJson, func(data interface{}) {
	db.Accord.Transaction(func(tx *gorm.DB) error {
		start := time.Now()
		for _, json := range arryJson {
			jsonmap := json.(map[string]interface{})
			datamodel := accord.Bsedeliveriable{}
			datamodel.DATE = helper.GetTimefromMap(jsonmap, "Date")
			datamodel.FINCODE = helper.GetIntfromMap(jsonmap, "FINCODE")
			// err := tx.Where("date=? AND fincode=?", datamodel.DATE, datamodel.FINCODE).First(&datamodel).Error

			// if err != nil {
			// 	Zerologs.Error().Msg("Record Not Found In Bsedeliveriable" + err.Error())
			// }
			date := datamodel.DATE.String()
			fincode := strconv.Itoa(datamodel.FINCODE)
			date_fincode := date + "_" + fincode
			datamodel.ID = date_fincode
			datamodel.SCRIPCODE = helper.GetIntfromMap(jsonmap, "SCRIPCODE")
			datamodel.DELV_VOLUME = helper.GetFloatfromMap(jsonmap, "DELV_VOLUME")
			datamodel.DELV_VALUE = helper.GetFloatfromMap(jsonmap, "DELV_VALUE")
			datamodel.VOLUME = helper.GetFloatfromMap(jsonmap, "VOLUME")
			datamodel.VALUE = helper.GetFloatfromMap(jsonmap, "VALUE")
			datamodel.DELV_PER = helper.GetFloatfromMap(jsonmap, "DELV_PER")
			datamodel.FLAG = helper.GetStringfromMap(jsonmap, "Flag")

			// err = tx.Save(&datamodel).Error
			// if err != nil {
			// 	buffer.WriteString(err.Error())
			// }
			datamodelUpdate = append(datamodelUpdate, datamodel)
			count++

		}
		err := db.Accord.Clauses(clause.OnConflict{
			Columns:   []clause.Column{{Name: "id"}},
			DoUpdates: clause.AssignmentColumns([]string{"date", "fincode", "scr_ip_code", "delv_volume", "delv_value", "volume", "value", "delv_per", "flag"}),
			// DoUpdates: clause.AssignmentColumns([]string{"rating"}),
		}).CreateInBatches(&datamodelUpdate, 1000).Error
		if err != nil {
			fmt.Println(err)
			Zerologs.Error().Msg("Error while Inserting data into Bsedeliverables")
		}
		Zerologs.Info().Msgf(" execution time for Bsedeliverables ==>", time.Since(start))
		buffer.WriteString("Total Record updated " + strconv.Itoa(count) + "\n")
		return nil
	})

	// })
	return nil
}
func SchemeMaster(strjson []byte, buffer *bytes.Buffer) error {
	var arryJson []interface{}
	if err := json.Unmarshal(strjson, &arryJson); err != nil {
		buffer.WriteString(err.Error() + "\n")
		return err
	}
	var datamodelUpdate []accord.Scheme_master
	count := 0
	// q.Enqueue(arryJson, func(data interface{}) {
	db.Accord.Transaction(func(tx *gorm.DB) error {
		start := time.Now()
		for _, json := range arryJson {
			jsonmap := json.(map[string]interface{})
			datamodel := accord.Scheme_master{}
			datamodel.Schemecode = helper.GetIntfromMap(jsonmap, "schemecode")
			// err := tx.Where("schemecode=? ", datamodel.Schemecode).First(&datamodel).Error

			// if err != nil {
			// 	Zerologs.Error().Msg("Record Not Found In Scheme_Master" + err.Error())
			// }
			scode := strconv.Itoa(datamodel.Schemecode)
			datamodel.ID = scode
			datamodel.Amc_code = helper.GetIntfromMap(jsonmap, "amc_code")
			datamodel.Scheme_name = helper.GetStringfromMap(jsonmap, "scheme_name")
			datamodel.Color = helper.GetStringfromMap(jsonmap, "color")
			datamodel.Flag = helper.GetStringfromMap(jsonmap, "flag")

			// err = tx.Save(&datamodel).Error
			// if err != nil {
			// 	buffer.WriteString(err.Error())
			// }
			datamodelUpdate = append(datamodelUpdate, datamodel)
			count++

		}
		err := db.Accord.Clauses(clause.OnConflict{
			Columns:   []clause.Column{{Name: "id"}},
			DoUpdates: clause.AssignmentColumns([]string{"schemecode", "amc_code", "scheme_name", "color", "flag"}),
			// DoUpdates: clause.AssignmentColumns([]string{"rating"}),
		}).CreateInBatches(&datamodelUpdate, 1000).Error
		if err != nil {
			fmt.Println(err)
			Zerologs.Error().Msg("Error while Inserting data into Schememaster")
		}
		Zerologs.Info().Msgf(" execution time for Schememaster ==>", time.Since(start))
		buffer.WriteString("Total Record updated " + strconv.Itoa(count) + "\n")
		return nil
	})

	// })
	return nil
}
func Scheme_NameChange(strjson []byte, buffer *bytes.Buffer) error {
	var arryJson []interface{}
	if err := json.Unmarshal(strjson, &arryJson); err != nil {
		buffer.WriteString(err.Error() + "\n")
		return err
	}
	var datamodelUpdate []accord.Scheme_Name_Change
	count := 0
	// q.Enqueue(arryJson, func(data interface{}) {
	db.Accord.Transaction(func(tx *gorm.DB) error {
		start := time.Now()
		for _, json := range arryJson {
			jsonmap := json.(map[string]interface{})
			datamodel := accord.Scheme_Name_Change{}
			datamodel.Amc_Code = helper.GetIntfromMap(jsonmap, "Amc_Code")
			datamodel.SchemeCode = helper.GetIntfromMap(jsonmap, "SchemeCode")
			datamodel.Effectivedate = helper.GetTimefromMap(jsonmap, "Effectivedate")
			// err := tx.Where(" amc_code=? AND scheme_code=? AND effectivedate=? ", datamodel.Amc_Code, datamodel.SchemeCode, datamodel.Effectivedate).First(&datamodel).Error
			// if err != nil {
			// 	Zerologs.Error().Msg("Record Not Found In Scheme_Name_Change" + err.Error())
			// }
			acode := strconv.Itoa(datamodel.Amc_Code)
			scode := strconv.Itoa(datamodel.SchemeCode)
			edate := datamodel.Effectivedate.String()
			acode_scode_edate := acode + "_" + scode + "_" + edate
			datamodel.ID = acode_scode_edate
			datamodel.OldName = helper.GetStringfromMap(jsonmap, "OldName")
			datamodel.Newname = helper.GetStringfromMap(jsonmap, "Newname")
			datamodel.Flag = helper.GetStringfromMap(jsonmap, "Flag")

			// err := tx.Where(" amc_code=? AND scheme_code=? AND effectivedate=? ", datamodel.Amc_Code, datamodel.SchemeCode, datamodel.Effectivedate).First(&datamodel).Error
			// if err != nil {
			// 	err := tx.Create(&datamodel).Error
			// 	if err != nil {
			// 		buffer.WriteString(err.Error())
			// 	}
			// } else {
			// err = tx.Save(&datamodel).Error
			// if err != nil {
			// 	buffer.WriteString(err.Error())
			// }
			// }
			datamodelUpdate = append(datamodelUpdate, datamodel)
			count++

		}
		err := db.Accord.Clauses(clause.OnConflict{
			Columns:   []clause.Column{{Name: "id"}},
			DoUpdates: clause.AssignmentColumns([]string{"amc_code", "scheme_code", "effectivedate", "old_name", "newname", "flag"}),
			// DoUpdates: clause.AssignmentColumns([]string{"rating"}),
		}).CreateInBatches(&datamodelUpdate, 1000).Error
		if err != nil {
			fmt.Println(err)
			Zerologs.Error().Msg("Error while Inserting data into Schemenamechange")
		}
		Zerologs.Info().Msgf(" execution time for Schemenamechange ==>", time.Since(start))
		buffer.WriteString("Total Record updated " + strconv.Itoa(count) + "\n")
		return nil
	})

	// })
	return nil
}
func Scheme_Rgess(strjson []byte, buffer *bytes.Buffer) error {
	var arryJson []interface{}
	if err := json.Unmarshal(strjson, &arryJson); err != nil {
		buffer.WriteString(err.Error() + "\n")
		return err
	}
	var datamodelUpdate []accord.Scheme_rgess
	count := 0
	// q.Enqueue(arryJson, func(data interface{}) {
	db.Accord.Transaction(func(tx *gorm.DB) error {
		start := time.Now()
		for _, json := range arryJson {
			jsonmap := json.(map[string]interface{})
			datamodel := accord.Scheme_rgess{}
			datamodel.Schemecode = helper.GetIntfromMap(jsonmap, "schemecode")
			// err := tx.Where(" schemecode=?", datamodel.Schemecode).First(&datamodel).Error
			// if err != nil {
			// 	Zerologs.Error().Msg("Record Not Found In Scheme_Rgess" + err.Error())
			// }
			scode := strconv.Itoa(datamodel.Schemecode)
			datamodel.ID = scode
			datamodel.Schemename = helper.GetStringfromMap(jsonmap, "schemename")
			datamodel.Flag = helper.GetStringfromMap(jsonmap, "flag")

			// err := tx.Where(" schemecode=?", datamodel.Schemecode).First(&datamodel).Error
			// if err != nil {
			// 	err := tx.Create(&datamodel).Error
			// 	if err != nil {
			// 		buffer.WriteString(err.Error())
			// 	}
			// } else {
			// err = tx.Save(&datamodel).Error
			// if err != nil {
			// 	buffer.WriteString(err.Error())
			// }
			// }
			datamodelUpdate = append(datamodelUpdate, datamodel)
			count++

		}
		err := db.Accord.Clauses(clause.OnConflict{
			Columns:   []clause.Column{{Name: "id"}},
			DoUpdates: clause.AssignmentColumns([]string{"schemecode", "schemename", "flag"}),
			// DoUpdates: clause.AssignmentColumns([]string{"rating"}),
		}).CreateInBatches(&datamodelUpdate, 1000).Error
		if err != nil {
			fmt.Println(err)
			Zerologs.Error().Msg("Error while Inserting data into Scheme_rgess")
		}
		Zerologs.Info().Msgf(" execution time for Scheme_rgess ==>", time.Since(start))
		buffer.WriteString("Total Record updated " + strconv.Itoa(count) + "\n")
		return nil
	})

	// })
	return nil
}

func Divdetails(strjson []byte, buffer *bytes.Buffer) error {
	var arryJson []interface{}
	if err := json.Unmarshal(strjson, &arryJson); err != nil {
		buffer.WriteString(err.Error() + "\n")
		return err
	}
	var datamodelUpdate []accord.Divdetails
	count := 0
	// q.Enqueue(arryJson, func(data interface{}) {
	db.Accord.Transaction(func(tx *gorm.DB) error {
		start := time.Now()
		for _, json := range arryJson {
			jsonmap := json.(map[string]interface{})
			datamodel := accord.Divdetails{}

			datamodel.Schemecode = helper.GetIntfromMap(jsonmap, "schemecode")
			datamodel.Recorddate = helper.GetTimefromMap(jsonmap, "recorddate")
			// err := tx.Where("schemecode=? AND recorddate=?", datamodel.Schemecode, datamodel.Recorddate).First(&datamodel).Error
			// if err != nil {
			// 	Zerologs.Error().Msg("Record Not Found In Divdetails" + err.Error())
			// }
			scode := strconv.Itoa(datamodel.Schemecode)
			rdate := datamodel.Recorddate.String()
			scode_rdate := scode + "_" + rdate
			datamodel.ID = scode_rdate
			datamodel.Amc_code = helper.GetIntfromMap(jsonmap, "amc_code")
			datamodel.Div_code = helper.GetIntfromMap(jsonmap, "div_code")
			datamodel.Exdivdate = helper.GetTimefromMap(jsonmap, "exdivdate")
			datamodel.Bonusrate1 = helper.GetFloatfromMap(jsonmap, "Bonusrate1")
			datamodel.Bonusrate2 = helper.GetFloatfromMap(jsonmap, "Bonusrate2")
			datamodel.Gross = helper.GetFloatfromMap(jsonmap, "gross")
			datamodel.Corporate = helper.GetFloatfromMap(jsonmap, "corporate")
			datamodel.Noncorporate = helper.GetFloatfromMap(jsonmap, "noncorporate")
			datamodel.Status = helper.GetStringfromMap(jsonmap, "status")
			datamodel.Flag = helper.GetStringfromMap(jsonmap, "flag")

			// err := tx.Where("schemecode=? AND recorddate=?", datamodel.Schemecode, datamodel.Recorddate).First(&datamodel).Error
			// if err != nil {
			// 	err := tx.Create(&datamodel).Error
			// 	if err != nil {
			// 		buffer.WriteString(err.Error())
			// 	}
			// } else {
			// err = tx.Save(&datamodel).Error
			// if err != nil {
			// 	buffer.WriteString(err.Error())
			// }
			// }
			datamodelUpdate = append(datamodelUpdate, datamodel)
			count++

		}
		err := db.Accord.Clauses(clause.OnConflict{
			Columns:   []clause.Column{{Name: "id"}},
			DoUpdates: clause.AssignmentColumns([]string{"amc_code", "schemecode", "recorddate", "div_code", "exdivdate ", "bonusrate1", "bonusrate2", "gross ", "corporate ", "noncorporate", "status  ", "flag"}),
			// DoUpdates: clause.AssignmentColumns([]string{"rating"}),
		}).CreateInBatches(&datamodelUpdate, 1000).Error
		if err != nil {
			fmt.Println(err)
			Zerologs.Error().Msg("Error while Inserting data into Divdetails")
		}
		Zerologs.Info().Msgf(" execution time for Divdetails ==>", time.Since(start))
		buffer.WriteString("Total Record updated " + strconv.Itoa(count) + "\n")
		return nil
	})

	// })
	return nil
}

func Expenceratio(strjson []byte, buffer *bytes.Buffer) error {
	var arryJson []interface{}
	if err := json.Unmarshal(strjson, &arryJson); err != nil {
		buffer.WriteString(err.Error() + "\n")
		return err
	}
	var datamodelUpdate []accord.Expenceratio
	count := 0
	// q.Enqueue(arryJson, func(data interface{}) {
	db.Accord.Transaction(func(tx *gorm.DB) error {
		start := time.Now()
		for _, json := range arryJson {
			jsonmap := json.(map[string]interface{})
			datamodel := accord.Expenceratio{}
			datamodel.Schemecode = helper.GetIntfromMap(jsonmap, "schemecode")
			datamodel.Date = helper.GetTimefromMap(jsonmap, "date")
			// err := tx.Where("schemecode=? AND date=?", datamodel.Schemecode, datamodel.Date).First(&datamodel).Error
			// if err != nil {
			// 	Zerologs.Error().Msg("Record Not Found In Expenceratio" + err.Error())
			// }
			scode := strconv.Itoa(datamodel.Schemecode)
			date := datamodel.Date.String()
			scode_date := scode + "_" + date
			datamodel.ID = scode_date
			datamodel.Amc_code = helper.GetIntfromMap(jsonmap, "amc_code")

			datamodel.Expratio = helper.GetFloatfromMap(jsonmap, "expratio")
			datamodel.Flag = helper.GetStringfromMap(jsonmap, "flag")

			// err := tx.Where("schemecode=? AND date=?", datamodel.Schemecode, datamodel.Date).First(&datamodel).Error
			// if err != nil {
			// 	err := tx.Create(&datamodel).Error
			// 	if err != nil {
			// 		buffer.WriteString(err.Error())
			// 	}
			// } else {
			// err = tx.Save(&datamodel).Error
			// if err != nil {
			// 	buffer.WriteString(err.Error())
			// }
			// }
			datamodelUpdate = append(datamodelUpdate, datamodel)
			count++

		}
		err := db.Accord.Clauses(clause.OnConflict{
			Columns:   []clause.Column{{Name: "id"}},
			DoUpdates: clause.AssignmentColumns([]string{"amc_code", "schemecode", "date", "expratio", "flag"}),
			// DoUpdates: clause.AssignmentColumns([]string{"rating"}),
		}).CreateInBatches(&datamodelUpdate, 1000).Error
		if err != nil {
			fmt.Println(err)
			Zerologs.Error().Msg("Error while Inserting data into Expenceratios")
		}
		Zerologs.Info().Msgf(" execution time for Expenceratios ==>", time.Since(start))
		buffer.WriteString("Total Record updated " + strconv.Itoa(count) + "\n")
		return nil
	})

	// })
	return nil
}

func Fmp_yielddetails(strjson []byte, buffer *bytes.Buffer) error {
	var arryJson []interface{}
	if err := json.Unmarshal(strjson, &arryJson); err != nil {
		buffer.WriteString(err.Error() + "\n")
		return err
	}
	var datamodelUpdate []accord.Fmp_yielddetails
	count := 0
	// q.Enqueue(arryJson, func(data interface{}) {
	db.Accord.Transaction(func(tx *gorm.DB) error {
		start := time.Now()
		for _, json := range arryJson {
			jsonmap := json.(map[string]interface{})
			datamodel := accord.Fmp_yielddetails{}
			datamodel.Schemecode = helper.GetIntfromMap(jsonmap, "schemecode")
			// err := tx.Where("schemecode=?", datamodel.Schemecode).First(&datamodel).Error
			// if err != nil {
			// 	Zerologs.Error().Msg("Record Not Found In Fmp_yielddetails" + err.Error())
			// }
			scode := strconv.Itoa(datamodel.Schemecode)
			datamodel.ID = scode
			datamodel.Maturitydate = helper.GetTimefromMap(jsonmap, "maturitydate")
			datamodel.Tenure_number = helper.GetFloatfromMap(jsonmap, "tenure_number")
			datamodel.Tenure_option = helper.GetStringfromMap(jsonmap, "tenure_option")
			datamodel.Net_inticative_yield1 = helper.GetFloatfromMap(jsonmap, "net_inticative_yield1")
			datamodel.Net_inticative_yield2 = helper.GetFloatfromMap(jsonmap, "net_inticative_yield2")
			datamodel.Post_taxyield_ind1 = helper.GetFloatfromMap(jsonmap, "post_taxyield_ind1")
			datamodel.Post_taxyield_ind2 = helper.GetFloatfromMap(jsonmap, "post_taxyield_ind2")
			datamodel.Post_taxyield_nonind1 = helper.GetFloatfromMap(jsonmap, "post_taxyield_nonind1")
			datamodel.Post_taxyield_nonind2 = helper.GetFloatfromMap(jsonmap, "post_taxyield_nonind2")
			datamodel.Exit_load = helper.GetStringfromMap(jsonmap, "exit_load")
			datamodel.Rollover = helper.GetStringfromMap(jsonmap, "rollover")
			datamodel.Maturitydate_after_rollover = helper.GetTimefromMap(jsonmap, "maturitydate_after_rollover")
			datamodel.Tenure_no_rollover = helper.GetFloatfromMap(jsonmap, "tenure_no_rollover")
			datamodel.Tenure_option_rollover = helper.GetStringfromMap(jsonmap, "tenure_option_rollover")
			datamodel.Flag = helper.GetStringfromMap(jsonmap, "flag")
			// err := tx.Where("schemecode=?", datamodel.Schemecode).First(&datamodel).Error
			// if err != nil {
			// 	err := tx.Create(&datamodel).Error
			// 	if err != nil {
			// 		buffer.WriteString(err.Error())
			// 	}
			// } else {
			// err = tx.Save(&datamodel).Error
			// if err != nil {
			// 	buffer.WriteString(err.Error())
			// }
			// }
			datamodelUpdate = append(datamodelUpdate, datamodel)
			count++

		}
		err := db.Accord.Clauses(clause.OnConflict{
			Columns:   []clause.Column{{Name: "id"}},
			DoUpdates: clause.AssignmentColumns([]string{"schemecode", "maturitydate", "tenure_number", "tenure_option", "net_inticative_yield1", "net_inticative_yield2", "post_taxyield_ind1", "post_taxyield_ind2", "post_taxyield_nonind1", "post_taxyield_nonind2", "exit_load", "rollover", "maturitydate_after_rollover", "tenure_no_rollover", "tenure_option_rollover", "flag"}),
			// DoUpdates: clause.AssignmentColumns([]string{"rating"}),
		}).CreateInBatches(&datamodelUpdate, 1000).Error
		if err != nil {
			fmt.Println(err)
			Zerologs.Error().Msg("Error while Inserting data into Fmp_yielddetails")
		}
		Zerologs.Info().Msgf(" execution time for Fmp_yielddetails ==>", time.Since(start))
		buffer.WriteString("Total Record updated " + strconv.Itoa(count) + "\n")
		return nil
	})

	// })
	return nil
}

func Fundmanager_mst(strjson []byte, buffer *bytes.Buffer) error {
	var arryJson []interface{}
	if err := json.Unmarshal(strjson, &arryJson); err != nil {
		buffer.WriteString(err.Error() + "\n")
		return err
	}
	var datamodelUpdate []accord.Fundmanager_mst
	count := 0
	// q.Enqueue(arryJson, func(data interface{}) {
	db.Accord.Transaction(func(tx *gorm.DB) error {
		start := time.Now()
		for _, json := range arryJson {
			jsonmap := json.(map[string]interface{})
			datamodel := accord.Fundmanager_mst{}
			// datamodel.Id = helper.GetIntfromMap(jsonmap, "id")
			datamodel.ID = helper.GetStringfromMap(jsonmap, "id")
			// err := tx.Where("id=?", datamodel.ID).First(&datamodel).Error
			// if err != nil {
			// 	Zerologs.Error().Msg("Record Not Found In Fundmanager_mst" + err.Error())
			// }

			datamodel.Initial = helper.GetStringfromMap(jsonmap, "initial")
			datamodel.Fundmanager = helper.GetStringfromMap(jsonmap, "fundmanager")
			datamodel.Qualification = helper.GetStringfromMap(jsonmap, "qualification")
			datamodel.Experience = helper.GetStringfromMap(jsonmap, "experience")
			datamodel.Basicdetails = helper.GetStringfromMap(jsonmap, "basicdetails")
			datamodel.Designation = helper.GetStringfromMap(jsonmap, "designation")
			datamodel.Age = helper.GetIntfromMap(jsonmap, "age")
			datamodel.Reporteddate = helper.GetTimefromMap(jsonmap, "reporteddate")
			datamodel.Flag = helper.GetStringfromMap(jsonmap, "flag")

			// err := tx.Where("id=?", datamodel.Id).First(&datamodel).Error
			// if err != nil {
			// 	err := tx.Create(&datamodel).Error
			// 	if err != nil {
			// 		buffer.WriteString(err.Error())
			// 	}
			// } else {
			// err = tx.Save(&datamodel).Error
			// if err != nil {
			// 	buffer.WriteString(err.Error())
			// }
			// }
			datamodelUpdate = append(datamodelUpdate, datamodel)
			count++

		}
		err := db.Accord.Clauses(clause.OnConflict{
			Columns:   []clause.Column{{Name: "id"}},
			DoUpdates: clause.AssignmentColumns([]string{"initial", "fundmanager", "qualification", "experience", "basicdetails", "designation", "age", "reporteddate", "flag"}),
			// DoUpdates: clause.AssignmentColumns([]string{"rating"}),
		}).CreateInBatches(&datamodelUpdate, 1000).Error
		if err != nil {
			fmt.Println(err)
			Zerologs.Error().Msg("Error while Inserting data into Fundmanager_mst")
		}
		Zerologs.Info().Msgf(" execution time for Fundmanager_mst ==>", time.Since(start))
		buffer.WriteString("Total Record updated " + strconv.Itoa(count) + "\n")
		return nil
	})

	// })
	return nil
}

func Fvchange(strjson []byte, buffer *bytes.Buffer) error {
	var arryJson []interface{}
	if err := json.Unmarshal(strjson, &arryJson); err != nil {
		buffer.WriteString(err.Error() + "\n")
		return err
	}
	var datamodelUpdate []accord.Fvchange
	count := 0
	// q.Enqueue(arryJson, func(data interface{}) {
	db.Accord.Transaction(func(tx *gorm.DB) error {
		start := time.Now()
		for _, json := range arryJson {
			jsonmap := json.(map[string]interface{})
			datamodel := accord.Fvchange{}
			datamodel.Schemecode = helper.GetIntfromMap(jsonmap, "schemecode")
			datamodel.Fvdate = helper.GetTimefromMap(jsonmap, "fvdate")
			// err := tx.Where("schemecode=? AND fvdate=?", datamodel.Schemecode, datamodel.Fvdate).First(&datamodel).Error
			// if err != nil {
			// 	Zerologs.Error().Msg("Record Not Found In Fvchange" + err.Error())
			// }
			scode := strconv.Itoa(datamodel.Schemecode)
			fvdate := datamodel.Fvdate.String()
			scode_fvdate := scode + "_" + fvdate
			datamodel.ID = scode_fvdate
			datamodel.Amc_code = helper.GetIntfromMap(jsonmap, "amc_code")

			datamodel.Scheme_name = helper.GetStringfromMap(jsonmap, "scheme_name")
			datamodel.Fvbefore = helper.GetFloatfromMap(jsonmap, "fvbefore")
			datamodel.Fvafter = helper.GetFloatfromMap(jsonmap, "fvafter")

			datamodel.Flag = helper.GetStringfromMap(jsonmap, "flag")

			// err := tx.Where("schemecode=? AND fvdate=?", datamodel.Schemecode, datamodel.Fvdate).First(&datamodel).Error
			// if err != nil {
			// 	err := tx.Create(&datamodel).Error
			// 	if err != nil {
			// 		buffer.WriteString(err.Error())
			// 	}
			// } else {
			// err = tx.Save(&datamodel).Error
			// if err != nil {
			// 	buffer.WriteString(err.Error())
			// }
			// }
			datamodelUpdate = append(datamodelUpdate, datamodel)
			count++

		}
		err := db.Accord.Clauses(clause.OnConflict{
			Columns:   []clause.Column{{Name: "id"}},
			DoUpdates: clause.AssignmentColumns([]string{"amc_code", "schemecode", "scheme_name", "fvbefore", "fvafter", "fvdate", "flag"}),
			// DoUpdates: clause.AssignmentColumns([]string{"rating"}),
		}).CreateInBatches(&datamodelUpdate, 1000).Error
		if err != nil {
			fmt.Println(err)
			Zerologs.Error().Msg("Error while Inserting data into Fvchange")
		}
		Zerologs.Info().Msgf(" execution time for Fvchange ==>", time.Since(start))
		buffer.WriteString("Total Record updated " + strconv.Itoa(count) + "\n")
		return nil
	})

	// })
	return nil
}

func Index_mst(strjson []byte, buffer *bytes.Buffer) error {
	var arryJson []interface{}
	if err := json.Unmarshal(strjson, &arryJson); err != nil {
		buffer.WriteString(err.Error() + "\n")
		return err
	}
	var datamodelUpdate []accord.Index_mst
	count := 0
	// q.Enqueue(arryJson, func(data interface{}) {
	db.Accord.Transaction(func(tx *gorm.DB) error {
		start := time.Now()
		for _, json := range arryJson {
			jsonmap := json.(map[string]interface{})
			datamodel := accord.Index_mst{}
			datamodel.Indexcode = helper.GetIntfromMap(jsonmap, "indexcode")
			// err := tx.Where("indexcode=?", datamodel.Indexcode).First(&datamodel).Error
			// if err != nil {
			// 	Zerologs.Error().Msg("Record Not Found In Index_mst" + err.Error())
			// }
			icode := strconv.Itoa(datamodel.Indexcode)
			datamodel.ID = icode
			datamodel.Fincode = helper.GetIntfromMap(jsonmap, "fincode")
			datamodel.Scripcode = helper.GetIntfromMap(jsonmap, "scripcode")
			datamodel.Indexname = helper.GetStringfromMap(jsonmap, "indexname")
			datamodel.Index_gp = helper.GetStringfromMap(jsonmap, "index_gp")
			datamodel.Subgroup = helper.GetStringfromMap(jsonmap, "subgroup")
			datamodel.Flag = helper.GetStringfromMap(jsonmap, "flag")

			// err := tx.Where("indexcode=?", datamodel.Indexcode).First(&datamodel).Error
			// if err != nil {
			// 	err := tx.Create(&datamodel).Error
			// 	if err != nil {
			// 		buffer.WriteString(err.Error())
			// 	}
			// } else {
			// err = tx.Save(&datamodel).Error
			// if err != nil {
			// 	buffer.WriteString(err.Error())
			// }
			// }
			datamodelUpdate = append(datamodelUpdate, datamodel)
			count++

		}
		err := db.Accord.Clauses(clause.OnConflict{
			Columns:   []clause.Column{{Name: "id"}},
			DoUpdates: clause.AssignmentColumns([]string{"indexcode", "fincode", "scripcode", "indexname", "index_gp", "subgroup", "flag"}),
			// DoUpdates: clause.AssignmentColumns([]string{"rating"}),
		}).CreateInBatches(&datamodelUpdate, 1000).Error
		if err != nil {
			fmt.Println(err)
			Zerologs.Error().Msg("Error while Inserting data into Index_mst")
		}
		Zerologs.Info().Msgf(" execution time for Index_mst ==>", time.Since(start))
		buffer.WriteString("Total Record updated " + strconv.Itoa(count) + "\n")
		return nil
	})

	// })
	return nil
}

func Industry_mst(strjson []byte, buffer *bytes.Buffer) error {
	var arryJson []interface{}
	if err := json.Unmarshal(strjson, &arryJson); err != nil {
		buffer.WriteString(err.Error() + "\n")
		return err
	}
	var datamodelUpdate []accord.Industry_mst
	count := 0
	// q.Enqueue(arryJson, func(data interface{}) {
	db.Accord.Transaction(func(tx *gorm.DB) error {
		start := time.Now()
		for _, json := range arryJson {
			jsonmap := json.(map[string]interface{})
			datamodel := accord.Industry_mst{}
			datamodel.Ind_code = helper.GetIntfromMap(jsonmap, "Ind_code")
			// err := tx.Where("ind_code=?", datamodel.Ind_code).First(&datamodel).Error
			// if err != nil {
			// 	Zerologs.Error().Msg("Record Not Found In Industry_mst" + err.Error())
			// }
			icode := strconv.Itoa(datamodel.Ind_code)
			datamodel.ID = icode
			datamodel.Industry = helper.GetStringfromMap(jsonmap, "Industry")
			datamodel.Ind_shortname = helper.GetStringfromMap(jsonmap, "Ind_shortname")
			datamodel.Sector = helper.GetStringfromMap(jsonmap, "Sector")
			datamodel.Sector_code = helper.GetIntfromMap(jsonmap, "Sector_code")
			datamodel.Flag = helper.GetStringfromMap(jsonmap, "Flag")

			// err := tx.Where("ind_code=?", datamodel.Ind_code).First(&datamodel).Error
			// if err != nil {
			// 	err := tx.Create(&datamodel).Error
			// 	if err != nil {
			// 		buffer.WriteString(err.Error())
			// 	}
			// } else {
			// err = tx.Save(&datamodel).Error
			// if err != nil {
			// 	buffer.WriteString(err.Error())
			// }
			// }
			datamodelUpdate = append(datamodelUpdate, datamodel)
			count++

		}
		err := db.Accord.Clauses(clause.OnConflict{
			Columns:   []clause.Column{{Name: "id"}},
			DoUpdates: clause.AssignmentColumns([]string{"ind_code", "industry", "ind_shortname", "sector", "sector_code", "flag"}),
			// DoUpdates: clause.AssignmentColumns([]string{"rating"}),
		}).CreateInBatches(&datamodelUpdate, 1000).Error
		if err != nil {
			fmt.Println(err)
			Zerologs.Error().Msg("Error while Inserting data into Industry_mst")
		}
		Zerologs.Info().Msgf(" execution time for Industry_mst ==>", time.Since(start))
		buffer.WriteString("Total Record updated " + strconv.Itoa(count) + "\n")
		return nil
	})

	// })
	return nil
}

func Loadtype_mst(strjson []byte, buffer *bytes.Buffer) error {
	var arryJson []interface{}
	if err := json.Unmarshal(strjson, &arryJson); err != nil {
		buffer.WriteString(err.Error() + "\n")
		return err
	}
	var datamodelUpdate []accord.Loadtype_mst
	count := 0
	// q.Enqueue(arryJson, func(data interface{}) {
	db.Accord.Transaction(func(tx *gorm.DB) error {
		start := time.Now()
		for _, json := range arryJson {
			jsonmap := json.(map[string]interface{})
			datamodel := accord.Loadtype_mst{}
			datamodel.Ltypecode = helper.GetIntfromMap(jsonmap, "ltypecode")
			// err := tx.Where("ltypecode=?", datamodel.Ltypecode).First(&datamodel).Error
			// if err != nil {
			// 	Zerologs.Error().Msg("Record Not Found In Loadtype_mst" + err.Error())
			// }
			ltypecode := strconv.Itoa(datamodel.Ltypecode)
			datamodel.ID = ltypecode
			datamodel.Load = helper.GetStringfromMap(jsonmap, "load")
			datamodel.Flag = helper.GetStringfromMap(jsonmap, "flag")

			// err := tx.Where("ltypecode=?", datamodel.Ltypecode).First(&datamodel).Error
			// if err != nil {
			// 	err := tx.Create(&datamodel).Error
			// 	if err != nil {
			// 		buffer.WriteString(err.Error())
			// 	}
			// } else {
			// err = tx.Save(&datamodel).Error
			// if err != nil {
			// 	buffer.WriteString(err.Error())
			// }
			// }
			datamodelUpdate = append(datamodelUpdate, datamodel)
			count++

		}
		err := db.Accord.Clauses(clause.OnConflict{
			Columns:   []clause.Column{{Name: "id"}},
			DoUpdates: clause.AssignmentColumns([]string{"ltypecode", "load", "flag"}),
			// DoUpdates: clause.AssignmentColumns([]string{"rating"}),
		}).CreateInBatches(&datamodelUpdate, 1000).Error
		if err != nil {
			fmt.Println(err)
			Zerologs.Error().Msg("Error while Inserting data into Loadtype_mst")
		}
		Zerologs.Info().Msgf(" execution time for Loadtype_mst ==>", time.Since(start))
		buffer.WriteString("Total Record updated " + strconv.Itoa(count) + "\n")
		return nil
	})

	// })
	return nil
}

func Mergedschemes(strjson []byte, buffer *bytes.Buffer) error {
	var arryJson []interface{}
	if err := json.Unmarshal(strjson, &arryJson); err != nil {
		buffer.WriteString(err.Error() + "\n")
		return err
	}
	var datamodelUpdate []accord.Mergedschemes
	count := 0
	// q.Enqueue(arryJson, func(data interface{}) {
	db.Accord.Transaction(func(tx *gorm.DB) error {
		start := time.Now()
		for _, json := range arryJson {
			jsonmap := json.(map[string]interface{})
			datamodel := accord.Mergedschemes{}
			datamodel.Schemecode = helper.GetIntfromMap(jsonmap, "schemecode")
			datamodel.Mergedwith = helper.GetIntfromMap(jsonmap, "mergedwith")
			// err := tx.Where("schemecode=? AND mergedwith=?", datamodel.Schemecode, datamodel.Mergedwith).First(&datamodel).Error
			// if err != nil {
			// 	Zerologs.Error().Msg("Record Not Found In Mergedschemes" + err.Error())
			// }
			scode := strconv.Itoa(datamodel.Schemecode)
			mwith := strconv.Itoa(datamodel.Mergedwith)
			scode_mwith := scode + "_" + mwith
			datamodel.ID = scode_mwith
			datamodel.EFFECT_DATE = helper.GetTimefromMap(jsonmap, "EFFECT_DATE")
			datamodel.Flag = helper.GetStringfromMap(jsonmap, "flag")

			// err := tx.Where("schemecode=? AND mergedwith=?", datamodel.Schemecode, datamodel.Mergedwith).First(&datamodel).Error
			// if err != nil {
			// 	err := tx.Create(&datamodel).Error
			// 	if err != nil {
			// 		buffer.WriteString(err.Error())
			// 	}
			// } else {
			// err = tx.Save(&datamodel).Error
			// if err != nil {
			// 	buffer.WriteString(err.Error())
			// }
			// }
			datamodelUpdate = append(datamodelUpdate, datamodel)
			count++

		}
		err := db.Accord.Clauses(clause.OnConflict{
			Columns:   []clause.Column{{Name: "id"}},
			DoUpdates: clause.AssignmentColumns([]string{"schemecode", "mergedwith", "effect_date", "flag"}),
			// DoUpdates: clause.AssignmentColumns([]string{"rating"}),
		}).CreateInBatches(&datamodelUpdate, 1000).Error
		if err != nil {
			fmt.Println(err)
			Zerologs.Error().Msg("Error while Inserting data into Mergedschemes")
		}
		Zerologs.Info().Msgf(" execution time for Mergedschemes ==>", time.Since(start))
		buffer.WriteString("Total Record updated " + strconv.Itoa(count) + "\n")
		return nil
	})

	// })
	return nil
}

func Mf_abs_return(strjson []byte, buffer *bytes.Buffer) error {
	var arryJson []interface{}
	if err := json.Unmarshal(strjson, &arryJson); err != nil {
		buffer.WriteString(err.Error() + "\n")
		return err
	}
	var datamodelUpdate []accord.Mf_abs_return
	count := 0
	// q.Enqueue(arryJson, func(data interface{}) {
	db.Accord.Transaction(func(tx *gorm.DB) error {
		start := time.Now()
		for _, json := range arryJson {
			jsonmap := json.(map[string]interface{})
			datamodel := accord.Mf_abs_return{}
			datamodel.Schemecode = helper.GetFloatfromMap(jsonmap, "schemecode")
			// err := tx.Where("schemecode=?", datamodel.Schemecode).First(&datamodel).Error
			// if err != nil {

			// 	Zerologs.Error().Msg("Record Not Found In Mf_abs_return" + err.Error())
			// }
			scode := fmt.Sprintf("%v", datamodel.Schemecode)
			datamodel.ID = scode
			datamodel.C_date = helper.GetTimefromMap(jsonmap, "c_date")
			datamodel.P_date = helper.GetTimefromMap(jsonmap, "p_date")
			datamodel.C_nav = helper.GetFloatfromMap(jsonmap, "c_nav")
			datamodel.P_nav = helper.GetFloatfromMap(jsonmap, "p_nav")
			datamodel.Dayret1 = helper.GetFloatfromMap(jsonmap, "1dayret")
			datamodel.Weekdate1 = helper.GetTimefromMap(jsonmap, "1weekdate")
			datamodel.Weeknav1 = helper.GetFloatfromMap(jsonmap, "1weeknav")
			datamodel.Weekret1 = helper.GetFloatfromMap(jsonmap, "1weekret")
			datamodel.Mthdate1 = helper.GetTimefromMap(jsonmap, "1mthdate")
			datamodel.Mthnav1 = helper.GetFloatfromMap(jsonmap, "1mthnav")
			datamodel.Monthret1 = helper.GetFloatfromMap(jsonmap, "1monthret")
			datamodel.Mthdate3 = helper.GetTimefromMap(jsonmap, "3mthdate")
			datamodel.Mthnav3 = helper.GetFloatfromMap(jsonmap, "3mthnav")
			datamodel.Monthret3 = helper.GetFloatfromMap(jsonmap, "3monthret")
			datamodel.Mntdate6 = helper.GetTimefromMap(jsonmap, "6mntdate")
			datamodel.Mnthnav6 = helper.GetFloatfromMap(jsonmap, "6mnthnav")
			datamodel.Monthret6 = helper.GetFloatfromMap(jsonmap, "6monthret")
			datamodel.Mnthdate9 = helper.GetTimefromMap(jsonmap, "9mnthdate")
			datamodel.Mnthnav9 = helper.GetFloatfromMap(jsonmap, "9mnthnav")
			datamodel.Mnthret9 = helper.GetFloatfromMap(jsonmap, "9mnthret")
			datamodel.Yrdate1 = helper.GetTimefromMap(jsonmap, "1yrdate")
			datamodel.Yrnav1 = helper.GetFloatfromMap(jsonmap, "1yrnav")
			datamodel.Yrret1 = helper.GetFloatfromMap(jsonmap, "1yrret")
			datamodel.Yrdate2 = helper.GetTimefromMap(jsonmap, "2yrdate")
			datamodel.Yrnav2 = helper.GetFloatfromMap(jsonmap, "2yrnav")
			datamodel.Yearret2 = helper.GetFloatfromMap(jsonmap, "2yearret")
			datamodel.Yrdate3 = helper.GetTimefromMap(jsonmap, "3yrdate")
			datamodel.Yrnav3 = helper.GetFloatfromMap(jsonmap, "3yrnav")
			datamodel.Yearret3 = helper.GetFloatfromMap(jsonmap, "3yearret")
			datamodel.Yrdate4 = helper.GetTimefromMap(jsonmap, "4yrdate")
			datamodel.Yrnav4 = helper.GetFloatfromMap(jsonmap, "4yrnav")
			datamodel.Yearret4 = helper.GetFloatfromMap(jsonmap, "4yearret")
			datamodel.Yrdate5 = helper.GetTimefromMap(jsonmap, "5yrdate")
			datamodel.Yrnav5 = helper.GetFloatfromMap(jsonmap, "5yrnav")
			datamodel.Yearret5 = helper.GetFloatfromMap(jsonmap, "5yearret")
			datamodel.Incdate = helper.GetTimefromMap(jsonmap, "incdate")
			datamodel.Incnav = helper.GetFloatfromMap(jsonmap, "incnav")
			datamodel.Incret = helper.GetFloatfromMap(jsonmap, "incret")
			datamodel.Flag = helper.GetStringfromMap(jsonmap, "flag")

			// err := tx.Where("schemecode=? ", datamodel.Schemecode).First(&datamodel).Error
			// if err != nil {
			// 	err := tx.Create(&datamodel).Error
			// 	if err != nil {
			// 		buffer.WriteString(err.Error())
			// 	}
			// } else {
			// err = tx.Save(&datamodel).Error
			// if err != nil {
			// 	buffer.WriteString(err.Error())
			// }
			// }
			datamodelUpdate = append(datamodelUpdate, datamodel)
			count++

		}
		err := db.Accord.Clauses(clause.OnConflict{
			Columns:   []clause.Column{{Name: "id"}},
			DoUpdates: clause.AssignmentColumns([]string{"schemecode", "c_date", "p_date", "c_nav", "p_nav", "dayret1", "weekdate1", "weeknav1", "weekret1", "mthdate1", "mthnav1", "monthret1", "mthdate3", "mthnav3", "monthret3", "mntdate6", "mnthnav6", "monthret6", "mnthdate9", "mnthnav9", "mnthret9", "yrdate1", "yrnav1", "yrret1", "yrdate2", "yrnav2", "yearret2", "yrdate3", "yrnav3", "yearret3", "yrdate4", "yrnav4", "yearret4", "yrdate5", "yrnav5", "yearret5", "incdate", "incnav", "incret", "flag"}),
			// DoUpdates: clause.AssignmentColumns([]string{"rating"}),
		}).CreateInBatches(&datamodelUpdate, 1000).Error
		if err != nil {
			fmt.Println(err)
			Zerologs.Error().Msg("Error while Inserting data into Mf_abs_return")
		}
		Zerologs.Info().Msgf(" execution time for Mf_abs_return ==>", time.Since(start))
		buffer.WriteString("Total Record updated " + strconv.Itoa(count) + "\n")
		return nil
	})

	// })
	return nil
}

func Mf_ans_return(strjson []byte, buffer *bytes.Buffer) error {
	var arryJson []interface{}
	if err := json.Unmarshal(strjson, &arryJson); err != nil {
		buffer.WriteString(err.Error() + "\n")
		return err
	}
	var datamodelUpdate []accord.Mf_ans_return
	count := 0
	// q.Enqueue(arryJson, func(data interface{}) {
	db.Accord.Transaction(func(tx *gorm.DB) error {
		start := time.Now()
		for _, json := range arryJson {
			jsonmap := json.(map[string]interface{})
			datamodel := accord.Mf_ans_return{}
			datamodel.Schemecode = helper.GetFloatfromMap(jsonmap, "schemecode")
			// err := tx.Where("schemecode=? ", datamodel.Schemecode).First(&datamodel).Error
			// if err != nil {
			// 	Zerologs.Error().Msg("Record Not Found In Mf_ans_return" + err.Error())
			// }
			schemecode := fmt.Sprintf("%v", datamodel.Schemecode)
			datamodel.ID = schemecode
			datamodel.C_date = helper.GetTimefromMap(jsonmap, "c_date")
			datamodel.P_date = helper.GetTimefromMap(jsonmap, "p_date")
			datamodel.C_nav = helper.GetFloatfromMap(jsonmap, "c_nav")
			datamodel.P_nav = helper.GetFloatfromMap(jsonmap, "p_nav")
			datamodel.Dayret1 = helper.GetFloatfromMap(jsonmap, "1dayret")
			datamodel.Weekdate1 = helper.GetTimefromMap(jsonmap, "1weekdate")
			datamodel.Weeknav1 = helper.GetFloatfromMap(jsonmap, "1weeknav")
			datamodel.Weekret1 = helper.GetFloatfromMap(jsonmap, "1weekret")
			datamodel.Mthdate1 = helper.GetTimefromMap(jsonmap, "1mthdate")
			datamodel.Mthnav1 = helper.GetFloatfromMap(jsonmap, "1mthnav")
			datamodel.Monthret1 = helper.GetFloatfromMap(jsonmap, "1monthret")
			datamodel.Mthdate3 = helper.GetTimefromMap(jsonmap, "3mthdate")
			datamodel.Mthnav3 = helper.GetFloatfromMap(jsonmap, "3mthnav")
			datamodel.Monthret3 = helper.GetFloatfromMap(jsonmap, "3monthret")
			datamodel.Mntdate6 = helper.GetTimefromMap(jsonmap, "6mntdate")
			datamodel.Mnthnav6 = helper.GetFloatfromMap(jsonmap, "6mnthnav")
			datamodel.Monthret6 = helper.GetFloatfromMap(jsonmap, "6monthret")
			datamodel.Mnthdate9 = helper.GetTimefromMap(jsonmap, "9mnthdate")
			datamodel.Mnthnav9 = helper.GetFloatfromMap(jsonmap, "9mnthnav")
			datamodel.Mnthret9 = helper.GetFloatfromMap(jsonmap, "9mnthret")
			datamodel.Yrdate1 = helper.GetTimefromMap(jsonmap, "1yrdate")
			datamodel.Yrnav1 = helper.GetFloatfromMap(jsonmap, "1yrnav")
			datamodel.Yrret1 = helper.GetFloatfromMap(jsonmap, "1yrret")
			datamodel.Yrdate2 = helper.GetTimefromMap(jsonmap, "2yrdate")
			datamodel.Yrnav2 = helper.GetFloatfromMap(jsonmap, "2yrnav")
			datamodel.Yearret2 = helper.GetFloatfromMap(jsonmap, "2yearret")
			datamodel.Yrdate3 = helper.GetTimefromMap(jsonmap, "3yrdate")
			datamodel.Yrnav3 = helper.GetFloatfromMap(jsonmap, "3yrnav")
			datamodel.Yearret3 = helper.GetFloatfromMap(jsonmap, "3yearret")
			datamodel.Yrdate4 = helper.GetTimefromMap(jsonmap, "4yrdate")
			datamodel.Yrnav4 = helper.GetFloatfromMap(jsonmap, "4yrnav")
			datamodel.Yearret4 = helper.GetFloatfromMap(jsonmap, "4yearret")
			datamodel.Yrdate5 = helper.GetTimefromMap(jsonmap, "5yrdate")
			datamodel.Yrnav5 = helper.GetFloatfromMap(jsonmap, "5yrnav")
			datamodel.Yearret5 = helper.GetFloatfromMap(jsonmap, "5yearret")
			datamodel.Incdate = helper.GetTimefromMap(jsonmap, "incdate")
			datamodel.Incnav = helper.GetFloatfromMap(jsonmap, "incnav")
			datamodel.Incret = helper.GetFloatfromMap(jsonmap, "incret")
			datamodel.Flag = helper.GetStringfromMap(jsonmap, "flag")

			// err := tx.Where("schemecode=? ", datamodel.Schemecode).First(&datamodel).Error
			// if err != nil {
			// 	err := tx.Create(&datamodel).Error
			// 	if err != nil {
			// 		buffer.WriteString(err.Error())
			// 	}
			// } else {
			// err = tx.Save(&datamodel).Error
			// if err != nil {
			// 	buffer.WriteString(err.Error())
			// }
			// }
			datamodelUpdate = append(datamodelUpdate, datamodel)
			count++

		}
		err := db.Accord.Clauses(clause.OnConflict{
			Columns:   []clause.Column{{Name: "id"}}, //, {Name: "invdate"}, {Name: "srno"}},
			DoUpdates: clause.AssignmentColumns([]string{"schemecode", "c_date", "p_date", "c_nav", "p_nav", "dayret1", "weekdate1", "weeknav1", "weekret1", "mthdate1", "mthnav1", "monthret1", "mthdate3", "mthnav3", "monthret3", "mntdate6", "mnthnav6", "monthret6", "mnthdate9", "mnthnav9", "mnthret9", "yrdate1", "yrnav1", "yrret1", "yrdate2", "yrnav2", "yearret2", "yrdate3", "yrnav3", "yearret3", "yrdate4", "yrnav4", "yearret4", "yrdate5", "yrnav5", "yearret5", "incdate", "incnav", "incret", "flag"}),
			//DoUpdates: clause.AssignmentColumns([]string{"rating"}),
		}).CreateInBatches(&datamodelUpdate, 1000).Error
		if err != nil {
			fmt.Println(err)
			Zerologs.Error().Msg("Error while Inserting data into Mf_ans_return")
		}

		Zerologs.Info().Msgf(" execution time for Mf_ans_return ==>", time.Since(start))
		buffer.WriteString("Total Record updated " + strconv.Itoa(count) + "\n")
		return nil
	})

	// })
	return nil
}

// func Mf_portfolio(strjson []byte, buffer *bytes.Buffer) error {
// 	var arryJson []interface{}
// 	if err := json.Unmarshal(strjson, &arryJson); err != nil {
// 		buffer.WriteString(err.Error() + "\n")
// 		return err
// 	}
// 	count := 0
// q.Enqueue(arryJson, func(data interface{}) {
// 	db.Accord.Transaction(func(tx *gorm.DB) error {
// 		start := time.Now()

// 		for _, json := range arryJson {
// 			jsonmap := json.(map[string]interface{})
// 			datamodel := accord.Mf_portfolio{}
// 			datamodel.Schemecode = helper.GetIntfromMap(jsonmap, "schemecode")
// 			datamodel.Invdate = helper.GetTimefromMap(jsonmap, "invdate")
// 			datamodel.Srno = helper.GetIntfromMap(jsonmap, "srno")
// 			err := tx.Where("schemecode=? AND invdate=? AND srno=?", datamodel.Schemecode, datamodel.Invdate, datamodel.Srno).First(&datamodel).Error
// 			if err != nil {
// 				Zerologs.Error().Msg("Record Not Found In Mf_portfolio" + err.Error())
// 			}
// 			datamodel.Invenddate = helper.GetTimefromMap(jsonmap, "invenddate")
// 			datamodel.Fincode = helper.GetIntfromMap(jsonmap, "fincode")
// 			datamodel.ASECT_CODE = helper.GetIntfromMap(jsonmap, "ASECT_CODE")
// 			datamodel.Sect_code = helper.GetIntfromMap(jsonmap, "sect_code")
// 			datamodel.Noshares = helper.GetFloatfromMap(jsonmap, "noshares")
// 			datamodel.Mktval = helper.GetFloatfromMap(jsonmap, "mktval")
// 			datamodel.Aum = helper.GetFloatfromMap(jsonmap, "aum")
// 			datamodel.Holdpercentage = helper.GetFloatfromMap(jsonmap, "holdpercentage")
// 			datamodel.Compname = helper.GetStringfromMap(jsonmap, "compname")
// 			datamodel.Sect_name = helper.GetStringfromMap(jsonmap, "sect_name")
// 			datamodel.Asect_name = helper.GetStringfromMap(jsonmap, "asect_name")
// 			datamodel.Rating = helper.GetStringfromMap(jsonmap, "rating")
// 			datamodel.Flag = helper.GetStringfromMap(jsonmap, "flag")
// 			// err := tx.Where("schemecode=? AND invdate=? AND srno=?", datamodel.Schemecode, datamodel.Invdate, datamodel.Srno).First(&datamodel).Error
// 			// if err != nil {
// 			// 	err := tx.Create(&datamodel).Error
// 			// 	if err != nil {
// 			// 		buffer.WriteString(err.Error())
// 			// 	}
// 			// } else {
// 			err = tx.Save(&datamodel).Error
// 			if err != nil {
// 				buffer.WriteString(err.Error())
// 			}
// 			// }
// 			count++

// 		}
// 		fmt.Println(time.Since(start))
// 		Zerologs.Info().Msgf(" execution time ==>", time.Since(start))
// 		return nil
// 	})
// 	buffer.WriteString("Total Record updated " + strconv.Itoa(count) + "\n")
// })
// 	return nil
// }

func Mf_portfolio(strjson []byte, buffer *bytes.Buffer) error {
	var arryJson []interface{}
	if err := json.Unmarshal(strjson, &arryJson); err != nil {
		buffer.WriteString(err.Error() + "\n")
		return err
	}

	var datamodelUpdate []accord.Mf_portfolio
	count := 0
	// q.Enqueue(arryJson, func(data interface{}) {

	db.Accord.Transaction(func(tx *gorm.DB) error {
		start := time.Now()

		for _, json := range arryJson {
			jsonmap := json.(map[string]interface{})
			datamodel := accord.Mf_portfolio{}
			datamodel.Schemecode = helper.GetIntfromMap(jsonmap, "schemecode")
			datamodel.Invdate = helper.GetTimefromMap(jsonmap, "invdate")
			datamodel.Srno = helper.GetIntfromMap(jsonmap, "srno")
			datamodel.Invenddate = helper.GetTimefromMap(jsonmap, "invenddate")
			datamodel.Fincode = helper.GetIntfromMap(jsonmap, "fincode")
			datamodel.ASECT_CODE = helper.GetIntfromMap(jsonmap, "ASECT_CODE")
			datamodel.Sect_code = helper.GetIntfromMap(jsonmap, "sect_code")
			datamodel.Noshares = helper.GetFloatfromMap(jsonmap, "noshares")
			datamodel.Mktval = helper.GetFloatfromMap(jsonmap, "mktval")
			datamodel.Aum = helper.GetFloatfromMap(jsonmap, "aum")
			datamodel.Holdpercentage = helper.GetFloatfromMap(jsonmap, "holdpercentage")
			datamodel.Compname = helper.GetStringfromMap(jsonmap, "compname")
			datamodel.Sect_name = helper.GetStringfromMap(jsonmap, "sect_name")
			datamodel.Asect_name = helper.GetStringfromMap(jsonmap, "asect_name")
			datamodel.Rating = helper.GetStringfromMap(jsonmap, "rating")
			datamodel.Flag = helper.GetStringfromMap(jsonmap, "flag")
			scode := strconv.Itoa(datamodel.Schemecode)
			idate := datamodel.Invdate.String()
			sr_no := strconv.Itoa(datamodel.Srno)
			datamodel.ID = scode + "_" + sr_no + "_" + idate
			datamodelUpdate = append(datamodelUpdate, datamodel)
			count++

		}

		err := db.Accord.Clauses(clause.OnConflict{
			Columns:   []clause.Column{{Name: "id"}}, //, {Name: "invdate"}, {Name: "srno"}},
			DoUpdates: clause.AssignmentColumns([]string{"schemecode", "invdate", "srno", "invenddate", "fincode", "sect_code", "noshares", "mktval", "aum", "holdpercentage", "compname", "sect_name", "asect_name", "rating", "flag", "asect_code"}),
			// DoUpdates: clause.AssignmentColumns([]string{"rating"}),
		}).CreateInBatches(&datamodelUpdate, 1000).Error
		if err != nil {
			fmt.Println(err)
			Zerologs.Error().Msg("Error while Inserting data into mf_portfolios")
		}
		// fmt.Println("updatemodel count", len(datamodelUpdate))
		// fmt.Println("execution time  for creating model update or insert==>", time.Since(start))
		// fmt.Println("execution time  for update==>", time.Since(start))
		// fmt.Println("execution time  for insert==>", time.Since(start))
		Zerologs.Info().Msgf(" execution time for mf_portfolios ==>", time.Since(start))
		fmt.Println("mf portpolios count=>", strconv.Itoa(count))
		buffer.WriteString("Total Record updated " + strconv.Itoa(count) + "\n")
		return nil
	})

	// })
	return nil
}

func Mf_ratio(strjson []byte, buffer *bytes.Buffer) error {
	var arryJson []interface{}
	if err := json.Unmarshal(strjson, &arryJson); err != nil {
		buffer.WriteString(err.Error() + "\n")
		return err
	}
	var datamodelUpdate []accord.Mf_ratio
	count := 0
	// q.Enqueue(arryJson, func(data interface{}) {
	db.Accord.Transaction(func(tx *gorm.DB) error {
		start := time.Now()
		for _, json := range arryJson {
			jsonmap := json.(map[string]interface{})
			datamodel := accord.Mf_ratio{}
			datamodel.Schemecode = helper.GetIntfromMap(jsonmap, "schemecode")
			// err := tx.Where("schemecode=?", datamodel.Schemecode).First(&datamodel).Error
			// if err != nil {
			// 	Zerologs.Error().Msg("Record Not Found In Mf_ratio" + err.Error())
			// }
			schemecode := strconv.Itoa(datamodel.Schemecode)
			datamodel.ID = schemecode
			datamodel.Upddate = helper.GetTimefromMap(jsonmap, "upddate")
			datamodel.Datefrom = helper.GetTimefromMap(jsonmap, "datefrom")
			datamodel.Dateto = helper.GetTimefromMap(jsonmap, "dateto")
			datamodel.Avg_x = helper.GetFloatfromMap(jsonmap, "avg_x")
			datamodel.Avg_y = helper.GetFloatfromMap(jsonmap, "avg_y")
			datamodel.Sd_x = helper.GetFloatfromMap(jsonmap, "sd_x")
			datamodel.Sd_y = helper.GetFloatfromMap(jsonmap, "sd_y")
			datamodel.Semisd_x = helper.GetFloatfromMap(jsonmap, "semisd_x")
			datamodel.Semisd_y = helper.GetFloatfromMap(jsonmap, "semisd_y")
			datamodel.Beta_x = helper.GetFloatfromMap(jsonmap, "beta_x")
			datamodel.Beta_y = helper.GetFloatfromMap(jsonmap, "beta_y")
			datamodel.Corelation_x = helper.GetFloatfromMap(jsonmap, "corelation_x")
			datamodel.Corelation_y = helper.GetFloatfromMap(jsonmap, "corelation_y")
			datamodel.Betacor_x = helper.GetFloatfromMap(jsonmap, "betacor_x")
			datamodel.Betacor_y = helper.GetFloatfromMap(jsonmap, "betacor_y")
			datamodel.Treynor_x = helper.GetFloatfromMap(jsonmap, "treynor_x")
			datamodel.Treynor_y = helper.GetFloatfromMap(jsonmap, "treynor_y")
			datamodel.Fama_x = helper.GetFloatfromMap(jsonmap, "fama_x")
			datamodel.Fama_y = helper.GetFloatfromMap(jsonmap, "fama_y")
			datamodel.Sharpe_x = helper.GetFloatfromMap(jsonmap, "sharpe_x")
			datamodel.Sharpe_y = helper.GetFloatfromMap(jsonmap, "sharpe_y")
			datamodel.Jalpha_x = helper.GetFloatfromMap(jsonmap, "jalpha_x")
			datamodel.Jalpha_y = helper.GetFloatfromMap(jsonmap, "jalpha_y")
			datamodel.Sortino_x = helper.GetFloatfromMap(jsonmap, "sortino_x")
			datamodel.Sortino_y = helper.GetFloatfromMap(jsonmap, "sortino_y")
			datamodel.Flag = helper.GetStringfromMap(jsonmap, "flag")
			// err := tx.Where("schemecode=?", datamodel.Schemecode).First(&datamodel).Error
			// if err != nil {
			// 	err := tx.Create(&datamodel).Error
			// 	if err != nil {
			// 		buffer.WriteString(err.Error())
			// 	}
			// } else {
			// err = tx.Save(&datamodel).Error
			// if err != nil {
			// 	buffer.WriteString(err.Error())
			// }
			datamodelUpdate = append(datamodelUpdate, datamodel)
			// }

			count++

		}
		err := db.Accord.Clauses(clause.OnConflict{
			Columns:   []clause.Column{{Name: "id"}}, //, {Name: "invdate"}, {Name: "srno"}},
			DoUpdates: clause.AssignmentColumns([]string{"schemecode", "upddate", "datefrom", "dateto", "avg_x", "avg_y", "sd_x", "sd_y", "semisd_x", "semisd_y", "beta_x", "beta_y", "corelation_x", "corelation_y", "betacor_x", "betacor_y", "treynor_x", "treynor_y", "fama_x", "fama_y", "sharpe_x", "sharpe_y", "jalpha_x", "jalpha_y", "sortino_x", "sortino_y", "flag"}),
			// DoUpdates: clause.AssignmentColumns([]string{"rating"}),
		}).CreateInBatches(&datamodelUpdate, 1000).Error
		if err != nil {
			fmt.Println(err)
			Zerologs.Error().Msg("Error while Inserting data into Mf_ratio")
		}
		Zerologs.Info().Msgf(" execution time for MF_ratio ==>", time.Since(start))
		buffer.WriteString("Total Record updated " + strconv.Itoa(count) + "\n")
		return nil
	})

	// })
	return nil
}

func Mf_sip(strjson []byte, buffer *bytes.Buffer) error {
	var arryJson []interface{}
	if err := json.Unmarshal(strjson, &arryJson); err != nil {
		buffer.WriteString(err.Error() + "\n")
		return err
	}
	var datamodelUpdate []accord.Mf_sip
	count := 0
	// q.Enqueue(arryJson, func(data interface{}) {
	db.Accord.Transaction(func(tx *gorm.DB) error {
		start := time.Now()
		for _, json := range arryJson {
			jsonmap := json.(map[string]interface{})
			datamodel := accord.Mf_sip{}
			datamodel.Schemecode = helper.GetIntfromMap(jsonmap, "schemecode")
			datamodel.Frequency = helper.GetStringfromMap(jsonmap, "frequency")
			// err := tx.Where("schemecode=? AND frequency=?", datamodel.Schemecode, datamodel.Frequency).First(&datamodel).Error
			// if err != nil {
			// 	Zerologs.Error().Msg("Record Not Found In Mf_sip" + err.Error())
			// }
			schemecode := strconv.Itoa(datamodel.Schemecode)
			datamodel.ID = schemecode + "_" + datamodel.Frequency
			datamodel.Amc_code = helper.GetIntfromMap(jsonmap, "amc_code")
			datamodel.Sip = helper.GetStringfromMap(jsonmap, "sip")
			datamodel.Sipdatescondition = helper.GetStringfromMap(jsonmap, "sipdatescondition")
			datamodel.Dates = helper.GetStringfromMap(jsonmap, "Dates")
			datamodel.Sipdaysall = helper.GetStringfromMap(jsonmap, "sipdaysall")
			datamodel.Sipmininvest = helper.GetFloatfromMap(jsonmap, "sipmininvest")
			datamodel.Sipaddninvest = helper.GetFloatfromMap(jsonmap, "sipaddninvest")
			datamodel.Sipfrequencyno = helper.GetIntfromMap(jsonmap, "sipfrequencyno")
			datamodel.Sipminimumperiod = helper.GetIntfromMap(jsonmap, "sipminimumperiod")
			datamodel.Sipmaximumperiod = helper.GetStringfromMap(jsonmap, "sipmaximumperiod")
			datamodel.Sipmincumamount = helper.GetStringfromMap(jsonmap, "sipmincumamount")
			datamodel.Sipminunits = helper.GetFloatfromMap(jsonmap, "sipminunits")
			datamodel.Sipmultiplesunits = helper.GetFloatfromMap(jsonmap, "sipmultiplesunits")
			datamodel.Flag = helper.GetStringfromMap(jsonmap, "flag")

			// err := tx.Where("schemecode=? AND frequency=?", datamodel.Schemecode, datamodel.Frequency).First(&datamodel).Error
			// if err != nil {
			// 	err := tx.Create(&datamodel).Error
			// 	if err != nil {
			// 		buffer.WriteString(err.Error())
			// 	}
			// } else {
			// err = tx.Save(&datamodel).Error
			// if err != nil {
			// 	buffer.WriteString(err.Error())
			// }
			datamodelUpdate = append(datamodelUpdate, datamodel)
			// }
			count++

		}
		err := db.Accord.Clauses(clause.OnConflict{
			Columns:   []clause.Column{{Name: "id"}}, //, {Name: "invdate"}, {Name: "srno"}},
			DoUpdates: clause.AssignmentColumns([]string{"schemecode", "amc_code", "frequency", "sip", "sipdatescondition", "dates", "sipdaysall", "sipmininvest", "sipaddninvest", "sipfrequencyno", "sipminimumperiod", "sipmaximumperiod", "sipmincumamount", "sipminunits", "sipmultiplesunits", "flag"}),
			// DoUpdates: clause.AssignmentColumns([]string{"rating"}),
		}).CreateInBatches(&datamodelUpdate, 1000).Error
		if err != nil {
			fmt.Println(err)
			Zerologs.Error().Msg("Error while Inserting data into Mf_sip")
		}
		Zerologs.Info().Msgf(" execution time for Mf_sip ==>", time.Since(start))
		buffer.WriteString("Total Record updated " + strconv.Itoa(count) + "\n")
		return nil
	})

	// })
	return nil
}

func Mf_stp(strjson []byte, buffer *bytes.Buffer) error {
	var arryJson []interface{}
	if err := json.Unmarshal(strjson, &arryJson); err != nil {
		buffer.WriteString(err.Error() + "\n")
		return err
	}
	var datamodelUpdate []accord.Mf_stp
	count := 0
	// q.Enqueue(arryJson, func(data interface{}) {
	db.Accord.Transaction(func(tx *gorm.DB) error {
		start := time.Now()
		for _, json := range arryJson {
			jsonmap := json.(map[string]interface{})
			datamodel := accord.Mf_stp{}
			datamodel.Schemecode = helper.GetIntfromMap(jsonmap, "schemecode")
			datamodel.Frequency = helper.GetStringfromMap(jsonmap, "frequency")
			datamodel.Stpinout = helper.GetStringfromMap(jsonmap, "stpinout")
			// err := tx.Where("schemecode=? AND frequency=? AND stpinout=?", datamodel.Schemecode, datamodel.Frequency, datamodel.Stpinout).First(&datamodel).Error
			// if err != nil {
			// 	Zerologs.Error().Msg("Record Not Found In Mf_stp" + err.Error())
			// }
			schemecode := strconv.Itoa(datamodel.Schemecode)
			datamodel.ID = schemecode + "-" + datamodel.Frequency + "_" + datamodel.Stpinout
			datamodel.Amc_code = helper.GetIntfromMap(jsonmap, "amc_code")
			datamodel.Stp = helper.GetStringfromMap(jsonmap, "stp")
			datamodel.Stpdatescondition = helper.GetStringfromMap(jsonmap, "stpdatescondition")
			datamodel.Dates = helper.GetStringfromMap(jsonmap, "Dates")
			datamodel.Stpdaysall = helper.GetStringfromMap(jsonmap, "stpdaysall")
			datamodel.Stpmininvest = helper.GetFloatfromMap(jsonmap, "stpmininvest")
			datamodel.Stpaddnivest = helper.GetFloatfromMap(jsonmap, "stpaddninvest")
			datamodel.Stpfreqencyno = helper.GetIntfromMap(jsonmap, "stpfrequencyno")
			datamodel.Stpinimumperiod = helper.GetIntfromMap(jsonmap, "stpminimumperiod")
			datamodel.Stpmaximumperiod = helper.GetStringfromMap(jsonmap, "stpmaximumperiod")
			datamodel.Stpmincumamount = helper.GetStringfromMap(jsonmap, "stpmincumamount")
			datamodel.Stpminunits = helper.GetFloatfromMap(jsonmap, "stpminunits")
			datamodel.Stpmultiplesunits = helper.GetFloatfromMap(jsonmap, "stpmultiplesunits")
			datamodel.Flag = helper.GetStringfromMap(jsonmap, "flag")

			// err := tx.Where("schemecode=? AND frequency=? AND stpinout=?", datamodel.Schemecode, datamodel.Frequency, datamodel.Stpinout).First(&datamodel).Error
			// if err != nil {
			// 	err := tx.Create(&datamodel).Error
			// 	if err != nil {
			// 		buffer.WriteString(err.Error())
			// 	}
			// } else {
			// err = tx.Save(&datamodel).Error
			// if err != nil {
			// 	buffer.WriteString(err.Error())
			// }
			datamodelUpdate = append(datamodelUpdate, datamodel)
			// }
			count++

		}
		err := db.Accord.Clauses(clause.OnConflict{
			Columns:   []clause.Column{{Name: "id"}}, //, {Name: "invdate"}, {Name: "srno"}},
			DoUpdates: clause.AssignmentColumns([]string{"schemecode", "amc_code", "frequency", "stpinout", "stp", "stpdatescondition", "dates", "stpdaysall", "stpmininvest", "stpaddnivest", "stpfreqencyno", "stpinimumperiod", "stpmaximumperiod", "stpmincumamount", "stpminunits", "stpmultiplesunits", "flag"}),
			// DoUpdates: clause.AssignmentColumns([]string{"rating"}),
		}).CreateInBatches(&datamodelUpdate, 1000).Error
		if err != nil {
			fmt.Println(err)
			Zerologs.Error().Msg("Error while Inserting data into Mf_stp")
		}
		Zerologs.Info().Msgf(" execution time for Mf_stp ==>", time.Since(start))
		buffer.WriteString("Total Record updated " + strconv.Itoa(count) + "\n")
		return nil
	})

	// })
	return nil
}

func Mf_swp(strjson []byte, buffer *bytes.Buffer) error {
	var arryJson []interface{}
	if err := json.Unmarshal(strjson, &arryJson); err != nil {
		buffer.WriteString(err.Error() + "\n")
		return err
	}
	var datamodelUpdate []accord.Mf_swp
	count := 0
	// q.Enqueue(arryJson, func(data interface{}) {
	db.Accord.Transaction(func(tx *gorm.DB) error {
		start := time.Now()
		for _, json := range arryJson {
			jsonmap := json.(map[string]interface{})
			datamodel := accord.Mf_swp{}
			datamodel.Schemecode = helper.GetIntfromMap(jsonmap, "schemecode")
			datamodel.Frequency = helper.GetStringfromMap(jsonmap, "frequency")
			// err := tx.Where("schemecode=? AND frequency=?", datamodel.Schemecode, datamodel.Frequency).First(&datamodel).Error
			// if err != nil {
			// 	Zerologs.Error().Msg("Record Not Found In Mf_swp" + err.Error())
			// }
			schemecode := strconv.Itoa(datamodel.Schemecode)
			datamodel.ID = schemecode + "_" + datamodel.Frequency
			datamodel.Amc_code = helper.GetIntfromMap(jsonmap, "amc_code")
			datamodel.Swp = helper.GetStringfromMap(jsonmap, "swp")
			datamodel.Swpdatescondition = helper.GetStringfromMap(jsonmap, "swpdatescondition")
			datamodel.Dates = helper.GetStringfromMap(jsonmap, "Dates")
			datamodel.Swpdaysall = helper.GetStringfromMap(jsonmap, "swpdaysall")
			datamodel.Swpmininvest = helper.GetFloatfromMap(jsonmap, "swpmininvest")
			datamodel.Swpaddninvest = helper.GetFloatfromMap(jsonmap, "swpaddninvest")
			datamodel.Swpfrequencyno = helper.GetIntfromMap(jsonmap, "swpfrequencyno")
			datamodel.Swpminimumperiod = helper.GetIntfromMap(jsonmap, "swpminimumperiod")
			datamodel.Swpmaximumperiod = helper.GetStringfromMap(jsonmap, "swpmaximumperiod")
			datamodel.Swpmincumamount = helper.GetStringfromMap(jsonmap, "swpmincumamount")
			datamodel.Swpminunits = helper.GetFloatfromMap(jsonmap, "swpminunits")
			datamodel.Swpmultiplesunits = helper.GetFloatfromMap(jsonmap, "swpmultiplesunits")
			datamodel.Flag = helper.GetStringfromMap(jsonmap, "Flag")

			// err := tx.Where("schemecode=? AND frequency=?", datamodel.Schemecode, datamodel.Frequency).First(&datamodel).Error
			// if err != nil {
			// 	err := tx.Create(&datamodel).Error
			// 	if err != nil {
			// 		buffer.WriteString(err.Error())
			// 	}
			// } else {

			datamodelUpdate = append(datamodelUpdate, datamodel)
			// }
			count++

		}
		err := db.Accord.Clauses(clause.OnConflict{
			Columns:   []clause.Column{{Name: "id"}}, //, {Name: "invdate"}, {Name: "srno"}},
			DoUpdates: clause.AssignmentColumns([]string{"schemecode", "amc_code", "frequency", "swp", "swpdatescondition", "dates", "swpdaysall", "swpmininvest", "swpaddninvest", "swpfrequencyno", "swpminimumperiod", "swpmaximumperiod", "swpmincumamount", "swpminunits", "swpmultiplesunits", "flag"}),
			// DoUpdates: clause.AssignmentColumns([]string{"rating"}),
		}).CreateInBatches(&datamodelUpdate, 1000).Error
		if err != nil {
			fmt.Println(err)
			Zerologs.Error().Msg("Error while Inserting data into Mf_swp")
		}
		Zerologs.Info().Msgf(" execution time for Mf_swp ==>", time.Since(start))
		buffer.WriteString("Total Record updated " + strconv.Itoa(count) + "\n")
		return nil
	})

	// })
	return nil
}

func MFBULKDEALS(strjson []byte, buffer *bytes.Buffer) error {
	var arryJson []interface{}
	if err := json.Unmarshal(strjson, &arryJson); err != nil {
		buffer.WriteString(err.Error() + "\n")
		return err
	}
	var datamodelUpdate []accord.MFBULKDEALS
	count := 0
	// q.Enqueue(arryJson, func(data interface{}) {
	db.Accord.Transaction(func(tx *gorm.DB) error {
		start := time.Now()
		for _, json := range arryJson {
			jsonmap := json.(map[string]interface{})
			datamodel := accord.MFBULKDEALS{}
			datamodel.Fincode = helper.GetIntfromMap(jsonmap, "fincode")
			datamodel.Date = helper.GetTimefromMap(jsonmap, "date")
			datamodel.Clientname = helper.GetStringfromMap(jsonmap, "clientname")
			datamodel.Dealtype = helper.GetStringfromMap(jsonmap, "dealtype")
			datamodel.Volume = helper.GetFloatfromMap(jsonmap, "volume")
			datamodel.Price = helper.GetFloatfromMap(jsonmap, "price")
			// err := tx.Where("fincode=? AND date=? AND clientname=? AND dealtype=? AND volume=? AND price=?", datamodel.Fincode, datamodel.Date, datamodel.Clientname, datamodel.Dealtype, datamodel.Volume, datamodel.Price).First(&datamodel).Error
			// if err != nil {
			// 	Zerologs.Error().Msg("Record Not Found In MFBULKDEALS" + err.Error())
			// }
			fincode := strconv.Itoa(datamodel.Fincode)
			date := datamodel.Date.String()
			volume := fmt.Sprintf("%v", datamodel.Volume)
			price := fmt.Sprintf("%v", datamodel.Price)
			datamodel.ID = fincode + "_" + date + "_" + datamodel.Clientname + "_" + datamodel.Dealtype + "_" + volume + "_" + price
			datamodel.Exchange = helper.GetStringfromMap(jsonmap, "exchange")
			datamodel.Type = helper.GetStringfromMap(jsonmap, "type")
			datamodel.Mfcode = helper.GetIntfromMap(jsonmap, "mfcode")
			datamodel.Flag = helper.GetStringfromMap(jsonmap, "flag")

			// err := tx.Where("fincode=? AND date=? AND clientname=? AND dealtype=? AND volume=? AND price=?", datamodel.Fincode, datamodel.Date, datamodel.Clientname, datamodel.Dealtype, datamodel.Volume, datamodel.Price).First(&datamodel).Error
			// if err != nil {
			// 	err := tx.Create(&datamodel).Error
			// 	if err != nil {
			// 		buffer.WriteString(err.Error())
			// 	}
			// } else {
			// err = tx.Save(&datamodel).Error
			// if err != nil {
			// 	buffer.WriteString(err.Error())
			// }
			datamodelUpdate = append(datamodelUpdate, datamodel)
			// }
			count++

		}
		err := db.Accord.Clauses(clause.OnConflict{
			Columns:   []clause.Column{{Name: "id"}}, //, {Name: "invdate"}, {Name: "srno"}},
			DoUpdates: clause.AssignmentColumns([]string{"fincode", "date", "exchange", "clientname", "type", "mfcode", "dealtype", "volume", "price", "flag"}),
			// DoUpdates: clause.AssignmentColumns([]string{"rating"}),
		}).CreateInBatches(&datamodelUpdate, 1000).Error
		if err != nil {
			fmt.Println(err)
			Zerologs.Error().Msg("Error while Inserting data into MFBULKDEALS")
		}
		Zerologs.Info().Msgf(" execution time for MFBULKDEALS ==>", time.Since(start))
		buffer.WriteString("Total Record updated " + strconv.Itoa(count) + "\n")
		return nil
	})

	// })
	return nil
}

func Plan_mst(strjson []byte, buffer *bytes.Buffer) error {
	var arryJson []interface{}
	if err := json.Unmarshal(strjson, &arryJson); err != nil {
		buffer.WriteString(err.Error() + "\n")
		return err
	}
	var datamodelUpdate []accord.Plan_mst
	count := 0
	// q.Enqueue(arryJson, func(data interface{}) {
	db.Accord.Transaction(func(tx *gorm.DB) error {
		start := time.Now()
		for _, json := range arryJson {
			jsonmap := json.(map[string]interface{})
			datamodel := accord.Plan_mst{}
			datamodel.Plan_code = helper.GetIntfromMap(jsonmap, "plan_code")
			// err := tx.Where("plan_code=?", datamodel.Plan_code).First(&datamodel).Error
			// if err != nil {
			// 	Zerologs.Error().Msg("Record Not Found In Plan_mst" + err.Error())
			// }
			plancode := strconv.Itoa(datamodel.Plan_code)
			datamodel.ID = plancode
			datamodel.Plan = helper.GetStringfromMap(jsonmap, "plan")
			datamodel.Flag = helper.GetStringfromMap(jsonmap, "flag")

			// err := tx.Where("plan_code=?", datamodel.Plan_code).First(&datamodel).Error
			// if err != nil {
			// 	err := tx.Create(&datamodel).Error
			// 	if err != nil {
			// 		buffer.WriteString(err.Error())
			// 	}
			// } else {
			// err = tx.Save(&datamodel).Error
			// if err != nil {
			// 	buffer.WriteString(err.Error())
			// }
			datamodelUpdate = append(datamodelUpdate, datamodel)
			// }
			count++

		}
		err := db.Accord.Clauses(clause.OnConflict{
			Columns:   []clause.Column{{Name: "id"}}, //, {Name: "invdate"}, {Name: "srno"}},
			DoUpdates: clause.AssignmentColumns([]string{"plan_code", "plan", "flag"}),
			// DoUpdates: clause.AssignmentColumns([]string{"rating"}),
		}).CreateInBatches(&datamodelUpdate, 1000).Error
		if err != nil {
			fmt.Println(err)
			Zerologs.Error().Msg("Error while Inserting data into Plan_mst")
		}
		Zerologs.Info().Msgf(" execution time for Plan_mst ==>", time.Since(start))
		buffer.WriteString("Total Record updated " + strconv.Itoa(count) + "\n")
		return nil
	})

	// })
	return nil
}

func Portfolio_inout(strjson []byte, buffer *bytes.Buffer) error {
	var arryJson []interface{}
	if err := json.Unmarshal(strjson, &arryJson); err != nil {
		buffer.WriteString(err.Error() + "\n")
		return err
	}
	var datamodelUpdate []accord.Portfolio_inout
	count := 0
	// q.Enqueue(arryJson, func(data interface{}) {
	db.Accord.Transaction(func(tx *gorm.DB) error {
		start := time.Now()
		for _, json := range arryJson {
			jsonmap := json.(map[string]interface{})
			datamodel := accord.Portfolio_inout{}
			datamodel.Fincode = helper.GetIntfromMap(jsonmap, "fincode")
			datamodel.Invdate = helper.GetTimefromMap(jsonmap, "invdate")

			// err := tx.Where("fincode=? AND invdate=?", datamodel.Fincode, datamodel.Invdate).First(&datamodel).Error
			// if err != nil {
			// 	Zerologs.Error().Msg("Record Not Found In Portfolio_inout" + err.Error())
			// }
			fincode := strconv.Itoa(datamodel.Fincode)
			invdate := datamodel.Invdate.String()
			datamodel.ID = fincode + "_" + invdate
			datamodel.Mode = helper.GetStringfromMap(jsonmap, "mode")
			datamodel.Compname = helper.GetStringfromMap(jsonmap, "compname")
			datamodel.S_name = helper.GetStringfromMap(jsonmap, "s_name")
			datamodel.Mktval = helper.GetFloatfromMap(jsonmap, "mktval")
			datamodel.Noshares = helper.GetFloatfromMap(jsonmap, "noshares")
			datamodel.Flag = helper.GetStringfromMap(jsonmap, "flag")

			// err := tx.Where("fincode=? AND invdate=?", datamodel.Fincode, datamodel.Invdate).First(&datamodel).Error
			// if err != nil {
			// 	err := tx.Create(&datamodel).Error
			// 	if err != nil {
			// 		buffer.WriteString(err.Error())
			// 	}
			// } else {
			// err = tx.Save(&datamodel).Error
			// if err != nil {
			// 	buffer.WriteString(err.Error())
			// }
			datamodelUpdate = append(datamodelUpdate, datamodel)
			// }
			count++

		}
		err := db.Accord.Clauses(clause.OnConflict{
			Columns:   []clause.Column{{Name: "id"}}, //, {Name: "invdate"}, {Name: "srno"}},
			DoUpdates: clause.AssignmentColumns([]string{"fincode", "invdate", "mode", "compname", "s_name", "mktval", "noshares", "flag"}),
			// DoUpdates: clause.AssignmentColumns([]string{"rating"}),
		}).CreateInBatches(&datamodelUpdate, 1000).Error
		if err != nil {
			fmt.Println(err)
			Zerologs.Error().Msg("Error while Inserting data into Portfolio_inout")
		}
		Zerologs.Info().Msgf(" execution time for Portfolio_inout ==>", time.Since(start))
		buffer.WriteString("Total Record updated " + strconv.Itoa(count) + "\n")
		return nil
	})

	// })
	return nil
}

func Scheme_objective(strjson []byte, buffer *bytes.Buffer) error {
	var arryJson []interface{}
	if err := json.Unmarshal(strjson, &arryJson); err != nil {
		buffer.WriteString(err.Error() + "\n")
		return err
	}
	var datamodelUpdate []accord.Scheme_objective
	count := 0
	// q.Enqueue(arryJson, func(data interface{}) {
	db.Accord.Transaction(func(tx *gorm.DB) error {
		start := time.Now()
		for _, json := range arryJson {
			jsonmap := json.(map[string]interface{})
			datamodel := accord.Scheme_objective{}
			datamodel.Schemecode = helper.GetIntfromMap(jsonmap, "schemecode")
			// err := tx.Where("schemecode=?", datamodel.Schemecode).First(&datamodel).Error
			// if err != nil {
			// 	Zerologs.Error().Msg("Record Not Found In Scheme_objective" + err.Error())
			// }
			schemecode := strconv.Itoa(datamodel.Schemecode)
			datamodel.ID = schemecode
			datamodel.Objective = helper.GetStringfromMap(jsonmap, "objective")
			datamodel.Flag = helper.GetStringfromMap(jsonmap, "flag")

			// err := tx.Where("schemecode=?", datamodel.Schemecode).First(&datamodel).Error
			// if err != nil {
			// 	err := tx.Create(&datamodel).Error
			// 	if err != nil {
			// 		buffer.WriteString(err.Error())
			// 	}
			// } else {
			// err = tx.Save(&datamodel).Error
			// if err != nil {
			// 	buffer.WriteString(err.Error())
			// }
			datamodelUpdate = append(datamodelUpdate, datamodel)
			// }
			count++

		}
		err := db.Accord.Clauses(clause.OnConflict{
			Columns:   []clause.Column{{Name: "id"}}, //, {Name: "invdate"}, {Name: "srno"}},
			DoUpdates: clause.AssignmentColumns([]string{"schemecode", "objective", "flag"}),
			// DoUpdates: clause.AssignmentColumns([]string{"rating"}),
		}).CreateInBatches(&datamodelUpdate, 1000).Error
		if err != nil {
			fmt.Println(err)
			Zerologs.Error().Msg("Error while Inserting data into Scheme_objective")
		}
		Zerologs.Info().Msgf(" execution time for Scheme_objective ==>", time.Since(start))
		buffer.WriteString("Total Record updated " + strconv.Itoa(count) + "\n")
		return nil
	})

	// })
	return nil
}

func Scheme_rtcode(strjson []byte, buffer *bytes.Buffer) error {
	var arryJson []interface{}
	if err := json.Unmarshal(strjson, &arryJson); err != nil {
		buffer.WriteString(err.Error() + "\n")
		return err
	}
	var datamodelUpdate []accord.Scheme_rtcode
	count := 0
	// q.Enqueue(arryJson, func(data interface{}) {
	db.Accord.Transaction(func(tx *gorm.DB) error {
		start := time.Now()
		for _, json := range arryJson {
			jsonmap := json.(map[string]interface{})
			datamodel := accord.Scheme_rtcode{}
			datamodel.Schemecode = helper.GetIntfromMap(jsonmap, "schemecode")
			// err := tx.Where("schemecode=?", datamodel.Schemecode).First(&datamodel).Error
			// if err != nil {
			// 	Zerologs.Error().Msg("Record Not Found In Scheme_rtcode" + err.Error())
			// }
			schemecode := strconv.Itoa(datamodel.Schemecode)
			datamodel.ID = schemecode
			datamodel.Rtschemecode = helper.GetStringfromMap(jsonmap, "rtschemecode")
			datamodel.Flag = helper.GetStringfromMap(jsonmap, "flag")

			// err := tx.Where("schemecode=?", datamodel.Schemecode).First(&datamodel).Error
			// if err != nil {
			// 	err := tx.Create(&datamodel).Error
			// 	if err != nil {
			// 		buffer.WriteString(err.Error())
			// 	}
			// } else {
			// err = tx.Save(&datamodel).Error
			// if err != nil {
			// 	buffer.WriteString(err.Error())
			// }
			datamodelUpdate = append(datamodelUpdate, datamodel)
			// }
			count++

		}
		err := db.Accord.Clauses(clause.OnConflict{
			Columns:   []clause.Column{{Name: "id"}}, //, {Name: "invdate"}, {Name: "srno"}},
			DoUpdates: clause.AssignmentColumns([]string{"schemecode", "rtschemecode", "flag"}),
			// DoUpdates: clause.AssignmentColumns([]string{"rating"}),
		}).CreateInBatches(&datamodelUpdate, 1000).Error
		if err != nil {
			fmt.Println(err)
			Zerologs.Error().Msg("Error while Inserting data into Scheme_rtcode")
		}
		Zerologs.Info().Msgf(" execution time for Scheme_rtcode ==>", time.Since(start))
		buffer.WriteString("Total Record updated " + strconv.Itoa(count) + "\n")
		return nil
	})

	// })
	return nil
}

func Scheme_paum(strjson []byte, buffer *bytes.Buffer) error {
	var arryJson []interface{}
	if err := json.Unmarshal(strjson, &arryJson); err != nil {
		buffer.WriteString(err.Error() + "\n")
		return err
	}
	var datamodelUpdate []accord.Scheme_paum
	count := 0
	// q.Enqueue(arryJson, func(data interface{}) {
	db.Accord.Transaction(func(tx *gorm.DB) error {
		start := time.Now()
		for _, json := range arryJson {
			jsonmap := json.(map[string]interface{})
			datamodel := accord.Scheme_paum{}
			datamodel.Schemecode = helper.GetIntfromMap(jsonmap, "schemecode")
			datamodel.Monthend = helper.GetIntfromMap(jsonmap, "monthend")
			// err := tx.Where("schemecode=? AND monthend=?", datamodel.Schemecode, datamodel.Monthend).First(&datamodel).Error
			// if err != nil {
			// 	Zerologs.Error().Msg("Record Not Found In Scheme_paum" + err.Error())
			// }
			schemecode := strconv.Itoa(datamodel.Schemecode)
			monthend := strconv.Itoa(datamodel.Monthend)
			datamodel.ID = schemecode + "_" + monthend
			datamodel.Amc_code = helper.GetIntfromMap(jsonmap, "amc_code")
			datamodel.Aum = helper.GetFloatfromMap(jsonmap, "aum")
			datamodel.Flag = helper.GetStringfromMap(jsonmap, "flag")

			// err := tx.Where("schemecode=? AND monthend=?", datamodel.Schemecode, datamodel.Monthend).First(&datamodel).Error
			// if err != nil {
			// 	err := tx.Create(&datamodel).Error
			// 	if err != nil {
			// 		buffer.WriteString(err.Error())
			// 	}
			// } else {
			// err = tx.Save(&datamodel).Error
			// if err != nil {
			// 	buffer.WriteString(err.Error())
			// }
			datamodelUpdate = append(datamodelUpdate, datamodel)
			// }
			count++

		}
		err := db.Accord.Clauses(clause.OnConflict{
			Columns:   []clause.Column{{Name: "id"}}, //, {Name: "invdate"}, {Name: "srno"}},
			DoUpdates: clause.AssignmentColumns([]string{"schemecode", "monthend", "amc_code", "aum", "flag"}),
			// DoUpdates: clause.AssignmentColumns([]string{"rating"}),
		}).CreateInBatches(&datamodelUpdate, 1000).Error
		if err != nil {
			fmt.Println(err)
			Zerologs.Error().Msg("Error while Inserting data into Scheme_paum")
		}
		Zerologs.Info().Msgf(" execution time for Scheme_paum ==>", time.Since(start))
		buffer.WriteString("Total Record updated " + strconv.Itoa(count) + "\n")
		return nil
	})

	// })
	return nil
}

func Finance_cons_bs(strjson []byte, buffer *bytes.Buffer) error {
	var arryJson []interface{}
	if err := json.Unmarshal(strjson, &arryJson); err != nil {
		buffer.WriteString(err.Error() + "\n")
		return err
	}
	var datamodelUpdate []accord.Finance_cons_bs
	count := 0
	// q.Enqueue(arryJson, func(data interface{}) {
	db.Accord.Transaction(func(tx *gorm.DB) error {
		start := time.Now()
		for _, json := range arryJson {
			jsonmap := json.(map[string]interface{})
			datamodel := accord.Finance_cons_bs{}
			datamodel.Fincode = helper.GetIntfromMap(jsonmap, "Fincode")
			datamodel.Year_end = helper.GetIntfromMap(jsonmap, "Year_end")
			datamodel.Type = helper.GetStringfromMap(jsonmap, "Type")
			// err := tx.Where("fincode=? AND year_end=? AND type=?", datamodel.Fincode, datamodel.Year_end, datamodel.Type).First(&datamodel).Error
			// if err != nil {
			// 	Zerologs.Error().Msg("Record Not Found In Finance_cons_bs" + err.Error())
			// }
			fincode := strconv.Itoa(datamodel.Fincode)
			year_end := strconv.Itoa(datamodel.Year_end)
			datamodel.ID = fincode + "_" + year_end + "_" + datamodel.Type
			datamodel.No_months = helper.GetIntfromMap(jsonmap, "No_months")
			datamodel.Unit = helper.GetIntfromMap(jsonmap, "Unit")
			datamodel.Share_Capital = helper.GetFloatfromMap(jsonmap, "Share_Capital")
			datamodel.Shares_warrants = helper.GetFloatfromMap(jsonmap, "Shares_warrants")
			datamodel.Shares_application_money = helper.GetFloatfromMap(jsonmap, "Shares_application_money")
			datamodel.ESOP_Outstanding = helper.GetFloatfromMap(jsonmap, "ESOP_Outstanding")
			datamodel.Share_suspense = helper.GetFloatfromMap(jsonmap, "Share_suspense")
			datamodel.Reserve = helper.GetFloatfromMap(jsonmap, "Reserve")
			datamodel.Sharehoders_funds = helper.GetFloatfromMap(jsonmap, "Sharehoders_funds")
			datamodel.Deposits = helper.GetFloatfromMap(jsonmap, "Deposits")
			datamodel.Borrowings = helper.GetFloatfromMap(jsonmap, "Borrowings")
			datamodel.Other_liabilities = helper.GetFloatfromMap(jsonmap, "Other_liabilities")
			datamodel.Total_sounces_Funds = helper.GetFloatfromMap(jsonmap, "Total_sounces_Funds")
			datamodel.Cash_balances_RBI = helper.GetFloatfromMap(jsonmap, "Cash_balances_RBI")
			datamodel.Bank_Call_money = helper.GetFloatfromMap(jsonmap, "Bank_Call_money")
			datamodel.Investments = helper.GetFloatfromMap(jsonmap, "Investments")
			datamodel.Advances = helper.GetFloatfromMap(jsonmap, "Advances")
			datamodel.Gross_block = helper.GetFloatfromMap(jsonmap, "Gross_block")
			datamodel.Acc_Depreciation = helper.GetFloatfromMap(jsonmap, "Acc_Depreciation")
			datamodel.Impairment_assets = helper.GetFloatfromMap(jsonmap, "Impairment_assets")
			datamodel.Lease_adj = helper.GetFloatfromMap(jsonmap, "Lease_adj")
			datamodel.CWIP = helper.GetFloatfromMap(jsonmap, "CWIP")
			datamodel.Other_Assets = helper.GetFloatfromMap(jsonmap, "Other_Assets")
			datamodel.Total_Applications = helper.GetFloatfromMap(jsonmap, "Total_Applications")
			datamodel.Contingent_liabilities = helper.GetFloatfromMap(jsonmap, "Contingent_liabilities")
			datamodel.Bills_For_Collection = helper.GetFloatfromMap(jsonmap, "Bills_For_Collection")
			datamodel.Ltrm_Borrowing = helper.GetFloatfromMap(jsonmap, "Ltrm_Borrowing")
			datamodel.Secured_Loans = helper.GetFloatfromMap(jsonmap, "Secured_Loans")
			datamodel.Unsecured_Loans_Nf = helper.GetFloatfromMap(jsonmap, "Unsecured_Loans_Nf")
			datamodel.Net_Def_Tax_Nf = helper.GetFloatfromMap(jsonmap, "Net_Def_Tax_Nf")
			datamodel.Oth_Lt_Liab = helper.GetFloatfromMap(jsonmap, "Oth_Lt_Liab")
			datamodel.Lt_Trade_Payables = helper.GetFloatfromMap(jsonmap, "Lt_Trade_Payables")
			datamodel.Lt_Provisions = helper.GetFloatfromMap(jsonmap, "Lt_Provisions")
			datamodel.Total_Nonliab = helper.GetFloatfromMap(jsonmap, "Total_Nonliab")
			datamodel.Trade_Payables = helper.GetFloatfromMap(jsonmap, "Trade_Payables")
			datamodel.Current_Liabilities_Nf = helper.GetFloatfromMap(jsonmap, "Current_Liabilities_Nf")
			datamodel.St_Borrowings = helper.GetFloatfromMap(jsonmap, "St_Borrowings")
			datamodel.Provisions = helper.GetFloatfromMap(jsonmap, "Provisions")
			datamodel.Current_Laib_Prov_Nf = helper.GetFloatfromMap(jsonmap, "Current_Laib_Prov_Nf")
			datamodel.Total_Sounces_Funds_Nf = helper.GetFloatfromMap(jsonmap, "Total_Sounces_Funds_Nf")
			datamodel.Non_Current_Assets = helper.GetFloatfromMap(jsonmap, "Non_Current_Assets")
			datamodel.Loan_Non_Cuurent_Assets = helper.GetFloatfromMap(jsonmap, "Loan_Non_Cuurent_Assets")
			datamodel.Net_Block = helper.GetFloatfromMap(jsonmap, "Net_Block")
			datamodel.Cwip_Nf = helper.GetFloatfromMap(jsonmap, "Cwip_Nf")
			datamodel.Intang_Assetunderdev = helper.GetFloatfromMap(jsonmap, "Intang_Assetunderdev")
			datamodel.Pre_Operatieve_Exps = helper.GetFloatfromMap(jsonmap, "Pre_Operatieve_Exps")
			datamodel.Assetsintransit = helper.GetFloatfromMap(jsonmap, "Assetsintransit")
			datamodel.Investments_Nf = helper.GetFloatfromMap(jsonmap, "Investments_Nf")
			datamodel.Lt_Loanadv = helper.GetFloatfromMap(jsonmap, "Lt_Loanadv")
			datamodel.Other_Noc_Assets = helper.GetFloatfromMap(jsonmap, "Other_Noc_Assets")
			datamodel.Total_Nonassets = helper.GetFloatfromMap(jsonmap, "Total_Nonassets")
			datamodel.Current_Investments = helper.GetFloatfromMap(jsonmap, "Current_Investments")
			datamodel.Inventory = helper.GetFloatfromMap(jsonmap, "Inventory")
			datamodel.Debtors = helper.GetFloatfromMap(jsonmap, "Debtors")
			datamodel.Cash_Bank = helper.GetFloatfromMap(jsonmap, "Cash_Bank")
			datamodel.Other_Current_Nf = helper.GetFloatfromMap(jsonmap, "Other_Current_Nf")
			datamodel.Loans_Adv = helper.GetFloatfromMap(jsonmap, "Loans_Adv")
			datamodel.Currant_Assets_Nf = helper.GetFloatfromMap(jsonmap, "Currant_Assets_Nf")
			datamodel.Net_Current_Assets_Nf = helper.GetFloatfromMap(jsonmap, "Net_Current_Assets_Nf")
			datamodel.Other_Crnt_Assets = helper.GetFloatfromMap(jsonmap, "Other_Crnt_Assets")
			datamodel.Misc_Exps_Not_Wo = helper.GetFloatfromMap(jsonmap, "Misc_Exps_Not_Wo")
			datamodel.Total_Applications_Nf = helper.GetFloatfromMap(jsonmap, "Total_Applications_Nf")
			datamodel.Total_Debt_Inclst_Nf = helper.GetFloatfromMap(jsonmap, "Total_Debt_Inclst_Nf")
			datamodel.Book_Nav_Share = helper.GetFloatfromMap(jsonmap, "Book_Nav_Share")
			datamodel.Adj_Bv = helper.GetFloatfromMap(jsonmap, "Adj_Bv")
			datamodel.Minority_Interest = helper.GetFloatfromMap(jsonmap, "Minority_Interest")
			datamodel.Equity_Authorised = helper.GetFloatfromMap(jsonmap, "Equity_Authorised")
			datamodel.Equity_Issued = helper.GetFloatfromMap(jsonmap, "Equity_Issued")
			datamodel.EQUITY_PAIDUP = helper.GetFloatfromMap(jsonmap, "EQUITY_PAIDUP")
			datamodel.Equity_Forfeited = helper.GetFloatfromMap(jsonmap, "Equity_Forfeited")
			datamodel.Adj_Equity = helper.GetFloatfromMap(jsonmap, "Adj_Equity")
			datamodel.Preference_Capital = helper.GetFloatfromMap(jsonmap, "Preference_Capital")
			datamodel.FACE_VALUE = helper.GetFloatfromMap(jsonmap, "FACE_VALUE")
			datamodel.Share_Premium = helper.GetFloatfromMap(jsonmap, "Share_Premium")
			datamodel.Capital_Reserve = helper.GetFloatfromMap(jsonmap, "Capital_Reserve")
			datamodel.Profit_Loss = helper.GetFloatfromMap(jsonmap, "Profit_Loss")
			datamodel.General_Reserve = helper.GetFloatfromMap(jsonmap, "General_Reserve")
			datamodel.Reserve_Excl_Revaluation = helper.GetFloatfromMap(jsonmap, "Reserve_Excl_Revaluation")
			datamodel.Revaluation_Reserve = helper.GetFloatfromMap(jsonmap, "Revaluation_Reserve")
			datamodel.Demand_Deposits = helper.GetFloatfromMap(jsonmap, "Demand_Deposits")
			datamodel.Saving_Deposits = helper.GetFloatfromMap(jsonmap, "Saving_Deposits")
			datamodel.Term_Fixed_Deposits = helper.GetFloatfromMap(jsonmap, "Term_Fixed_Deposits")
			datamodel.Current_Deposits = helper.GetFloatfromMap(jsonmap, "Current_Deposits")
			datamodel.Recurring_Deposits = helper.GetFloatfromMap(jsonmap, "Recurring_Deposits")
			datamodel.Borrowings_RBI = helper.GetFloatfromMap(jsonmap, "Borrowings_RBI")
			datamodel.Borrowings_Banks = helper.GetFloatfromMap(jsonmap, "Borrowings_Banks")
			datamodel.Borrowings_GOI = helper.GetFloatfromMap(jsonmap, "Borrowings_GOI")
			datamodel.Borrowings_FI = helper.GetFloatfromMap(jsonmap, "Borrowings_FI")
			datamodel.Borrowings_Bonds = helper.GetFloatfromMap(jsonmap, "Borrowings_Bonds")
			datamodel.Borrowings_Other = helper.GetFloatfromMap(jsonmap, "Borrowings_Other")
			datamodel.Borrowings_Outof_India = helper.GetFloatfromMap(jsonmap, "Borrowings_Outof_India")
			datamodel.Bills_payable = helper.GetFloatfromMap(jsonmap, "Bills_payable")
			datamodel.Inter_oofice_adjustments_liabilities = helper.GetFloatfromMap(jsonmap, "Inter_oofice_adjustments_liabilities")
			datamodel.Interest_accrued = helper.GetFloatfromMap(jsonmap, "Interest_accrued")
			datamodel.Proposed_dividend = helper.GetFloatfromMap(jsonmap, "Proposed_dividend")
			datamodel.Corporate_dividend_tax = helper.GetFloatfromMap(jsonmap, "Corporate_dividend_tax")
			datamodel.Cash_RBI = helper.GetFloatfromMap(jsonmap, "Cash_RBI")
			datamodel.Cash_In_hand = helper.GetFloatfromMap(jsonmap, "Cash_In_hand")
			datamodel.Investments_India = helper.GetFloatfromMap(jsonmap, "Investments_India")
			datamodel.GOI_Securities = helper.GetFloatfromMap(jsonmap, "GOI_Securities")
			datamodel.Equity_Shares_corporate = helper.GetFloatfromMap(jsonmap, "Equity_Shares_corporate")
			datamodel.Debentures_Bonds = helper.GetFloatfromMap(jsonmap, "Debentures_Bonds")
			datamodel.Subsidiaries_Joint_ventures = helper.GetFloatfromMap(jsonmap, "Subsidiaries_Joint_ventures")
			datamodel.Mutual_Funds_insurance_Units = helper.GetFloatfromMap(jsonmap, "Mutual_Funds_insurance_Units")
			datamodel.Investments_Outside_India = helper.GetFloatfromMap(jsonmap, "Investments_Outside_India")
			datamodel.GOI_Securities_Outside_india = helper.GetFloatfromMap(jsonmap, "GOI_Securities_Outside_india")
			datamodel.Subsidiaries_Joint_ventures_outside_india = helper.GetFloatfromMap(jsonmap, "Subsidiaries_Joint_ventures_outside_india")
			datamodel.Other_investments_outside_India = helper.GetFloatfromMap(jsonmap, "Other_investments_outside_India")
			datamodel.Dimunition_Investments = helper.GetFloatfromMap(jsonmap, "Dimunition_Investments")
			datamodel.Bills_purchased_discounted = helper.GetFloatfromMap(jsonmap, "Bills_purchased_discounted")
			datamodel.Cash_credit_overdraft = helper.GetFloatfromMap(jsonmap, "Cash_credit_overdraft")
			datamodel.Term_Loans = helper.GetFloatfromMap(jsonmap, "Term_Loans")
			datamodel.Finance_Lease_Hire_purchase = helper.GetFloatfromMap(jsonmap, "Finance_Lease_Hire_purchase")
			datamodel.Buildings = helper.GetFloatfromMap(jsonmap, "Buildings")
			datamodel.Assets_despose = helper.GetFloatfromMap(jsonmap, "Assets_despose")
			datamodel.Other_fix_assets = helper.GetFloatfromMap(jsonmap, "Other_fix_assets")
			datamodel.Inter_office_adjustments_Assets = helper.GetFloatfromMap(jsonmap, "Inter_office_adjustments_Assets")
			datamodel.Interest_accrued_assets = helper.GetFloatfromMap(jsonmap, "Interest_accrued_assets")
			datamodel.Advance_tax_TDS = helper.GetFloatfromMap(jsonmap, "Advance_tax_TDS")
			datamodel.Stationery_stamps = helper.GetFloatfromMap(jsonmap, "Stationery_stamps")
			datamodel.Non_banking_assets = helper.GetFloatfromMap(jsonmap, "Non_banking_assets")
			datamodel.Deferred_tax_Assets = helper.GetFloatfromMap(jsonmap, "Deferred_tax_Assets")
			datamodel.Misc_expenditures_Not_writtoff = helper.GetFloatfromMap(jsonmap, "Misc_expenditures_Not_writtoff")
			datamodel.Claims_Not_acknowledge_debt = helper.GetFloatfromMap(jsonmap, "Claims_Not_acknowledge_debt")
			datamodel.Outstanding_Forward_Exchange_Contract = helper.GetFloatfromMap(jsonmap, "Outstanding_Forward_Exchange_Contract")
			datamodel.Guarantees_Constituents_India = helper.GetFloatfromMap(jsonmap, "Guarantees_Constituents_India")
			datamodel.Guarantees_Constituents_Outside_India = helper.GetFloatfromMap(jsonmap, "Guarantees_Constituents_Outside_India")
			datamodel.Acceptances_Endorsements_Obligations = helper.GetFloatfromMap(jsonmap, "Acceptances_Endorsements_Obligations")
			datamodel.Non_Convertible_Debenture = helper.GetFloatfromMap(jsonmap, "Non_Convertible_Debenture")
			datamodel.Conv_Debenture_Bnds = helper.GetFloatfromMap(jsonmap, "Conv_Debenture_Bnds")
			datamodel.Packing_Credit = helper.GetFloatfromMap(jsonmap, "Packing_Credit")
			datamodel.Intercorpsecdeposits = helper.GetFloatfromMap(jsonmap, "Intercorpsecdeposits")
			datamodel.Term_Loan_Bank = helper.GetFloatfromMap(jsonmap, "Term_Loan_Bank")
			datamodel.Term_Loan_Inst = helper.GetFloatfromMap(jsonmap, "Term_Loan_Inst")
			datamodel.Fixed_Deposits = helper.GetFloatfromMap(jsonmap, "Fixed_Deposits")
			datamodel.Loans_Susidiaries = helper.GetFloatfromMap(jsonmap, "Loans_Susidiaries")
			datamodel.Inter_Corp_Deposits = helper.GetFloatfromMap(jsonmap, "Inter_Corp_Deposits")
			datamodel.Foreign_Curr_Convertible_Notes = helper.GetFloatfromMap(jsonmap, "Foreign_Curr_Convertible_Notes")
			datamodel.Foreign_Curr_Long_Term_Loans = helper.GetFloatfromMap(jsonmap, "Foreign_Curr_Long_Term_Loans")
			datamodel.Loans_Bank = helper.GetFloatfromMap(jsonmap, "Loans_Bank")
			datamodel.Loans_Govt = helper.GetFloatfromMap(jsonmap, "Loans_Govt")
			datamodel.Loans_Others = helper.GetFloatfromMap(jsonmap, "Loans_Others")
			datamodel.Def_Tax_Assets = helper.GetFloatfromMap(jsonmap, "Def_Tax_Assets")
			datamodel.Def_Tax_Liability = helper.GetFloatfromMap(jsonmap, "Def_Tax_Liability")
			datamodel.Sundry_Crs = helper.GetFloatfromMap(jsonmap, "Sundry_Crs")
			datamodel.Acceptances = helper.GetFloatfromMap(jsonmap, "Acceptances")
			datamodel.Trade_Paysubs = helper.GetFloatfromMap(jsonmap, "Trade_Paysubs")
			datamodel.Bank_Od = helper.GetFloatfromMap(jsonmap, "Bank_Od")
			datamodel.Adv_Customers = helper.GetFloatfromMap(jsonmap, "Adv_Customers")
			datamodel.Interest_Not_Due = helper.GetFloatfromMap(jsonmap, "Interest_Not_Due")
			datamodel.Share_Application = helper.GetFloatfromMap(jsonmap, "Share_Application")
			datamodel.Cl_Curmat_Deb = helper.GetFloatfromMap(jsonmap, "Cl_Curmat_Deb")
			datamodel.Cl_Curmat_Others = helper.GetFloatfromMap(jsonmap, "Cl_Curmat_Others")
			datamodel.Loans = helper.GetFloatfromMap(jsonmap, "Loans")
			datamodel.Stbs_Sec_Loandemand = helper.GetFloatfromMap(jsonmap, "Stbs_Sec_Loandemand")
			datamodel.Stbs_Wcap = helper.GetFloatfromMap(jsonmap, "Stbs_Wcap")
			datamodel.Stbu_Buycredit = helper.GetFloatfromMap(jsonmap, "Stbu_Buycredit")
			datamodel.Stbu_Commborr = helper.GetFloatfromMap(jsonmap, "Stbu_Commborr")
			datamodel.Proposed_Divided = helper.GetFloatfromMap(jsonmap, "Proposed_Divided")
			datamodel.Prov_Corp_Tax = helper.GetFloatfromMap(jsonmap, "Prov_Corp_Tax")
			datamodel.Prov_Tax = helper.GetFloatfromMap(jsonmap, "Prov_Tax")
			datamodel.Prov_Retirements = helper.GetFloatfromMap(jsonmap, "Prov_Retirements")
			datamodel.Prefence_Dividend = helper.GetFloatfromMap(jsonmap, "Prefence_Dividend")
			datamodel.Long_Term_Investments_Nf = helper.GetFloatfromMap(jsonmap, "Long_Term_Investments_Nf")
			datamodel.Long_Term_Quoted = helper.GetFloatfromMap(jsonmap, "Long_Term_Quoted")
			datamodel.Long_Term_Unquoted = helper.GetFloatfromMap(jsonmap, "Long_Term_Unquoted")
			datamodel.CURRENT_QUOTED = helper.GetFloatfromMap(jsonmap, "CURRENT_QUOTED")
			datamodel.Raw_Material = helper.GetFloatfromMap(jsonmap, "Raw_Material")
			datamodel.Wip = helper.GetFloatfromMap(jsonmap, "Wip")
			datamodel.Fin_Goods = helper.GetFloatfromMap(jsonmap, "Fin_Goods")
			datamodel.Packing_Materials_Inventory = helper.GetFloatfromMap(jsonmap, "Packing_Materials_Inventory")
			datamodel.Store_Spares = helper.GetFloatfromMap(jsonmap, "Store_Spares")
			datamodel.Drs_Six_Months = helper.GetFloatfromMap(jsonmap, "Drs_Six_Months")
			datamodel.Drs_Others = helper.GetFloatfromMap(jsonmap, "Drs_Others")
			datamodel.Cash_Hand = helper.GetFloatfromMap(jsonmap, "Cash_Hand")
			datamodel.Bank_Balance = helper.GetFloatfromMap(jsonmap, "Bank_Balance")
			datamodel.Interest_Investments = helper.GetFloatfromMap(jsonmap, "Interest_Investments")
			datamodel.Interest_Debentures = helper.GetFloatfromMap(jsonmap, "Interest_Debentures")
			datamodel.Deposits_Govt_Other = helper.GetFloatfromMap(jsonmap, "Deposits_Govt_Other")
			datamodel.Interest_Accrued_Due = helper.GetFloatfromMap(jsonmap, "Interest_Accrued_Due")
			datamodel.Prepaid_Exps = helper.GetFloatfromMap(jsonmap, "Prepaid_Exps")
			datamodel.Adv_Cash_Kind = helper.GetFloatfromMap(jsonmap, "Adv_Cash_Kind")
			datamodel.Adv_Tax = helper.GetFloatfromMap(jsonmap, "Adv_Tax")
			datamodel.Due_Director = helper.GetFloatfromMap(jsonmap, "Due_Director")
			datamodel.Due_Subsidiaries = helper.GetFloatfromMap(jsonmap, "Due_Subsidiaries")
			datamodel.Inter_Corporate_Deposits = helper.GetFloatfromMap(jsonmap, "Inter_Corporate_Deposits")
			datamodel.Corporate_Deposits = helper.GetFloatfromMap(jsonmap, "Corporate_Deposits")
			datamodel.Flag = helper.GetStringfromMap(jsonmap, "flag")
			//datamodel.Model = jsonmap["Model"].(int)

			// err = tx.Save(&datamodel).Error
			// if err != nil {
			// 	buffer.WriteString(err.Error())
			// }
			datamodelUpdate = append(datamodelUpdate, datamodel)
			count++

		}
		err := db.Accord.Clauses(clause.OnConflict{
			Columns:   []clause.Column{{Name: "id"}}, //, {Name: "invdate"}, {Name: "srno"}},
			DoUpdates: clause.AssignmentColumns([]string{"fincode", "year_end", "type", "no_months", "unit", "share_capital", "shares_warrants", "shares_application_money", "esop_outstanding", "share_suspense", "reserve", "sharehoders_funds", "deposits", "borrowings", "other_liabilities", "total_sounces_funds", "cash_balances_rbi", "bank_call_money", "investments", "advances", "gross_block", "acc_depreciation", "impairment_assets", "lease_adj", "cw_ip", "other_assets", "total_applications", "contingent_liabilities", "bills_for_collection", "ltrm_borrowing", "secured_loans", "unsecured_loans_nf", "net_def_tax_nf", "oth_lt_liab", "lt_trade_payables", "lt_provisions", "total_nonliab", "trade_payables", "current_liabilities_nf", "st_borrowings", "provisions", "current_laib_prov_nf", "total_sounces_funds_nf", "non_current_assets", "loan_non_cuurent_assets", "net_block", "cwip_nf", "intang_assetunderdev", "pre_operatieve_exps", "assetsintransit", "investments_nf", "lt_loanadv", "other_noc_assets", "total_nonassets", "current_investments", "inventory", "debtors", "cash_bank", "other_current_nf", "loans_adv", "currant_assets_nf", "net_current_assets_nf", "other_crnt_assets", "misc_exps_not_wo", "total_applications_nf", "total_debt_inclst_nf", "book_nav_share", "adj_bv", "minority_interest", "equity_authorised", "equity_issued", "eq_ui_ty_pa_id_up", "equity_forfeited", "adj_equity", "preference_capital", "face_value", "share_premium", "capital_reserve", "profit_loss", "general_reserve", "reserve_excl_revaluation", "revaluation_reserve", "demand_deposits", "saving_deposits", "term_fixed_deposits", "current_deposits", "recurring_deposits", "borrowings_rbi", "borrowings_banks", "borrowings_goi", "borrowings_fi", "borrowings_bonds", "borrowings_other", "borrowings_outof_india", "bills_payable", "inter_oofice_adjustments_liabilities", "interest_accrued", "proposed_dividend", "corporate_dividend_tax", "cash_rbi", "cash_in_hand", "investments_india", "goi_securities", "equity_shares_corporate", "debentures_bonds", "subsidiaries_joint_ventures", "mutual_funds_insurance_units", "investments_outside_india", "goi_securities_outside_india", "subsidiaries_joint_ventures_outside_india", "other_investments_outside_india", "dimunition_investments", "bills_purchased_discounted", "cash_credit_overdraft", "term_loans", "finance_lease_hire_purchase", "buildings", "assets_despose", "other_fix_assets", "inter_office_adjustments_assets", "interest_accrued_assets", "advance_tax_tds", "stationery_stamps", "non_banking_assets", "deferred_tax_assets", "misc_expenditures_not_writtoff", "claims_not_acknowledge_debt", "outstanding_forward_exchange_contract", "guarantees_constituents_india", "guarantees_constituents_outside_india", "acceptances_endorsements_obligations", "non_convertible_debenture", "conv_debenture_bnds", "packing_credit", "intercorpsecdeposits", "term_loan_bank", "term_loan_inst", "fixed_deposits", "loans_susidiaries", "inter_corp_deposits", "foreign_curr_convertible_notes", "foreign_curr_long_term_loans", "loans_bank", "loans_govt", "loans_others", "def_tax_assets", "def_tax_liability", "sundry_crs", "acceptances", "trade_paysubs", "bank_od", "adv_customers", "interest_not_due", "share_application", "cl_curmat_deb", "cl_curmat_others", "loans", "stbs_sec_loandemand", "stbs_wcap", "stbu_buycredit", "stbu_commborr", "proposed_divided", "prov_corp_tax", "prov_tax", "prov_retirements", "prefence_dividend", "long_term_investments_nf", "long_term_quoted", "long_term_unquoted", "current_quoted", "raw_material", "wip", "fin_goods", "packing_materials_inventory", "store_spares", "drs_six_months", "drs_others", "cash_hand", "bank_balance", "interest_investments", "interest_debentures", "deposits_govt_other", "interest_accrued_due", "prepaid_exps", "adv_cash_kind", "adv_tax", "due_director", "due_subsidiaries", "inter_corporate_deposits", "corporate_deposits", "flag"}),
			// DoUpdates: clause.AssignmentColumns([]string{"rating"}),
		}).CreateInBatches(&datamodelUpdate, 1000).Error
		if err != nil {
			fmt.Println(err)
			Zerologs.Error().Msg("Error while Inserting data into Finance_cons_bs")
		}
		Zerologs.Info().Msgf(" execution time for Finance_cons_bs ==>", time.Since(start))
		buffer.WriteString("Total Record updated " + strconv.Itoa(count) + "\n")
		return nil
	})

	// })
	return nil
}

func Finance_cf(strjson []byte, buffer *bytes.Buffer) error {
	var arryJson []interface{}
	if err := json.Unmarshal(strjson, &arryJson); err != nil {
		buffer.WriteString(err.Error() + "\n")
		return err
	}
	var datamodelUpdate []accord.Finance_cf
	count := 0
	// q.Enqueue(arryJson, func(data interface{}) {
	db.Accord.Transaction(func(tx *gorm.DB) error {
		start := time.Now()
		for _, json := range arryJson {
			jsonmap := json.(map[string]interface{})
			datamodel := accord.Finance_cf{}
			datamodel.FINCODE = helper.GetIntfromMap(jsonmap, "FINCODE")
			datamodel.Year_end = helper.GetIntfromMap(jsonmap, "Year_end")
			datamodel.Type = helper.GetStringfromMap(jsonmap, "type")
			// err := tx.Where("fincode=? AND year_end=? AND type=?", datamodel.FINCODE, datamodel.Year_end, datamodel.Type).First(&datamodel).Error
			// if err != nil {
			// 	Zerologs.Error().Msg("Record Not Found In Finance_cf" + err.Error())
			// }
			fincode := strconv.Itoa(datamodel.FINCODE)
			yearend := strconv.Itoa(datamodel.Year_end)
			datamodel.ID = fincode + "_" + yearend + "_" + datamodel.Type
			datamodel.No_Months = helper.GetIntfromMap(jsonmap, "No_Months")
			datamodel.Unit = helper.GetIntfromMap(jsonmap, "Unit")
			datamodel.Profit_bef_tax = helper.GetFloatfromMap(jsonmap, "Profit_bef_tax")
			datamodel.Adjustment_total = helper.GetFloatfromMap(jsonmap, "Adjustment_total")
			datamodel.Change_WC_total = helper.GetFloatfromMap(jsonmap, "Change_WC_total")
			datamodel.Tax_paid = helper.GetFloatfromMap(jsonmap, "Tax_paid")
			datamodel.Other_Dir_exps = helper.GetFloatfromMap(jsonmap, "Other_Dir_exps")
			datamodel.Cash_from_Operation = helper.GetFloatfromMap(jsonmap, "Cash_from_Operation")
			datamodel.Cash_from_Investment = helper.GetFloatfromMap(jsonmap, "Cash_from_Investment")
			datamodel.Cash_from_Financing = helper.GetFloatfromMap(jsonmap, "Cash_from_Financing")
			datamodel.FExchDiff = helper.GetFloatfromMap(jsonmap, "FExchDiff")
			datamodel.Net_Cash_inflow_outflow = helper.GetFloatfromMap(jsonmap, "Net_Cash_inflow_outflow")
			datamodel.Opening_cash = helper.GetFloatfromMap(jsonmap, "Opening_cash")
			datamodel.Cash_amalgmation = helper.GetFloatfromMap(jsonmap, "Cash_amalgmation")
			datamodel.Cash_subsidiaries = helper.GetFloatfromMap(jsonmap, "Cash_subsidiaries")
			datamodel.Traslation_adj_Subsidiaries = helper.GetFloatfromMap(jsonmap, "Traslation_adj_Subsidiaries")
			datamodel.Effect_foreign_exchange = helper.GetFloatfromMap(jsonmap, "Effect_foreign_exchange")
			datamodel.Closing_cash = helper.GetFloatfromMap(jsonmap, "Closing_cash")
			datamodel.Cashflow_after_WC = helper.GetFloatfromMap(jsonmap, "Cashflow_after_WC")
			datamodel.Flag = helper.GetStringfromMap(jsonmap, "Flag")

			// err = tx.Save(&datamodel).Error
			// if err != nil {
			// 	buffer.WriteString(err.Error())
			// }
			datamodelUpdate = append(datamodelUpdate, datamodel)
			count++

		}
		err := db.Accord.Clauses(clause.OnConflict{
			Columns:   []clause.Column{{Name: "id"}}, //, {Name: "invdate"}, {Name: "srno"}},
			DoUpdates: clause.AssignmentColumns([]string{"fincode", "year_end", "type", "no_months", "unit", "profit_bef_tax", "adjustment_total", "change_wc_total", "tax_paid", "other_dir_exps", "cash_from_operation", "cash_from_investment", "cash_from_financing", "f_exch_diff", "net_cash_inflow_outflow", "opening_cash", "cash_amalgmation", "cash_subsidiaries", "traslation_adj_subsidiaries", "effect_foreign_exchange", "closing_cash", "cashflow_after_wc", "flag"}),
			// DoUpdates: clause.AssignmentColumns([]string{"rating"}),
		}).CreateInBatches(&datamodelUpdate, 1000).Error
		if err != nil {
			fmt.Println(err)
			Zerologs.Error().Msg("Error while Inserting data into Finance_cf")
		}
		Zerologs.Info().Msgf(" execution time for Finance_cf ==>", time.Since(start))
		buffer.WriteString("Total Record updated " + strconv.Itoa(count) + "\n")
		return nil
	})

	// })
	return nil
}
func Finance_cons_cf(strjson []byte, buffer *bytes.Buffer) error {
	var arryJson []interface{}
	if err := json.Unmarshal(strjson, &arryJson); err != nil {
		buffer.WriteString(err.Error() + "\n")
		return err
	}
	var datamodelUpdate []accord.Finance_cons_cf
	count := 0
	// q.Enqueue(arryJson, func(data interface{}) {
	db.Accord.Transaction(func(tx *gorm.DB) error {
		start := time.Now()
		for _, json := range arryJson {
			jsonmap := json.(map[string]interface{})
			datamodel := accord.Finance_cons_cf{}
			datamodel.FINCODE = helper.GetIntfromMap(jsonmap, "FINCODE")
			datamodel.Year_end = helper.GetIntfromMap(jsonmap, "Year_end")
			datamodel.Type = helper.GetStringfromMap(jsonmap, "type")
			// err := tx.Where("fincode=? AND year_end=? AND type=?", datamodel.FINCODE, datamodel.Year_end, datamodel.Type).First(&datamodel).Error
			// if err != nil {
			// 	Zerologs.Error().Msg("Record Not Found In Finance_cons_cf" + err.Error())
			// }
			fincode := strconv.Itoa(datamodel.FINCODE)
			yearend := strconv.Itoa(datamodel.Year_end)
			datamodel.ID = fincode + "_" + yearend + "_" + datamodel.Type
			datamodel.No_Months = helper.GetIntfromMap(jsonmap, "No_Months")
			datamodel.Unit = helper.GetIntfromMap(jsonmap, "Unit")
			datamodel.Profit_bef_tax = helper.GetFloatfromMap(jsonmap, "Profit_bef_tax")
			datamodel.Adjustment_total = helper.GetFloatfromMap(jsonmap, "Adjustment_total")
			datamodel.Change_WC_total = helper.GetFloatfromMap(jsonmap, "Change_WC_total")
			datamodel.Tax_paid = helper.GetFloatfromMap(jsonmap, "Tax_paid")
			datamodel.Other_Dir_exps = helper.GetFloatfromMap(jsonmap, "Other_Dir_exps")
			datamodel.Cash_from_Operation = helper.GetFloatfromMap(jsonmap, "Cash_from_Operation")
			datamodel.Cash_from_Investment = helper.GetFloatfromMap(jsonmap, "Cash_from_Investment")
			datamodel.Cash_from_Financing = helper.GetFloatfromMap(jsonmap, "Cash_from_Financing")
			datamodel.FExchDiff = helper.GetFloatfromMap(jsonmap, "FExchDiff")
			datamodel.Net_Cash_inflow_outflow = helper.GetFloatfromMap(jsonmap, "Net_Cash_inflow_outflow")
			datamodel.Opening_cash = helper.GetFloatfromMap(jsonmap, "Opening_cash")
			datamodel.Cash_amalgmation = helper.GetFloatfromMap(jsonmap, "Cash_amalgmation")
			datamodel.Cash_subsidiaries = helper.GetFloatfromMap(jsonmap, "Cash_subsidiaries")
			datamodel.Traslation_adj_Subsidiaries = helper.GetFloatfromMap(jsonmap, "Traslation_adj_Subsidiaries")
			datamodel.Effect_foreign_exchange = helper.GetFloatfromMap(jsonmap, "Effect_foreign_exchange")
			datamodel.Closing_cash = helper.GetFloatfromMap(jsonmap, "Closing_cash")
			datamodel.Cashflow_after_WC = helper.GetFloatfromMap(jsonmap, "Cashflow_after_WC")
			datamodel.Flag = helper.GetStringfromMap(jsonmap, "Flag")

			// err = tx.Save(&datamodel).Error
			// if err != nil {
			// 	buffer.WriteString(err.Error())
			// }
			datamodelUpdate = append(datamodelUpdate, datamodel)

			count++

		}
		err := db.Accord.Clauses(clause.OnConflict{
			Columns:   []clause.Column{{Name: "id"}}, //, {Name: "invdate"}, {Name: "srno"}},
			DoUpdates: clause.AssignmentColumns([]string{"fincode", "year_end", "type", "no_months", "unit", "profit_bef_tax", "adjustment_total", "change_wc_total", "tax_paid", "other_dir_exps", "cash_from_operation", "cash_from_investment", "cash_from_financing", "f_exch_diff", "net_cash_inflow_outflow", "opening_cash", "cash_amalgmation", "cash_subsidiaries", "traslation_adj_subsidiaries", "effect_foreign_exchange", "closing_cash", "cashflow_after_wc", "flag"}),
			// DoUpdates: clause.AssignmentColumns([]string{"rating"}),
		}).CreateInBatches(&datamodelUpdate, 1000).Error
		if err != nil {
			fmt.Println(err)
			Zerologs.Error().Msg("Error while Inserting data into Finance_cons_cf")
		}
		Zerologs.Info().Msgf(" execution time for Finance_cons_cf ==>", time.Since(start))
		buffer.WriteString("Total Record updated " + strconv.Itoa(count) + "\n")
		return nil
	})

	// })
	return nil
}
func Rt_mst(strjson []byte, buffer *bytes.Buffer) error {
	var arryJson []interface{}
	if err := json.Unmarshal(strjson, &arryJson); err != nil {
		buffer.WriteString(err.Error() + "\n")
		return err
	}
	var datamodelUpdate []accord.Rt_mst
	count := 0
	// q.Enqueue(arryJson, func(data interface{}) {
	db.Accord.Transaction(func(tx *gorm.DB) error {
		start := time.Now()
		for _, json := range arryJson {
			jsonmap := json.(map[string]interface{})
			datamodel := accord.Rt_mst{}
			datamodel.Rt_code = helper.GetIntfromMap(jsonmap, "rt_code")
			// err := tx.Where("rt_code=?", datamodel.Rt_code).First(&datamodel).Error
			// if err != nil {
			// 	Zerologs.Error().Msg("Record Not Found In Rt_mst" + err.Error())
			// }
			rt_code := strconv.Itoa(datamodel.Rt_code)
			datamodel.ID = rt_code
			datamodel.Rt_name = helper.GetStringfromMap(jsonmap, "rt_name")
			datamodel.Sebi_reg_no = helper.GetStringfromMap(jsonmap, "sebi_reg_no")
			datamodel.Address1 = helper.GetStringfromMap(jsonmap, "address1")
			datamodel.Address2 = helper.GetStringfromMap(jsonmap, "address2")
			datamodel.Address3 = helper.GetStringfromMap(jsonmap, "address3")
			datamodel.State = helper.GetStringfromMap(jsonmap, "state")
			datamodel.Tel = helper.GetStringfromMap(jsonmap, "tel")
			datamodel.Fax = helper.GetStringfromMap(jsonmap, "fax")
			datamodel.Website = helper.GetStringfromMap(jsonmap, "website")
			datamodel.Reg_address = helper.GetStringfromMap(jsonmap, "reg_address")
			datamodel.Email = helper.GetStringfromMap(jsonmap, "email")
			datamodel.Flag = helper.GetStringfromMap(jsonmap, "flag")

			// err := tx.Where("rt_code=?", datamodel.Rt_code).First(&datamodel).Error
			// if err != nil {
			// 	err := tx.Create(&datamodel).Error
			// 	if err != nil {
			// 		buffer.WriteString(err.Error())
			// 	}
			// } else {
			// err = tx.Save(&datamodel).Error
			// if err != nil {
			// 	buffer.WriteString(err.Error())
			// }
			// }
			datamodelUpdate = append(datamodelUpdate, datamodel)
			count++

		}
		err := db.Accord.Clauses(clause.OnConflict{
			Columns:   []clause.Column{{Name: "id"}}, //, {Name: "invdate"}, {Name: "srno"}},
			DoUpdates: clause.AssignmentColumns([]string{"rt_code", "rt_name", "sebi_reg_no", "address1", "address2", "address3", "state", "tel", "fax", "website", "reg_address", "email", "flag"}),
			// DoUpdates: clause.AssignmentColumns([]string{"rating"}),
		}).CreateInBatches(&datamodelUpdate, 1000).Error
		if err != nil {
			fmt.Println(err)
			Zerologs.Error().Msg("Error while Inserting data into Rt_mst")
		}
		Zerologs.Info().Msgf(" execution time for Rt_mst ==>", time.Since(start))
		buffer.WriteString("Total Record updated " + strconv.Itoa(count) + "\n")
		return nil
	})

	// })
	return nil
}

func Scheme_assetalloc(strjson []byte, buffer *bytes.Buffer) error {
	var arryJson []interface{}
	if err := json.Unmarshal(strjson, &arryJson); err != nil {
		buffer.WriteString(err.Error() + "\n")
		return err
	}
	var datamodelUpdate []accord.Scheme_assetalloc
	count := 0
	// q.Enqueue(arryJson, func(data interface{}) {
	db.Accord.Transaction(func(tx *gorm.DB) error {
		start := time.Now()
		for _, json := range arryJson {
			jsonmap := json.(map[string]interface{})
			datamodel := accord.Scheme_assetalloc{}
			datamodel.Schemecode = helper.GetIntfromMap(jsonmap, "schemecode")
			datamodel.Investment = helper.GetStringfromMap(jsonmap, "investment")
			// err := tx.Where("schemecode=? AND investment=?", datamodel.Schemecode, datamodel.Investment).First(&datamodel).Error
			// if err != nil {
			// 	Zerologs.Error().Msg("Record Not Found In Scheme_assetalloc" + err.Error())
			// }
			schemecode := strconv.Itoa(datamodel.Schemecode)
			datamodel.ID = schemecode + "_" + datamodel.Investment
			datamodel.Schemeinv_id = helper.GetIntfromMap(jsonmap, "schemeinv_id")

			datamodel.Mininv = helper.GetFloatfromMap(jsonmap, "mininv")
			datamodel.Maxinv = helper.GetFloatfromMap(jsonmap, "maxinv")
			datamodel.Flag = helper.GetStringfromMap(jsonmap, "flag")

			// err := tx.Where("schemecode=? AND investment=?", datamodel.Schemecode, datamodel.Investment).First(&datamodel).Error
			// if err != nil {
			// 	err := tx.Create(&datamodel).Error
			// 	if err != nil {
			// 		buffer.WriteString(err.Error())
			// 	}
			// } else {
			// err = tx.Save(&datamodel).Error
			// if err != nil {
			// 	buffer.WriteString(err.Error())
			// }
			datamodelUpdate = append(datamodelUpdate, datamodel)
			// }
			count++

		}
		err := db.Accord.Clauses(clause.OnConflict{
			Columns:   []clause.Column{{Name: "id"}}, //, {Name: "invdate"}, {Name: "srno"}},
			DoUpdates: clause.AssignmentColumns([]string{"schemeinv_id", "schemecode", "investment", "mininv", "maxinv", "flag"}),
			// DoUpdates: clause.AssignmentColumns([]string{"rating"}),
		}).CreateInBatches(&datamodelUpdate, 1000).Error
		if err != nil {
			fmt.Println(err)
			Zerologs.Error().Msg("Error while Inserting data into Scheme_assetalloc")
		}
		Zerologs.Info().Msgf(" execution time for Scheme_assetalloc ==>", time.Since(start))
		buffer.WriteString("Total Record updated " + strconv.Itoa(count) + "\n")
		return nil
	})

	// })
	return nil
}

func Scheme_aum(strjson []byte, buffer *bytes.Buffer) error {
	var arryJson []interface{}
	if err := json.Unmarshal(strjson, &arryJson); err != nil {
		buffer.WriteString(err.Error() + "\n")
		return err
	}
	var datamodelUpdate []accord.Scheme_aum
	count := 0
	// q.Enqueue(arryJson, func(data interface{}) {
	db.Accord.Transaction(func(tx *gorm.DB) error {
		start := time.Now()
		for _, json := range arryJson {
			jsonmap := json.(map[string]interface{})
			datamodel := accord.Scheme_aum{}
			datamodel.Schemecode = helper.GetIntfromMap(jsonmap, "schemecode")
			datamodel.Date = helper.GetTimefromMap(jsonmap, "date")
			// err := tx.Where("schemecode=? AND date=?", datamodel.Schemecode, datamodel.Date).First(&datamodel).Error
			// if err != nil {
			// 	Zerologs.Error().Msg("Record Not Found In Scheme_aum" + err.Error())
			// }
			schemecode := strconv.Itoa(datamodel.Schemecode)
			date := datamodel.Date.String()
			datamodel.ID = schemecode + "_" + date
			datamodel.Exfof = helper.GetFloatfromMap(jsonmap, "exfof")
			datamodel.Fof = helper.GetFloatfromMap(jsonmap, "fof")
			datamodel.Total = helper.GetFloatfromMap(jsonmap, "total")
			datamodel.Flag = helper.GetStringfromMap(jsonmap, "flag")

			// err := tx.Where("schemecode=? AND date=?", datamodel.Schemecode, datamodel.Date).First(&datamodel).Error
			// if err != nil {
			// 	err := tx.Create(&datamodel).Error
			// 	if err != nil {
			// 		buffer.WriteString(err.Error())
			// 	}
			// } else {
			// err = tx.Save(&datamodel).Error
			// if err != nil {
			// 	buffer.WriteString(err.Error())
			// }
			datamodelUpdate = append(datamodelUpdate, datamodel)
			// }
			count++

		}
		err := db.Accord.Clauses(clause.OnConflict{
			Columns:   []clause.Column{{Name: "id"}}, //, {Name: "invdate"}, {Name: "srno"}},
			DoUpdates: clause.AssignmentColumns([]string{"schemecode", "date", "exfof", "fof", "total", "flag"}),
			// DoUpdates: clause.AssignmentColumns([]string{"rating"}),
		}).CreateInBatches(&datamodelUpdate, 1000).Error
		if err != nil {
			fmt.Println(err)
			Zerologs.Error().Msg("Error while Inserting data into Scheme_aum")
		}
		Zerologs.Info().Msgf(" execution time for Scheme_aum ==>", time.Since(start))
		buffer.WriteString("Total Record updated " + strconv.Itoa(count) + "\n")
		return nil
	})

	// })
	return nil
}

func Scheme_details(strjson []byte, buffer *bytes.Buffer) error {
	var arryJson []interface{}
	if err := json.Unmarshal(strjson, &arryJson); err != nil {
		buffer.WriteString(err.Error() + "\n")
		return err
	}
	var datamodelUpdate []accord.Scheme_details
	count := 0
	// q.Enqueue(arryJson, func(data interface{}) {
	db.Accord.Transaction(func(tx *gorm.DB) error {
		start := time.Now()
		for _, json := range arryJson {
			jsonmap := json.(map[string]interface{})
			datamodel := accord.Scheme_details{}
			datamodel.Schemecode = helper.GetIntfromMap(jsonmap, "schemecode")
			// err := tx.Where("schemecode=?", datamodel.Schemecode).First(&datamodel).Error
			// if err != nil {
			// 	Zerologs.Error().Msg("Record Not Found In Scheme_details" + err.Error())
			// }
			schemecode := strconv.Itoa(datamodel.Schemecode)
			datamodel.ID = schemecode
			datamodel.Amfi_code = helper.GetIntfromMap(jsonmap, "amfi_code")
			datamodel.Cams_code = helper.GetStringfromMap(jsonmap, "cams_code")
			datamodel.Amc_code = helper.GetIntfromMap(jsonmap, "amc_code")
			datamodel.S_name = helper.GetStringfromMap(jsonmap, "s_name")
			datamodel.Amfi_name = helper.GetStringfromMap(jsonmap, "amfi_name")
			datamodel.Isin_code = helper.GetStringfromMap(jsonmap, "isin_code")
			datamodel.Type_code = helper.GetIntfromMap(jsonmap, "type_code")
			datamodel.Opt_code = helper.GetIntfromMap(jsonmap, "opt_code")
			datamodel.Classcode = helper.GetIntfromMap(jsonmap, "classcode")
			datamodel.Theme_code = helper.GetIntfromMap(jsonmap, "theme_code")
			datamodel.Rt_code = helper.GetIntfromMap(jsonmap, "rt_code")
			datamodel.Plan = helper.GetIntfromMap(jsonmap, "plan")
			datamodel.Cust_code = helper.GetIntfromMap(jsonmap, "cust_code")
			datamodel.Cust_code2 = helper.GetIntfromMap(jsonmap, "cust_code2")
			datamodel.Price_freq = helper.GetIntfromMap(jsonmap, "price_freq")
			datamodel.Init_price = helper.GetFloatfromMap(jsonmap, "init_price")
			datamodel.Offerprice = helper.GetFloatfromMap(jsonmap, "offerprice")
			datamodel.Nfo_open = helper.GetTimefromMap(jsonmap, "nfo_open")
			datamodel.Nfo_close = helper.GetTimefromMap(jsonmap, "nfo_close")
			datamodel.Reopen_dt = helper.GetTimefromMap(jsonmap, "reopen_dt")
			datamodel.Elf = helper.GetStringfromMap(jsonmap, "elf")
			datamodel.Etf = helper.GetStringfromMap(jsonmap, "etf")
			datamodel.Stp = helper.GetStringfromMap(jsonmap, "stp")
			datamodel.Primary_fund = helper.GetStringfromMap(jsonmap, "primary_fund")
			datamodel.Primary_fd_code = helper.GetIntfromMap(jsonmap, "primary_fd_code")
			datamodel.Sip = helper.GetStringfromMap(jsonmap, "sip")
			datamodel.Swp = helper.GetStringfromMap(jsonmap, "swp")
			datamodel.Switch = helper.GetStringfromMap(jsonmap, "switch")
			datamodel.Mininvt = helper.GetFloatfromMap(jsonmap, "mininvt")
			datamodel.Multiples = helper.GetIntfromMap(jsonmap, "multiples")
			datamodel.Inc_invest = helper.GetFloatfromMap(jsonmap, "inc_invest")
			datamodel.Adnmultiples = helper.GetFloatfromMap(jsonmap, "adnmultiples")
			datamodel.Fund_mgr1 = helper.GetStringfromMap(jsonmap, "fund_mgr1")
			datamodel.Fund_mgr2 = helper.GetStringfromMap(jsonmap, "fund_mgr2")
			datamodel.Fund_mgr3 = helper.GetStringfromMap(jsonmap, "fund_mgr3")
			datamodel.Fund_mgr4 = helper.GetStringfromMap(jsonmap, "fund_mgr4")
			datamodel.Since = helper.GetTimefromMap(jsonmap, "since")
			datamodel.Status = helper.GetStringfromMap(jsonmap, "status")
			datamodel.Cutsub = helper.GetStringfromMap(jsonmap, "cutsub")
			datamodel.Cutred = helper.GetStringfromMap(jsonmap, "cutred")
			datamodel.Red = helper.GetStringfromMap(jsonmap, "red")
			datamodel.Mob_name = helper.GetStringfromMap(jsonmap, "mob_name")
			datamodel.Div_freq = helper.GetIntfromMap(jsonmap, "div_freq")
			datamodel.Scheme_symbol = helper.GetStringfromMap(jsonmap, "scheme_symbol")
			datamodel.Fund_mgr_code1 = helper.GetIntfromMap(jsonmap, "fund_mgr_code1")
			datamodel.FUND_MGR_CODE2 = helper.GetIntfromMap(jsonmap, "FUND_MGR_CODE2")
			datamodel.FUND_MGR_CODE3 = helper.GetIntfromMap(jsonmap, "FUND_MGR_CODE3")
			datamodel.FUND_MGR_CODE4 = helper.GetIntfromMap(jsonmap, "FUND_MGR_CODE4")
			datamodel.Redemption_date = helper.GetTimefromMap(jsonmap, "Redemption_date")
			datamodel.DateOfAllot = helper.GetTimefromMap(jsonmap, "DateOfAllot")
			datamodel.Div_Code = helper.GetFloatfromMap(jsonmap, "Div_Code")
			datamodel.LegalNames = helper.GetStringfromMap(jsonmap, "LegalNames")
			datamodel.AMFIType = helper.GetStringfromMap(jsonmap, "AMFIType")
			datamodel.NonTxnDay = helper.GetStringfromMap(jsonmap, "NonTxnDay")
			datamodel.SchemeBank = helper.GetStringfromMap(jsonmap, "SchemeBank")
			datamodel.SchemeBankAccountNumber = helper.GetStringfromMap(jsonmap, "SchemeBankAccountNumber")
			datamodel.SchemeBankBranch = helper.GetStringfromMap(jsonmap, "SchemeBankBranch")
			datamodel.DividendOptionFlag = helper.GetStringfromMap(jsonmap, "DividendOptionFlag")
			datamodel.LockIn = helper.GetStringfromMap(jsonmap, "LockIn")
			datamodel.IsPurchaseAvailable = helper.GetStringfromMap(jsonmap, "IsPurchaseAvailable")
			datamodel.IsRedeemAvailable = helper.GetStringfromMap(jsonmap, "IsRedeemAvailable")
			datamodel.MinRedemptionAmount = helper.GetFloatfromMap(jsonmap, "MinRedemptionAmount")
			datamodel.RedemptionMultipleAmount = helper.GetFloatfromMap(jsonmap, "RedemptionMultipleAmount")
			datamodel.MinRedemptionUnits = helper.GetFloatfromMap(jsonmap, "MinRedemptionUnits")
			datamodel.RedemptionMultiplesUnits = helper.GetFloatfromMap(jsonmap, "RedemptionMultiplesUnits")
			datamodel.MinSwitchAmount = helper.GetFloatfromMap(jsonmap, "MinSwitchAmount")
			datamodel.SwitchMultipleAmount = helper.GetFloatfromMap(jsonmap, "Switch")
			datamodel.MinSwitchUnits = helper.GetFloatfromMap(jsonmap, "MinSwitchUnits")
			datamodel.SwitchMultiplesUnits = helper.GetFloatfromMap(jsonmap, "SwitchMultiplesUnits")
			datamodel.Securitycode = helper.GetStringfromMap(jsonmap, "securitycode")
			datamodel.Unit = helper.GetStringfromMap(jsonmap, "unit")
			datamodel.SwitchOut = helper.GetStringfromMap(jsonmap, "SwitchOut")
			datamodel.MinSwitchOutAmount = helper.GetFloatfromMap(jsonmap, "MinSwitchOutAmount")
			datamodel.SwitchOutMultipleAmount = helper.GetFloatfromMap(jsonmap, "SwitchOutMultipleAmount")
			datamodel.MinSwitchOutUnits = helper.GetFloatfromMap(jsonmap, "MinSwitchOutUnits")
			datamodel.SwitchOutMultiplesUnits = helper.GetFloatfromMap(jsonmap, "SwitchOutMultiplesUnits")
			datamodel.Incept_date = helper.GetTimefromMap(jsonmap, "Incept_date")
			datamodel.Incept_Nav = helper.GetFloatfromMap(jsonmap, "Incept_Nav")
			datamodel.DefaultOpt = helper.GetStringfromMap(jsonmap, "DefaultOpt")
			datamodel.DefaultPlan = helper.GetStringfromMap(jsonmap, "DefaultPlan")
			datamodel.LockPeriod = helper.GetIntfromMap(jsonmap, "LockPeriod")
			datamodel.ODDraftDate = helper.GetTimefromMap(jsonmap, "ODDraftDate")
			datamodel.Liquidated_Date = helper.GetTimefromMap(jsonmap, "Liquidated_Date")
			datamodel.Old_Plan = helper.GetIntfromMap(jsonmap, "Old_Plan")
			datamodel.Direct_Plan = helper.GetIntfromMap(jsonmap, "Direct_Plan")
			datamodel.OptionType = helper.GetStringfromMap(jsonmap, "optionType")
			datamodel.Flag = helper.GetStringfromMap(jsonmap, "flag")

			// err := tx.Where("schemecode=?", datamodel.Schemecode).First(&datamodel).Error
			// if err != nil {
			// 	err := tx.Create(&datamodel).Error
			// 	if err != nil {
			// 		buffer.WriteString(err.Error())
			// 	}
			// } else {
			// err = tx.Save(&datamodel).Error
			// if err != nil {
			// 	buffer.WriteString(err.Error())
			// }
			datamodelUpdate = append(datamodelUpdate, datamodel)
			// }
			count++

		}
		err := db.Accord.Clauses(clause.OnConflict{
			Columns:   []clause.Column{{Name: "id"}}, //, {Name: "invdate"}, {Name: "srno"}},
			DoUpdates: clause.AssignmentColumns([]string{"schemecode", "amfi_code", "cams_code", "amc_code", "s_name", "amfi_name", "isin_code", "type_code", "opt_code", "classcode", "theme_code", "rt_code", "plan", "cust_code", "cust_code2", "price_freq", "init_price", "offerprice", "nfo_open", "nfo_close", "reopen_dt", "elf", "etf", "stp", "primary_fund", "primary_fd_code", "sip", "swp", "switch", "mininvt", "multiples", "inc_invest", "adnmultiples", "fund_mgr1", "fund_mgr2", "fund_mgr3", "fund_mgr4", "since", "status", "cutsub", "cutred", "red", "mob_name", "div_freq", "scheme_symbol", "fund_mgr_code1", "fund_mgr_code2", "fund_mgr_code3", "fund_mgr_code4", "redemption_date", "date_of_allot", "div_code", "legal_names", "amfi_type", "non_txn_day", "scheme_bank", "scheme_bank_account_number", "scheme_bank_branch", "dividend_option_flag", "lock_in", "is_purchase_available", "is_redeem_available", "min_redemption_amount", "redemption_multiple_amount", "min_redemption_units", "redemption_multiples_units", "min_switch_amount", "switch_multiple_amount", "min_switch_units", "switch_multiples_units", "securitycode", "unit", "switch_out", "min_switch_out_amount", "switch_out_multiple_amount", "min_switch_out_units", "switch_out_multiples_units", "incept_date", "incept_nav", "default_opt", "default_plan", "lock_period", "od_draft_date", "liquidated_date", "old_plan", "direct_plan", "option_type", "flag"}),
			// DoUpdates: clause.AssignmentColumns([]string{"rating"}),
		}).CreateInBatches(&datamodelUpdate, 300).Error
		if err != nil {
			fmt.Println(err)
			Zerologs.Error().Msg("Error while Inserting data into Scheme_details")
		}
		Zerologs.Info().Msgf(" execution time for Scheme_details ==>", time.Since(start))
		buffer.WriteString("Total Record updated " + strconv.Itoa(count) + "\n")
		return nil
	})

	// })
	return nil
}

func Scheme_eq_details(strjson []byte, buffer *bytes.Buffer) error {
	var arryJson []interface{}
	if err := json.Unmarshal(strjson, &arryJson); err != nil {
		buffer.WriteString(err.Error() + "\n")
		return err
	}
	var datamodelUpdate []accord.Scheme_eq_details
	count := 0
	// q.Enqueue(arryJson, func(data interface{}) {
	db.Accord.Transaction(func(tx *gorm.DB) error {
		start := time.Now()
		for _, json := range arryJson {
			jsonmap := json.(map[string]interface{})
			datamodel := accord.Scheme_eq_details{}
			datamodel.SchemeCode = helper.GetIntfromMap(jsonmap, "SchemeCode")
			// err := tx.Where("schemecode=?", datamodel.SchemeCode).First(&datamodel).Error
			// if err != nil {
			// 	Zerologs.Error().Msg("Record Not Found In Scheme_eq_details" + err.Error())
			// }
			schemecode := strconv.Itoa(datamodel.SchemeCode)
			datamodel.ID = schemecode
			datamodel.MonthEnd = helper.GetIntfromMap(jsonmap, "MonthEnd")
			datamodel.MCAP = helper.GetFloatfromMap(jsonmap, "MCAP")
			datamodel.PE = helper.GetFloatfromMap(jsonmap, "PE")
			datamodel.PB = helper.GetFloatfromMap(jsonmap, "PB")
			datamodel.Div_Yield = helper.GetFloatfromMap(jsonmap, "Div_Yield")
			datamodel.FLAG = helper.GetStringfromMap(jsonmap, "FLAG")

			// err := tx.Where("schemecode=?", datamodel.SchemeCode).First(&datamodel).Error
			// if err != nil {
			// 	err := tx.Create(&datamodel).Error
			// 	if err != nil {
			// 		buffer.WriteString(err.Error())
			// 	}
			// } else {
			// err = tx.Save(&datamodel).Error
			// if err != nil {
			// 	buffer.WriteString(err.Error())
			// }
			datamodelUpdate = append(datamodelUpdate, datamodel)
			// }
			count++

		}
		err := db.Accord.Clauses(clause.OnConflict{
			Columns:   []clause.Column{{Name: "id"}}, //, {Name: "invdate"}, {Name: "srno"}},
			DoUpdates: clause.AssignmentColumns([]string{"scheme_code", "month_end", "mcap", "pe", "pb", "div_yield", "flag"}),
			// DoUpdates: clause.AssignmentColumns([]string{"rating"}),
		}).CreateInBatches(&datamodelUpdate, 1000).Error
		if err != nil {
			fmt.Println(err)
			Zerologs.Error().Msg("Error while Inserting data into Scheme_eq_details")
		}
		Zerologs.Info().Msgf(" execution time for Scheme_eq_details ==>", time.Since(start))
		buffer.WriteString("Total Record updated " + strconv.Itoa(count) + "\n")
		return nil
	})

	// })
	return nil
}

func Scheme_index_part(strjson []byte, buffer *bytes.Buffer) error {
	var arryJson []interface{}
	if err := json.Unmarshal(strjson, &arryJson); err != nil {
		buffer.WriteString(err.Error() + "\n")
		return err
	}
	var datamodelUpdate []accord.Scheme_index_part
	count := 0
	// q.Enqueue(arryJson, func(data interface{}) {
	db.Accord.Transaction(func(tx *gorm.DB) error {
		start := time.Now()
		for _, json := range arryJson {
			jsonmap := json.(map[string]interface{})
			datamodel := accord.Scheme_index_part{}
			datamodel.SCHEMECODE = helper.GetIntfromMap(jsonmap, "SCHEMECODE")
			datamodel.INDEXCODE = helper.GetIntfromMap(jsonmap, "INDEXCODE")
			// err := tx.Where("schemecode=? AND indexcode=?", datamodel.SCHEMECODE, datamodel.INDEXCODE).First(&datamodel).Error
			// if err != nil {
			// 	Zerologs.Error().Msg("Record Not Found In Scheme_index_part" + err.Error())
			// }
			schemecode := strconv.Itoa(datamodel.SCHEMECODE)
			indexcode := strconv.Itoa(datamodel.INDEXCODE)
			datamodel.ID = schemecode + "_" + indexcode
			datamodel.Benchmark_Weightage = helper.GetFloatfromMap(jsonmap, "Benchmark_Weightage")
			datamodel.IndexOrder = helper.GetIntfromMap(jsonmap, "IndexOrder")
			datamodel.Remark = helper.GetStringfromMap(jsonmap, "Remark")
			datamodel.FLAG = helper.GetStringfromMap(jsonmap, "FLAG")

			// err := tx.Where("schemecode=? AND indexcode=?", datamodel.SCHEMECODE, datamodel.INDEXCODE).First(&datamodel).Error
			// if err != nil {
			// 	err := tx.Create(&datamodel).Error
			// 	if err != nil {
			// 		buffer.WriteString(err.Error())
			// 	}
			// } else {
			// err = tx.Save(&datamodel).Error
			// if err != nil {
			// 	buffer.WriteString(err.Error())
			// }
			datamodelUpdate = append(datamodelUpdate, datamodel)
			// }
			count++

		}
		err := db.Accord.Clauses(clause.OnConflict{
			Columns:   []clause.Column{{Name: "id"}}, //, {Name: "invdate"}, {Name: "srno"}},
			DoUpdates: clause.AssignmentColumns([]string{"schemecode", "indexcode", "benchmark_weightage", "index_order", "remark", "flag"}),
			// DoUpdates: clause.AssignmentColumns([]string{"rating"}),
		}).CreateInBatches(&datamodelUpdate, 1000).Error
		if err != nil {
			fmt.Println(err)
			Zerologs.Error().Msg("Error while Inserting data into Scheme_index_part")
		}
		Zerologs.Info().Msgf(" execution time for Scheme_index_part ==>", time.Since(start))
		buffer.WriteString("Total Record updated " + strconv.Itoa(count) + "\n")
		return nil
	})

	// })
	return nil
}

func Option_mst(strjson []byte, buffer *bytes.Buffer) error {

	var arryJson []interface{}
	if err := json.Unmarshal(strjson, &arryJson); err != nil {
		buffer.WriteString(err.Error() + "\n")
		return err
	}
	var datamodelUpdate []accord.Option_mst
	count := 0
	// q.Enqueue(arryJson, func(data interface{}) {
	db.Accord.Transaction(func(tx *gorm.DB) error {
		start := time.Now()
		for _, json := range arryJson {
			jsonmap := json.(map[string]interface{})
			datamodel := accord.Option_mst{}
			datamodel.Opt_code = helper.GetIntfromMap(jsonmap, "opt_code")
			// err := tx.Where("opt_code=?", datamodel.Opt_code).First(&datamodel).Error
			// if err != nil {
			// 	Zerologs.Error().Msg("Record Not Found In Option_mst" + err.Error())
			// }
			opt_code := strconv.Itoa(datamodel.Opt_code)
			datamodel.ID = opt_code
			datamodel.Option = helper.GetStringfromMap(jsonmap, "option")
			datamodel.Flag = helper.GetStringfromMap(jsonmap, "flag")

			// err := tx.Where("opt_code=?", datamodel.Opt_code).First(&datamodel).Error
			// if err != nil {
			// 	err := tx.Create(&datamodel).Error
			// 	if err != nil {
			// 		buffer.WriteString(err.Error())
			// 	}
			// } else {
			// err = tx.Save(&datamodel).Error
			// if err != nil {
			// 	buffer.WriteString(err.Error())
			// }
			datamodelUpdate = append(datamodelUpdate, datamodel)
			// }
			count++

		}
		err := db.Accord.Clauses(clause.OnConflict{
			Columns:   []clause.Column{{Name: "id"}}, //, {Name: "invdate"}, {Name: "srno"}},
			DoUpdates: clause.AssignmentColumns([]string{"opt_code", "option", "flag"}),
			// DoUpdates: clause.AssignmentColumns([]string{"rating"}),
		}).CreateInBatches(&datamodelUpdate, 1000).Error
		if err != nil {
			fmt.Println(err)
			Zerologs.Error().Msg("Error while Inserting data into Option_mst")
		}
		Zerologs.Info().Msgf(" execution time for Option_mst ==>", time.Since(start))
		buffer.WriteString("Total Record updated " + strconv.Itoa(count) + "\n")
		return nil
	})

	// })
	return nil
}
func Navhist_HL(strjson []byte, buffer *bytes.Buffer) error {
	var arryJson []interface{}
	if err := json.Unmarshal(strjson, &arryJson); err != nil {
		buffer.WriteString(err.Error() + "\n")
		return err
	}
	var datamodelUpdate []accord.Navhist_HL
	count := 0
	// q.Enqueue(arryJson, func(data interface{}) {
	db.Accord.Transaction(func(tx *gorm.DB) error {
		start := time.Now()
		for _, json := range arryJson {
			jsonmap := json.(map[string]interface{})
			datamodel := accord.Navhist_HL{}
			datamodel.Schemecode = helper.GetIntfromMap(jsonmap, "schemecode")
			// err := tx.Where("schemecode=?", datamodel.Schemecode).First(&datamodel).Error
			// if err != nil {
			// 	Zerologs.Error().Msg("Record Not Found In Navhist_HL" + err.Error())
			// }
			schemecode := strconv.Itoa(datamodel.Schemecode)
			datamodel.ID = schemecode
			datamodel.Monthhhigh3 = helper.GetFloatfromMap(jsonmap, "3monthhhigh")
			datamodel.Monthlow3 = helper.GetFloatfromMap(jsonmap, "3monthlow")
			datamodel.Mhdate3 = helper.GetTimefromMap(jsonmap, "3mhdate")
			datamodel.Mldate3 = helper.GetTimefromMap(jsonmap, "3mldate")
			datamodel.Monthhhigh6 = helper.GetFloatfromMap(jsonmap, "6monthhhigh")
			datamodel.Monthlow6 = helper.GetFloatfromMap(jsonmap, "6monthlow")
			datamodel.Mhdate6 = helper.GetTimefromMap(jsonmap, "6mhdate")
			datamodel.Mldate6 = helper.GetTimefromMap(jsonmap, "6mldate")
			datamodel.Monthhhigh9 = helper.GetFloatfromMap(jsonmap, "9monthhhigh")
			datamodel.Monthlow9 = helper.GetFloatfromMap(jsonmap, "9monthlow")
			datamodel.Mhdate9 = helper.GetTimefromMap(jsonmap, "9mhdate")
			datamodel.Mldate9 = helper.GetTimefromMap(jsonmap, "9mldate")
			datamodel.Weekhhigh52 = helper.GetFloatfromMap(jsonmap, "52weekhhigh")
			datamodel.Weeklow52 = helper.GetFloatfromMap(jsonmap, "52weeklow")
			datamodel.Whdate52 = helper.GetTimefromMap(jsonmap, "52whdate")
			datamodel.Wldate52 = helper.GetTimefromMap(jsonmap, "52wldate")
			datamodel.Yrhigh1 = helper.GetFloatfromMap(jsonmap, "1yrhigh")
			datamodel.Yrlow1 = helper.GetFloatfromMap(jsonmap, "1yrlow")
			datamodel.Yhdate1 = helper.GetTimefromMap(jsonmap, "1yhdate")
			datamodel.Yldate1 = helper.GetTimefromMap(jsonmap, "1yldate")
			datamodel.Yrhigh2 = helper.GetFloatfromMap(jsonmap, "2yrhigh")
			datamodel.Yrlow2 = helper.GetFloatfromMap(jsonmap, "2yrlow")
			datamodel.Yhdate2 = helper.GetTimefromMap(jsonmap, "2yhdate")
			datamodel.Yldate2 = helper.GetTimefromMap(jsonmap, "2yldate")
			datamodel.Yrhigh3 = helper.GetFloatfromMap(jsonmap, "3yrhigh")
			datamodel.Yrlow3 = helper.GetFloatfromMap(jsonmap, "3yrlow")
			datamodel.Yhdate3 = helper.GetTimefromMap(jsonmap, "3yhdate")
			datamodel.Yldate3 = helper.GetTimefromMap(jsonmap, "3yldate")
			datamodel.Yrhigh5 = helper.GetFloatfromMap(jsonmap, "5yrhigh")
			datamodel.Yrlow5 = helper.GetFloatfromMap(jsonmap, "5yrlow")
			datamodel.Yhdate5 = helper.GetTimefromMap(jsonmap, "5yhdate")
			datamodel.Yldate5 = helper.GetTimefromMap(jsonmap, "5yldate")
			datamodel.Ytdhigh = helper.GetFloatfromMap(jsonmap, "ytdhigh")
			datamodel.Ytdlow = helper.GetFloatfromMap(jsonmap, "ytdlow")

			datamodel.Ytdhdate = helper.GetTimefromMap(jsonmap, "ytdldate")
			datamodel.Ytdldate = helper.GetTimefromMap(jsonmap, "ytdldate")
			datamodel.Sihigh = helper.GetFloatfromMap(jsonmap, "sihigh")
			datamodel.Silow = helper.GetFloatfromMap(jsonmap, "siLow")
			datamodel.Sihdate = helper.GetTimefromMap(jsonmap, "sihdate")
			datamodel.Sildate = helper.GetTimefromMap(jsonmap, "sildate")

			datamodel.Flag = helper.GetStringfromMap(jsonmap, "flag")

			// err := tx.Where("schemecode=?", datamodel.Schemecode).First(&datamodel).Error
			// if err != nil {
			// 	err := tx.Create(&datamodel).Error
			// 	if err != nil {
			// 		buffer.WriteString(err.Error())
			// 	}
			// } else {
			// err = tx.Save(&datamodel).Error
			// if err != nil {
			// 	buffer.WriteString(err.Error())
			// }
			datamodelUpdate = append(datamodelUpdate, datamodel)
			// }
			count++

		}
		err := db.Accord.Clauses(clause.OnConflict{
			Columns:   []clause.Column{{Name: "id"}}, //, {Name: "invdate"}, {Name: "srno"}},
			DoUpdates: clause.AssignmentColumns([]string{"schemecode", "monthhhigh3", "monthlow3", "mhdate3", "mldate3", "monthhhigh6", "monthlow6", "mhdate6", "mldate6", "monthhhigh9", "monthlow9", "mhdate9", "mldate9", "weekhhigh52", "weeklow52", "whdate52", "wldate52", "yrhigh1", "yrlow1", "yhdate1", "yldate1", "yrhigh2", "yrlow2", "yhdate2", "yldate2", "yrhigh3", "yrlow3", "yhdate3", "yldate3", "yrhigh5", "yrlow5", "yhdate5", "yldate5", "ytdhigh", "ytdlow", "ytdhdate", "ytdldate", "sihigh", "silow", "sihdate", "sildate", "flag"}),
			// DoUpdates: clause.AssignmentColumns([]string{"rating"}),
		}).CreateInBatches(&datamodelUpdate, 1000).Error
		if err != nil {
			fmt.Println(err)
			Zerologs.Error().Msg("Error while Inserting data into Navhist_HL")
		}
		Zerologs.Info().Msgf(" execution time for Navhist_HL ==>", time.Since(start))
		buffer.WriteString("Total Record updated " + strconv.Itoa(count) + "\n")
		return nil
	})

	// })
	return nil
}
func Navhist(strjson []byte, buffer *bytes.Buffer) error {
	var arryJson []interface{}
	if err := json.Unmarshal(strjson, &arryJson); err != nil {
		buffer.WriteString(err.Error() + "\n")
		return err
	}
	var datamodelUpdate []accord.Navhist
	count := 0
	// q.Enqueue(arryJson, func(data interface{}) {
	db.Accord.Transaction(func(tx *gorm.DB) error {
		start := time.Now()
		for _, json := range arryJson {
			jsonmap := json.(map[string]interface{})
			datamodel := accord.Navhist{}
			datamodel.Schemecode = helper.GetIntfromMap(jsonmap, "schemecode")
			datamodel.Navdate = helper.GetTimefromMap(jsonmap, "navdate")
			// err := tx.Where("schemecode=? AND navdate=?", datamodel.Schemecode, datamodel.Navdate).First(&datamodel).Error
			// if err != nil {
			// 	Zerologs.Error().Msg("Record Not Found In Navhist" + err.Error())
			// }
			schemecode := strconv.Itoa(datamodel.Schemecode)
			navdate := datamodel.Navdate.String()
			datamodel.ID = schemecode + "_" + navdate
			datamodel.Navrs = helper.GetFloatfromMap(jsonmap, "navrs")
			datamodel.Repurprice = helper.GetFloatfromMap(jsonmap, "repurprice")
			datamodel.Adjustednav_c = helper.GetFloatfromMap(jsonmap, "adjustednav_c")
			datamodel.Adjustednav_nonc = helper.GetFloatfromMap(jsonmap, "adjustednav_nonc")

			datamodel.Saleprice = helper.GetFloatfromMap(jsonmap, "saleprice")
			datamodel.Flag = helper.GetStringfromMap(jsonmap, "flag")

			// err := tx.Where("schemecode=? AND navdate ", datamodel.Schemecode, datamodel.Navdate).First(&datamodel).Error
			// if err != nil {
			// 	err := tx.Create(&datamodel).Error
			// 	if err != nil {
			// 		buffer.WriteString(err.Error())
			// 	}
			// } else {
			// err = tx.Save(&datamodel).Error
			// if err != nil {
			// 	buffer.WriteString(err.Error())
			// }
			datamodelUpdate = append(datamodelUpdate, datamodel)
			// }
			count++
		}
		err := db.Accord.Clauses(clause.OnConflict{
			Columns:   []clause.Column{{Name: "id"}}, //, {Name: "invdate"}, {Name: "srno"}},
			DoUpdates: clause.AssignmentColumns([]string{"schemecode", "navdate", "navrs", "repurprice", "saleprice", "adjustednav_c", "adjustednav_nonc", "flag"}),
			// DoUpdates: clause.AssignmentColumns([]string{"rating"}),
		}).CreateInBatches(&datamodelUpdate, 500).Error
		if err != nil {
			fmt.Println(err)
			Zerologs.Error().Msg("Error while Inserting data into Navhist")
		}
		Zerologs.Info().Msgf(" execution time for Navhist ==>", time.Since(start))
		buffer.WriteString("Total Record updated " + strconv.Itoa(count) + "\n")
		return nil
	})

	// })
	return nil
}

func Asect_mst(strjson []byte, buffer *bytes.Buffer) error {
	var arryJson []interface{}
	if err := json.Unmarshal(strjson, &arryJson); err != nil {
		buffer.WriteString(err.Error() + "\n")
		return err
	}
	var datamodelUpdate []accord.Asect_mst
	count := 0
	// q.Enqueue(arryJson, func(data interface{}) {
	db.Accord.Transaction(func(tx *gorm.DB) error {
		start := time.Now()
		for _, json := range arryJson {
			jsonmap := json.(map[string]interface{})
			datamodel := accord.Asect_mst{}
			datamodel.Asect_code = helper.GetFloatfromMap(jsonmap, "asect_code")
			// err := tx.Where("asect_code=?", datamodel.Asect_code).First(&datamodel).Error
			// if err != nil {
			// 	Zerologs.Error().Msg("Record Not Found In Asect_mst" + err.Error())
			// }
			asect_code := fmt.Sprintf("%v", datamodel.Asect_code)
			datamodel.ID = asect_code
			datamodel.Asect_type = helper.GetStringfromMap(jsonmap, "asect_type")
			datamodel.Asset = helper.GetStringfromMap(jsonmap, "asset")
			datamodel.As_name = helper.GetStringfromMap(jsonmap, "as_name")
			datamodel.Flag = helper.GetStringfromMap(jsonmap, "flag")
			// err := tx.Where("asect_code=?", datamodel.Asect_code).First(&datamodel).Error
			// if err != nil {
			// 	err := tx.Create(&datamodel).Error
			// 	if err != nil {
			// 		buffer.WriteString(err.Error())
			// 	}
			// } else {
			// err = tx.Save(&datamodel).Error
			// if err != nil {
			// 	buffer.WriteString(err.Error())
			// }
			datamodelUpdate = append(datamodelUpdate, datamodel)
			// }
			count++

		}
		err := db.Accord.Clauses(clause.OnConflict{
			Columns:   []clause.Column{{Name: "id"}}, //, {Name: "invdate"}, {Name: "srno"}},
			DoUpdates: clause.AssignmentColumns([]string{"asect_code", "asect_type", "asset", "as_name", "flag"}),
			// DoUpdates: clause.AssignmentColumns([]string{"rating"}),
		}).CreateInBatches(&datamodelUpdate, 1000).Error
		if err != nil {
			fmt.Println(err)
			Zerologs.Error().Msg("Error while Inserting data into Asect_mst")
		}
		Zerologs.Info().Msgf(" execution time for Asect_mst ==>", time.Since(start))
		buffer.WriteString("Total Record updated " + strconv.Itoa(count) + "\n")
		return nil
	})

	// })
	return nil
}

func Div_mst(strjson []byte, buffer *bytes.Buffer) error {
	var arryJson []interface{}
	if err := json.Unmarshal(strjson, &arryJson); err != nil {
		buffer.WriteString(err.Error() + "\n")
		return err
	}
	var datamodelUpdate []accord.Div_mst
	count := 0
	// q.Enqueue(arryJson, func(data interface{}) {
	db.Accord.Transaction(func(tx *gorm.DB) error {
		start := time.Now()
		for _, json := range arryJson {
			jsonmap := json.(map[string]interface{})
			datamodel := accord.Div_mst{}
			datamodel.Div_code = helper.GetFloatfromMap(jsonmap, "div_code")
			// err := tx.Where("div_code=?", datamodel.Div_code).First(&datamodel).Error
			// if err != nil {
			// 	Zerologs.Error().Msg("Record Not Found In Div_mst" + err.Error())
			// }
			divcode := fmt.Sprintf("%v", datamodel.Div_code)
			datamodel.ID = divcode
			datamodel.Div_type = helper.GetStringfromMap(jsonmap, "div_type")
			datamodel.Flag = helper.GetStringfromMap(jsonmap, "flag")
			// err := tx.Where("div_code=?", datamodel.Div_code).First(&datamodel).Error
			// if err != nil {
			// 	err := tx.Create(&datamodel).Error
			// 	if err != nil {
			// 		buffer.WriteString(err.Error())
			// 	}
			// } else {
			// err = tx.Save(&datamodel).Error
			// if err != nil {
			// 	buffer.WriteString(err.Error())
			// }
			datamodelUpdate = append(datamodelUpdate, datamodel)
			// }
			count++

		}
		err := db.Accord.Clauses(clause.OnConflict{
			Columns:   []clause.Column{{Name: "id"}}, //, {Name: "invdate"}, {Name: "srno"}},
			DoUpdates: clause.AssignmentColumns([]string{"div_code", "div_type", "flag"}),
			// DoUpdates: clause.AssignmentColumns([]string{"rating"}),
		}).CreateInBatches(&datamodelUpdate, 1000).Error
		if err != nil {
			fmt.Println(err)
			Zerologs.Error().Msg("Error while Inserting data into Div_mst")
		}
		Zerologs.Info().Msgf(" execution time for Div_mst ==>", time.Since(start))
		buffer.WriteString("Total Record updated " + strconv.Itoa(count) + "\n")
		return nil
	})

	// })
	return nil
}
func Amc_paum(strjson []byte, buffer *bytes.Buffer) error {
	var arryJson []interface{}
	if err := json.Unmarshal(strjson, &arryJson); err != nil {
		buffer.WriteString(err.Error() + "\n")
		return err
	}
	var datamodelUpdate []accord.Amc_paum
	count := 0
	// q.Enqueue(arryJson, func(data interface{}) {
	db.Accord.Transaction(func(tx *gorm.DB) error {
		start := time.Now()
		for _, json := range arryJson {
			jsonmap := json.(map[string]interface{})
			datamodel := accord.Amc_paum{}
			datamodel.Amc_code = helper.GetIntfromMap(jsonmap, "amc_code")
			datamodel.Aumdate = helper.GetTimefromMap(jsonmap, "aumdate")
			// err := tx.Where("amc_code=? AND aumdate=?", datamodel.Amc_code, datamodel.Aumdate).First(&datamodel).Error
			// if err != nil {
			// 	Zerologs.Error().Msg("Record Not Found In Amc_paum" + err.Error())
			// }
			amc_code := strconv.Itoa(datamodel.Amc_code)
			aum_date := datamodel.Aumdate.String()
			datamodel.ID = amc_code + "_" + aum_date
			datamodel.Totalaum = helper.GetFloatfromMap(jsonmap, "totalaum")
			datamodel.FLAG = helper.GetStringfromMap(jsonmap, "FLAG")
			// err := tx.Where("amc_code=? AND aumdate=?", datamodel.Amc_code, datamodel.Aumdate).First(&datamodel).Error
			// if err != nil {
			// 	err := tx.Create(&datamodel).Error
			// 	if err != nil {
			// 		buffer.WriteString(err.Error())
			// 	}
			// } else {
			// err = tx.Save(&datamodel).Error
			// if err != nil {
			// 	buffer.WriteString(err.Error())
			// }
			datamodelUpdate = append(datamodelUpdate, datamodel)
			// }
			count++

		}
		err := db.Accord.Clauses(clause.OnConflict{
			Columns:   []clause.Column{{Name: "id"}}, //, {Name: "invdate"}, {Name: "srno"}},
			DoUpdates: clause.AssignmentColumns([]string{"amc_code", "aumdate", "totalaum", "flag"}),
			// DoUpdates: clause.AssignmentColumns([]string{"rating"}),
		}).CreateInBatches(&datamodelUpdate, 1000).Error
		if err != nil {
			fmt.Println(err)
			Zerologs.Error().Msg("Error while Inserting data into Amc_paum")
		}
		Zerologs.Info().Msgf(" execution time for Amc_paum ==>", time.Since(start))
		buffer.WriteString("Total Record updated " + strconv.Itoa(count) + "\n")
		return nil
	})

	// })
	return nil
}
func Cust_mst(strjson []byte, buffer *bytes.Buffer) error {
	var arryJson []interface{}
	if err := json.Unmarshal(strjson, &arryJson); err != nil {
		buffer.WriteString(err.Error() + "\n")
		return err
	}
	var datamodelUpdate []accord.Cust_mst
	count := 0
	// q.Enqueue(arryJson, func(data interface{}) {
	db.Accord.Transaction(func(tx *gorm.DB) error {
		start := time.Now()
		for _, json := range arryJson {
			jsonmap := json.(map[string]interface{})
			datamodel := accord.Cust_mst{}
			datamodel.Cust_code = helper.GetIntfromMap(jsonmap, "cust_code")
			// err := tx.Where("cust_code=?", datamodel.Cust_code).First(&datamodel).Error
			// if err != nil {
			// 	Zerologs.Error().Msg("Record Not Found In Cust_mst" + err.Error())
			// }
			cust_code := strconv.Itoa(datamodel.Cust_code)
			datamodel.ID = cust_code
			datamodel.Cust_name = helper.GetStringfromMap(jsonmap, "cust_name")
			datamodel.Sebi_reg_no = helper.GetStringfromMap(jsonmap, "sebi_reg_no")
			datamodel.Add1 = helper.GetStringfromMap(jsonmap, "add1")
			datamodel.Add2 = helper.GetStringfromMap(jsonmap, "add2")
			datamodel.Add3 = helper.GetStringfromMap(jsonmap, "add3")
			datamodel.Flag = helper.GetStringfromMap(jsonmap, "flag")
			// err := tx.Where("cust_code=?", datamodel.Cust_code).First(&datamodel).Error
			// if err != nil {
			// 	err := tx.Create(&datamodel).Error
			// 	if err != nil {
			// 		buffer.WriteString(err.Error())
			// 	}
			// } else {
			//
			datamodelUpdate = append(datamodelUpdate, datamodel)
			// }
			count++

		}
		err := db.Accord.Clauses(clause.OnConflict{
			Columns:   []clause.Column{{Name: "id"}}, //, {Name: "invdate"}, {Name: "srno"}},
			DoUpdates: clause.AssignmentColumns([]string{"cust_code", "cust_name", "sebi_reg_no", "add1", "add2", "add3", "flag"}),
			// DoUpdates: clause.AssignmentColumns([]string{"rating"}),
		}).CreateInBatches(&datamodelUpdate, 1000).Error
		if err != nil {
			fmt.Println(err)
			Zerologs.Error().Msg("Error while Inserting data into Cust_mst")
		}
		Zerologs.Info().Msgf(" execution time for Cust_mst ==>", time.Since(start))
		buffer.WriteString("Total Record updated " + strconv.Itoa(count) + "\n")
		return nil
	})

	// })
	return nil
}
func Amc_aum(strjson []byte, buffer *bytes.Buffer) error {
	var arryJson []interface{}
	if err := json.Unmarshal(strjson, &arryJson); err != nil {
		buffer.WriteString(err.Error() + "\n")
		return err
	}
	var datamodelUpdate []accord.Amc_aum
	count := 0
	// q.Enqueue(arryJson, func(data interface{}) {
	db.Accord.Transaction(func(tx *gorm.DB) error {
		start := time.Now()
		for _, json := range arryJson {
			jsonmap := json.(map[string]interface{})
			datamodel := accord.Amc_aum{}
			datamodel.Amc_code = helper.GetIntfromMap(jsonmap, "amc_code")
			datamodel.Aumdate = helper.GetTimefromMap(jsonmap, "aumdate")
			// err := tx.Where("amc_code=? and aumdate=?", datamodel.Amc_code, datamodel.Aumdate).First(&datamodel).Error
			// if err != nil {
			// 	Zerologs.Error().Msg("Record Not Found In Amc_aum" + err.Error())
			// }
			amc_code := strconv.Itoa(datamodel.Amc_code)
			aumdate := datamodel.Aumdate.String()
			datamodel.ID = amc_code + "_" + aumdate
			datamodel.Totalaum = helper.GetFloatfromMap(jsonmap, "totalaum")
			datamodel.Flag = helper.GetStringfromMap(jsonmap, "flag")
			// err := tx.Where("amc_code=? and aumdate=?", datamodel.Amc_code, datamodel.Aumdate).First(&datamodel).Error
			// if err != nil {
			// 	err := tx.Create(&datamodel).Error
			// 	if err != nil {
			// 		buffer.WriteString(err.Error())
			// 	}
			// } else {
			// err = tx.Save(&datamodel).Error
			// if err != nil {
			// 	buffer.WriteString(err.Error())
			// }
			datamodelUpdate = append(datamodelUpdate, datamodel)
			// }
			count++

		}
		err := db.Accord.Clauses(clause.OnConflict{
			Columns:   []clause.Column{{Name: "id"}}, //, {Name: "invdate"}, {Name: "srno"}},
			DoUpdates: clause.AssignmentColumns([]string{"amc_code", "aumdate", "totalaum", "flag"}),
			// DoUpdates: clause.AssignmentColumns([]string{"rating"}),
		}).CreateInBatches(&datamodelUpdate, 1000).Error
		if err != nil {
			fmt.Println(err)
			Zerologs.Error().Msg("Error while Inserting data into Amc_aum")
		}
		Zerologs.Info().Msgf(" execution time for Amc_aum ==>", time.Since(start))
		buffer.WriteString("Total Record updated " + strconv.Itoa(count) + "\n")
		return nil
	})

	// })
	return nil
}

func ClassWisereturn(strjson []byte, buffer *bytes.Buffer) error {
	var arryJson []interface{}
	if err := json.Unmarshal(strjson, &arryJson); err != nil {
		buffer.WriteString(err.Error() + "\n")
		return err
	}
	var datamodelUpdate []accord.ClassWisereturn
	count := 0
	// q.Enqueue(arryJson, func(data interface{}) {
	db.Accord.Transaction(func(tx *gorm.DB) error {
		start := time.Now()
		for _, json := range arryJson {
			jsonmap := json.(map[string]interface{})
			datamodel := accord.ClassWisereturn{}
			datamodel.Classcode = helper.GetIntfromMap(jsonmap, "classcode")
			datamodel.Opt_code = helper.GetIntfromMap(jsonmap, "opt_code")
			// err := tx.Where("classcode=? AND opt_code=? ", datamodel.Classcode, datamodel.Opt_code).First(&datamodel).Error
			// if err != nil {
			// 	Zerologs.Error().Msg("Record Not Found In ClassWisereturn" + err.Error())
			// }
			classcode := strconv.Itoa(datamodel.Classcode)
			opt_code := strconv.Itoa(datamodel.Opt_code)
			datamodel.ID = classcode + "_" + opt_code
			datamodel.Classname = helper.GetStringfromMap(jsonmap, "classname")
			datamodel.Date = helper.GetTimefromMap(jsonmap, "date")
			datamodel.Dayret1 = helper.GetFloatfromMap(jsonmap, "1dayret")
			datamodel.Weekret1 = helper.GetFloatfromMap(jsonmap, "1weekret")
			datamodel.Weekret2 = helper.GetFloatfromMap(jsonmap, "2weekret")
			datamodel.Weekret3 = helper.GetFloatfromMap(jsonmap, "3weekret")
			datamodel.Monthret1 = helper.GetFloatfromMap(jsonmap, "1monthret")
			datamodel.Monthret2 = helper.GetFloatfromMap(jsonmap, "2monthret")
			datamodel.Monthret3 = helper.GetFloatfromMap(jsonmap, "3monthret")
			datamodel.Monthret6 = helper.GetFloatfromMap(jsonmap, "6monthret")
			datamodel.Mnthret9 = helper.GetFloatfromMap(jsonmap, "9mnthret")
			datamodel.Yearret1 = helper.GetFloatfromMap(jsonmap, "1yearret")
			datamodel.Yearret2 = helper.GetFloatfromMap(jsonmap, "2yearret")
			datamodel.Yearret3 = helper.GetFloatfromMap(jsonmap, "3yearret")
			datamodel.Yearret4 = helper.GetFloatfromMap(jsonmap, "4yearret")
			datamodel.Yearret5 = helper.GetFloatfromMap(jsonmap, "5yearret")
			datamodel.Incret = helper.GetFloatfromMap(jsonmap, "incret")
			datamodel.Ytdret = helper.GetFloatfromMap(jsonmap, "ytdret")
			datamodel.Wschemecode1 = helper.GetIntfromMap(jsonmap, "1wschemecode")
			datamodel.WeekHighRet = helper.GetFloatfromMap(jsonmap, "weekHighRet")
			datamodel.Mschemecode1 = helper.GetIntfromMap(jsonmap, "1mschemecode")
			datamodel.Monthhighret = helper.GetFloatfromMap(jsonmap, "monthhighret")
			datamodel.Mschemecode3 = helper.GetIntfromMap(jsonmap, "3mschemecode")
			datamodel.MonthHighret3 = helper.GetFloatfromMap(jsonmap, "3monthHighret")
			datamodel.Mschemecode6 = helper.GetIntfromMap(jsonmap, "6mschemecode")
			datamodel.Monthhighret6 = helper.GetFloatfromMap(jsonmap, "6monthhighret")
			datamodel.Yschemecode1 = helper.GetIntfromMap(jsonmap, "1yschemecode")
			datamodel.Yhighret1 = helper.GetFloatfromMap(jsonmap, "1yhighret")
			datamodel.Yschemecode3 = helper.GetIntfromMap(jsonmap, "3yschemecode")
			datamodel.Yhighret3 = helper.GetFloatfromMap(jsonmap, "3yhighret")
			datamodel.Yschemecode5 = helper.GetIntfromMap(jsonmap, "5yschemecode")
			datamodel.Yhighret5 = helper.GetFloatfromMap(jsonmap, "5yhighret")
			datamodel.Incretschemecode = helper.GetIntfromMap(jsonmap, "incretschemecode")
			datamodel.Increthighret = helper.GetFloatfromMap(jsonmap, "increthighret")
			datamodel.Worst1wSchemecode = helper.GetIntfromMap(jsonmap, "worst1wSchemecode")
			datamodel.WeekWorstRet = helper.GetFloatfromMap(jsonmap, "weekWorstRet")
			datamodel.Worst1mschemecode = helper.GetIntfromMap(jsonmap, "worst1mschemecode")
			datamodel.Monthworstret = helper.GetFloatfromMap(jsonmap, "monthworstret")
			datamodel.Worst3mschemecode = helper.GetIntfromMap(jsonmap, "worst3mschemecode")
			datamodel.Monthworstret3 = helper.GetFloatfromMap(jsonmap, "monthworstret")
			datamodel.Worst6mschemecode = helper.GetIntfromMap(jsonmap, "worst6mschemecode")
			datamodel.MonthWorstRet6 = helper.GetFloatfromMap(jsonmap, "monthWorstRet6")
			datamodel.Worst1yschemecode = helper.GetIntfromMap(jsonmap, "worst1yschemecode")
			datamodel.Yworstret1 = helper.GetFloatfromMap(jsonmap, "1yworstret1")
			datamodel.Worst3yschemecode = helper.GetIntfromMap(jsonmap, "worst3yschemecode")
			datamodel.Yworstret3 = helper.GetFloatfromMap(jsonmap, "3yworstret")
			datamodel.Worst5yschemecode = helper.GetIntfromMap(jsonmap, "worst5yschemecode")
			datamodel.Yworstret5 = helper.GetFloatfromMap(jsonmap, "5yworstret5")
			datamodel.Worstincretschemecode = helper.GetIntfromMap(jsonmap, "worstincretschemecode")
			datamodel.Incretworstret = helper.GetFloatfromMap(jsonmap, "incretworstret")
			datamodel.Flag = helper.GetStringfromMap(jsonmap, "flag")
			// err := tx.Where("classcode=? AND opt_code ", datamodel.Classcode, datamodel.Opt_code).First(&datamodel).Error
			// if err != nil {
			// 	err := tx.Create(&datamodel).Error
			// 	if err != nil {
			// 		buffer.WriteString(err.Error())
			// 	}
			// } else {
			// err = tx.Save(&datamodel).Error
			// if err != nil {
			// 	buffer.WriteString(err.Error())
			// }
			datamodelUpdate = append(datamodelUpdate, datamodel)
			// }

			count++

		}
		err := db.Accord.Clauses(clause.OnConflict{
			Columns:   []clause.Column{{Name: "id"}}, //, {Name: "invdate"}, {Name: "srno"}},
			DoUpdates: clause.AssignmentColumns([]string{"classcode", "classname", "opt_code", "date", "dayret1", "weekret1", "weekret2", "weekret3", "monthret1", "monthret2", "monthret3", "monthret6", "mnthret9", "yearret1", "yearret2", "yearret3", "yearret4", "yearret5", "incret", "ytdret", "wschemecode1", "week_high_ret", "mschemecode1", "monthhighret", "mschemecode3", "month_highret3", "mschemecode6", "monthhighret6", "yschemecode1", "yhighret1", "yschemecode3", "yhighret3", "yschemecode5", "yhighret5", "incretschemecode", "increthighret", "worst1w_schemecode", "week_worst_ret", "worst1mschemecode", "monthworstret", "worst3mschemecode", "monthworstret3", "worst6mschemecode", "month_worst_ret6", "worst1yschemecode", "yworstret1", "worst3yschemecode", "yworstret3", "worst5yschemecode", "yworstret5", "worstincretschemecode", "incretworstret", "flag"}),
			// DoUpdates: clause.AssignmentColumns([]string{"rating"}),
		}).CreateInBatches(&datamodelUpdate, 1000).Error
		if err != nil {
			fmt.Println(err)
			Zerologs.Error().Msg("Error while Inserting data into ClassWisereturn")
		}
		Zerologs.Info().Msgf(" execution time for ClassWisereturn ==>", time.Since(start))
		buffer.WriteString("Total Record updated " + strconv.Itoa(count) + "\n")
		return nil
	})

	// })
	return nil
}
func Currentnav(strjson []byte, buffer *bytes.Buffer) error {
	var arryJson []interface{}
	if err := json.Unmarshal(strjson, &arryJson); err != nil {
		buffer.WriteString(err.Error() + "\n")
		return err
	}
	var datamodelUpdate []accord.Currentnav
	count := 0
	// q.Enqueue(arryJson, func(data interface{}) {
	db.Accord.Transaction(func(tx *gorm.DB) error {
		start := time.Now()
		for _, json := range arryJson {
			jsonmap := json.(map[string]interface{})
			datamodel := accord.Currentnav{}
			datamodel.Schemecode = helper.GetIntfromMap(jsonmap, "schemecode")
			// err := tx.Where("schemecode=? ", datamodel.Schemecode).First(&datamodel).Error
			// if err != nil {
			// 	Zerologs.Error().Msg("Record Not Found In Currentnav" + err.Error())
			// }
			schemecode := strconv.Itoa(datamodel.Schemecode)
			datamodel.ID = schemecode
			datamodel.Navdate = helper.GetTimefromMap(jsonmap, "navdate")
			datamodel.Navrs = helper.GetFloatfromMap(jsonmap, "navrs")
			datamodel.Repurprice = helper.GetFloatfromMap(jsonmap, "repurprice")
			datamodel.Saleprice = helper.GetFloatfromMap(jsonmap, "saleprice")
			datamodel.Cldate = helper.GetTimefromMap(jsonmap, "cldate")
			datamodel.Change = helper.GetFloatfromMap(jsonmap, "change")
			datamodel.Netchange = helper.GetFloatfromMap(jsonmap, "netchange")
			datamodel.Prevnav = helper.GetFloatfromMap(jsonmap, "prevnav")
			datamodel.Prenavdate = helper.GetTimefromMap(jsonmap, "prenavdate")
			datamodel.Flag = helper.GetStringfromMap(jsonmap, "flag")
			// err := tx.Where("schemecode=? ", datamodel.Schemecode).First(&datamodel).Error
			// if err != nil {
			// 	err := tx.Create(&datamodel).Error
			// 	if err != nil {
			// 		buffer.WriteString(err.Error())
			// 	}
			// } else {
			// err = tx.Save(&datamodel).Error
			// if err != nil {
			// 	buffer.WriteString(err.Error())
			// }
			// }
			datamodelUpdate = append(datamodelUpdate, datamodel)
			count++

		}
		err := db.Accord.Clauses(clause.OnConflict{
			Columns:   []clause.Column{{Name: "id"}}, //, {Name: "invdate"}, {Name: "srno"}},
			DoUpdates: clause.AssignmentColumns([]string{"schemecode", "navdate", "navrs", "repurprice", "saleprice", "cldate", "change", "netchange", "prevnav", "prenavdate", "flag"}),
			// DoUpdates: clause.AssignmentColumns([]string{"rating"}),
		}).CreateInBatches(&datamodelUpdate, 1000).Error
		if err != nil {
			fmt.Println(err)
			Zerologs.Error().Msg("Error while Inserting data into Currentnav")
		}
		Zerologs.Info().Msgf(" execution time for Currentnav ==>", time.Since(start))
		buffer.WriteString("Total Record updated " + strconv.Itoa(count) + "\n")
		return nil
	})

	// })
	return nil
}

func DailyFundmanager(strjson []byte, buffer *bytes.Buffer) error {
	var arryJson []interface{}
	if err := json.Unmarshal(strjson, &arryJson); err != nil {
		buffer.WriteString(err.Error() + "\n")
		return err
	}
	var datamodelUpdate []accord.DailyFundmanager
	count := 0
	// q.Enqueue(arryJson, func(data interface{}) {
	db.Accord.Transaction(func(tx *gorm.DB) error {
		start := time.Now()
		for _, json := range arryJson {
			jsonmap := json.(map[string]interface{})
			datamodel := accord.DailyFundmanager{}
			datamodel.Date = helper.GetTimefromMap(jsonmap, "date")
			datamodel.Schemecode = helper.GetIntfromMap(jsonmap, "schemecode")
			// err := tx.Where("date=? AND schemecode=?", datamodel.Date, datamodel.Schemecode).First(&datamodel).Error
			// if err != nil {
			// 	Zerologs.Error().Msg("Record Not Found In DailyFundmanager" + err.Error())
			// }
			date := datamodel.Date.String()
			schemecode := strconv.Itoa(datamodel.Schemecode)
			datamodel.ID = date + "_" + schemecode
			datamodel.Amc = helper.GetIntfromMap(jsonmap, "amc")
			datamodel.FundManger1 = helper.GetIntfromMap(jsonmap, "fundManger1")
			datamodel.FundManger2 = helper.GetIntfromMap(jsonmap, "fundManger2")
			datamodel.FundManger3 = helper.GetIntfromMap(jsonmap, "fundManger3")
			datamodel.FundManger4 = helper.GetIntfromMap(jsonmap, "fundManger4")
			datamodel.Flag = helper.GetStringfromMap(jsonmap, "flag")
			// err := tx.Where("date=? AND schemecode=?", datamodel.Date, datamodel.Schemecode).First(&datamodel).Error
			// if err != nil {
			// 	err := tx.Create(&datamodel).Error
			// 	if err != nil {
			// 		buffer.WriteString(err.Error())
			// 	}
			// } else {
			// err = tx.Save(&datamodel).Error
			// if err != nil {
			// 	buffer.WriteString(err.Error())
			// }
			datamodelUpdate = append(datamodelUpdate, datamodel)
			// }
			count++

		}
		err := db.Accord.Clauses(clause.OnConflict{
			Columns:   []clause.Column{{Name: "id"}}, //, {Name: "invdate"}, {Name: "srno"}},
			DoUpdates: clause.AssignmentColumns([]string{"date", "amc", "schemecode", "fund_manger1", "fund_manger2", "fund_manger3", "fund_manger4", "flag"}),
			// DoUpdates: clause.AssignmentColumns([]string{"rating"}),
		}).CreateInBatches(&datamodelUpdate, 1000).Error
		if err != nil {
			fmt.Println(err)
			Zerologs.Error().Msg("Error while Inserting data into DailyFundmanager")
		}
		Zerologs.Info().Msgf(" execution time for DailyFundmanager ==>", time.Since(start))
		buffer.WriteString("Total Record updated " + strconv.Itoa(count) + "\n")
		return nil
	})

	// })
	return nil
}
func CompanymasterMF(strjson []byte, buffer *bytes.Buffer) error {
	var arryJson []interface{}
	if err := json.Unmarshal(strjson, &arryJson); err != nil {
		buffer.WriteString(err.Error() + "\n")
		return err
	}
	var datamodelUpdate []accord.MF_Companymaster
	count := 0
	// q.Enqueue(arryJson, func(data interface{}) {
	db.Accord.Transaction(func(tx *gorm.DB) error {
		start := time.Now()
		for _, json := range arryJson {
			jsonmap := json.(map[string]interface{})
			datamodel := accord.MF_Companymaster{}
			datamodel.Fincode = helper.GetIntfromMap(jsonmap, "fincode")
			// err := tx.Where("fincode=? ", datamodel.Fincode).First(&datamodel).Error
			// if err != nil {
			// 	Zerologs.Error().Msg("Record Not Found In MF_Companymaster" + err.Error())
			// }
			fincode := strconv.Itoa(datamodel.Fincode)
			datamodel.ID = fincode
			datamodel.Scripcode = helper.GetIntfromMap(jsonmap, "scripcode")
			datamodel.Symbol = helper.GetStringfromMap(jsonmap, "symbol")
			datamodel.Compname = helper.GetStringfromMap(jsonmap, "compname")
			datamodel.S_name = helper.GetStringfromMap(jsonmap, "s_name")
			datamodel.Ind_code = helper.GetIntfromMap(jsonmap, "ind_code")
			datamodel.Industry = helper.GetStringfromMap(jsonmap, "Industry")
			datamodel.Isin = helper.GetStringfromMap(jsonmap, "isin")
			datamodel.Status = helper.GetStringfromMap(jsonmap, "status")
			datamodel.Series = helper.GetStringfromMap(jsonmap, "series")
			datamodel.Listing = helper.GetStringfromMap(jsonmap, "listing")
			datamodel.Sublisting = helper.GetStringfromMap(jsonmap, "sublisting")
			datamodel.Fv = helper.GetFloatfromMap(jsonmap, "fv")
			datamodel.Flag = helper.GetStringfromMap(jsonmap, "flag")
			// err := tx.Where("fincode=? ", datamodel.Fincode).First(&datamodel).Error
			// if err != nil {
			// 	err := tx.Create(&datamodel).Error
			// 	if err != nil {
			// 		buffer.WriteString(err.Error())
			// 	}
			// } else {
			// err = tx.Save(&datamodel).Error
			// if err != nil {
			// 	buffer.WriteString(err.Error())
			// }
			datamodelUpdate = append(datamodelUpdate, datamodel)
			// }
			count++

		}
		err := db.Accord.Clauses(clause.OnConflict{
			Columns:   []clause.Column{{Name: "id"}}, //, {Name: "invdate"}, {Name: "srno"}},
			DoUpdates: clause.AssignmentColumns([]string{"fincode", "scripcode", "symbol", "compname", "s_name", "ind_code", "industry", "isin", "status", "series", "listing", "sublisting", "fv", "flag"}),
			// DoUpdates: clause.AssignmentColumns([]string{"rating"}),
		}).CreateInBatches(&datamodelUpdate, 1000).Error
		if err != nil {
			fmt.Println(err)
			Zerologs.Error().Msg("Error while Inserting data into MF_Companymaster")
		}
		Zerologs.Info().Msgf(" execution time for MF_Companymaster ==>", time.Since(start))
		buffer.WriteString("Total Record updated " + strconv.Itoa(count) + "\n")
		return nil
	})

	// })
	return nil
}
func BM_AnnualisedReturn(strjson []byte, buffer *bytes.Buffer) error {
	var arryJson []interface{}
	if err := json.Unmarshal(strjson, &arryJson); err != nil {
		buffer.WriteString(err.Error() + "\n")
		return err
	}
	var datamodelUpdate []accord.BM_AnnualisedReturn
	count := 0
	// q.Enqueue(arryJson, func(data interface{}) {
	db.Accord.Transaction(func(tx *gorm.DB) error {
		start := time.Now()
		for _, json := range arryJson {
			jsonmap := json.(map[string]interface{})
			datamodel := accord.BM_AnnualisedReturn{}
			datamodel.Index_code = helper.GetIntfromMap(jsonmap, "index_code")
			// err := tx.Where("index_code=? ", datamodel.Index_code).First(&datamodel).Error
			// if err != nil {
			// 	Zerologs.Error().Msg("Record Not Found In BM_AnnualisedReturn" + err.Error())
			// }
			index_code := strconv.Itoa(datamodel.Index_code)
			datamodel.ID = index_code
			datamodel.Symbol = helper.GetStringfromMap(jsonmap, "symbol")
			datamodel.Scripcode = helper.GetIntfromMap(jsonmap, "scripcode")
			datamodel.Date = helper.GetTimefromMap(jsonmap, "date")
			datamodel.Prev_date = helper.GetTimefromMap(jsonmap, "prev_date")
			datamodel.Close = helper.GetFloatfromMap(jsonmap, "close")
			datamodel.Prev_close = helper.GetFloatfromMap(jsonmap, "prev_close")
			datamodel.Dayret1 = helper.GetFloatfromMap(jsonmap, "1dayret")
			datamodel.Weekdate1 = helper.GetTimefromMap(jsonmap, "1weekdate")
			datamodel.Weekclose1 = helper.GetFloatfromMap(jsonmap, "1weekclose")
			datamodel.Weekret1 = helper.GetFloatfromMap(jsonmap, "1weekret")
			datamodel.Mthdate1 = helper.GetTimefromMap(jsonmap, "1mthdate")
			datamodel.Mthclose1 = helper.GetFloatfromMap(jsonmap, "1mthclose")
			datamodel.Monthret1 = helper.GetFloatfromMap(jsonmap, "1monthret")
			datamodel.Mthdate3 = helper.GetTimefromMap(jsonmap, "3mthdate")
			datamodel.Mthclose3 = helper.GetFloatfromMap(jsonmap, "3mthclose")
			datamodel.Monthret3 = helper.GetFloatfromMap(jsonmap, "3monthret")
			datamodel.Mntdate6 = helper.GetTimefromMap(jsonmap, "6mntdate")
			datamodel.Mnthclose6 = helper.GetFloatfromMap(jsonmap, "6mnthclose")
			datamodel.Monthret6 = helper.GetFloatfromMap(jsonmap, "6monthret")
			datamodel.Mnthdate9 = helper.GetTimefromMap(jsonmap, "9mnthdate")
			datamodel.Mnthclose9 = helper.GetFloatfromMap(jsonmap, "9mnthclose")
			datamodel.Mnthret9 = helper.GetFloatfromMap(jsonmap, "9mnthret")
			datamodel.Yrdate1 = helper.GetTimefromMap(jsonmap, "1yrdate")
			datamodel.Yrclose1 = helper.GetFloatfromMap(jsonmap, "1yrclose")
			datamodel.Yrret1 = helper.GetFloatfromMap(jsonmap, "1yrret")
			datamodel.Yrdate2 = helper.GetTimefromMap(jsonmap, "2yrdate")
			datamodel.Yrclose2 = helper.GetFloatfromMap(jsonmap, "2yrclose")
			datamodel.Yearret2 = helper.GetFloatfromMap(jsonmap, "2yearret")
			datamodel.Yrdate3 = helper.GetTimefromMap(jsonmap, "3yrdate")
			datamodel.Yrclose3 = helper.GetFloatfromMap(jsonmap, "3yrclose")
			datamodel.Yearret3 = helper.GetFloatfromMap(jsonmap, "3yearret")
			datamodel.Yrdate4 = helper.GetTimefromMap(jsonmap, "4yrdate")
			datamodel.Yrclose4 = helper.GetFloatfromMap(jsonmap, "4yrclose")
			datamodel.Yearret4 = helper.GetFloatfromMap(jsonmap, "4yearret")
			datamodel.Yrdate5 = helper.GetTimefromMap(jsonmap, "5yrdate")
			datamodel.Yrclose5 = helper.GetFloatfromMap(jsonmap, "5yrclose")
			datamodel.Yearret5 = helper.GetFloatfromMap(jsonmap, "5yearret")
			datamodel.Incdate = helper.GetTimefromMap(jsonmap, "incdate")
			datamodel.Incclose = helper.GetFloatfromMap(jsonmap, "incclose")
			datamodel.Incret = helper.GetFloatfromMap(jsonmap, "incret")
			datamodel.Weekdate2 = helper.GetTimefromMap(jsonmap, "2weekdate")
			datamodel.Weekclose2 = helper.GetFloatfromMap(jsonmap, "2weekclose")
			datamodel.Weekret2 = helper.GetFloatfromMap(jsonmap, "2weekret")
			datamodel.Weekdate3 = helper.GetTimefromMap(jsonmap, "3weekdate")
			datamodel.Weekclose3 = helper.GetFloatfromMap(jsonmap, "3weekclose")
			datamodel.Weekret3 = helper.GetFloatfromMap(jsonmap, "3weekret")
			datamodel.Mthdate2 = helper.GetTimefromMap(jsonmap, "2mthdate")
			datamodel.Mthclose2 = helper.GetFloatfromMap(jsonmap, "2mthclose")
			datamodel.Monthret2 = helper.GetFloatfromMap(jsonmap, "2monthret")
			datamodel.Ytddate = helper.GetTimefromMap(jsonmap, "ytddate")
			datamodel.Ytdclose = helper.GetFloatfromMap(jsonmap, "ytdclose")
			datamodel.Ytdret = helper.GetFloatfromMap(jsonmap, "ytdret")
			datamodel.Flag = helper.GetStringfromMap(jsonmap, "flag")
			// err := tx.Where("index_code=? ", datamodel.Index_code).First(&datamodel).Error
			// if err != nil {
			// 	err := tx.Create(&datamodel).Error
			// 	if err != nil {
			// 		buffer.WriteString(err.Error())
			// 	}
			// } else {
			// err = tx.Save(&datamodel).Error
			// if err != nil {
			// 	buffer.WriteString(err.Error())
			// }
			datamodelUpdate = append(datamodelUpdate, datamodel)
			// }
			count++

		}
		err := db.Accord.Clauses(clause.OnConflict{
			Columns:   []clause.Column{{Name: "id"}}, //, {Name: "invdate"}, {Name: "srno"}},
			DoUpdates: clause.AssignmentColumns([]string{"index_code", "symbol", "scripcode", "date", "prev_date", "close", "prev_close", "dayret1", "weekdate1", "weekclose1", "weekret1", "mthdate1", "mthclose1", "monthret1", "mthdate3", "mthclose3", "monthret3", "mntdate6", "mnthclose6", "monthret6", "mnthdate9", "mnthclose9", "mnthret9", "yrdate1", "yrclose1", "yrret1", "yrdate2", "yrclose2", "yearret2", "yrdate3", "yrclose3", "yearret3", "yrdate4", "yrclose4", "yearret4", "yrdate5", "yrclose5", "yearret5", "incdate", "incclose", "incret", "weekdate2", "weekclose2", "weekret2", "weekdate3", "weekclose3", "weekret3", "mthdate2", "mthclose2", "monthret2", "ytddate", "ytdclose", "ytdret", "flag"}),
			//DoUpdates: clause.AssignmentColumns([]string{"rating"}),
		}).CreateInBatches(&datamodelUpdate, 1000).Error
		if err != nil {
			fmt.Println(err)
			Zerologs.Error().Msg("Error while Inserting data into BM_AnnualisedReturn")
		}
		Zerologs.Info().Msgf(" execution time for BM_AnnualisedReturn ==>", time.Since(start))
		buffer.WriteString("Total Record updated " + strconv.Itoa(count) + "\n")
		return nil
	})

	// })
	return nil
}
func BM_AbsoluteReturn(strjson []byte, buffer *bytes.Buffer) error {
	var arryJson []interface{}
	if err := json.Unmarshal(strjson, &arryJson); err != nil {
		buffer.WriteString(err.Error() + "\n")
		return err
	}
	var datamodelUpdate []accord.BM_AbsoluteReturn
	count := 0
	// q.Enqueue(arryJson, func(data interface{}) {
	db.Accord.Transaction(func(tx *gorm.DB) error {
		start := time.Now()
		for _, json := range arryJson {
			jsonmap := json.(map[string]interface{})
			datamodel := accord.BM_AbsoluteReturn{}
			datamodel.Index_code = helper.GetIntfromMap(jsonmap, "index_code")
			// err := tx.Where("index_code=? ", datamodel.Index_code).First(&datamodel).Error
			// if err != nil {
			// 	Zerologs.Error().Msg("Record Not Found In BM_AbsoluteReturn" + err.Error())
			// }
			index_code := strconv.Itoa(datamodel.Index_code)
			datamodel.ID = index_code
			datamodel.Symbol = helper.GetStringfromMap(jsonmap, "symbol")
			datamodel.Scripcode = helper.GetIntfromMap(jsonmap, "scripcode")
			datamodel.Date = helper.GetTimefromMap(jsonmap, "date")
			datamodel.Prev_date = helper.GetTimefromMap(jsonmap, "prev_date")
			datamodel.Close = helper.GetFloatfromMap(jsonmap, "close")
			datamodel.Prev_close = helper.GetFloatfromMap(jsonmap, "prev_close")
			datamodel.Dayret1 = helper.GetFloatfromMap(jsonmap, "1dayret")
			datamodel.Weekdate1 = helper.GetTimefromMap(jsonmap, "1weekdate")
			datamodel.Weekclose1 = helper.GetFloatfromMap(jsonmap, "1weekclose")
			datamodel.Weekret1 = helper.GetFloatfromMap(jsonmap, "1weekret")
			datamodel.Mthdate1 = helper.GetTimefromMap(jsonmap, "1mthdate")
			datamodel.Mthclose1 = helper.GetFloatfromMap(jsonmap, "1mthclose")
			datamodel.Monthret1 = helper.GetFloatfromMap(jsonmap, "1monthret")
			datamodel.Mthdate3 = helper.GetTimefromMap(jsonmap, "3mthdate")
			datamodel.Mthclose3 = helper.GetFloatfromMap(jsonmap, "3mthclose")
			datamodel.Monthret3 = helper.GetFloatfromMap(jsonmap, "3monthret")
			datamodel.Mntdate6 = helper.GetTimefromMap(jsonmap, "6mntdate")
			datamodel.Mnthclose6 = helper.GetFloatfromMap(jsonmap, "6mnthclose")
			datamodel.Monthret6 = helper.GetFloatfromMap(jsonmap, "6monthret")
			datamodel.Mnthdate9 = helper.GetTimefromMap(jsonmap, "9mnthdate")
			datamodel.Mnthclose9 = helper.GetFloatfromMap(jsonmap, "9mnthclose")
			datamodel.Mnthret9 = helper.GetFloatfromMap(jsonmap, "9mnthret")
			datamodel.Yrdate1 = helper.GetTimefromMap(jsonmap, "1yrdate")
			datamodel.Yrclose1 = helper.GetFloatfromMap(jsonmap, "1yrclose")
			datamodel.Yrret1 = helper.GetFloatfromMap(jsonmap, "Yrret1")
			datamodel.Yrdate2 = helper.GetTimefromMap(jsonmap, "2yrdate")
			datamodel.Yrclose2 = helper.GetFloatfromMap(jsonmap, "2yrclose")
			datamodel.Yearret2 = helper.GetFloatfromMap(jsonmap, "2yearret")
			datamodel.Yrdate3 = helper.GetTimefromMap(jsonmap, "3yrdate")
			datamodel.Yrclose3 = helper.GetFloatfromMap(jsonmap, "3yrclose")
			datamodel.Yearret3 = helper.GetFloatfromMap(jsonmap, "3yearret")
			datamodel.Yrdate4 = helper.GetTimefromMap(jsonmap, "4yrdate")
			datamodel.Yrclose4 = helper.GetFloatfromMap(jsonmap, "4yrclose")
			datamodel.Yearret4 = helper.GetFloatfromMap(jsonmap, "4yearret")
			datamodel.Yrdate5 = helper.GetTimefromMap(jsonmap, "5yrdate")
			datamodel.Yrclose5 = helper.GetFloatfromMap(jsonmap, "5yrclose")
			datamodel.Yearret5 = helper.GetFloatfromMap(jsonmap, "5yearret")
			datamodel.Incdate = helper.GetTimefromMap(jsonmap, "incdate")
			datamodel.Incclose = helper.GetFloatfromMap(jsonmap, "incclose")
			datamodel.Incret = helper.GetFloatfromMap(jsonmap, "incret")
			datamodel.Weekdate2 = helper.GetTimefromMap(jsonmap, "2weekdate")
			datamodel.Weekclose2 = helper.GetFloatfromMap(jsonmap, "2weekclose")
			datamodel.Weekret2 = helper.GetFloatfromMap(jsonmap, "2weekret")
			datamodel.Weekdate3 = helper.GetTimefromMap(jsonmap, "3weekdate")
			datamodel.Weekclose3 = helper.GetFloatfromMap(jsonmap, "3weekclose")
			datamodel.Weekret3 = helper.GetFloatfromMap(jsonmap, "3weekret")
			datamodel.Mthdate2 = helper.GetTimefromMap(jsonmap, "2mthdate")
			datamodel.Mthclose2 = helper.GetFloatfromMap(jsonmap, "2mthclose")
			datamodel.Monthret2 = helper.GetFloatfromMap(jsonmap, "2monthret")
			datamodel.Ytddate = helper.GetTimefromMap(jsonmap, "ytddate")
			datamodel.Ytdclose = helper.GetFloatfromMap(jsonmap, "ytdclose")
			datamodel.Ytdret = helper.GetFloatfromMap(jsonmap, "ytdret")
			datamodel.Flag = helper.GetStringfromMap(jsonmap, "flag")
			// err := tx.Where("index_code=? ", datamodel.Index_code).First(&datamodel).Error
			// if err != nil {
			// 	err := tx.Create(&datamodel).Error
			// 	if err != nil {
			// 		buffer.WriteString(err.Error())
			// 	}
			// } else {
			// err = tx.Save(&datamodel).Error
			// if err != nil {
			// 	buffer.WriteString(err.Error())
			// }
			datamodelUpdate = append(datamodelUpdate, datamodel)
			// }
			count++

		}
		err := db.Accord.Clauses(clause.OnConflict{
			Columns:   []clause.Column{{Name: "id"}}, //, {Name: "invdate"}, {Name: "srno"}},
			DoUpdates: clause.AssignmentColumns([]string{"index_code", "symbol", "scripcode", "date", "prev_date", "close", "prev_close", "dayret1", "weekdate1", "weekclose1", "weekret1", "mthdate1", "mthclose1", "monthret1", "mthdate3", "mthclose3", "monthret3", "mntdate6", "mnthclose6", "monthret6", "mnthdate9", "mnthclose9", "mnthret9", "yrdate1", "yrclose1", "yrret1", "yrdate2", "yrclose2", "yearret2", "yrdate3", "yrclose3", "yearret3", "yrdate4", "yrclose4", "yearret4", "yrdate5", "yrclose5", "yearret5", "incdate", "incclose", "incret", "weekdate2", "weekclose2", "weekret2", "weekdate3", "weekclose3", "weekret3", "mthdate2", "mthclose2", "monthret2", "ytddate", "ytdclose", "ytdret", "flag"}),
			// DoUpdates: clause.AssignmentColumns([]string{"rating"}),
		}).CreateInBatches(&datamodelUpdate, 1000).Error
		if err != nil {
			fmt.Println(err)
			Zerologs.Error().Msg("Error while Inserting data into BM_AbsoluteReturn")
		}
		Zerologs.Info().Msgf(" execution time for BM_AbsoluteReturn ==>", time.Since(start))
		buffer.WriteString("Total Record updated " + strconv.Itoa(count) + "\n")
		return nil
	})

	// })
	return nil
}
func Avg_scheme_aum(strjson []byte, buffer *bytes.Buffer) error {
	var arryJson []interface{}
	if err := json.Unmarshal(strjson, &arryJson); err != nil {
		buffer.WriteString(err.Error() + "\n")
		return err
	}
	var datamodelUpdate []accord.Avg_scheme_aum
	count := 0
	// q.Enqueue(arryJson, func(data interface{}) {
	db.Accord.Transaction(func(tx *gorm.DB) error {
		start := time.Now()
		for _, json := range arryJson {
			jsonmap := json.(map[string]interface{})
			datamodel := accord.Avg_scheme_aum{}
			datamodel.Schemecode = helper.GetIntfromMap(jsonmap, "schemecode")
			datamodel.Date = helper.GetTimefromMap(jsonmap, "date")
			// err := tx.Where("schemecode=? and date=?", datamodel.Schemecode, datamodel.Date).First(&datamodel).Error
			// if err != nil {
			// 	Zerologs.Error().Msg("Record Not Found In Avg_scheme_aum" + err.Error())
			// }
			schemecode := strconv.Itoa(datamodel.Schemecode)
			date := datamodel.Date.String()
			datamodel.ID = schemecode + "_" + date
			datamodel.Exfof = helper.GetFloatfromMap(jsonmap, "exfof")
			datamodel.Fof = helper.GetFloatfromMap(jsonmap, "fof")
			datamodel.Total = helper.GetFloatfromMap(jsonmap, "total")
			datamodel.Flag = helper.GetStringfromMap(jsonmap, "flag")
			// err := tx.Where("schemecode=? and date=?", datamodel.Schemecode, datamodel.Date).First(&datamodel).Error
			// if err != nil {
			// 	err := tx.Create(&datamodel).Error
			// 	if err != nil {
			// 		buffer.WriteString(err.Error())
			// 	}
			// } else {
			// err = tx.Save(&datamodel).Error
			// if err != nil {
			// 	buffer.WriteString(err.Error())
			// }
			datamodelUpdate = append(datamodelUpdate, datamodel)
			// }
			count++

		}
		err := db.Accord.Clauses(clause.OnConflict{
			Columns:   []clause.Column{{Name: "id"}}, //, {Name: "invdate"}, {Name: "srno"}},
			DoUpdates: clause.AssignmentColumns([]string{"schemecode", "date", "exfof", "fof", "total", "flag"}),
			// DoUpdates: clause.AssignmentColumns([]string{"rating"}),
		}).CreateInBatches(&datamodelUpdate, 1000).Error
		if err != nil {
			fmt.Println(err)
			Zerologs.Error().Msg("Error while Inserting data into Avg_scheme_aum")
		}
		Zerologs.Info().Msgf(" execution time for Avg_scheme_aum ==>", time.Since(start))
		buffer.WriteString("Total Record updated " + strconv.Itoa(count) + "\n")
		return nil
	})

	// })
	return nil
}
func Avg_maturity(strjson []byte, buffer *bytes.Buffer) error {
	var arryJson []interface{}
	if err := json.Unmarshal(strjson, &arryJson); err != nil {
		buffer.WriteString(err.Error() + "\n")
		return err
	}
	var datamodelUpdate []accord.Avg_maturity
	count := 0
	// q.Enqueue(arryJson, func(data interface{}) {
	db.Accord.Transaction(func(tx *gorm.DB) error {
		start := time.Now()
		for _, json := range arryJson {
			jsonmap := json.(map[string]interface{})
			datamodel := accord.Avg_maturity{}
			datamodel.Schemecode = helper.GetIntfromMap(jsonmap, "schemecode")
			datamodel.Date = helper.GetTimefromMap(jsonmap, "date")
			// err := tx.Where("schemecode=? AND date=?", datamodel.Schemecode, datamodel.Date).First(&datamodel).Error
			// if err != nil {
			// 	Zerologs.Error().Msg("Record Not Found In Avg_maturity" + err.Error())
			// }
			scheme_code := strconv.Itoa(datamodel.Schemecode)
			date := datamodel.Date.String()
			datamodel.ID = scheme_code + "_" + date
			datamodel.Amc_code = helper.GetIntfromMap(jsonmap, "amc_code")
			datamodel.Invenddate = helper.GetTimefromMap(jsonmap, "invenddate")
			datamodel.Avg_mat_days = helper.GetStringfromMap(jsonmap, "avg_mat_days")
			datamodel.Avg_mat_num = helper.GetFloatfromMap(jsonmap, "avg_mat_num")
			datamodel.Mod_dur_days = helper.GetStringfromMap(jsonmap, "mod_dur_days")
			datamodel.Mod_dur_num = helper.GetFloatfromMap(jsonmap, "mod_dur_num")
			datamodel.Ytm = helper.GetFloatfromMap(jsonmap, "ytm")
			datamodel.Turnover_ratio = helper.GetFloatfromMap(jsonmap, "turnover_ratio")
			datamodel.Tr_mode = helper.GetStringfromMap(jsonmap, "tr_mode")
			datamodel.Flag = helper.GetStringfromMap(jsonmap, "flag")
			// err := tx.Where("schemecode=? AND date=?", datamodel.Schemecode, datamodel.Date).First(&datamodel).Error
			// if err != nil {
			// 	err := tx.Create(&datamodel).Error
			// 	if err != nil {
			// 		buffer.WriteString(err.Error())
			// 	}
			// } else {
			// err = tx.Save(&datamodel).Error
			// if err != nil {
			// 	buffer.WriteString(err.Error())
			// }
			datamodelUpdate = append(datamodelUpdate, datamodel)
			// }
			count++

		}
		err := db.Accord.Clauses(clause.OnConflict{
			Columns:   []clause.Column{{Name: "id"}}, //, {Name: "invdate"}, {Name: "srno"}},
			DoUpdates: clause.AssignmentColumns([]string{"amc_code", "schemecode", "date", "invenddate", "avg_mat_num", "avg_mat_days", "mod_dur_num", "mod_dur_days", "ytm", "turnover_ratio", "tr_mode", "flag"}),
			// DoUpdates: clause.AssignmentColumns([]string{"rating"}),
		}).CreateInBatches(&datamodelUpdate, 1000).Error
		if err != nil {
			fmt.Println(err)
			Zerologs.Error().Msg("Error while Inserting data into Avg_maturity")
		}
		Zerologs.Info().Msgf(" execution time for Avg_maturity ==>", time.Since(start))
		buffer.WriteString("Total Record updated " + strconv.Itoa(count) + "\n")
		return nil
	})

	// })
	return nil
}

func Amc_mst(strjson []byte, buffer *bytes.Buffer) error {
	var arryJson []interface{}
	if err := json.Unmarshal(strjson, &arryJson); err != nil {
		buffer.WriteString(err.Error() + "\n")
		return err
	}
	var datamodelUpdate []accord.Amc_mst
	count := 0
	// q.Enqueue(arryJson, func(data interface{}) {
	db.Accord.Transaction(func(tx *gorm.DB) error {
		start := time.Now()
		for _, json := range arryJson {
			jsonmap := json.(map[string]interface{})
			datamodel := accord.Amc_mst{}
			datamodel.Amc_code = helper.GetIntfromMap(jsonmap, "amc_code")
			// err := tx.Where("amc_code=? ", datamodel.Amc_code).First(&datamodel).Error

			// if err != nil {
			// 	Zerologs.Error().Msg("Record Not Found In Amc_Mst" + err.Error())
			// }
			amc_code := strconv.Itoa(datamodel.Amc_code)
			datamodel.ID = amc_code
			datamodel.Amc = helper.GetStringfromMap(jsonmap, "amc")
			datamodel.Fund = helper.GetStringfromMap(jsonmap, "fund")
			datamodel.Srno = helper.GetIntfromMap(jsonmap, "srno")
			datamodel.Office_type = helper.GetStringfromMap(jsonmap, "office_type")
			datamodel.Add1 = helper.GetStringfromMap(jsonmap, "add1")
			datamodel.Add2 = helper.GetStringfromMap(jsonmap, "add2")
			datamodel.Add3 = helper.GetStringfromMap(jsonmap, "add3")
			datamodel.Email = helper.GetStringfromMap(jsonmap, "email")
			datamodel.Phone = helper.GetStringfromMap(jsonmap, "phone")
			datamodel.Fax = helper.GetStringfromMap(jsonmap, "fax")
			datamodel.Website = helper.GetStringfromMap(jsonmap, "website")
			datamodel.Setup_date = helper.GetTimefromMap(jsonmap, "setup_date")
			datamodel.Mf_type = helper.GetStringfromMap(jsonmap, "mf_type")
			datamodel.Trustee_name = helper.GetStringfromMap(jsonmap, "trustee_name")
			datamodel.Sponsor_name = helper.GetStringfromMap(jsonmap, "sponsor_name")
			datamodel.Amc_inc_date = helper.GetTimefromMap(jsonmap, "amc_inc_date")
			datamodel.S_name = helper.GetStringfromMap(jsonmap, "s_name")
			datamodel.Amc_symbol = helper.GetStringfromMap(jsonmap, "amc_symbol")
			datamodel.City = helper.GetStringfromMap(jsonmap, "city")
			datamodel.Rtamccode = helper.GetStringfromMap(jsonmap, "rtamccode")
			datamodel.Flag = helper.GetStringfromMap(jsonmap, "flag")

			// err = tx.Save(&datamodel).Error
			// if err != nil {
			// 	buffer.WriteString(err.Error())
			// }
			datamodelUpdate = append(datamodelUpdate, datamodel)
			count++

		}
		err := db.Accord.Clauses(clause.OnConflict{
			Columns:   []clause.Column{{Name: "id"}}, //, {Name: "invdate"}, {Name: "srno"}},
			DoUpdates: clause.AssignmentColumns([]string{"amc_code", "amc", "fund", "srno", "office_type", "add1", "add2", "add3", "email", "phone", "fax", "website", "setup_date", "mf_type", "trustee_name", "sponsor_name", "amc_inc_date", "s_name", "amc_symbol", "city", "rtamccode", "flag"}),
			// DoUpdates: clause.AssignmentColumns([]string{"rating"}),
		}).CreateInBatches(&datamodelUpdate, 1000).Error
		if err != nil {
			fmt.Println(err)
			Zerologs.Error().Msg("Error while Inserting data into Amc_mst")
		}
		Zerologs.Info().Msgf(" execution time for Amc_mst ==>", time.Since(start))
		buffer.WriteString("Total Record updated " + strconv.Itoa(count) + "\n")
		return nil
	})

	// })
	return nil
}

func Amc_keypersons(strjson []byte, buffer *bytes.Buffer) error {
	var arryJson []interface{}
	if err := json.Unmarshal(strjson, &arryJson); err != nil {
		buffer.WriteString(err.Error() + "\n")
		return err
	}
	var datamodelUpdate []accord.Amc_keypersons
	count := 0
	// q.Enqueue(arryJson, func(data interface{}) {
	db.Accord.Transaction(func(tx *gorm.DB) error {
		start := time.Now()
		for _, json := range arryJson {
			jsonmap := json.(map[string]interface{})
			datamodel := accord.Amc_keypersons{}
			datamodel.Amc_code = helper.GetIntfromMap(jsonmap, "amc_code")
			datamodel.Srno = helper.GetIntfromMap(jsonmap, "srno")
			// err := tx.Where("amc_code=? and srno=?", datamodel.Amc_code, datamodel.Srno).First(&datamodel).Error
			// if err != nil {
			// 	Zerologs.Error().Msg("Record Not Found In Amc_keypersons" + err.Error())
			// }
			amc_code := strconv.Itoa(datamodel.Amc_code)
			srno := strconv.Itoa(datamodel.Srno)
			datamodel.ID = amc_code + "_" + srno
			datamodel.Amc_name = helper.GetStringfromMap(jsonmap, "amc_name")
			datamodel.Name = helper.GetStringfromMap(jsonmap, "name")
			datamodel.Desig = helper.GetStringfromMap(jsonmap, "desig")
			datamodel.Flag = helper.GetStringfromMap(jsonmap, "flag")
			// err := tx.Where("amc_code=? and srno=?", datamodel.Amc_code, datamodel.Srno).First(&datamodel).Error
			// if err != nil {
			// 	err := tx.Create(&datamodel).Error
			// 	if err != nil {
			// 		buffer.WriteString(err.Error())
			// 	}
			// } else {
			// err = tx.Save(&datamodel).Error
			// if err != nil {
			// 	buffer.WriteString(err.Error())
			// }
			datamodelUpdate = append(datamodelUpdate, datamodel)
			// }
			count++

		}
		err := db.Accord.Clauses(clause.OnConflict{
			Columns:   []clause.Column{{Name: "id"}}, //, {Name: "invdate"}, {Name: "srno"}},
			DoUpdates: clause.AssignmentColumns([]string{"amc_code", "amc_name", "srno", "name", "desig", "flag"}),
			// DoUpdates: clause.AssignmentColumns([]string{"rating"}),
		}).CreateInBatches(&datamodelUpdate, 1000).Error
		if err != nil {
			fmt.Println(err)
			Zerologs.Error().Msg("Error while Inserting data into Amc_keypersons")
		}
		Zerologs.Info().Msgf(" execution time for Amc_keypersons ==>", time.Since(start))
		buffer.WriteString("Total Record updated " + strconv.Itoa(count) + "\n")
		return nil
	})

	// })
	return nil
}
func MF_Ratios_DefaultBM(strjson []byte, buffer *bytes.Buffer) error {
	var arryJson []interface{}
	if err := json.Unmarshal(strjson, &arryJson); err != nil {
		buffer.WriteString(err.Error() + "\n")
		return err
	}
	var datamodelUpdate []accord.MF_Ratios_DefaultBM
	count := 0
	// q.Enqueue(arryJson, func(data interface{}) {
	db.Accord.Transaction(func(tx *gorm.DB) error {
		start := time.Now()
		for _, json := range arryJson {
			jsonmap := json.(map[string]interface{})
			datamodel := accord.MF_Ratios_DefaultBM{}
			datamodel.Schemecode = helper.GetIntfromMap(jsonmap, "schemecode")
			// err := tx.Where("schemecode=? ", datamodel.Schemecode).First(&datamodel).Error
			// if err != nil {

			// 	Zerologs.Error().Msg("Record Not Found In MF_Ratios_DefaultBM" + err.Error())
			// }
			schemecode := strconv.Itoa(datamodel.Schemecode)
			datamodel.ID = schemecode
			datamodel.Upddate = helper.GetTimefromMap(jsonmap, "upddate")
			datamodel.Datefrom = helper.GetTimefromMap(jsonmap, "datefrom")
			datamodel.Dateto = helper.GetTimefromMap(jsonmap, "dateto")
			datamodel.Average = helper.GetFloatfromMap(jsonmap, "average")
			datamodel.Bmaverage = helper.GetFloatfromMap(jsonmap, "bmaverage")
			datamodel.Sd = helper.GetFloatfromMap(jsonmap, "sd")
			datamodel.Bmsd = helper.GetFloatfromMap(jsonmap, "bmsd")
			datamodel.Semisd = helper.GetFloatfromMap(jsonmap, "semisd")
			datamodel.Semisdii = helper.GetFloatfromMap(jsonmap, "semisdii")
			datamodel.Beta = helper.GetFloatfromMap(jsonmap, "beta")
			datamodel.Correlation = helper.GetFloatfromMap(jsonmap, "correlation")
			datamodel.Beta_corelation = helper.GetFloatfromMap(jsonmap, "beta_corelation")
			datamodel.Covariance = helper.GetFloatfromMap(jsonmap, "covariance")
			datamodel.Treynor = helper.GetFloatfromMap(jsonmap, "treynor")
			datamodel.Fama = helper.GetFloatfromMap(jsonmap, "fama")
			datamodel.Sharpe = helper.GetFloatfromMap(jsonmap, "sharpe")
			datamodel.Alpha = helper.GetFloatfromMap(jsonmap, "alpha")
			datamodel.Sortino = helper.GetFloatfromMap(jsonmap, "sortino")
			datamodel.Sortinoii = helper.GetFloatfromMap(jsonmap, "sortinoii")
			datamodel.Ret_improper = helper.GetFloatfromMap(jsonmap, "ret_improper")
			datamodel.Ret_selectivity = helper.GetFloatfromMap(jsonmap, "ret_selectivity")
			datamodel.Down_probability = helper.GetFloatfromMap(jsonmap, "down_probability")
			datamodel.Rsquared = helper.GetFloatfromMap(jsonmap, "rsquared")
			datamodel.TrackingError = helper.GetFloatfromMap(jsonmap, "trackingError")
			datamodel.Down_risk = helper.GetFloatfromMap(jsonmap, "down_risk")
			datamodel.Sd_annualised = helper.GetFloatfromMap(jsonmap, "sd_annualised")
			datamodel.InformationRatio = helper.GetFloatfromMap(jsonmap, "informationRatio")
			datamodel.Flag = helper.GetStringfromMap(jsonmap, "flag")
			// err := tx.Where("schemecode=? ", datamodel.Schemecode).First(&datamodel).Error
			// if err != nil {
			// 	err := tx.Create(&datamodel).Error
			// 	if err != nil {
			// 		buffer.WriteString(err.Error())
			// 	}
			// } else {
			// err = tx.Save(&datamodel).Error
			// if err != nil {
			// 	buffer.WriteString(err.Error())
			// }
			datamodelUpdate = append(datamodelUpdate, datamodel)
			// }
			count++

		}
		err := db.Accord.Clauses(clause.OnConflict{
			Columns:   []clause.Column{{Name: "id"}}, //, {Name: "invdate"}, {Name: "srno"}},
			DoUpdates: clause.AssignmentColumns([]string{"schemecode", "upddate", "datefrom", "dateto", "average", "bmaverage", "sd", "bmsd", "semisd", "semisdii", "beta", "correlation", "beta_corelation", "covariance", "treynor", "fama", "sharpe", "alpha", "sortino", "sortinoii", "ret_improper", "ret_selectivity", "down_probability", "rsquared", "tracking_error", "down_risk", "sd_annualised", "information_ratio", "flag"}),
			//DoUpdates:clause.AssignmentColumns([]string{"rating"}),
		}).CreateInBatches(&datamodelUpdate, 1000).Error
		if err != nil {
			fmt.Println(err)
			Zerologs.Error().Msg("Error while Inserting data into MF_Ratios_DefaultBM")
		}
		Zerologs.Info().Msgf(" execution time for MF_Ratios_DefaultBM ==>", time.Since(start))
		buffer.WriteString("Total Record updated " + strconv.Itoa(count) + "\n")
		return nil
	})

	// })
	return nil
}
func Mf_return(strjson []byte, buffer *bytes.Buffer) error {
	var arryJson []interface{}
	if err := json.Unmarshal(strjson, &arryJson); err != nil {
		buffer.WriteString(err.Error() + "\n")
		return err
	}
	var datamodelUpdate []accord.Mf_return
	count := 0
	// q.Enqueue(arryJson, func(data interface{}) {
	db.Accord.Transaction(func(tx *gorm.DB) error {
		start := time.Now()
		for _, json := range arryJson {
			jsonmap := json.(map[string]interface{})
			datamodel := accord.Mf_return{}
			datamodel.Schemecode = helper.GetFloatfromMap(jsonmap, "schemecode")
			// err := tx.Where("schemecode=? ", datamodel.Schemecode).First(&datamodel).Error
			// if err != nil {

			// 	Zerologs.Error().Msg("Record Not Found In Mf_return" + err.Error())
			// }
			scode := fmt.Sprintf("%v", datamodel.Schemecode)
			datamodel.ID = scode
			datamodel.C_date = helper.GetTimefromMap(jsonmap, "c_date")
			datamodel.P_date = helper.GetTimefromMap(jsonmap, "p_date")
			datamodel.C_nav = helper.GetFloatfromMap(jsonmap, "c_nav")
			datamodel.P_nav = helper.GetFloatfromMap(jsonmap, "p_nav")
			datamodel.Dayret1 = helper.GetFloatfromMap(jsonmap, "1dayret")
			datamodel.Weekdate1 = helper.GetTimefromMap(jsonmap, "1weekdate")
			datamodel.Weekret1 = helper.GetFloatfromMap(jsonmap, "1weekret")
			datamodel.Mthdate1 = helper.GetTimefromMap(jsonmap, "1mthdate")
			datamodel.Mthnav1 = helper.GetFloatfromMap(jsonmap, "1mthnav")
			datamodel.Monthret1 = helper.GetFloatfromMap(jsonmap, "1monthret")
			datamodel.Mthdate3 = helper.GetTimefromMap(jsonmap, "3mthdate")
			datamodel.Mthnav3 = helper.GetFloatfromMap(jsonmap, "3mthnav")
			datamodel.Monthret3 = helper.GetFloatfromMap(jsonmap, "3monthret")
			datamodel.Mntdate6 = helper.GetTimefromMap(jsonmap, "6mntdate")
			datamodel.Mnthnav6 = helper.GetFloatfromMap(jsonmap, "6mnthnav")
			datamodel.Monthret6 = helper.GetFloatfromMap(jsonmap, "6monthret")
			datamodel.Mnthdate9 = helper.GetTimefromMap(jsonmap, "9mnthdate")
			datamodel.Mnthnav9 = helper.GetFloatfromMap(jsonmap, "9mnthnav")
			datamodel.Mnthret9 = helper.GetFloatfromMap(jsonmap, "9mnthret")
			datamodel.Yrdate1 = helper.GetTimefromMap(jsonmap, "1yrdate")
			datamodel.Yrnav1 = helper.GetFloatfromMap(jsonmap, "1yrnav")
			datamodel.Yrret1 = helper.GetFloatfromMap(jsonmap, "1yrret")
			datamodel.Yrdate2 = helper.GetTimefromMap(jsonmap, "2yrdate")
			datamodel.Yrnav2 = helper.GetFloatfromMap(jsonmap, "2yrnav")
			datamodel.Yearret2 = helper.GetFloatfromMap(jsonmap, "2yearret")
			datamodel.Yrdate3 = helper.GetTimefromMap(jsonmap, "3yrdate")
			datamodel.Yrnav3 = helper.GetFloatfromMap(jsonmap, "3yrnav")
			datamodel.Yearret3 = helper.GetFloatfromMap(jsonmap, "3yearret")
			datamodel.Yrdate4 = helper.GetTimefromMap(jsonmap, "4yrdate")
			datamodel.Yrnav4 = helper.GetFloatfromMap(jsonmap, "4yrnav")
			datamodel.Yearret4 = helper.GetFloatfromMap(jsonmap, "4yearret")
			datamodel.Yrdate5 = helper.GetTimefromMap(jsonmap, "5yrdate")
			datamodel.Yrnav5 = helper.GetFloatfromMap(jsonmap, "5yrnav")
			datamodel.Yearret5 = helper.GetFloatfromMap(jsonmap, "5yearret")
			datamodel.Incdate = helper.GetTimefromMap(jsonmap, "incdate")
			datamodel.Incnav = helper.GetFloatfromMap(jsonmap, "incnav")
			datamodel.Incret = helper.GetFloatfromMap(jsonmap, "incret")
			datamodel.Flag = helper.GetStringfromMap(jsonmap, "flag")
			// err := tx.Where("schemecode=? ", datamodel.Schemecode).First(&datamodel).Error
			// if err != nil {
			// 	err := tx.Create(&datamodel).Error
			// 	if err != nil {
			// 		buffer.WriteString(err.Error())
			// 	}
			// } else {
			// err = tx.Save(&datamodel).Error
			// if err != nil {
			// 	buffer.WriteString(err.Error())
			// }
			// }
			datamodelUpdate = append(datamodelUpdate, datamodel)
			count++

		}
		err := db.Accord.Clauses(clause.OnConflict{
			Columns:   []clause.Column{{Name: "id"}},
			DoUpdates: clause.AssignmentColumns([]string{"schemecode", "c_date", "p_date", "c_nav", "p_nav", "dayret1", "weekdate1", "weeknav1", "weekret1", "mthdate1", "mthnav1", "monthret1", "mthdate3", "mthnav3", "monthret3", "mntdate6", "mnthnav6", "monthret6", "mnthdate9", "mnthnav9", "mnthret9", "yrdate1", "yrnav1", "yrret1", "yrdate2", "yrnav2", "yearret2", "yrdate3", "yrnav3", "yearret3", "yrdate4", "yrnav4", "yearret4", "yrdate5", "yrnav5", "yearret5", "incdate", "incnav", "incret", "flag"}),
			// DoUpdates: clause.AssignmentColumns([]string{"rating"}),
		}).CreateInBatches(&datamodelUpdate, 1000).Error
		if err != nil {
			fmt.Println(err)
			Zerologs.Error().Msg("Error while Inserting data into Mf_return")
		}
		Zerologs.Info().Msgf(" execution time for Mf_return ==>", time.Since(start))
		buffer.WriteString("Total Record updated " + strconv.Itoa(count) + "\n")
		return nil
	})

	// })
	return nil
}

func News(strjson []byte, buffer *bytes.Buffer) error {
	var arryJson []interface{}
	if err := json.Unmarshal(strjson, &arryJson); err != nil {
		Zerologs.Error().Msgf("Error while unmarshal strjson==>>", err)
		buffer.WriteString(err.Error() + "\n")
		return err
	}
	var datamodelUpdate []accord.News
	count := 0
	// q.Enqueue(arryJson, func(data interface{}) {

	db.Accord.Transaction(func(tx *gorm.DB) error {
		start := time.Now()
		for _, json := range arryJson {
			jsonmap := json.(map[string]interface{})
			datamodel := accord.News{}
			datamodel.NEWSID = helper.GetIntfromMap(jsonmap, "NEWSID")
			// err := tx.Where("news_id=?", datamodel.NEWSID).First(&datamodel).Error
			// if err != nil {
			// 	Zerologs.Error().Msg("Record Not Found In News" + err.Error())
			// }
			nid := strconv.Itoa(datamodel.NEWSID)
			datamodel.ID = nid
			datamodel.SECNAME = helper.GetStringfromMap(jsonmap, "SECNAME")
			datamodel.SUBSECNAME = helper.GetStringfromMap(jsonmap, "SUBSECNAME")
			datamodel.DATE = helper.GetTimefromMap(jsonmap, "DATE")
			datamodel.TIME = helper.GetStringfromMap(jsonmap, "TIME")
			datamodel.HEADING = helper.GetStringfromMap(jsonmap, "HEADING")
			datamodel.CAPTION = helper.GetStringfromMap(jsonmap, "CAPTION")
			datamodel.DETAILS = helper.GetStringfromMap(jsonmap, "DETAILS")
			datamodel.FINCODE = helper.GetStringfromMap(jsonmap, "FINCODE") //In company_earnings Fincode comes and in company_news FINCODE comes
			if datamodel.FINCODE == "" {
				datamodel.FINCODE = helper.GetStringfromMap(jsonmap, "Fincode")
			}
			datamodel.INDUSTRY = helper.GetFloatToStringfromMap(jsonmap, "INDUSTRY") //float data convert into string
			datamodel.FLAG = helper.GetStringfromMap(jsonmap, "FLAG")                ///In company_earnings Flag comes and in company_news FLAG comes
			if datamodel.FLAG == "" {
				datamodel.FLAG = helper.GetStringfromMap(jsonmap, "Flag")
			}
			// err := tx.Where("news_id=?", datamodel.NEWSID).First(&datamodel).Error
			// if err != nil {

			// 	err := tx.Create(&datamodel).Error
			// 	if err != nil {
			// 		buffer.WriteString(err.Error())

			// 	}

			// } else {

			// err = tx.Save(&datamodel).Error

			// if err != nil {
			// 	buffer.WriteString(err.Error())
			// 	Zerologs.Error().Msgf("Error while Saving data in accorddb==>>", err)

			// }

			// }
			datamodelUpdate = append(datamodelUpdate, datamodel)
			count++
		}
		err := db.Accord.Clauses(clause.OnConflict{
			Columns:   []clause.Column{{Name: "id"}},
			DoUpdates: clause.AssignmentColumns([]string{"news_id", "secname", "subsecname", "date", "time", "heading", "caption", "details", "fincode", "industry", "flag"}),
			// DoUpdates: clause.AssignmentColumns([]string{"rating"}),
		}).CreateInBatches(&datamodelUpdate, 1000).Error
		if err != nil {
			fmt.Println(err)
			Zerologs.Error().Msg("Error while Inserting data into News")
		}
		Zerologs.Info().Msgf(" execution time for News ==>", time.Since(start))
		buffer.WriteString("Total Record updated " + strconv.Itoa(count) + "\n")
		return nil
	})

	// })
	return nil
}

func Ipo_syndicate(strjson []byte, buffer *bytes.Buffer) error {
	var arryJson []interface{}
	if err := json.Unmarshal(strjson, &arryJson); err != nil {
		buffer.WriteString(err.Error() + "\n")
		return err
	}
	var datamodelUpdate []accord.Ipo_syndicate
	count := 0
	// q.Enqueue(arryJson, func(data interface{}) {
	db.Accord.Transaction(func(tx *gorm.DB) error {
		start := time.Now()
		for _, json := range arryJson {
			jsonmap := json.(map[string]interface{})
			datamodel := accord.Ipo_syndicate{}
			datamodel.IPOCODE = helper.GetFloatfromMap(jsonmap, "IPOCODE")
			datamodel.SRNO = helper.GetFloatfromMap(jsonmap, "SRNO")
			// err := tx.Where("IPOCODE=? and SRNO=?", datamodel.IPOCODE, datamodel.SRNO).First(&datamodel).Error
			// if err != nil {
			// 	Zerologs.Error().Msg("Record Not Found In Ipo_syndicate" + err.Error())
			// }
			icode := fmt.Sprintf("%v", datamodel.IPOCODE)
			srNo := fmt.Sprintf("%v", datamodel.SRNO)
			icode_srno := icode + "_" + srNo
			datamodel.ID = icode_srno
			datamodel.FINCODE = helper.GetFloatfromMap(jsonmap, "FINCODE")
			datamodel.SYNDICATE_CODE = helper.GetFloatfromMap(jsonmap, "SYNDICATE_CODE")
			datamodel.SYNDICATE_NAME = helper.GetStringfromMap(jsonmap, "SYNDICATE_NAME")
			datamodel.FLAG = helper.GetStringfromMap(jsonmap, "FLAG")

			// err := tx.Where("IPOCODE=? and SRNO=?", datamodel.IPOCODE, datamodel.SRNO).First(&datamodel).Error
			// if err != nil {
			// 	err := tx.Create(&datamodel).Error
			// 	if err != nil {
			// 		buffer.WriteString(err.Error())
			// 	}
			// } else {
			// err = tx.Save(&datamodel).Error
			// if err != nil {
			// 	buffer.WriteString(err.Error())
			// }
			// }
			datamodelUpdate = append(datamodelUpdate, datamodel)
			count++

		}
		err := db.Accord.Clauses(clause.OnConflict{
			Columns:   []clause.Column{{Name: "id"}},
			DoUpdates: clause.AssignmentColumns([]string{"ip_ocode", "fincode", "srno", "syndicate_code", "syndicate_name", "flag"}),
			// DoUpdates: clause.AssignmentColumns([]string{"rating"}),
		}).CreateInBatches(&datamodelUpdate, 1000).Error
		if err != nil {
			fmt.Println(err)
			Zerologs.Error().Msg("Error while Inserting data into IPO_syndicate")
		}
		Zerologs.Info().Msgf(" execution time for IPO_syndicate ==>", time.Since(start))
		buffer.WriteString("Total Record updated " + strconv.Itoa(count) + "\n")
		return nil
	})

	// })
	return nil
}
