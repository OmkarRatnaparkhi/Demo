package service

import (
	"os"

	"github.com/TecXLab/libdb/settingservice"
)

func EnvSettingService(EnvSettingModel []settingservice.Tbl_SettingService) error {
	for _, v := range EnvSettingModel {
		EnvVal := os.Getenv(v.Name)
		if EnvVal != "" {
			os.Setenv(v.Name, v.Value)
		}
	}
	return nil
}
