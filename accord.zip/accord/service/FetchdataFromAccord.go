package service

import (
	"accorddata/helper"
	"accorddata/model"
	"bytes"
	"encoding/json"
	"fmt"
	"strings"
	"time"

	"github.com/TecXLab/libdb/accord"
	"github.com/TecXLab/libslack"
	"github.com/gin-gonic/gin"
)

func FetchdataFromAccord(fromdate string, name string, buffer bytes.Buffer) ([]byte, error) {
	name = strings.ToLower(name)
	querystring := UrlMap[name].URL
	fmt.Println(querystring)
	// datetime := time.Now().Format("02012006")
	// datetime = "15072022"
	querystring = strings.ReplaceAll(querystring, "ddMMyyyy", fromdate)
	querystring = strings.ReplaceAll(querystring, "{token}", UrlMap[name].Token)
	querystring = strings.ReplaceAll(querystring, "{sub}", UrlMap[name].Sub)
	fmt.Println(querystring)
	Zerologs.Info().Msgf("querystring==>>", querystring)
	buffer.WriteString("HTTP Call =" + querystring)
	body, err := helper.HttpGet(querystring)
	if err != nil {
		fmt.Println(querystring + " Error " + err.Error())
		Zerologs.Error().Msg(querystring + " Error while calling HttpGet" + err.Error())
		buffer.WriteString(err.Error())
		return nil, err
	}
	strjson, err := helper.ParseDataByte(body)
	//fmt.Println(strjson)
	if err != nil {
		fmt.Println(err)
		Zerologs.Error().Msg("ParseDataByte Error " + err.Error())
		buffer.WriteString(err.Error())
		return nil, err
	}

	// f, err := os.Create("data.txt")
	// if err != nil {
	// 	//log.Fatal(err)
	// }

	// defer f.Close()

	// _, err2 := f.WriteString(strjson)

	// if err2 != nil {
	// 	log.Fatal(err2)
	// }
	return strjson, nil
}

func FetchDataOnTimer(timername string) error {

	q.Enqueue(timername, func(data interface{}) {
		Zerologs.Info().Msg("Cron processing ===>step 2")
		var buffer bytes.Buffer
		buffer.WriteString("Call Timer Name " + timername + "\n")
		timerlist := TimerMap[timername]
		if timerlist == nil {
			//return errors.New("Timer not found in map")
			Zerologs.Error().Msg("FetchDataOnTimer timerlist is nil")
			return
		}
		//fmt.Println(timerlist)
		strdate := time.Now().Format("02012006")
		for _, item := range timerlist {
			fmt.Println(item)
			buffer.WriteString(" Calling Data From" + "==>" + item + "==>")
			strJson, err := FetchdataFromAccord(strdate, item, buffer)
			//fmt.Println(strJson)
			if err != nil {
				fmt.Println("Error while executing timer")
				Zerologs.Error().Msg("Error while executing timer " + err.Error())
			}
			FunctionMap[item].(func([]byte, *bytes.Buffer) error)(strJson, &buffer)
		}

		err := libslack.SentoAccordCronJob(buffer)
		if err != nil {
			fmt.Println("Error while sending to slack")
		}
	})
	return nil
}

func FetchSearchData(Filterstring string) (string, error) {

	type SelectedData struct {
		S_NAME   string `json:"s_name"`
		COMPNAME string `json:"compname"`
	}
	var compnames []SelectedData
	err := db.Accord.Model(&accord.Companymaster{}).Select("company_weburls.url s_name,companymasters.compname").Joins("inner join company_weburls on companymasters.fincode = company_weburls.fincode").Where("compname LIKE ?", "%"+Filterstring+"%").Limit(10).Find(&compnames).Error
	//	err := db.Accord.Model(&accord.Companymaster{}).Limit(10).Select("replace(replace(replace(lower(s_name)	,' ',''),'.',''),'''','') s_name,compname").Where("compname LIKE ?", "%"+Filterstring+"%").Find(&compnames).Error
	if err != nil {
		return "", err
	}
	bytestr, err := json.Marshal(compnames)
	if err != nil {
		fmt.Println(err)
		return "", err
	}
	return string(bytestr), nil
}

func GetStockList() ([]model.StockModel, error) {
	lstStockModel := []model.StockModel{}
	dbcompweburl := []accord.Company_weburl{}
	err := db.Accord.Model(&accord.Company_weburl{}).Find(&dbcompweburl).Error
	if err != nil {
		return nil, err
	}

	for _, v := range dbcompweburl {
		compdetailmodel := model.StockModel{}
		companymaster := accord.Companymaster{}
		err = db.Accord.Model(&accord.Companymaster{}).Where("fincode = ?", v.FINCODE).First(&companymaster).Error
		if err != nil {
			return nil, err
		}

		compdetailmodel.FINCODE = companymaster.FINCODE
		compdetailmodel.SCRIP_GROUP = companymaster.SCRIP_GROUP
		compdetailmodel.COMPNAME = companymaster.COMPNAME
		compdetailmodel.SYMBOL = companymaster.SYMBOL
		compdetailmodel.SERIES = companymaster.SERIES
		compdetailmodel.IND_CODE = companymaster.IND_CODE
		compdetailmodel.ISIN = companymaster.ISIN
		compdetailmodel.Status = companymaster.Status

		sectordetail := accord.Industry_mst{}
		err = db.Accord.Where("ind_code=?", companymaster.IND_CODE).First(&sectordetail).Error
		if err != nil {
			//return err
		} else {
			compdetailmodel.Industry = sectordetail.Industry
		}
		CompanyEQData := accord.Company_equity{}
		//err = db.Accord.Model(&accord.Company_equity{}).Select("booknavpershare,Round(mcap/10000000,2) mcap").Where("fincode = ?", compdetailmodel.FINCODE).Last(CompanyEQData).Error
		err = db.Accord.Select("booknavpershare,Round(mcap/10000000,2) mcap,price_bv").Where("fincode = ?", compdetailmodel.FINCODE).Last(&CompanyEQData).Error
		if err != nil {
		} else {
			compdetailmodel.MCAP = fmt.Sprintf("%.2f", CompanyEQData.MCAP)
		}

		compdetailmodel.URLPATH = v.URL
		compdetailmodel.Token = v.TOKEN

		lstStockModel = append(lstStockModel, compdetailmodel)
	}
	return lstStockModel, nil
}

func GetStockInfo(compdetailmodel *model.CompanyDetailModel, Filterstring string) error {
	dbcompweburl := accord.Company_weburl{}
	err := db.Accord.Where("url=?", Filterstring).First(&dbcompweburl).Error
	if err != nil {
		return err
	}
	compdetailmodel.Token = dbcompweburl.TOKEN
	err = db.Accord.Model(&accord.Companymaster{}).Select("fincode,scr_ip_code,scr_ip_name,scr_ip_group,compname,ind_code,hse_code,symbol,series,isin,s_name,status,flag").Where("fincode = ?", dbcompweburl.FINCODE).First(compdetailmodel).Error
	if err != nil {
		return err
	}
	sectordetail := accord.Industry_mst{}
	err = db.Accord.Where("ind_code=?", compdetailmodel.IND_CODE).First(&sectordetail).Error
	if err != nil {
		//return err
	} else {
		compdetailmodel.Industry = sectordetail.Industry
	}

	CompanyEQData := accord.Company_equity{}
	//err = db.Accord.Model(&accord.Company_equity{}).Select("booknavpershare,Round(mcap/10000000,2) mcap").Where("fincode = ?", compdetailmodel.FINCODE).Last(CompanyEQData).Error
	err = db.Accord.Select("booknavpershare,Round(mcap/10000000,2) mcap,price_bv").Where("fincode = ?", compdetailmodel.FINCODE).Last(&CompanyEQData).Error
	if err != nil {
	} else {
		compdetailmodel.BOOKVALUE = fmt.Sprintf("%.2f", CompanyEQData.BOOKNAVPERSHARE)
		compdetailmodel.MCAP = fmt.Sprintf("%.2f", CompanyEQData.MCAP)
	}

	FinanceData := accord.Finance_fr{}
	//err = db.Accord.Model(&accord.Company_equity{}).Select("booknavpershare,Round(mcap/10000000,2) mcap").Where("fincode = ?", compdetailmodel.FINCODE).Last(CompanyEQData).Error
	err = db.Accord.Select("per,roa,roe,pce,price_book,book_nav_share,yield").Where("fincode = ?", compdetailmodel.FINCODE).Order("updated_at desc").Last(&FinanceData).Error
	if err != nil {
	} else {
		compdetailmodel.PERATIO = fmt.Sprintf("%.2f", FinanceData.PER)
		compdetailmodel.PBRATIO = fmt.Sprintf("%.2f", FinanceData.Price_Book)
		compdetailmodel.ROE = fmt.Sprintf("%.2f", FinanceData.ROE)
		compdetailmodel.DIVIDENDYIELD = fmt.Sprintf("%.2f", FinanceData.Yield)
	}
	var result float64
	err = db.Accord.Model(&accord.Finance_fr{}).Select("sum(per)/count(*)").Where("fincode in(select DISTINCT(fincode) from companymasters where ind_code = ?		) and per > 0 ", compdetailmodel.IND_CODE).Scan(&result).Error
	if err != nil {
	} else {
		compdetailmodel.INDPERATIO = fmt.Sprintf("%.2f", result)
	}

	indresult := []accord.Companymaster{}
	err = db.Accord.Model(&accord.Companymaster{}).Select("isin,s_name,compname,companymasters.fincode").Joins("inner join finance_frs on companymasters.fincode = finance_frs.fincode").Where("companymasters.ind_code = ? and finance_frs.per > 0 and companymasters.fincode != ?", compdetailmodel.IND_CODE, compdetailmodel.FINCODE).Order("finance_frs.per desc").Limit(10).Find(&indresult).Error
	if err != nil {
	} else {
		for _, v := range indresult {
			var similarItem model.SimilarStock
			dbweburl := accord.Company_weburl{}
			err = db.Accord.Where("fincode=?", v.FINCODE).First(&dbweburl).Error
			if err != nil {
				continue
			} else {
				if !CompanyExistInSimilarStock(v.COMPNAME, compdetailmodel.SimilarStock) {
					similarItem.URLPATH = dbweburl.URL
					similarItem.S_NAME = v.S_NAME
					similarItem.ISIN = v.ISIN
					similarItem.COMPNAME = v.COMPNAME
					compdetailmodel.SimilarStock = append(compdetailmodel.SimilarStock, similarItem)
				}
			}
		}

	}
	FinancePL := accord.Finance_pl{}
	//err = db.Accord.Model(&accord.Company_equity{}).Select("booknavpershare,Round(mcap/10000000,2) mcap").Where("fincode = ?", compdetailmodel.FINCODE).Last(CompanyEQData).Error
	err = db.Accord.Select("eps,dividend_perc").Where("fincode = ?", compdetailmodel.FINCODE).Last(&FinancePL).Error
	if err != nil {
	} else {
		compdetailmodel.EPS = fmt.Sprintf("%.2f", FinancePL.EPS)
		//  Dividend Yield = Cash Dividend per share / Market Price per share * 100
	}

	return nil
}

func GetNewsNevents(fincode string) ([]model.NewsModel, error) {
	var newsmodels []model.NewsModel
	var newsdb []accord.News
	err := db.Accord.Where("fincode = ?", fincode).Find(&newsdb).Order("date desc").Error
	if err != nil {
		return nil, err
	}
	for _, v := range newsdb {
		newsmodel := model.NewsModel{
			NEWSID:     v.NEWSID,
			SECNAME:    v.SECNAME,
			SUBSECNAME: v.SUBSECNAME,
			DATE:       v.DATE,
			TIME:       v.TIME,
			HEADING:    v.HEADING,
			CAPTION:    v.CAPTION,
			DETAILS:    v.DETAILS,
		}
		newsmodels = append(newsmodels, newsmodel)
	}

	return newsmodels, nil
}

func GetCorpActions(fincode string) ([]model.CorpActionModel, error) {

	var corpactionmodels []model.CorpActionModel
	var corpactiondb []accord.Corpevent
	err := db.Accord.Where("fincode = ?", fincode).Order("sdate desc").Limit(15).Find(&corpactiondb).Error
	if err != nil {
		return nil, err
	}
	for i, v := range corpactiondb {
		var corpactiondb accord.CorpeventMst
		err := db.Accord.Where("corpact_id = ?", v.CORPACT_ID).Find(&corpactiondb).Error
		if err != nil {
			return nil, err
		}
		date := v.EX_DATE
		if v.CORPACT_ID == 64 {
			date = v.EF_FROMDATE
		}

		if date.Year() == 0001 || date.Year() == 1070 {
			continue
		}

		corpactionmodel := model.CorpActionModel{
			CORPACTID:       i,
			CORPACTNAME:     corpactiondb.CORP_ACTION,
			CORPACTMASTERID: v.CORPACT_ID,
			DATE:            date,
			DETAILS:         v.DETAILS,
		}
		corpactionmodels = append(corpactionmodels, corpactionmodel)
	}

	return corpactionmodels, nil
}

func CompanyExistInSimilarStock(a string, list []model.SimilarStock) bool {
	for _, b := range list {
		if b.COMPNAME == a {
			return true
		}
	}
	return false
}

func FetchDataOnTimerDate(c *gin.Context) error {

	type DateMOdel struct {
		Date      string `json:"date"`
		TimerName string `json:"timer_name"`
	}
	var date DateMOdel
	if err := c.BindJSON(&date); err != nil {
		Zerologs.Error().Err(err).Msg("Error in Json Bindinig")

	}
	q.Enqueue(date.TimerName, func(data interface{}) {

		var buffer bytes.Buffer
		buffer.WriteString("Call Timer Name " + date.TimerName + "\n")
		timerlist := TimerMap[date.TimerName]
		if timerlist == nil {
			//return errors.New("Timer not found in map")
			Zerologs.Error().Msg("FetchDataOnTimer timerlist is nil")
			return
		}
		//fmt.Println(timerlist)

		strdate := date.Date //time.Now().Format("02012006")
		for _, item := range timerlist {
			fmt.Println(item)
			buffer.WriteString(" Calling Data From " + "==>" + item + "==>")
			strJson, err := FetchdataFromAccord(strdate, item, buffer)
			//fmt.Println(strJson)
			if err != nil {
				fmt.Println("Error while executing timer")
				Zerologs.Error().Msg("Error while executing timer " + err.Error())
			}
			FunctionMap[item].(func([]byte, *bytes.Buffer) error)(strJson, &buffer)
		}

		err := libslack.SentoAccordCronJob(buffer)
		if err != nil {
			fmt.Println("Error while sending to slack")
		}
	})
	return nil
}
