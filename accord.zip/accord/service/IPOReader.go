package service

import (
	"accorddata/helper"
	"accorddata/model"
	"errors"
	"fmt"
	"math"
	"strings"
	"time"

	"github.com/TecXLab/libdb/accord"
)

func IPOReader() (*model.AllIPOModels, error) {
	var result model.AllIPOModels
	// SELECT A.ip_ocode, A.listdate,A.issueprice1,A.issueprice2,A.nselist,A.minapln , A.total_eq_ui_ty,
	//A.total_eq_ui_ty*A.issueprice2/10000000 , B.fincode, B.compname,A.* FROM accord_dev.ipodetails A
	// inner join accord_dev.companymasters B on A.fincode = B.fincode
	// where A.fincode =235668;
	var arrrecentIPOModel []model.RecentIPOModel
	var arropennowIPOModel []model.OpenIPOModel
	var arrrecentcloseIPOModel []model.RecentIPOModel
	indresult := []accord.Ipodetails{}
	err := db.Accord.Model(&accord.Ipodetails{}).Select("ipodetails.ip_ocode,ipodetails.fincode,opendate,closedate,listdate,listprice,issueprice1,issueprice2,nselist,minapln,total_eq_ui_ty,total_eq_ui_ty*issueprice2/10000000").Joins("inner join companymasters on ipodetails.fincode=companymasters.fincode").Joins("inner join ipo_listings on ipo_listings.fincode=ipodetails.fincode").Where("ipo_listings.stk_id=23 AND ipodetails.issueprice2!=0 AND total_eq_ui_ty*issueprice2/10000000 > 50 AND ABS(DateDiff(listdate,now())) < 275").Order("ipodetails.listdate desc").Order("companymasters.compname").Find(&indresult).Error
	if err != nil {
		return nil, err
	} else {
		for _, v := range indresult {
			compDetails := accord.Companymaster{}
			err = db.Accord.Model(&accord.Companymaster{}).Select("compname,isin").Where("fincode = ?", v.FINCODE).Find(&compDetails).Error
			if err != nil {
				return nil, err
			}

			var model model.RecentIPOModel
			companyWebUrls := accord.Company_weburl{}
			if v.FINCODE == 0 {
				model.CompanyUrl = ""
			} else {
				err = db.Accord.Model(&accord.Company_weburl{}).Select("URL").Where("fincode = ?", v.FINCODE).Find(&companyWebUrls).Error
				if err != nil {
					companyname := strings.ReplaceAll(compDetails.COMPNAME, " Ltd.", "")
					model.CompanyUrl = strings.ReplaceAll(companyname, " ", "-") + "-ipo.png"
				} else {
					model.CompanyUrl = strings.Replace(companyWebUrls.URL, "share-price", "ipo", 1)
				}
			}
			model.IPOCode = v.IPOCODE
			model.ListDate = v.LISTDATE
			model.Issueprice1 = v.ISSUEPRICE1
			model.Issueprice2 = v.ISSUEPRICE2
			model.ListPrice = v.LISTPRICE
			model.Isin = compDetails.ISIN
			model.NSEList = v.Nselist
			//(final - initial / intial ) * 100

			if model.NSEList != 0 && model.Issueprice2 != 0 {
				ratio := math.Pow(10, float64(2))
				listgain := math.Round(((model.NSEList-model.Issueprice2)/model.Issueprice2*100)*ratio) / ratio
				model.ListGain = listgain
			}

			model.MinaPlan = v.MINAPLN
			model.TotalEquity = v.TOTAL_EQUITY
			model.FinCode = v.FINCODE
			model.CompanyName = compDetails.COMPNAME
			model.OpenDate = v.OPENDATE
			model.CloseDate = v.CLOSEDATE
			model.IssueSize = (v.TOTAL_EQUITY * v.ISSUEPRICE2) / 10000000
			arrrecentIPOModel = append(arrrecentIPOModel, model)
		}
	}

	// 	select c.compname,i.* from ipodetails i
	// inner join companymasters c on c.fincode=i.fincode
	// where closedate < now()  and i.issuetype="Book Building" and (year(listdate) IN ("1070","0000") or listdate <now()) and c.isin="" and i.issueprice2!=0
	// ORDER BY `i`.`closedate` DESC;

	indresult = []accord.Ipodetails{}
	err = db.Accord.Model(&accord.Ipodetails{}).Joins("inner join companymasters on ipodetails.fincode=companymasters.fincode").Where("closedate <  ?  and issuetype='Book Building' and year(listdate) IN ('1070','0000')  and issueprice2!=0", time.Now()).Find(&indresult).Error
	if err != nil {
		return nil, err
	} else {
		for _, v := range indresult {
			compDetails := accord.Companymaster{}
			err = db.Accord.Model(&accord.Companymaster{}).Select("compname,isin").Where("fincode = ?", v.FINCODE).Find(&compDetails).Error

			if err != nil {
				return nil, err
			}

			var model model.RecentIPOModel
			companyWebUrls := accord.Company_weburl{}
			if v.FINCODE == 0 {
				companyname := strings.ReplaceAll(compDetails.COMPNAME, " Ltd.", "")
				model.CompanyUrl = strings.ReplaceAll(companyname, " ", "-") + "-ipo.png"
			} else {
				err = db.Accord.Model(&accord.Company_weburl{}).Select("URL").Where("fincode = ?", v.FINCODE).Find(&companyWebUrls).Error
				if err != nil {
					companyname := strings.ReplaceAll(compDetails.COMPNAME, " Ltd.", "")
					model.CompanyUrl = strings.ReplaceAll(companyname, " ", "-") + "-ipo.png"
				} else {
					companyname := strings.ReplaceAll(compDetails.COMPNAME, " Ltd.", "")
					model.CompanyUrl = strings.ReplaceAll(companyname, " ", "-") + "-ipo.png"
				}
			}
			model.IPOCode = v.IPOCODE
			model.ListDate = v.LISTDATE
			model.Issueprice1 = v.ISSUEPRICE1
			model.Issueprice2 = v.ISSUEPRICE2
			model.Isin = compDetails.ISIN
			model.NSEList = v.Nselist
			model.MinaPlan = v.MINAPLN
			model.TotalEquity = v.TOTAL_EQUITY
			model.FinCode = v.FINCODE
			model.CompanyName = compDetails.COMPNAME
			model.OpenDate = v.OPENDATE
			model.CloseDate = v.CLOSEDATE
			model.IssueSize = (v.TOTAL_EQUITY * v.ISSUEPRICE2) / 10000000
			fmt.Println(model)
			arrrecentcloseIPOModel = append(arrrecentcloseIPOModel, model)
		}
	}

	var arrcompanyIPOModel []model.OpenIPOModel
	companyResult := []accord.Ipodetails{}
	// closedate > now() and opendate > now() and closedate < DATE_ADD(now(), INTERVAL 1 WEEK)

	err = db.Accord.Model(&accord.Ipodetails{}).Joins("inner join companymasters on ipodetails.fincode=companymasters.fincode").Where("opendate >  now() and closedate > now() and closedate <  DATE_ADD(now(), INTERVAL 1 WEEK)  and issuetype='Book Building'").Find(&companyResult).Error
	if err != nil {
		return nil, err
	} else {
		for _, v := range companyResult {
			var model model.OpenIPOModel
			var compDetails accord.Companymaster
			err = db.Accord.Model(&accord.Companymaster{}).Select("compname").Where("fincode = ?", v.FINCODE).Find(&compDetails).Error
			if err == nil {
				companyWebUrls := accord.Company_weburl{}
				if v.FINCODE == 0 {
					companyname := strings.ReplaceAll(compDetails.COMPNAME, " Ltd.", "")
					model.CompanyUrl = strings.ReplaceAll(companyname, " ", "-") + "-ipo.png"
				} else {
					err = db.Accord.Model(&accord.Company_weburl{}).Select("URL").Where("fincode = ?", v.FINCODE).Find(&companyWebUrls).Error
					if err != nil {
						companyname := strings.ReplaceAll(compDetails.COMPNAME, " Ltd.", "")
						model.CompanyUrl = strings.ReplaceAll(companyname, " ", "-") + "-ipo.png"
					} else {
						companyname := strings.ReplaceAll(compDetails.COMPNAME, " Ltd.", "")
						model.CompanyUrl = strings.ReplaceAll(companyname, " ", "-") + "-ipo.png"
					}
				}
				model.IPOCode = v.IPOCODE
				model.ListDate = v.LISTDATE
				model.Issueprice1 = v.ISSUEPRICE1
				model.Issueprice2 = v.ISSUEPRICE2
				model.Isin = compDetails.ISIN
				model.NSEList = v.Nselist
				model.MinaPlan = v.MINAPLN
				model.TotalEquity = v.TOTAL_EQUITY
				model.FinCode = v.FINCODE
				model.CompanyName = compDetails.COMPNAME
				model.OpenDate = v.OPENDATE
				model.CloseDate = v.CLOSEDATE
				model.IssueSize = (v.TOTAL_EQUITY * v.ISSUEPRICE2) / 10000000
				arrcompanyIPOModel = append(arrcompanyIPOModel, model)
			} else {

			}

		}
	}
	indresult = []accord.Ipodetails{}
	err = db.Accord.Model(&accord.Ipodetails{}).Select("ipodetails.ip_ocode,ipodetails.fincode,opendate,closedate,listdate,issueprice1,issueprice2,nselist,minapln,total_eq_ui_ty,total_eq_ui_ty*issueprice2/10000000").Joins("inner join companymasters on ipodetails.fincode=companymasters.fincode").Where("closedate >= ? && opendate <= ? && ipodetails.issueprice2!=0", time.Now(), time.Now()).Order("ipodetails.listdate desc").Order("companymasters.compname").Find(&indresult).Error
	if err != nil {
		return nil, err
	} else {
		for _, v := range indresult {
			compDetails := accord.Companymaster{}
			err = db.Accord.Model(&accord.Companymaster{}).Select("compname,isin").Where("fincode = ?", v.FINCODE).Find(&compDetails).Error
			if err != nil {
				return nil, err
			}

			var model model.OpenIPOModel
			companyWebUrls := accord.Company_weburl{}
			if v.FINCODE == 0 {
				companyname := strings.ReplaceAll(compDetails.COMPNAME, " Ltd.", "")
				model.CompanyUrl = strings.ReplaceAll(companyname, " ", "-") + "-ipo.png"
			} else {
				err = db.Accord.Model(&accord.Company_weburl{}).Select("URL").Where("fincode = ?", v.FINCODE).Find(&companyWebUrls).Error
				if err != nil {
					companyname := strings.ReplaceAll(compDetails.COMPNAME, " Ltd.", "")
					model.CompanyUrl = strings.ReplaceAll(companyname, " ", "-") + "-ipo.png"
				} else {
					companyname := strings.ReplaceAll(compDetails.COMPNAME, " Ltd.", "")
					model.CompanyUrl = strings.ReplaceAll(companyname, " ", "-") + "-ipo.png"
				}
			}
			model.IPOCode = v.IPOCODE
			model.ListDate = v.LISTDATE
			model.Issueprice1 = v.ISSUEPRICE1
			model.Issueprice2 = v.ISSUEPRICE2
			model.Isin = compDetails.ISIN
			model.NSEList = v.Nselist
			model.MinaPlan = v.MINAPLN
			model.TotalEquity = v.TOTAL_EQUITY
			model.FinCode = v.FINCODE
			model.CompanyName = compDetails.COMPNAME
			model.OpenDate = v.OPENDATE
			model.CloseDate = v.CLOSEDATE
			model.IssueSize = (v.TOTAL_EQUITY * v.ISSUEPRICE2) / 10000000
			arropennowIPOModel = append(arropennowIPOModel, model)
		}
	}

	result.RecentlyAddedList = arrrecentIPOModel
	result.UpcomingList = arrcompanyIPOModel
	result.OpenNowList = arropennowIPOModel
	result.RecentlyClosedList = arrrecentcloseIPOModel
	return &result, nil
}

func IPODetails(symbol string, ipoDetails *model.IPODetails) {
	//select c.symbol,c.compname,ilo.stk_id,s.stk_name,i.issueprice,i.nselist,i.opendate,i.closedate,i.minapln,i.issueprice1,i.issueprice2 from companymasters c
	//inner join ipodetails i
	// on i.fincode=c.fincode
	//inner join ipo_listings ilo
	// on ilo.fincode=c.fincode
	//inner join stockexchangemasters s
	// on ilo.stk_id=s.stk_id
	//where  c.fincode = '208883' ;
	//.Select("companymasters.symbol,companymasters.compname,ipo_listings.stk_id,stockexchangemasters.stk_name,ipodetails.issueprice,ipodetails.nselist,ipodetails.opendate,ipodetails.closedate,ipodetails.minapln,ipodetails.issueprice1,ipodetails.issueprice2")
	companyDetails := accord.Companymaster{}
	ipodetails := accord.Ipodetails{}
	companyWebUrl := accord.Company_weburl{}
	var ipoListings []accord.Ipo_listings
	var stockExchangeMaster []accord.Stockexchangemaster
	symbol = strings.Replace(symbol, "ipo", "share-price", 1)
	err := db.Accord.Model(&accord.Company_weburl{}).Where("url like ?", "%"+symbol+"%").Find(&companyWebUrl).Error
	if err != nil {

	} else {
		err := db.Accord.Model(&accord.Companymaster{}).Where("fincode = ? ", companyWebUrl.FINCODE).Find(&companyDetails).Error
		if err != nil {

		} else {
			err := db.Accord.Model(&accord.Ipodetails{}).Where("ipodetails.fincode = ?", companyDetails.FINCODE).Find(&ipodetails).Error
			if err != nil {

			} else {
				err := db.Accord.Model(&accord.Ipo_listings{}).Where("fincode = ?", companyDetails.FINCODE).Find(&ipoListings).Error
				if err != nil {

				} else {
					ipoDetails.Symbol = companyDetails.SYMBOL
					ipoDetails.CompanyName = companyDetails.COMPNAME

					for _, v := range ipoListings {
						err := db.Accord.Model(&accord.Stockexchangemaster{}).Where("stk_id = ?", v.STK_ID).Find(&stockExchangeMaster).Error
						if err != nil {

						} else {
							for _, stock := range stockExchangeMaster {
								ipoDetails.StkId = append(ipoDetails.StkId, stock.STK_ID)
								ipoDetails.StkName = append(ipoDetails.StkName, stock.STK_NAME)
							}
						}
						//err = db.Accord.Model(&accord.Stockexchangemaster{}).Where("stk_id = ?", ipoListings.STK_ID).Find(stockExchangeMaster).Error
						//ipoDetails.StkName = append(ipoDetails.StkName, v.STK_NAME)
						ipoDetails.Fincode = companyDetails.FINCODE
						ipoDetails.IssuePrice = ipodetails.ISSUEPRICE
						ipoDetails.NSEList = ipodetails.Nselist
						ipoDetails.Opendate = ipodetails.OPENDATE
						ipoDetails.Closedate = ipodetails.CLOSEDATE
						ipoDetails.MinaPlan = ipodetails.MINAPLN
						ipoDetails.Issueprice1 = ipodetails.ISSUEPRICE1
						ipoDetails.Issueprice2 = ipodetails.ISSUEPRICE2
						if companyDetails.MDIR == "" {
							ipoDetails.Mdir = companyDetails.CHAIRMAN
						} else {
							ipoDetails.Mdir = companyDetails.MDIR
						}
						ipoDetails.Isin = companyDetails.ISIN
						ipoDetails.Objective = strings.Split(ipodetails.Objective, "\r\n\r\n")
						ipoDetails.Foundyear = companyDetails.INC_YEAR
						ipoDetails.CompanyUrl = strings.Replace(companyWebUrl.URL, "share-price", "ipo", 1)
					}
				}
			}

		}
	}
}

func DownloadDRHPDownload(symbol string, name string) ([]byte, error) {
	if Env == nil {
		Zerologs.Error().Msg("env is empty")
		return nil, errors.New("env is empty")
	}
	if Env.ACCORD_KEY == "" {
		Zerologs.Error().Msg("Env.AccordKey not found")
		return nil, errors.New("env.qccordKey not found")
	}
	if symbol == "" {
		Zerologs.Error().Msg("symbol is empt")
		return nil, errors.New("symbol is empty")
	}
	if db == nil {
		Zerologs.Error().Msg("db is null")
		return nil, errors.New("db is null")
	}
	if db.Accord == nil {
		Zerologs.Error().Msg("db.Accord is null")
		return nil, errors.New("db.Accord is null")
	}
	symbol = strings.Replace(symbol, "ipo-rhp", "share-price", 1)
	dbweburl := accord.Company_weburl{}
	err := db.Accord.Where("url=?", symbol).First(&dbweburl).Error
	if err != nil {
		Zerologs.Error().Err(err).Msg("Error in Company_weburl symbol =" + symbol)
		return nil, err
	}
	if dbweburl.URL != symbol {
		Zerologs.Error().Msg("symbol not match")
		return nil, errors.New("symbol not match")
	}
	ipoDetails := accord.Ipodetails{}
	err = db.Accord.Where("fincode = ? ", dbweburl.FINCODE).First(&ipoDetails).Error
	if err != nil {
		Zerologs.Error().Msg("accord.Ipodetails fincode=")
		return nil, err
	}
	if ipoDetails.IPOCODE <= 0 {
		Zerologs.Error().Msg("ipocode not found")
		return nil, errors.New("ipocode not found")
	}
	querystring := fmt.Sprintf("https://contentapi.accordwebservices.com/RawData/GetIPODPPDF?section=ipofile&ipocode=%d&token=J1yHW6kYHOBy0IuzePKWnGFWTv1J1ztD", int(ipoDetails.IPOCODE))
	body, err := helper.HttpGet(querystring)
	if err != nil {
		Zerologs.Error().Err(err).Msg("querystring = " + querystring)
		return nil, err
	} else {
		return body, nil
	}

}
