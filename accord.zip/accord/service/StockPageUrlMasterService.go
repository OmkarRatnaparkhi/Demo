package service

import (
	"crypto/md5"
	"fmt"
	"strconv"
	"strings"

	"github.com/TecXLab/libdb/accord"
	"github.com/TecXLab/libdb/contracts"
	"github.com/xuri/excelize/v2"
	"gorm.io/gorm"
)

func StockPageUrlMaster() (string, error) {
	// foocut path
	f, err := excelize.OpenFile(Env.VOLUMNE_PATH + "/accord/200 stocks - FIle with URL Paths - Aug-22.xlsx")
	// local path
	// f, err := excelize.OpenFile("C:/Users/admin/Downloads/200 stocks - FIle with URL Paths - Aug-22.xlsx")

	if err != nil {
		fmt.Println(err)
	}

	rows, err := f.GetRows("Top 200 List")
	if err != nil {
		fmt.Println(err)
	}
	count := 0
	db.Accord.Transaction(func(tx *gorm.DB) error {
		// var arrStockPageModel []model.StockPageUrlMaster
		for _, row := range rows {
			if row == nil || row[4] == "ISIN Code" {
				continue
			}
			var StockPageModel accord.StockPageUrlMaster
			StockPageModel.SISINCode = row[4]
			StockPageModel.SURLPath = row[5]
			// StockPageModel.NLastUpdatedTime = time.Now()
			// arrStockPageModel = append(arrStockPageModel, StockPageModel)
			var StockPageUrlModel accord.StockPageUrlMaster
			err := db.Accord.Where("sisin_code=?", row[4]).First(&StockPageUrlModel).Error
			if err != nil {
				err := tx.Create(&StockPageModel).Error
				if err != nil {
					fmt.Println(err)
				}
			} else {
				err = tx.Model(&accord.StockPageUrlMaster{}).Where("sisin_code=?", row[4]).Update("s_url_path", row[5]).Error
				if err != nil {
					fmt.Println(err)
				}
			}
			count++
		}
		return nil
	})
	fmt.Println("Total Record updated " + strconv.Itoa(count))

	// err = db.Accord.Create(arrStockPageModel).Error
	// if err != nil {
	// 	fmt.Println(err)
	// }
	return "Success", nil
}

func StockPageUrlMasterUpload(fileData []byte) error {

	hash := md5.Sum(fileData)
	smd5 := fmt.Sprintf("%x", hash)
	err := db.Accord.Transaction(func(tx *gorm.DB) error {
		dbweburl := accord.MDFIVE{}
		err := db.Accord.First(&dbweburl).Error
		bfind := false
		if err != nil {
			//return err
			bfind = false
		} else {
			bfind = true
		}

		if dbweburl.MD5 == smd5 {
			return nil
		}
		var strData = string(fileData)
		splitrow := strings.Split(strData, "\n")
		for _, v := range splitrow {
			splitrecord := strings.Split(v, ",")
			if len(splitrecord) == 3 {
				dbcompmaster := accord.Companymaster{}
				err := tx.Where("isin=?", splitrecord[1]).First(&dbcompmaster).Error
				if err != nil {
					continue
				}
				dburlmaster := accord.Company_weburl{}
				err = tx.Where("fincode=?", dbcompmaster.FINCODE).First(&dburlmaster).Error
				if err != nil {
					eqcontract := contracts.Contract_NSEEQ{}
					err = contractdb.Client.Where("sisin=?", splitrecord[1]).First(&eqcontract).Error
					if err != nil {
						return err
					}
					dburlmaster = accord.Company_weburl{
						FINCODE: dbcompmaster.FINCODE,
						TOKEN:   eqcontract.NToken,
						URL:     strings.Trim(strings.Trim(splitrecord[2], "\r"), " "),
					}
					err = tx.Create(&dburlmaster).Error
					if err != nil {
						return err
					}
				} else {
					dburlmaster.URL = strings.Trim(strings.Trim(splitrecord[2], "\r"), " ")
					err = tx.Save(&dburlmaster).Error
					if err != nil {
						return err

					}
				}

			}

		}
		dbweburl.MD5 = smd5
		if bfind {
			err = tx.Save(&dbweburl).Error
			if err != nil {
				return err
			}
		} else {
			err = tx.Create(&dbweburl).Error
			if err != nil {
				return err
			}
		}
		return nil
	})

	return err
}
