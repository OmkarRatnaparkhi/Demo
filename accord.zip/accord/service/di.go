package service

import (
	"github.com/TecXLab/libdb"
	"github.com/TecXLab/libdrainer"
	"github.com/TecXLab/libenv"
	"github.com/TecXLab/libinterface"
	"github.com/TecXLab/libredis"
	"github.com/golobby/container/v3"
	"github.com/rs/zerolog"
)

var (
	q                 *libdrainer.Q
	db                *libdb.AccordDB
	contractdb        *libdb.ContractMasterDB
	RedisLib          *libredis.RedisClient
	Env               *libenv.Env
	Zerologs          zerolog.Logger
	BaseURL           string
	TypessenseKey     string
	TypessenseValue   string
	CollectionName    string
	Query_By          string
	Query_ByLetter    string
	Group_Limit       string
	PerPage           string
	Sort_by           string
	Exhaustive_search string
	AccordFacet_by    string
	AccordmcapSort    string
)

func InitDI() error {
	err := container.Resolve(&Env)
	if err != nil {
		panic("Env Lib Not Initialize" + err.Error())
	}
	err = container.NamedResolve(&Zerologs, "zerologs")
	if err != nil {
		panic("Log Lib Not Initialize" + err.Error())
	}

	err = container.NamedResolve(&q, "timerdrainer")
	if err != nil {
		panic("Drainer Lib Not Initialize" + err.Error())
	}

	var userdb libinterface.IDBContext
	err = container.NamedResolve(&userdb, Env.DI_DB_ACCORD)
	if err != nil {
		panic("Database Lib Not Initialize" + err.Error())
	}
	db = userdb.(*libdb.AccordDB)

	var contrb libinterface.IDBContract
	err = container.NamedResolve(&contrb, Env.DI_DB_CONTRACTS)
	if err != nil {
		panic("Database Lib Not Initialize" + err.Error())
	}
	contractdb = contrb.(*libdb.ContractMasterDB)

	// err = container.Resolve(&RedisLib)
	// if err != nil {
	// 	panic("RedisLib Lib Not Initialize" + err.Error())
	// }

	FunctionMap["companymaster"] = Companymaster
	FunctionMap["industrymaster"] = Industrymaster
	FunctionMap["housemaster"] = Housemaster
	FunctionMap["stockexchangemaster"] = Stockexchangemaster
	FunctionMap["complistings"] = Complistings
	FunctionMap["companyaddress"] = Companyaddress
	FunctionMap["registrarmaster"] = Registrarmaster
	FunctionMap["registrardata"] = Registrardata
	FunctionMap["board"] = Board
	FunctionMap["monthlyprice"] = Monthlyprice
	FunctionMap["nse_monthprice"] = Nse_Monthprice
	FunctionMap["finance_bs"] = Finance_bs
	FunctionMap["finance_cons_bs"] = Finance_cons_bs
	FunctionMap["finance_pl"] = Finance_pl
	FunctionMap["finance_cons_pl"] = Finance_cons_pl
	FunctionMap["quarterly"] = Quarterly
	FunctionMap["quarterly_cons"] = Quarterly_Cons
	FunctionMap["finance_fr"] = Finance_fr
	FunctionMap["finance_cons_fr"] = Finance_cons_fr
	FunctionMap["finance_cf"] = Finance_cf
	FunctionMap["finance_cons_cf"] = Finance_cons_cf
	FunctionMap["shpsummary"] = Shpsummary
	FunctionMap["shp_details"] = Shp_details
	FunctionMap["shp_catmaster_2"] = Shp_catmaster_2
	FunctionMap["company_equity"] = Company_equity
	FunctionMap["company_equity_cons"] = Company_equity_cons
	FunctionMap["corpevents"] = CorpEvents
	FunctionMap["corpevent_mst"] = CorpEventMaster
	FunctionMap["ipodetails"] = Ipodetails
	FunctionMap["ipo_registrar"] = Ipo_Registrar
	FunctionMap["ipo_leadmgr"] = Ipo_leadmgr
	FunctionMap["ipo_listings"] = Ipo_listings
	FunctionMap["ipo_promoters"] = Ipo_promoters
	FunctionMap["ipo_projects"] = Ipo_projects
	FunctionMap["ipo_promoterholdings"] = Ipo_promoterholdings
	FunctionMap["namechange"] = Namechange
	FunctionMap["delistedcompanies"] = Delistedcompanies
	FunctionMap["bse_bulkdeals"] = Bse_bulkdeals
	FunctionMap["bse_blockdeals"] = Bse_blockdeals
	FunctionMap["insider_trading"] = Insider_trading
	FunctionMap["bsedeliverables"] = Bsedeliverables
	//FunctionMap["ipo_syndicate"] = Companymaster
	FunctionMap["ipo_subscriptions"] = Ipo_subscriptions
	FunctionMap["amc_mst"] = Amc_mst
	FunctionMap["scheme_master"] = SchemeMaster
	FunctionMap["scheme_details"] = Scheme_details
	FunctionMap["sclass_mst"] = Sclass_mst
	FunctionMap["asect_mst"] = Asect_mst
	FunctionMap["cust_mst"] = Cust_mst
	FunctionMap["option_mst"] = Option_mst
	FunctionMap["plan_mst"] = Plan_mst
	FunctionMap["div_mst"] = Div_mst
	FunctionMap["rt_mst"] = Rt_mst
	FunctionMap["sect_mst"] = Sect_mst
	FunctionMap["type_mst"] = Type_mst
	FunctionMap["loadtype_mst"] = Loadtype_mst
	FunctionMap["index_mst"] = Index_mst
	FunctionMap["scheme_objective"] = Scheme_objective
	FunctionMap["scheme_rtcode"] = Scheme_rtcode
	FunctionMap["amc_keypersons"] = Amc_keypersons
	FunctionMap["mf_sip"] = Mf_sip
	FunctionMap["mf_swp"] = Mf_swp
	FunctionMap["scheme_index_part"] = Scheme_index_part
	// FunctionMap["companymastermf"] = Companymaster
	FunctionMap["fundmanager_mst"] = Fundmanager_mst
	FunctionMap["schemeisinmaster"] = Schemeisinmaster
	FunctionMap["scheme_rgess"] = Scheme_Rgess
	FunctionMap["schemeload"] = Schemeload
	FunctionMap["industry_mst"] = Industry_mst
	FunctionMap["mf_portfolio"] = Mf_portfolio
	FunctionMap["amc_aum"] = Amc_aum
	FunctionMap["scheme_aum"] = Scheme_aum
	FunctionMap["portfolio_inout"] = Portfolio_inout
	FunctionMap["sect_allocation"] = Sect_allocation
	FunctionMap["amc_paum"] = Amc_paum
	FunctionMap["scheme_paum"] = Scheme_paum
	FunctionMap["avg_scheme_aum"] = Avg_scheme_aum
	FunctionMap["currentnav"] = Currentnav
	FunctionMap["navhist_1"] = Navhist
	FunctionMap["navhist_2"] = Navhist
	FunctionMap["navhist_3"] = Navhist
	FunctionMap["navhist_4"] = Navhist
	FunctionMap["navhist_5"] = Navhist
	FunctionMap["navhist_6"] = Navhist
	FunctionMap["navhist_7"] = Navhist
	FunctionMap["navhist"] = Navhist
	FunctionMap["navhist_hl"] = Navhist_HL
	FunctionMap["mf_return"] = Mf_return
	FunctionMap["mf_abs_return"] = Mf_abs_return
	FunctionMap["mf_ans_return"] = Mf_ans_return
	FunctionMap["classwisereturn"] = ClassWisereturn
	FunctionMap["mf_ratio"] = Mf_ratio
	FunctionMap["mf_ratios_defaultbm"] = MF_Ratios_DefaultBM
	FunctionMap["bm_absolutereturn"] = BM_AbsoluteReturn
	FunctionMap["bm_annualisedreturn"] = BM_AnnualisedReturn
	FunctionMap["divdetails"] = Divdetails
	FunctionMap["expenceratio"] = Expenceratio
	FunctionMap["scheme_eq_details"] = Scheme_eq_details
	FunctionMap["fmp_yielddetails"] = Fmp_yielddetails
	FunctionMap["avg_maturity"] = Avg_maturity
	FunctionMap["fvchange"] = Fvchange
	FunctionMap["scheme_name_change"] = Scheme_NameChange
	FunctionMap["dailyfundmanager"] = DailyFundmanager
	FunctionMap["mergedschemes"] = Mergedschemes
	FunctionMap["mfbulkdeals"] = MFBULKDEALS
	FunctionMap["scheme_assetalloc"] = Scheme_assetalloc
	FunctionMap["company_earnings"] = News
	FunctionMap["company_news"] = News
	FunctionMap["economy_mktpulse"] = News
	FunctionMap["economy_indmkt"] = News
	FunctionMap["economy_inflation"] = News
	FunctionMap["equity_closingbell"] = News
	FunctionMap["equity_corpnews"] = News
	FunctionMap["equity_global"] = News
	FunctionMap["equity_midday"] = News
	FunctionMap["equity_movers"] = News
	FunctionMap["equity_stockalerts"] = News
	FunctionMap["equity_corpresult"] = News
	FunctionMap["equity_openingbell"] = News
	FunctionMap["ipo_analysis"] = News
	FunctionMap["ipo_news"] = News
	FunctionMap["mfinews"] = News
	FunctionMap["mfimf"] = News
	FunctionMap["fao_news"] = News
	FunctionMap["commodity_news"] = News
	FunctionMap["commodity_price"] = News
	FunctionMap["commodity_intmkt"] = News
	FunctionMap["others_politicalnews"] = News
	FunctionMap["others_fiiposition"] = News
	FunctionMap["money_bonds"] = News
	FunctionMap["money_callmoney"] = News
	FunctionMap["money_forexrates"] = News
	FunctionMap["finance_currency"] = News
	FunctionMap["mf_stp"] = Mf_stp
	FunctionMap["companymastermf"] = CompanymasterMF
	FunctionMap["ipo_syndicate"] = Ipo_syndicate

	return nil
}

func InitEnvvariables() {
	BaseURL = "https://www.foocut.com"
	TypessenseKey = Env.TYPESENSE_KEY
	TypessenseValue = Env.TYPESENSE_VALUE
	CollectionName = Env.ACCORD_TYPESENSE_COLLECTION
	Query_By = Env.ACCORD_TYPESENSE_QUERY_BY
	Group_Limit = Env.TYPESENSE_GROUP_LIMIT
	PerPage = Env.ACCORD_TYPESENSE_PERPAGE
	Sort_by = Env.ACCORD_TYPESENSE_SORT_BY
	Exhaustive_search = Env.TYPESENSE_EXHAUSTIVE_SEARCH
	AccordFacet_by = "industry"
	AccordmcapSort = "mcap:desc"
	Query_ByLetter = "startletter"
}
