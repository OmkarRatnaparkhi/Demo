package service

import (
	"accorddata/model"
	"encoding/csv"
	"fmt"
	"os"
	"strings"
)

var UrlMap = make(map[string]model.ParamData)
var TimerMap = make(map[string][]string)

func InitRouteFile(path string) error {
	csvFile, err := os.Open(path)
	if err != nil {
		fmt.Println(err)
		return err
	}
	fmt.Println("Successfully Opened CSV file")
	defer csvFile.Close()

	csvLines, err := csv.NewReader(csvFile).ReadAll()
	if err != nil {
		fmt.Println(err)
		return err
	}

	// fmt.Println(csvLines)

	for _, line := range csvLines {
		param := model.ParamData{
			MainMenu: line[0],
			Handler:  line[1],
			URL:      line[2],
			Sub:      line[3],
			Token:    line[4],
			Timer:    line[5],
		}
		name := strings.ToLower(param.Handler)
		splitstr := strings.Split(param.Timer, "/")
		for i := 0; i < len(splitstr); i++ {
			stime := splitstr[i]
			if stime != "" {
				TimerMap[stime] = append(TimerMap[stime], name)
			}
		}

		UrlMap[name] = param
	}
	return nil
}
