package service

import (
	"accorddata/model"
	"bytes"
	"encoding/json"
	"fmt"
	"net/http"
	"time"

	"github.com/TecXLab/libdb/accord"
	"github.com/TecXLab/libdb/contracts"
	"github.com/typesense/typesense-go/typesense"
	"github.com/typesense/typesense-go/typesense/api"
)

var collectionname = "companymasters"

var EnumNSECMInstrumentType = map[string]int{
	"Equities": 0,
}

func getContractDay() int64 {
	t1 := time.Date(2018, time.Month(1), 1, 0, 0, 0, 0, time.UTC)
	t2 := time.Now()
	days := int64(t2.Sub(t1).Hours() / 24)
	return days
}

func DropCollection() {
	// t := time.Now()
	// Today := t.Format("02-01-2006 15:04:05")

	client := typesense.NewClient(
		typesense.WithServer(BaseURL),
		typesense.WithAPIKey(TypessenseValue))

	client.Collection(collectionname).Delete()

	// elapsed := time.Since(t)
	// ReqTime := fmt.Sprintf("%v", elapsed)
	// str := Today + "\n Data of " + collectionname + " collection dropped sucessfully in " + ReqTime
	// err := SentToAccordCronJob(str)
	// if err != nil {
	// 	fmt.Println("Error while sending to slack")
	// }

	// Zerologs.Info().Msg(time.Now().Format("2006-01-02 15:04:05") + " Sucessfully collection dropped from Typesense. ")
	// fmt.Println(time.Now().Format("2006-01-02 15:04:05") + " Sucessfully collection dropped from Typesense. ")
}

func uploadtypesenseData(objData interface{}, companyurl interface{}, ssymbol string, ntoken int) error {
	Zerologs.Info().Msg("uploadtypesenseData Start")
	client := typesense.NewClient(
		typesense.WithServer(BaseURL),
		typesense.WithAPIKey(TypessenseValue))

	_, err := client.Collection(collectionname).Retrieve()
	if err != nil {
		bfacet := true
		schema := &api.CollectionSchema{
			Name: collectionname,
			Fields: []api.Field{
				{
					Name:  "exid",
					Type:  "int64",
					Facet: &bfacet,
				},
				{
					Name:  "fincode",
					Type:  "int64",
					Facet: &bfacet,
				},
				{
					Name:  "scrnm",
					Type:  "string",
					Facet: &bfacet,
				},
				{
					Name:  "cnm",
					Type:  "string",
					Facet: &bfacet,
				},
				{
					Name:  "isin",
					Type:  "string",
					Facet: &bfacet,
				},
				{
					Name:  "tk",
					Type:  "int64",
					Facet: &bfacet,
				},
				{
					Name:  "url",
					Type:  "string",
					Facet: &bfacet,
				},
				{
					Name:  "symbl",
					Type:  "string",
					Facet: &bfacet,
				},
				{
					Name:  "industry",
					Type:  "string",
					Facet: &bfacet,
				},
			},
			// DefaultSortingField: ,
		}
		_, err := client.Collections().Create(schema)
		if err != nil {
			fmt.Println(err)
		}
	}

	objDocModel := model.TypesenseDocumentModel{}

	objDetails := objData.(accord.Companymaster)
	objDocModel.ExchangeID = 1
	objDocModel.Fincode = int64(objDetails.FINCODE)
	objDocModel.Scr_ip_name = objDetails.SCRIP_NAME
	objDocModel.Compname = objDetails.COMPNAME
	objDocModel.Isin = objDetails.ISIN

	objcompanyurl := companyurl.(accord.Company_weburl)
	objDocModel.URL = objcompanyurl.URL

	objDocModel.SSymbol = ssymbol
	objDocModel.Token = ntoken
	document := objDocModel

	_, err = client.Collection(collectionname).Documents().Upsert(document)
	if err != nil {
		Zerologs.Error().Err(err).Msgf("Error in uploadtypesenseData")
		fmt.Println(err)
		return err
	}
	return nil
}

func uploadtypesenseData1(objData []interface{}) error {
	Zerologs.Info().Msg("uploadtypesenseData Start")
	client := typesense.NewClient(
		typesense.WithServer(BaseURL),
		typesense.WithAPIKey(TypessenseValue))

	_, err := client.Collection(collectionname).Retrieve()
	if err != nil {
		bfacet := true
		schema := &api.CollectionSchema{
			Name: collectionname,
			Fields: []api.Field{
				{
					Name:  "exid",
					Type:  "int64",
					Facet: &bfacet,
				},
				{
					Name:  "fincode",
					Type:  "int64",
					Facet: &bfacet,
				},
				{
					Name:  "scrnm",
					Type:  "string",
					Facet: &bfacet,
				},
				{
					Name:  "cnm",
					Type:  "string",
					Facet: &bfacet,
				},
				{
					Name:  "isin",
					Type:  "string",
					Facet: &bfacet,
				},
				{
					Name:  "tk",
					Type:  "int64",
					Facet: &bfacet,
				},
				{
					Name:  "url",
					Type:  "string",
					Facet: &bfacet,
				},
				{
					Name:  "symbl",
					Type:  "string",
					Facet: &bfacet,
				},
				{
					Name:  "industry",
					Type:  "string",
					Facet: &bfacet,
				},
				{
					Name:  "mcap",
					Type:  "float",
					Facet: &bfacet,
				},
				{
					Name:  "startletter",
					Type:  "string",
					Facet: &bfacet,
				},
			},
			// DefaultSortingField: ,
		}
		_, err := client.Collections().Create(schema)
		if err != nil {
			fmt.Println(err)
		}
	}

	document := objData

	var action = "upsert"
	var batch = 40
	params := &api.ImportDocumentsParams{
		Action:    &action,
		BatchSize: &batch,
	}

	_, err = client.Collection(collectionname).Documents().Import(document, params)
	if err != nil {
		Zerologs.Error().Err(err).Msgf("Error in uploadtypesenseData")
		fmt.Println(err)
		return err
	}
	return nil
}

func GetDataFromDB() {
	Zerologs.Info().Msg(time.Now().Format("2006-01-02 15:04:05") + " Data Reading from DB Start.")
	fmt.Println(time.Now().Format("2006-01-02 15:04:05") + " Data Reading from DB Start.")

	var (
		companymasterdata []accord.Companymaster
	)

	db.Accord.Find(&companymasterdata)

	fmt.Println("companymasterdata Count:", len(companymasterdata))
	Zerologs.Info().Msgf("companymasterdata Count %d", len(companymasterdata))

	Zerologs.Info().Msg(time.Now().Format("2006-01-02 15:04:05") + " Data Reading from DB End.")
	fmt.Println(time.Now().Format("2006-01-02 15:04:05") + " Data Reading from DB End.")

	Zerologs.Info().Msg(time.Now().Format("2006-01-02 15:04:05") + " Uploading Data to Typesense Start.")
	fmt.Println(time.Now().Format("2006-01-02 15:04:05") + " Uploading Data to Typesense Start.")

	days := getContractDay()

	for _, v := range companymasterdata {
		var symbol string
		var token int
		model := accord.Company_weburl{}
		eqmodel := contracts.Contract_NSEEQ{}
		err := db.Accord.Model(&accord.Company_weburl{}).Where("fincode=?", v.FINCODE).Find(&model).Error
		if err != nil {
			Zerologs.Error().Err(err).Msgf("Error while finding data")
			fmt.Println(err)
		} else {
			err := contractdb.Client.Model(&contracts.Contract_NSEEQ{}).Where("n_contract_date=? AND s_series=? AND sisin=?", days, "EQ", v.ISIN).Find(&eqmodel).Error
			if err != nil {
				Zerologs.Error().Err(err).Msgf("Error while finding data")
				fmt.Println(err)
			} else {
				symbol = eqmodel.SSymbol
				token = eqmodel.NToken
			}
			uploadtypesenseData(v, model, symbol, token)
		}
	}

	Zerologs.Info().Msg(time.Now().Format("2006-01-02 15:04:05") + " Uploading Data to Typesense End.")
	fmt.Println(time.Now().Format("2006-01-02 15:04:05") + " Uploading Data to Typesense End.")
}

func GetDataFromDBOptimized() {

	// t := time.Now()
	// Today := t.Format("02-01-2006 15:04:05")
	Zerologs.Info().Msg(time.Now().Format("2006-01-02 15:04:05") + " Data Reading from DB Start.")
	fmt.Println(time.Now().Format("2006-01-02 15:04:05") + " Data Reading from DB Start.")

	var (
		companymasterdata    []accord.Companymaster
		mf_companymasterdata []accord.MF_Companymaster
		indexmaster          []contracts.IndexMaster
	)

	/*******************Upload Equity data********************/
	db.Accord.Find(&companymasterdata)

	fmt.Println("companymasterdata Count:", len(companymasterdata))
	Zerologs.Info().Msgf("companymasterdata Count %d", len(companymasterdata))

	Zerologs.Info().Msg(time.Now().Format("2006-01-02 15:04:05") + " Data Reading from DB End.")
	fmt.Println(time.Now().Format("2006-01-02 15:04:05") + " Data Reading from DB End.")

	Zerologs.Info().Msg(time.Now().Format("2006-01-02 15:04:05") + " Uploading Data to Typesense Start.")
	fmt.Println(time.Now().Format("2006-01-02 15:04:05") + " Uploading Data to Typesense Start.")

	if len(companymasterdata) > 0 {
		doc := GenerateDoc(companymasterdata)
		if len(doc) > 0 {
			batch := 500
			for i := 0; i < len(doc); i += batch {
				j := i + batch
				if j > len(doc) {
					j = len(doc)
				}
				uploadtypesenseData1(doc[i:j]) // Process the batch.
				fmt.Println("Uploading typesense data...", i, j)
			}
		}
	}

	/*******************Upload Mutual Fund data********************/
	Zerologs.Info().Msg(time.Now().Format("2006-01-02 15:04:05") + "Mutual fund data Reading from DB Start.")
	fmt.Println(time.Now().Format("2006-01-02 15:04:05") + "Mutual fund data Reading from DB Start.")

	//db.Accord.Find(&mf_companymasterdata)
	db.Accord.Where("status=? or series=?", "MutualFund", "MF").Find(&mf_companymasterdata)

	fmt.Println("Mfcompanymasterdata Count:", len(mf_companymasterdata))
	Zerologs.Info().Msgf("Mfcompanymasterdata Count %d", len(mf_companymasterdata))

	Zerologs.Info().Msg(time.Now().Format("2006-01-02 15:04:05") + " Data Reading from DB End.")
	fmt.Println(time.Now().Format("2006-01-02 15:04:05") + " Data Reading from DB End.")

	Zerologs.Info().Msg(time.Now().Format("2006-01-02 15:04:05") + " Uploading Data to Typesense Start.")
	fmt.Println(time.Now().Format("2006-01-02 15:04:05") + " Uploading Data to Typesense Start.")

	if len(mf_companymasterdata) > 0 {
		doc := GenerateMfDoc(mf_companymasterdata)
		if len(doc) > 0 {
			batch := 500
			for i := 0; i < len(doc); i += batch {
				j := i + batch
				if j > len(doc) {
					j = len(doc)
				}
				uploadtypesenseData1(doc[i:j])
				fmt.Println("Uploading typesense data...", i, j)
			}
		}
	}

	/*******************Upload Index Master data********************/
	Zerologs.Info().Msg(time.Now().Format("2006-01-02 15:04:05") + "Indexmaster data Reading from DB Start.")
	fmt.Println(time.Now().Format("2006-01-02 15:04:05") + "Indexmaster data Reading from DB Start.")

	contractdb.Client.Find(&indexmaster)

	fmt.Println("Indexmaster Count:", len(indexmaster))
	Zerologs.Info().Msgf("Indexmaster Count %d", len(indexmaster))

	Zerologs.Info().Msg(time.Now().Format("2006-01-02 15:04:05") + " Data Reading from DB End.")
	fmt.Println(time.Now().Format("2006-01-02 15:04:05") + " Data Reading from DB End.")

	Zerologs.Info().Msg(time.Now().Format("2006-01-02 15:04:05") + " Uploading Data to Typesense Start.")
	fmt.Println(time.Now().Format("2006-01-02 15:04:05") + " Uploading Data to Typesense Start.")

	if len(indexmaster) > 0 {
		doc := GenerateIndexMaster(indexmaster)
		if len(doc) > 0 {
			uploadtypesenseData1(doc)
		}
		Zerologs.Info().Msg(time.Now().Format("2006-01-02 15:04:05") + " Uploading Indexmaster data to Typesense Done.")
		fmt.Println(time.Now().Format("2006-01-02 15:04:05") + " Uploading Indexmaster data to Typesense Done.")
	}

	// elapsed := time.Since(t)
	// ReqTime := fmt.Sprintf("%v", elapsed)
	// str := Today + "\n Accord data inserted in " + collectionname + " collection of typesense in " + ReqTime + "\n Length of companymaster data = " + strconv.Itoa(len(companymasterdata)) + "\n Length of mf_companymaster data = " + strconv.Itoa(len(mf_companymasterdata)) + "\n Length of indexmaster = " + strconv.Itoa(len(indexmaster))
	// err := SentToAccordCronJob(str)
	// if err != nil {
	// 	fmt.Println("Error while sending to slack")
	// }
	// Zerologs.Info().Msg(time.Now().Format("2006-01-02 15:04:05") + " Uploading Data to Typesense End.")
	// fmt.Println(time.Now().Format("2006-01-02 15:04:05") + " Uploading Data to Typesense End.")

}

func GetMfDataFromDB() {
	Zerologs.Info().Msg(time.Now().Format("2006-01-02 15:04:05") + " Data Reading from DB Start.")
	fmt.Println(time.Now().Format("2006-01-02 15:04:05") + " Data Reading from DB Start.")

	var (
		mf_companymasterdata []accord.MF_Companymaster
	)

	db.Accord.Find(&mf_companymasterdata)

	fmt.Println("companymasterdata Count:", len(mf_companymasterdata))
	Zerologs.Info().Msgf("companymasterdata Count %d", len(mf_companymasterdata))

	Zerologs.Info().Msg(time.Now().Format("2006-01-02 15:04:05") + " Data Reading from DB End.")
	fmt.Println(time.Now().Format("2006-01-02 15:04:05") + " Data Reading from DB End.")

	Zerologs.Info().Msg(time.Now().Format("2006-01-02 15:04:05") + " Uploading Data to Typesense Start.")
	fmt.Println(time.Now().Format("2006-01-02 15:04:05") + " Uploading Data to Typesense Start.")

	if len(mf_companymasterdata) > 0 {
		doc := GenerateMfDoc(mf_companymasterdata)
		if len(doc) > 0 {
			batch := 500
			for i := 0; i < len(doc); i += batch {
				j := i + batch
				if j > len(doc) {
					j = len(doc)
				}
				uploadtypesenseData1(doc[i:j])
				fmt.Println("Uploading typesense data...", i, j)
			}
		}
	}

	Zerologs.Info().Msg(time.Now().Format("2006-01-02 15:04:05") + " Uploading Data to Typesense End.")
	fmt.Println(time.Now().Format("2006-01-02 15:04:05") + " Uploading Data to Typesense End.")
}

func GenerateDoc(companymasterdata []accord.Companymaster) []interface{} {
	slcDocument := make([]interface{}, len(companymasterdata))

	days := getContractDay()

	var objWeb1 []accord.Company_weburl
	var eqmodel1 []contracts.Contract_NSEEQ
	db.Accord.Model(&accord.Company_weburl{}).Find(&objWeb1)
	contractdb.Client.Model(&contracts.Contract_NSEEQ{}).Where("n_contract_date=? AND s_series=?", days, "EQ").Find(&eqmodel1)

	fmt.Println("webUrl Count: ", len(objWeb1))
	fmt.Println("nseeq Count: ", len(eqmodel1))

	mapWebUrl := make(map[int64]accord.Company_weburl)
	mapNSEEQ := make(map[string]contracts.Contract_NSEEQ)

	for i := 0; i < len(objWeb1); i++ {
		mapWebUrl[(int64(objWeb1[i].FINCODE))] = objWeb1[i]
	}

	for i := 0; i < len(eqmodel1); i++ {
		mapNSEEQ[eqmodel1[i].SISIN] = eqmodel1[i]
	}
	//var count int
	for v := range companymasterdata {

		objDocModel := model.TypesenseDocumentModel{}

		objDocModel.ExchangeID = 1

		objDocModel.Fincode = int64(companymasterdata[v].FINCODE)
		if mapWebUrl[objDocModel.Fincode].URL == "" {
			continue
		}
		objDocModel.Scr_ip_name = companymasterdata[v].SCRIP_NAME
		objDocModel.Compname = companymasterdata[v].COMPNAME
		objDocModel.Start_Letter = objDocModel.Compname[0:1]
		objDocModel.Isin = companymasterdata[v].ISIN

		objDocModel.URL = mapWebUrl[objDocModel.Fincode].URL

		objDocModel.SSymbol = mapNSEEQ[objDocModel.Isin].SSymbol
		objDocModel.Token = mapNSEEQ[objDocModel.Isin].NToken
		sectordetail := accord.Industry_mst{}
		err := db.Accord.Where("ind_code=?", companymasterdata[v].IND_CODE).First(&sectordetail).Error
		if err != nil {
			Zerologs.Error().Err(err).Msgf("Error while  getting ind_code from Industry_mst")
			fmt.Println(err)
			//return err
		} else {
			objDocModel.Industry = sectordetail.Industry
		}
		CompanyEQData := accord.Company_equity{}
		//err = db.Accord.Select("mcap").Where("fincode = ?", objDocModel.Fincode).Last(&CompanyEQData).Error
		//err = db.Accord.Where("fincode=?", companymasterdata[v].FINCODE).First(&CompanyEQData).Error
		err = db.Accord.Select("mcap").Where("fincode = ?", companymasterdata[v].FINCODE).Last(&CompanyEQData).Error
		if err != nil {
			Zerologs.Error().Err(err).Msgf("Error while getting MCAP from company_equities")
			fmt.Println(err)
		} else {
			//count++
			//objDocModel.MCAP = fmt.Sprintf("%.2f", CompanyEQData.MCAP)
			objDocModel.MCAP = CompanyEQData.MCAP
			//fmt.Println(count)
			//fmt.Println(strconv.Itoa(companymasterdata[v].FINCODE) + " " + companymasterdata[v].COMPNAME + " ")
		}

		slcDocument[v] = objDocModel

	}

	return slcDocument
}

func GenerateMfDoc(mf_companymasterdata []accord.MF_Companymaster) []interface{} {

	if len(mf_companymasterdata) > 0 {
		slcDocument := make([]interface{}, len(mf_companymasterdata))

		for i := range mf_companymasterdata {
			objMfDocModel := model.TypesenseDocumentModel{}
			objMfScripDetails := mf_companymasterdata[i]

			objMfDocModel.ExchangeID = 4
			objMfDocModel.Fincode = int64(objMfScripDetails.Fincode)
			objMfDocModel.Scr_ip_name = objMfScripDetails.S_name
			objMfDocModel.Compname = objMfScripDetails.Compname
			objMfDocModel.Start_Letter = objMfScripDetails.Compname[0:1]
			objMfDocModel.Isin = objMfScripDetails.Isin
			objMfDocModel.Industry = objMfScripDetails.Industry
			slcDocument[i] = objMfDocModel
		}
		return slcDocument
	}
	return nil
}

func GenerateIndexMaster(indexmaster []contracts.IndexMaster) []interface{} {
	if len(indexmaster) > 0 {

		slcDocument := make([]interface{}, len(indexmaster))

		for i := range indexmaster {
			objDocModel := model.TypesenseDocumentModel{}
			objScripDetails := indexmaster[i]
			objDocModel.Compname = objScripDetails.SIndexName
			objDocModel.Start_Letter = objScripDetails.SIndexName[0:1]
			objDocModel.ExchangeID = 1
			objDocModel.Token = objScripDetails.NtokenNo
			objDocModel.Scr_ip_name = objScripDetails.SIndexName
			objDocModel.SSymbol = objScripDetails.S_Symbol
			slcDocument[i] = objDocModel
		}
		return slcDocument
	}
	return nil
}

func SentToAccordCronJob(str string) error {
	var objSlackMessage model.SlackMessage
	objSlackMessage.Text = str
	jsonStr, err := json.Marshal(objSlackMessage)
	if err != nil {
		Zerologs.Debug().Stack().Err(err).Msg("Error in marshalling objSlackMessage")
		return err
	}

	req, err := http.NewRequest("POST", Env.SLACKURL_ACCORDCRONJOB, bytes.NewBuffer(jsonStr))
	if err != nil {
		Zerologs.Debug().Stack().Err(err).Msg("Error While Sending POST Request to SentToContractCronJob")
		return err
	}
	req.Header.Set("Content-type", "application/json")
	client := &http.Client{}
	resp, err := client.Do(req)
	if err != nil {
		Zerologs.Debug().Stack().Err(err).Msg("Error while Getting response from SentToContractCronJob")
		return err
	}
	defer resp.Body.Close()
	return nil
}
