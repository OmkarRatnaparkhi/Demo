document.addEventListener('DOMContentLoaded', () => {
        $('#meeting-time').val('05/07/2022')
        //     var routename = $( "#hdRouteName").val()
        //     $.get('/accord/api/'+routename,
        //     function (data, textStatus, jqXHR) {
        //         //alert(JSON.stringify(data))
        //         if(!(typeof data === 'undefined' || data === null || data === "null" )) 
        //         {
        //             const objPrase = JSON.parse(data);
        //             if( !(typeof objPrase === 'undefined' || objPrase === null) ) 
        //             {
        //                 const keysObj =  Object.keys(objPrase[0]);
        //                 var columnDefs=[]
        //                 for (let i = 0; i < keysObj.length; i++) {
        //                     var newfield = {field: keysObj[i] }
        //                     columnDefs.push(newfield)          
        //                     }

        //                     const gridOptions = {
        //                     columnDefs: columnDefs,
        //                     rowData: objPrase,
        //                     rowHeight: 35,
        //                     };

        //                 const gridDiv = document.querySelector('#myGrid');
        //                 new agGrid.Grid(gridDiv, gridOptions);
        //             }
        //         }
        // });
   
});

function OnButtonClick() {
    var date = new Date($('#meeting-time').val());
    var day = date.getDate();
    var month = date.getMonth() + 1;
    var year = date.getFullYear();
    var strdate = pad(day,2)+pad(month,2)+year.toString();
    var routename = $( "#hdRouteName").val()
    $.get('/accord/api/'+routename+'?date='+strdate,
    function (data, textStatus, jqXHR) {
        //alert(JSON.stringify(data))
        if(!(typeof data === 'undefined' || data === null || data === "null" )) 
        {
            const objPrase = JSON.parse(data);
            if( !(typeof objPrase === 'undefined' || objPrase === null) ) 
            {
                const keysObj =  Object.keys(objPrase[0]);
                var columnDefs=[]
                for (let i = 0; i < keysObj.length; i++) {
                    var newfield = {field: keysObj[i] }
                    columnDefs.push(newfield)          
                    }

                    const gridOptions = {
                    columnDefs: columnDefs,
                    rowData: objPrase,
                    rowHeight: 35,
                    };

                const gridDiv = document.querySelector('#myGrid');
                new agGrid.Grid(gridDiv, gridOptions);
            }
        }
});
}

function pad (str, max) {
    str = str.toString();
    return str.length < max ? pad("0" + str, max) : str;
  }
  